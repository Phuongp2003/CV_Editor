#!/usr/bin/env node
import { n as e } from "./rolldown-runtime-Dw4lsX4b.js";
import { t } from "./typeof-BPvFRMZW.js";
import { readFile as n, writeFile as r } from "node:fs/promises";
import { dirname as i, resolve as a } from "node:path";
import { fileURLToPath as o } from "node:url";
import { deflateRawSync as s } from "node:zlib";
// src/utils/cvAudit.ts
var c = /* @__PURE__ */ "spearheaded.leveraged.leveraging.utilized.utilizing.orchestrated.championed.synergy.robust.seamless.cutting-edge.passionate.results-driven.detail-oriented.team player.fast learner.proven track record.innovative.holistic.delve.tapestry.testament.pivotal.vibrant.learning mindset.contribute effectively.i am writing to apply.i am excited to.hands-on experience in.not just.more than just.thank you for considering.practical exposure.dynamic environment.high-traffic.world-class.game-changer.đam mê.năng động.tinh thần cầu tiến.không ngừng học hỏi.môi trường chuyên nghiệp.đóng góp hết mình".split("."), l = [
	"worked on",
	"helped",
	"assisted",
	"responsible for",
	"involved in",
	"participated in",
	"supported",
	"tham gia",
	"hỗ trợ",
	"phụ trách"
], u = new Set("a an the and or of to in on for with at by from as is are was were be been it its this that these those i my me we our you your their they he she his her not no but if so than then into about over under via per use used using have has had will can could would should may might also other such each both all any more most and và của là có cho với các một những được trong khi để này đã đang không".split(" ")), d = /* @__PURE__ */ new Set([
	"summary",
	"objective",
	"experience",
	"work experience",
	"professional experience",
	"education",
	"skills",
	"technical skills",
	"projects",
	"certificates",
	"certifications",
	"kinh nghiệm",
	"học vấn",
	"kỹ năng",
	"dự án",
	"chứng chỉ",
	"mục tiêu",
	"tóm tắt"
]), f = /* @__PURE__ */ "C#,.NET,.NET Core,.NET Framework,ASP.NET,ASP.NET Core,ASP.NET MVC,Web API,Entity Framework,EF Core,LINQ,SignalR,Blazor,WPF,WinForms,SQL Server,T-SQL,stored procedures,MySQL,MariaDB,PostgreSQL,Oracle,MongoDB,Redis,Elasticsearch,RabbitMQ,Kafka,Azure Service Bus,Service Bus,Azure,Azure DevOps,AWS,GCP,Docker,Kubernetes,CI/CD,GitHub Actions,GitLab CI,Jenkins,xUnit,NUnit,MSTest,unit test,integration test,TDD,REST,RESTful,GraphQL,gRPC,microservices,API gateway,Angular,React,Vue,Next.js,TypeScript,JavaScript,HTML,CSS,Node.js,Express,NestJS,Python,FastAPI,Django,Flask,Java,Spring Boot,PHP,Laravel,Ruby on Rails,C++,Golang,OAuth,JWT,Keycloak,Git,Agile,Scrum,Linux,Nginx,design patterns,SOLID,OOP,clean architecture,DDD,English,Japanese".split(","), p = new Set(f.map((e) => e.toLowerCase())), m = {
	"entity framework": ["ef core", "entity framework core"],
	"ef core": ["entity framework core", "entity framework"],
	".net": [
		".net core",
		".net 5",
		".net 6",
		".net 7",
		".net 8",
		".net 9",
		"asp.net"
	],
	".net core": [
		".net 5",
		".net 6",
		".net 7",
		".net 8",
		".net 9",
		"asp.net core"
	],
	"asp.net": ["asp.net core"],
	rest: [
		"restful",
		"rest api",
		"rest apis"
	],
	restful: ["rest api", "rest apis"],
	"web api": [
		"rest api",
		"rest apis",
		"asp.net core"
	],
	"ci/cd": [
		"github actions",
		"gitlab ci",
		"azure devops",
		"jenkins",
		"continuous integration"
	],
	"unit test": [
		"unit tests",
		"unit testing",
		"xunit",
		"nunit",
		"mstest"
	],
	"service bus": ["azure service bus"],
	microservices: ["microservice"],
	vue: ["vue 3", "vue.js"],
	react: ["react.js", "reactjs"],
	"node.js": ["nodejs"],
	python: [
		"fastapi",
		"django",
		"flask"
	],
	kubernetes: ["k8s"],
	english: [
		"toeic",
		"ielts",
		"toefl"
	]
}, h = (e) => e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), g = (e) => RegExp(`(?<![A-Za-z0-9])${h(e)}(?![A-Za-z0-9])`, "i");
function _(e, t) {
	return [t, ...m[t.toLowerCase()] || []].some((t) => g(t).test(e));
}
var v = /\b(?:[A-Z][a-z]+[A-Z][A-Za-z0-9]*|[A-Za-z]+[.#+][A-Za-z0-9.#+]+|[A-Z]{2,}[a-z0-9]*|[A-Za-z]+\d+[A-Za-z0-9]*)\b/g, y = /\bfrom\b.{1,40}\bto\b|→|->|\bgiảm\b.{1,30}\bxuống\b|\d+\s?%|\d+\s?(x|×)\b/i, b = /^[A-Z][A-Za-z0-9 &/+.\-]{2,40}:\s/;
function x(e) {
	let t = [];
	for (let n of f) {
		let r = g(n).exec(e);
		r && t.push([r.index, n]);
	}
	let n = t.sort((e, t) => e[0] - t[0]).map(([, e]) => e), r = /experience|knowledge|proficien|familiar|skill|understanding|hands-on|expertise|must|requir|strong|solid|plus/i, i = [];
	for (let t of e.split(/\r?\n/)) {
		if (!r.test(t)) continue;
		let e = [...t.match(v) || [], ...t.match(/\b(Dapper|Moq|Selenium|Playwright|Cypress|Knockout\.js|jQuery|OData|Razor|Aspose\.\w+)\b/g) || []];
		for (let t of e) {
			let e = t.toLowerCase();
			t.length < 3 || p.has(e) || n.some((t) => t.toLowerCase() === e) || i.includes(t) || /\.(com|net|org|vn|io)$|^e\.g|^i\.e/.test(e) || e.endsWith(".js") && p.has(e.slice(0, -3)) || e === "k8s" || e === "sql" || n.some((t) => (m[t.toLowerCase()] || []).includes(e)) || (!/^[A-Z]{2,4}$/.test(t) || [
				"ORM",
				"SQL",
				"API",
				"MVC",
				"DDD",
				"TDD",
				"SPA"
			].includes(t)) && i.push(t);
		}
	}
	return [...n, ...i].slice(0, 35);
}
function S(e, t = /* @__PURE__ */ new Date()) {
	let n = (e) => {
		let n = e.trim();
		if (/^(present|now|nay|hiện tại)/i.test(n)) return t.getFullYear() * 12 + t.getMonth();
		let r = n.match(/(\d{1,2})\/(\d{4})/);
		if (r) return Number(r[2]) * 12 + Number(r[1]) - 1;
		let i = n.match(/(\d{4})/);
		return i ? Number(i[1]) * 12 : null;
	}, r = e.experiences.map((e) => e.dates.split(/\s+[-–]\s+/)).filter((e) => e.length === 2).map(([e, t]) => [n(e), n(t)]).filter((e) => e[0] !== null && e[1] !== null).map(([e, t]) => [e, t + 1]).sort((e, t) => e[0] - t[0]), i = 0, a = null;
	for (let e of r) a && e[0] <= a[1] ? a = [a[0], Math.max(a[1], e[1])] : (a && (i += a[1] - a[0]), a = e);
	return a && (i += a[1] - a[0]), i;
}
function C(e) {
	return (e || "").replace(/<\/?u>/gi, "").replace(/\*\*\*(.*?)\*\*\*/g, "$1").replace(/\*\*(.*?)\*\*/g, "$1").replace(/\*(.*?)\*/g, "$1").trim();
}
var w = (e) => e.split(/\s+/).filter(Boolean), T = (e) => (e.toLowerCase().match(/[a-zà-ỹ][a-zà-ỹ0-9+#.\-]*/gi) || []).map((e) => e.replace(/^[.\-]+|[.\-]+$/g, "")).filter((e) => e.length > 2 && !u.has(e));
function E(e) {
	let t = [];
	for (let n = 0; n + 2 < e.length; n++) t.push(`${e[n]} ${e[n + 1]} ${e[n + 2]}`);
	return t;
}
function D(e) {
	if (e.length < 3) return null;
	let t = e.reduce((e, t) => e + t, 0) / e.length;
	if (!t) return null;
	let n = Math.sqrt(e.reduce((e, n) => e + (n - t) ** 2, 0) / e.length);
	return Math.round(n / t * 100) / 100;
}
var O = (e, t = 110) => e.length > t ? e.slice(0, t - 1) + "…" : e, k = (e, t) => ({
	English: e,
	Vietnamese: t
});
function A(e, t) {
	let n = [];
	return t.includes("experience") || e.experiences.forEach((e, t) => e.bullets.forEach((e) => {
		e.type !== "header" && C(e.text) && n.push({
			text: C(e.text),
			section: "experience",
			index: t
		});
	})), t.includes("projects") || e.projects.forEach((e, t) => e.bullets.forEach((e) => {
		e.type !== "header" && C(e.text) && n.push({
			text: C(e.text),
			section: "projects",
			index: t
		});
	})), n;
}
function j(e) {
	let t = new Set(e.match(v) || []), n = 0;
	/\d/.test(e) && n++, y.test(e) && n++, t.size >= 2 && n++, w(e).length >= 12 && n++;
	let r = e.toLowerCase();
	return (l.some((e) => r.includes(e)) || c.some((e) => r.includes(e))) && n--, Math.max(n, 0);
}
function M(e) {
	let t = e.trim();
	return t ? /\b\d{2}\/\d{4}\b/.test(t) ? "MM/YYYY" : /\b(January|February|March|April|May|June|July|August|September|October|November|December) \d{4}\b/.test(t) ? "Month YYYY" : /\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\.? \d{4}\b/.test(t) ? "Mon YYYY" : /^\d{4}$/.test(t) ? "YYYY" : "other" : null;
}
function N(e) {
	let { cv: t, disabledSections: n } = e, r = [], i = (e) => r.push(e), a = n.includes("objective") ? n.includes("summary") ? "" : C(t.summary) : C(t.objective), o = n.includes("objective") ? "summary" : "objective", s = A(t, n), u = s.map((e) => e.text), f = [...t.experiences, ...t.projects].flatMap((e) => e.bullets.filter((e) => e.type === "header").map((e) => C(e.text))), p = !n.includes("skills"), m = p ? t.skills.map((e) => `${e.skill}: ${C(e.description)}`).join("\n") : "", h = [
		a,
		m,
		...u
	].join("\n"), g = w(h).length, N = [
		"name",
		"email",
		"phone"
	].filter((e) => !t[e]?.trim());
	N.length && i({
		id: "ats-contact",
		severity: "blocker",
		category: "ats",
		title: k("Missing contact details", "Thiếu thông tin liên hệ"),
		detail: k(`Add: ${N.join(", ")}.`, `Cần bổ sung: ${N.join(", ")}.`),
		target: { section: "personal" }
	});
	let P = [...n.includes("experience") ? [] : t.experiences.map((e) => e.dates), ...n.includes("education") ? [] : t.educations.map((e) => e.graduationDate)], F = new Set(P.map(M).filter((e) => !!e && e !== "YYYY"));
	F.size > 1 && i({
		id: "ats-dates",
		severity: "minor",
		category: "ats",
		title: k("Mixed date formats", "Định dạng ngày không thống nhất"),
		detail: k(`Found ${[...F].join(", ")}. Pick one format (e.g. 07/2025 - Present) for every role and degree.`, `Đang dùng ${[...F].join(", ")}. Chọn một kiểu (vd. 07/2025 - Present) cho mọi mục.`),
		quotes: P.filter(Boolean)
	}), e.pageCount > 1 && i({
		id: "ats-pages",
		severity: "major",
		category: "ats",
		title: k(`CV runs to ${e.pageCount} pages`, `CV dài ${e.pageCount} trang`),
		detail: k("Under ~5 years of experience, recruiters expect one page. Cut the weakest bullets, not the font size.", "Dưới ~5 năm kinh nghiệm nên giữ 1 trang. Cắt bullet yếu nhất thay vì thu nhỏ chữ.")
	});
	let I = Object.entries(e.customSectionLabels).filter(([e, t]) => t?.trim() && !n.includes(e)).filter(([, e]) => !d.has(e.trim().toLowerCase()));
	I.length && i({
		id: "ats-headings",
		severity: "minor",
		category: "ats",
		title: k("Non-standard section headings", "Tiêu đề section không chuẩn"),
		detail: k("ATS maps sections by heading. Prefer Experience, Education, Skills, Projects, Certifications.", "ATS nhận diện section theo tiêu đề. Nên dùng Experience, Education, Skills, Projects, Certifications."),
		quotes: I.map(([, e]) => e)
	}), [
		"•",
		"-",
		"–",
		"*",
		"·"
	].includes(e.bulletChars.l1.trim()) || i({
		id: "ats-bullet-glyph",
		severity: "minor",
		category: "ats",
		title: k("Unusual bullet symbol", "Ký tự bullet lạ"),
		detail: k(`"${e.bulletChars.l1}" may extract as garbage in ATS. Use • or -.`, `"${e.bulletChars.l1}" có thể bị ATS đọc thành ký tự lỗi. Dùng • hoặc -.`)
	}), t.profileImage && i({
		id: "ats-photo",
		severity: "minor",
		category: "ats",
		title: k("Profile photo included", "CV có ảnh chân dung"),
		detail: k("Harvard-style and most international/ATS pipelines expect no photo. Keep it only if the employer asks.", "Chuẩn Harvard và đa số hệ thống ATS quốc tế không dùng ảnh. Chỉ giữ khi nhà tuyển dụng yêu cầu."),
		target: { section: "personal" }
	});
	let L = s.filter((e) => b.test(e.text)), ee = s.length ? L.length / s.length : 0;
	s.length >= 4 && ee >= .6 && i({
		id: "slop-labels",
		severity: "major",
		category: "slop",
		title: k(`${Math.round(ee * 100)}% of bullets start with a "Label:" prefix`, `${Math.round(ee * 100)}% bullet mở đầu bằng "Nhãn:"`),
		detail: k("Identical \"Label: verb + object + result\" shapes are the clearest generated-text pattern. Keep a label only where it helps scanning, and let the strongest result open the bullet.", "Mọi bullet cùng khuôn \"Nhãn: động từ + đối tượng + kết quả\" là dấu hiệu văn AI rõ nhất. Chỉ giữ nhãn khi thật sự giúp đọc lướt, để kết quả mạnh nhất đứng đầu."),
		quotes: L.slice(0, 4).map((e) => O(e.text, 60))
	});
	let R = u.map((e) => w(e).length), z = D(R);
	s.length >= 4 && z !== null && z < .25 && i({
		id: "slop-uniform",
		severity: "minor",
		category: "slop",
		title: k("Bullets are suspiciously uniform in length", "Độ dài bullet đều một cách bất thường"),
		detail: k(`Length variation ${z} (under 0.25 reads machine-made). Real bullets are lumpy: one short punchy line next to a detailed one.`, `Độ biến thiên độ dài ${z} (dưới 0.25 trông như máy viết). Bullet thật thường so le: một câu ngắn gọn cạnh một câu chi tiết.`)
	});
	let B = /* @__PURE__ */ new Map();
	s.forEach((e) => {
		let t = (e.text.replace(b, "").split(/\s+/)[0] || "").toLowerCase().replace(/[^a-zà-ỹ]/g, "");
		t && B.set(t, (B.get(t) || 0) + 1);
	});
	let te = [...B].filter(([, e]) => e >= 3);
	te.length && i({
		id: "slop-openers",
		severity: "minor",
		category: "slop",
		title: k("Same opening verb repeated", "Lặp động từ mở đầu"),
		detail: k("Vary openings: verb-first, outcome-first (\"Login time dropped from ~30s to ~5s after...\"), or context-first.", "Đổi cách mở câu: bắt đầu bằng động từ, bằng kết quả (\"Thời gian login giảm từ ~30s xuống ~5s sau khi...\"), hoặc bằng bối cảnh."),
		quotes: te.map(([e, t]) => `${e} ×${t}`)
	});
	let V = h.toLowerCase(), H = c.filter((e) => V.includes(e));
	H.length && i({
		id: "slop-cliche",
		severity: H.length >= 3 ? "major" : "minor",
		category: "slop",
		title: k("Generic buzzwords", "Từ sáo rỗng"),
		detail: k("Each is fine once if a concrete fact sits next to it. Otherwise replace it with what you actually did.", "Mỗi từ chỉ chấp nhận được khi đi kèm dữ kiện cụ thể. Nếu không, thay bằng việc bạn thật sự đã làm."),
		quotes: H
	});
	let U = l.filter((e) => u.some((t) => t.toLowerCase().includes(e)));
	U.length && i({
		id: "slop-weak",
		severity: "minor",
		category: "slop",
		title: k("Weak ownership verbs", "Động từ thể hiện vai trò mờ nhạt"),
		detail: k("\"Supported\", \"helped\", \"involved in\" hide what you personally did. Name your part.", "\"Supported\", \"helped\", \"tham gia\" che mất phần bạn tự làm. Nêu rõ phần của bạn."),
		quotes: U
	});
	let ne = (h.match(/—/g) || []).length;
	if (ne >= 2 && i({
		id: "slop-emdash",
		severity: "minor",
		category: "slop",
		title: k(`${ne} em-dashes`, `${ne} dấu gạch dài (—)`),
		detail: k("Em-dashes used as rhythm are a common generated-text tic. Use a period or comma.", "Gạch dài dùng để tạo nhịp là thói quen phổ biến của văn AI. Dùng dấu chấm hoặc phẩy.")
	}), a) {
		let e = w(a).length, t = new Set(a.match(v) || []).size;
		(e > 55 || t > 7) && i({
			id: "slop-intro",
			severity: "minor",
			category: "slop",
			title: k("Objective is long or a keyword list", "Objective quá dài hoặc liệt kê từ khóa"),
			detail: k(`${e} words, ${t} tech names. Two lines: role + level + 2-3 target technologies + one proof point.`, `${e} từ, ${t} tên công nghệ. Viết 2 dòng: vị trí + cấp độ + 2-3 công nghệ mục tiêu + một bằng chứng cụ thể.`),
			target: { section: o }
		});
	}
	let W = /* @__PURE__ */ new Map();
	T([a, ...u].join(" ")).forEach((e) => W.set(e, (W.get(e) || 0) + 1));
	let G = new Set(T(t.name)), re = [...W].filter(([e, t]) => t >= 5 && e.length > 4 && !G.has(e)).sort((e, t) => t[1] - e[1]).slice(0, 6);
	re.length && i({
		id: "slop-repeat",
		severity: "minor",
		category: "slop",
		title: k("Overused words", "Từ bị lặp nhiều"),
		detail: k("Repetition flattens the page. Replace with the specific system, user or result each time.", "Lặp từ làm CV nhạt. Mỗi lần hãy thay bằng tên hệ thống, người dùng hoặc kết quả cụ thể."),
		quotes: re.map(([e, t]) => `${e} ×${t}`)
	});
	let ie = [...e.cv.experiences, ...e.cv.projects].flatMap((e) => e.bullets).filter((e) => (e.text.match(/\*\*[^*]+\*\*/g) || []).length > 2);
	ie.length && i({
		id: "slop-bold",
		severity: "minor",
		category: "slop",
		title: k("Too much bold", "In đậm quá nhiều"),
		detail: k("Bold at most one key result per bullet, or the eye has nowhere to land.", "Mỗi bullet chỉ in đậm tối đa một kết quả chính."),
		quotes: ie.slice(0, 3).map((e) => O(C(e.text), 60))
	});
	let ae = (h.match(v) || []).length + (h.match(/\d+/g) || []).length, K = g ? Math.round(1e3 * ae / g) / 10 : 0;
	g > 80 && K < 10 && i({
		id: "slop-density",
		severity: K < 6 ? "major" : "minor",
		category: "slop",
		title: k(`Low specificity: ${K} named things per 100 words`, `Ít chi tiết: ${K} tên riêng/số trên 100 từ`),
		detail: k("Confident tone with few systems, tools or numbers is the signature of generated text. Name the system, version, scale.", "Giọng tự tin nhưng ít tên hệ thống, công cụ, con số là đặc trưng của văn AI. Nêu tên hệ thống, phiên bản, quy mô.")
	});
	let oe = s.filter((e) => !/\d/.test(e.text) && !y.test(e.text));
	if (s.length >= 4 && oe.length / s.length > .6 && i({
		id: "ev-numbers",
		severity: "minor",
		category: "evidence",
		title: k(`${oe.length}/${s.length} bullets have no number or before/after`, `${oe.length}/${s.length} bullet không có số liệu hay trước/sau`),
		detail: k("Only use real numbers. Without one, describe the concrete change (manual to automated, N screens to 1).", "Chỉ dùng số thật. Không có số thì mô tả thay đổi cụ thể (thủ công thành tự động, N màn hình còn 1).")
	}), s.map((e) => ({
		...e,
		score: j(e.text)
	})).filter((e) => e.score <= 1).sort((e, t) => e.score - t.score).slice(0, 4).forEach((e, t) => i({
		id: `ev-weak-${t}`,
		severity: "minor",
		category: "evidence",
		title: k(`Low-information bullet (${e.score}/4)`, `Bullet ít thông tin (${e.score}/4)`),
		detail: k("Could this line sit unchanged in a stranger's CV? Add what was broken, which tool, what changed.", "Câu này có thể nằm nguyên trong CV người khác không? Thêm vấn đề gì, công cụ nào, thay đổi ra sao."),
		quotes: [O(e.text)],
		target: {
			section: e.section,
			index: e.index
		}
	})), s.filter((e) => w(e.text).length > 45).slice(0, 3).forEach((e, t) => i({
		id: `ev-long-${t}`,
		severity: "minor",
		category: "evidence",
		title: k(`Bullet has ${w(e.text).length} words`, `Bullet dài ${w(e.text).length} từ`),
		detail: k("Split it or cut the tool list. Two lines on the page is the ceiling.", "Tách đôi hoặc bớt danh sách công cụ. Tối đa 2 dòng trên trang."),
		quotes: [O(e.text)],
		target: {
			section: e.section,
			index: e.index
		}
	})), n.includes("experience") || t.experiences.forEach((e, n) => {
		let r = e.bullets.filter((e) => e.type !== "header" && C(e.text)).length, a = t.experiences[n - 1], o = !!a && !!e.company.trim() && a.company.trim().toLowerCase() === e.company.trim().toLowerCase();
		(e.company || e.position) && (r === 0 || r > 6 || r < 2 && !o) && i({
			id: `ev-count-${n}`,
			severity: r === 0 ? "major" : "minor",
			category: "evidence",
			title: k(`${e.company || e.position}: ${r} bullets`, `${e.company || e.position}: ${r} bullet`),
			detail: k("Aim for 3-5 bullets per role, strongest first (1-2 is fine for an earlier role at the same company).", "Nên có 3-5 bullet mỗi vị trí, mạnh nhất lên đầu (vị trí trước đó ở cùng công ty có 1-2 bullet là được)."),
			target: {
				section: "experience",
				index: n
			}
		});
	}), p) {
		let e = [...u, ...f].join(" ").toLowerCase(), n = t.skills.flatMap((e) => C(e.description).split(/[,;|]/)).map((e) => e.replace(/\(.*?\)/g, "").trim()).filter((e) => e.length > 1 && e.length < 30), r = [...new Set(n)].filter((t) => !_(e, t) && !t.split("/").some((t) => t.trim().length > 1 && _(e, t.trim())));
		r.length && i({
			id: "ev-claimed",
			severity: r.length > 8 ? "major" : "minor",
			category: "evidence",
			title: k(`${r.length} skills are claimed but never shown`, `${r.length} kỹ năng chỉ liệt kê, không có bằng chứng`),
			detail: k("A skill that appears only in Skills is \"claimed\", not \"proven\". Show the important ones in a bullet or drop the ones you cannot discuss for 5 minutes.", "Kỹ năng chỉ có trong mục Skills là \"tự nhận\", chưa \"chứng minh\". Đưa kỹ năng quan trọng vào bullet, bỏ kỹ năng không nói được 5 phút."),
			quotes: r.slice(0, 14),
			target: { section: "skills" }
		});
	}
	let se = 0, ce = 0, le = (e.jobDescription || "").trim();
	if (le) {
		let e = [...t.certificates.map((e) => `${e.certName} ${e["issuer/description"]}`), ...t.educations.map((e) => `${e.degree} ${e.university}`)].join(" "), n = [
			a,
			...u,
			...f,
			e
		].join(" "), r = [], o = [], s = [];
		for (let e of x(le)) _(n, e) ? r.push(e) : _(m, e) ? o.push(e) : s.push(e);
		se = r.length + o.length + s.length, ce = r.length, s.length && i({
			id: "jd-missing",
			severity: s.length > 6 ? "major" : "minor",
			category: "jd",
			title: k(`${s.length} JD terms absent from the CV`, `${s.length} thuật ngữ của JD không có trong CV`),
			detail: k("Use the JD wording where it is true. If you never did it, leave it out and address it once in the cover letter.", "Dùng đúng thuật ngữ của JD nếu đúng sự thật. Nếu chưa từng làm thì bỏ qua và nói một lần trong cover letter."),
			quotes: s
		}), o.length && i({
			id: "jd-claimed",
			severity: "minor",
			category: "jd",
			title: k(`${o.length} JD terms only in Skills`, `${o.length} thuật ngữ JD chỉ có ở Skills`),
			detail: k("Prove them in a bullet: action + outcome.", "Chứng minh bằng một bullet: hành động + kết quả."),
			quotes: o,
			target: { section: "skills" }
		});
		let c = [...le.matchAll(/(\d{1,2})\s*\+?\s*(?:years?|yrs?|năm)/gi)].map((e) => Number(e[1])).filter((e) => e > 0 && e < 20);
		if (c.length) {
			let e = Math.min(...c), n = S(t) / 12;
			n + .25 < e && i({
				id: "jd-years",
				severity: "minor",
				category: "jd",
				title: k(`JD asks ${e}+ years; CV dates show about ${n.toFixed(1)}`, `JD yêu cầu ${e}+ năm; ngày tháng trong CV cho thấy khoảng ${n.toFixed(1)}`),
				detail: k("State the real span; do not stretch dates. Lead with the strongest relevant evidence instead.", "Ghi đúng thời gian thật, không kéo dài ngày tháng. Thay vào đó, đưa bằng chứng mạnh nhất lên đầu.")
			});
		}
	}
	let ue = e.coverLetter, de = ue ? [
		ue.openingParagraph,
		...ue.bodyParagraphs,
		ue.closingParagraph
	].map(C).join(" ").trim() : "";
	if (de) {
		let e = w(de).length;
		(e < 150 || e > 300) && i({
			id: "cl-length",
			severity: "minor",
			category: "letter",
			title: k(`Cover letter is ${e} words`, `Cover letter dài ${e} từ`),
			detail: k("150-250 words is enough to add what the CV cannot.", "150-250 từ là đủ để bổ sung điều CV không nói được.")
		});
		let t = new Set(E(T(h))), n = de.split(/(?<=[.!?])\s+/).filter((e) => w(e).length >= 4), r = n.filter((e) => {
			let n = E(T(e));
			return n.length && n.filter((e) => t.has(e)).length / n.length >= .25;
		});
		n.length && r.length / n.length > 1 / 3 && i({
			id: "cl-repeat",
			severity: "major",
			category: "letter",
			title: k(`${r.length}/${n.length} letter sentences restate the CV`, `${r.length}/${n.length} câu trong thư lặp lại CV`),
			detail: k("Replace them with why this company, why this role, and one short story.", "Thay bằng lý do chọn công ty, vị trí này và một câu chuyện ngắn."),
			quotes: r.slice(0, 3).map((e) => O(e))
		});
	}
	let fe = {
		blocker: 25,
		major: 10,
		minor: 3
	}, pe = Math.max(0, 100 - r.reduce((e, t) => e + fe[t.severity], 0)), me = {
		blocker: 0,
		major: 1,
		minor: 2
	};
	return r.sort((e, t) => me[e.severity] - me[t.severity]), {
		score: pe,
		findings: r,
		stats: {
			bullets: s.length,
			avgWords: R.length ? Math.round(R.reduce((e, t) => e + t, 0) / R.length * 10) / 10 : 0,
			lengthVariation: z,
			labelRatio: Math.round(ee * 100) / 100,
			noNumber: oe.length,
			density: K,
			words: g,
			jdTerms: se,
			jdProven: ce
		}
	};
}
// node_modules/fflate/esm/browser.js
var P = Uint8Array, F = Uint16Array, I = Int32Array, L = new P([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]), ee = new P([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]), R = new P([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), z = function(e, t) {
	for (var n = new F(31), r = 0; r < 31; ++r) n[r] = t += 1 << e[r - 1];
	for (var i = new I(n[30]), r = 1; r < 30; ++r) for (var a = n[r]; a < n[r + 1]; ++a) i[a] = a - n[r] << 5 | r;
	return {
		b: n,
		r: i
	};
}, B = z(L, 2), te = B.b, V = B.r;
te[28] = 258, V[258] = 28;
var H = z(ee, 0);
H.b;
for (var U = H.r, ne = new F(32768), W = 0; W < 32768; ++W) {
	var G = (W & 43690) >> 1 | (W & 21845) << 1;
	G = (G & 52428) >> 2 | (G & 13107) << 2, G = (G & 61680) >> 4 | (G & 3855) << 4, ne[W] = ((G & 65280) >> 8 | (G & 255) << 8) >> 1;
}
for (var re = (function(e, t, n) {
	for (var r = e.length, i = 0, a = new F(t); i < r; ++i) e[i] && ++a[e[i] - 1];
	var o = new F(t);
	for (i = 1; i < t; ++i) o[i] = o[i - 1] + a[i - 1] << 1;
	var s;
	if (n) {
		s = new F(1 << t);
		var c = 15 - t;
		for (i = 0; i < r; ++i) if (e[i]) for (var l = i << 4 | e[i], u = t - e[i], d = o[e[i] - 1]++ << u, f = d | (1 << u) - 1; d <= f; ++d) s[ne[d] >> c] = l;
	} else for (s = new F(r), i = 0; i < r; ++i) e[i] && (s[i] = ne[o[e[i] - 1]++] >> 15 - e[i]);
	return s;
}), ie = new P(288), W = 0; W < 144; ++W) ie[W] = 8;
for (var W = 144; W < 256; ++W) ie[W] = 9;
for (var W = 256; W < 280; ++W) ie[W] = 7;
for (var W = 280; W < 288; ++W) ie[W] = 8;
for (var ae = new P(32), W = 0; W < 32; ++W) ae[W] = 5;
var K = /*#__PURE__*/ re(ie, 9, 0), oe = /*#__PURE__*/ re(ae, 5, 0), se = function(e) {
	return (e + 7) / 8 | 0;
}, ce = function(e, t, n) {
	return (t == null || t < 0) && (t = 0), (n == null || n > e.length) && (n = e.length), new P(e.subarray(t, n));
}, le = function(e, t, n) {
	n <<= t & 7;
	var r = t / 8 | 0;
	e[r] |= n, e[r + 1] |= n >> 8;
}, ue = function(e, t, n) {
	n <<= t & 7;
	var r = t / 8 | 0;
	e[r] |= n, e[r + 1] |= n >> 8, e[r + 2] |= n >> 16;
}, de = function(e, t) {
	for (var n = [], r = 0; r < e.length; ++r) e[r] && n.push({
		s: r,
		f: e[r]
	});
	var i = n.length, a = n.slice();
	if (!i) return {
		t: ve,
		l: 0
	};
	if (i == 1) {
		var o = new P(n[0].s + 1);
		return o[n[0].s] = 1, {
			t: o,
			l: 1
		};
	}
	n.sort(function(e, t) {
		return e.f - t.f;
	}), n.push({
		s: -1,
		f: 25001
	});
	var s = n[0], c = n[1], l = 0, u = 1, d = 2;
	for (n[0] = {
		s: -1,
		f: s.f + c.f,
		l: s,
		r: c
	}; u != i - 1;) s = n[n[l].f < n[d].f ? l++ : d++], c = n[l != u && n[l].f < n[d].f ? l++ : d++], n[u++] = {
		s: -1,
		f: s.f + c.f,
		l: s,
		r: c
	};
	for (var f = a[0].s, r = 1; r < i; ++r) a[r].s > f && (f = a[r].s);
	var p = new F(f + 1), m = fe(n[u - 1], p, 0);
	if (m > t) {
		var r = 0, h = 0, g = m - t, _ = 1 << g;
		for (a.sort(function(e, t) {
			return p[t.s] - p[e.s] || e.f - t.f;
		}); r < i; ++r) {
			var v = a[r].s;
			if (p[v] > t) h += _ - (1 << m - p[v]), p[v] = t;
			else break;
		}
		for (h >>= g; h > 0;) {
			var y = a[r].s;
			p[y] < t ? h -= 1 << t - p[y]++ - 1 : ++r;
		}
		for (; r >= 0 && h; --r) {
			var b = a[r].s;
			p[b] == t && (--p[b], ++h);
		}
		m = t;
	}
	return {
		t: new P(p),
		l: m
	};
}, fe = function(e, t, n) {
	return e.s == -1 ? Math.max(fe(e.l, t, n + 1), fe(e.r, t, n + 1)) : t[e.s] = n;
}, pe = function(e) {
	for (var t = e.length; t && !e[--t];);
	for (var n = new F(++t), r = 0, i = e[0], a = 1, o = function(e) {
		n[r++] = e;
	}, s = 1; s <= t; ++s) if (e[s] == i && s != t) ++a;
	else {
		if (!i && a > 2) {
			for (; a > 138; a -= 138) o(32754);
			a > 2 && (o(a > 10 ? a - 11 << 5 | 28690 : a - 3 << 5 | 12305), a = 0);
		} else if (a > 3) {
			for (o(i), --a; a > 6; a -= 6) o(8304);
			a > 2 && (o(a - 3 << 5 | 8208), a = 0);
		}
		for (; a--;) o(i);
		a = 1, i = e[s];
	}
	return {
		c: n.subarray(0, r),
		n: t
	};
}, me = function(e, t) {
	for (var n = 0, r = 0; r < t.length; ++r) n += e[r] * t[r];
	return n;
}, he = function(e, t, n) {
	var r = n.length, i = se(t + 2);
	e[i] = r & 255, e[i + 1] = r >> 8, e[i + 2] = e[i] ^ 255, e[i + 3] = e[i + 1] ^ 255;
	for (var a = 0; a < r; ++a) e[i + a + 4] = n[a];
	return (i + 4 + r) * 8;
}, ge = function(e, t, n, r, i, a, o, s, c, l, u) {
	le(t, u++, n), ++i[256];
	for (var d = de(i, 15), f = d.t, p = d.l, m = de(a, 15), h = m.t, g = m.l, _ = pe(f), v = _.c, y = _.n, b = pe(h), x = b.c, S = b.n, C = new F(19), w = 0; w < v.length; ++w) ++C[v[w] & 31];
	for (var w = 0; w < x.length; ++w) ++C[x[w] & 31];
	for (var T = de(C, 7), E = T.t, D = T.l, O = 19; O > 4 && !E[R[O - 1]]; --O);
	var k = l + 5 << 3, A = me(i, ie) + me(a, ae) + o, j = me(i, f) + me(a, h) + o + 14 + 3 * O + me(C, E) + 2 * C[16] + 3 * C[17] + 7 * C[18];
	if (c >= 0 && k <= A && k <= j) return he(t, u, e.subarray(c, c + l));
	var M, N, P, I;
	if (le(t, u, 1 + (j < A)), u += 2, j < A) {
		M = re(f, p, 0), N = f, P = re(h, g, 0), I = h;
		var z = re(E, D, 0);
		le(t, u, y - 257), le(t, u + 5, S - 1), le(t, u + 10, O - 4), u += 14;
		for (var w = 0; w < O; ++w) le(t, u + 3 * w, E[R[w]]);
		u += 3 * O;
		for (var B = [v, x], te = 0; te < 2; ++te) for (var V = B[te], w = 0; w < V.length; ++w) {
			var H = V[w] & 31;
			le(t, u, z[H]), u += E[H], H > 15 && (le(t, u, V[w] >> 5 & 127), u += V[w] >> 12);
		}
	} else M = K, N = ie, P = oe, I = ae;
	for (var w = 0; w < s; ++w) {
		var U = r[w];
		if (U > 255) {
			var H = U >> 18 & 31;
			ue(t, u, M[H + 257]), u += N[H + 257], H > 7 && (le(t, u, U >> 23 & 31), u += L[H]);
			var ne = U & 31;
			ue(t, u, P[ne]), u += I[ne], ne > 3 && (ue(t, u, U >> 5 & 8191), u += ee[ne]);
		} else ue(t, u, M[U]), u += N[U];
	}
	return ue(t, u, M[256]), u + N[256];
}, _e = /*#__PURE__*/ new I([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]), ve = /*#__PURE__*/ new P(0), ye = function(e, t, n, r, i, a) {
	var o = a.z || e.length, s = new P(r + o + 5 * (1 + Math.ceil(o / 7e3)) + i), c = s.subarray(r, s.length - i), l = a.l, u = (a.r || 0) & 7;
	if (t) {
		u && (c[0] = a.r >> 3);
		for (var d = _e[t - 1], f = d >> 13, p = d & 8191, m = (1 << n) - 1, h = a.p || new F(32768), g = a.h || new F(m + 1), _ = Math.ceil(n / 3), v = 2 * _, y = function(t) {
			return (e[t] ^ e[t + 1] << _ ^ e[t + 2] << v) & m;
		}, b = new I(25e3), x = new F(288), S = new F(32), C = 0, w = 0, T = a.i || 0, E = 0, D = a.w || 0, O = 0; T + 2 < o; ++T) {
			var k = y(T), A = T & 32767, j = g[k];
			if (h[A] = j, g[k] = A, D <= T) {
				var M = o - T;
				if ((C > 7e3 || E > 24576) && (M > 423 || !l)) {
					u = ge(e, c, 0, b, x, S, w, E, O, T - O, u), E = C = w = 0, O = T;
					for (var N = 0; N < 286; ++N) x[N] = 0;
					for (var N = 0; N < 30; ++N) S[N] = 0;
				}
				var R = 2, z = 0, B = p, te = A - j & 32767;
				if (M > 2 && k == y(T - te)) for (var H = Math.min(f, M) - 1, ne = Math.min(32767, T), W = Math.min(258, M); te <= ne && --B && A != j;) {
					if (e[T + R] == e[T + R - te]) {
						for (var G = 0; G < W && e[T + G] == e[T + G - te]; ++G);
						if (G > R) {
							if (R = G, z = te, G > H) break;
							for (var re = Math.min(te, G - 2), ie = 0, N = 0; N < re; ++N) {
								var ae = T - te + N & 32767, K = ae - h[ae] & 32767;
								K > ie && (ie = K, j = ae);
							}
						}
					}
					A = j, j = h[A], te += A - j & 32767;
				}
				if (z) {
					b[E++] = 268435456 | V[R] << 18 | U[z];
					var oe = V[R] & 31, le = U[z] & 31;
					w += L[oe] + ee[le], ++x[257 + oe], ++S[le], D = T + R, ++C;
				} else b[E++] = e[T], ++x[e[T]];
			}
		}
		for (T = Math.max(T, D); T < o; ++T) b[E++] = e[T], ++x[e[T]];
		u = ge(e, c, l, b, x, S, w, E, O, T - O, u), l || (a.r = u & 7 | c[u / 8 | 0] << 3, u -= 7, a.h = g, a.p = h, a.i = T, a.w = D);
	} else {
		for (var T = a.w || 0; T < o + l; T += 65535) {
			var ue = T + 65535;
			ue >= o && (c[u / 8 | 0] = l, ue = o), u = he(c, u + 1, e.subarray(T, ue));
		}
		a.i = o;
	}
	return ce(s, 0, r + se(u) + i);
}, be = function() {
	var e = 1, t = 0;
	return {
		p: function(n) {
			for (var r = e, i = t, a = n.length | 0, o = 0; o != a;) {
				for (var s = Math.min(o + 2655, a); o < s; ++o) i += r += n[o];
				r = (r & 65535) + 15 * (r >> 16), i = (i & 65535) + 15 * (i >> 16);
			}
			e = r, t = i;
		},
		d: function() {
			return e %= 65521, t %= 65521, (e & 255) << 24 | (e & 65280) << 8 | (t & 255) << 8 | t >> 8;
		}
	};
}, xe = function(e, t, n, r, i) {
	if (!i && (i = { l: 1 }, t.dictionary)) {
		var a = t.dictionary.subarray(-32768), o = new P(a.length + e.length);
		o.set(a), o.set(e, a.length), e = o, i.w = a.length;
	}
	return ye(e, t.level == null ? 6 : t.level, t.mem == null ? i.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(e.length))) * 1.5) : 20 : 12 + t.mem, n, r, i);
}, Se = function(e, t, n) {
	for (; n; ++t) e[t] = n, n >>>= 8;
}, Ce = function(e, t) {
	var n = t.level, r = n == 0 ? 0 : n < 6 ? 1 : n == 9 ? 3 : 2;
	if (e[0] = 120, e[1] = r << 6 | (t.dictionary && 32), e[1] |= 31 - (e[0] << 8 | e[1]) % 31, t.dictionary) {
		var i = be();
		i.p(t.dictionary), Se(e, 2, i.d());
	}
};
function we(e, t) {
	t ||= {};
	var n = be();
	n.p(e);
	var r = xe(e, t, t.dictionary ? 6 : 2, 4);
	return Ce(r, t), Se(r, r.length - 4, n.d()), r;
}
var Te = typeof TextDecoder < "u" && /*#__PURE__*/ new TextDecoder();
try {
	Te.decode(ve, { stream: !0 });
} catch {}
// node_modules/@babel/runtime/helpers/esm/arrayWithHoles.js
function Ee(e) {
	if (Array.isArray(e)) return e;
}
// node_modules/@babel/runtime/helpers/esm/iterableToArrayLimit.js
function De(e, t) {
	var n = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
	if (n != null) {
		var r, i, a, o, s = [], c = !0, l = !1;
		try {
			if (a = (n = n.call(e)).next, t === 0) {
				if (Object(n) !== n) return;
				c = !1;
			} else for (; !(c = (r = a.call(n)).done) && (s.push(r.value), s.length !== t); c = !0);
		} catch (e) {
			l = !0, i = e;
		} finally {
			try {
				if (!c && n.return != null && (o = n.return(), Object(o) !== o)) return;
			} finally {
				if (l) throw i;
			}
		}
		return s;
	}
}
// node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js
function Oe(e, t) {
	(t == null || t > e.length) && (t = e.length);
	for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
	return r;
}
// node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js
function ke(e, t) {
	if (e) {
		if (typeof e == "string") return Oe(e, t);
		var n = {}.toString.call(e).slice(8, -1);
		return n === "Object" && e.constructor && (n = e.constructor.name), n === "Map" || n === "Set" ? Array.from(e) : n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? Oe(e, t) : void 0;
	}
}
// node_modules/@babel/runtime/helpers/esm/nonIterableRest.js
function Ae() {
	throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
// node_modules/@babel/runtime/helpers/esm/slicedToArray.js
function je(e, t) {
	return Ee(e) || De(e, t) || ke(e, t) || Ae();
}
// node_modules/iobuffer/lib-esm/text.js
function Me(e, t = "utf8") {
	return new TextDecoder(t).decode(e);
}
var q = new TextEncoder();
function Ne(e) {
	return q.encode(e);
}
// node_modules/iobuffer/lib-esm/IOBuffer.js
var Pe = 8192, Fe = (() => {
	let e = /* @__PURE__ */ new Uint8Array(4), t = new Uint32Array(e.buffer);
	return !((t[0] = 1) & e[0]);
})(), Ie = {
	int8: globalThis.Int8Array,
	uint8: globalThis.Uint8Array,
	int16: globalThis.Int16Array,
	uint16: globalThis.Uint16Array,
	int32: globalThis.Int32Array,
	uint32: globalThis.Uint32Array,
	uint64: globalThis.BigUint64Array,
	int64: globalThis.BigInt64Array,
	float32: globalThis.Float32Array,
	float64: globalThis.Float64Array
}, Le = class e {
	buffer;
	byteLength;
	byteOffset;
	length;
	offset;
	lastWrittenByte;
	littleEndian;
	_data;
	_mark;
	_marks;
	constructor(t = Pe, n = {}) {
		let r = !1;
		typeof t == "number" ? t = new ArrayBuffer(t) : (r = !0, this.lastWrittenByte = t.byteLength);
		let i = n.offset ? n.offset >>> 0 : 0, a = t.byteLength - i, o = i;
		(ArrayBuffer.isView(t) || t instanceof e) && (t.byteLength !== t.buffer.byteLength && (o = t.byteOffset + i), t = t.buffer), this.lastWrittenByte = r ? a : 0, this.buffer = t, this.length = a, this.byteLength = a, this.byteOffset = o, this.offset = 0, this.littleEndian = !0, this._data = new DataView(this.buffer, o, a), this._mark = 0, this._marks = [];
	}
	available(e = 1) {
		return this.offset + e <= this.length;
	}
	isLittleEndian() {
		return this.littleEndian;
	}
	setLittleEndian() {
		return this.littleEndian = !0, this;
	}
	isBigEndian() {
		return !this.littleEndian;
	}
	setBigEndian() {
		return this.littleEndian = !1, this;
	}
	skip(e = 1) {
		return this.offset += e, this;
	}
	back(e = 1) {
		return this.offset -= e, this;
	}
	seek(e) {
		return this.offset = e, this;
	}
	mark() {
		return this._mark = this.offset, this;
	}
	reset() {
		return this.offset = this._mark, this;
	}
	pushMark() {
		return this._marks.push(this.offset), this;
	}
	popMark() {
		let e = this._marks.pop();
		if (e === void 0) throw Error("Mark stack empty");
		return this.seek(e), this;
	}
	rewind() {
		return this.offset = 0, this;
	}
	ensureAvailable(e = 1) {
		if (!this.available(e)) {
			let t = (this.offset + e) * 2, n = new Uint8Array(t);
			n.set(new Uint8Array(this.buffer)), this.buffer = n.buffer, this.length = t, this.byteLength = t, this._data = new DataView(this.buffer);
		}
		return this;
	}
	readBoolean() {
		return this.readUint8() !== 0;
	}
	readInt8() {
		return this._data.getInt8(this.offset++);
	}
	readUint8() {
		return this._data.getUint8(this.offset++);
	}
	readByte() {
		return this.readUint8();
	}
	readBytes(e = 1) {
		return this.readArray(e, "uint8");
	}
	readArray(e, t) {
		let n = Ie[t].BYTES_PER_ELEMENT * e, r = this.byteOffset + this.offset, i = this.buffer.slice(r, r + n);
		if (this.littleEndian === Fe && t !== "uint8" && t !== "int8") {
			let e = new Uint8Array(this.buffer.slice(r, r + n));
			e.reverse();
			let i = new Ie[t](e.buffer);
			return this.offset += n, i.reverse(), i;
		}
		let a = new Ie[t](i);
		return this.offset += n, a;
	}
	readInt16() {
		let e = this._data.getInt16(this.offset, this.littleEndian);
		return this.offset += 2, e;
	}
	readUint16() {
		let e = this._data.getUint16(this.offset, this.littleEndian);
		return this.offset += 2, e;
	}
	readInt32() {
		let e = this._data.getInt32(this.offset, this.littleEndian);
		return this.offset += 4, e;
	}
	readUint32() {
		let e = this._data.getUint32(this.offset, this.littleEndian);
		return this.offset += 4, e;
	}
	readFloat32() {
		let e = this._data.getFloat32(this.offset, this.littleEndian);
		return this.offset += 4, e;
	}
	readFloat64() {
		let e = this._data.getFloat64(this.offset, this.littleEndian);
		return this.offset += 8, e;
	}
	readBigInt64() {
		let e = this._data.getBigInt64(this.offset, this.littleEndian);
		return this.offset += 8, e;
	}
	readBigUint64() {
		let e = this._data.getBigUint64(this.offset, this.littleEndian);
		return this.offset += 8, e;
	}
	readChar() {
		return String.fromCharCode(this.readInt8());
	}
	readChars(e = 1) {
		let t = "";
		for (let n = 0; n < e; n++) t += this.readChar();
		return t;
	}
	readUtf8(e = 1) {
		return Me(this.readBytes(e));
	}
	decodeText(e = 1, t = "utf8") {
		return Me(this.readBytes(e), t);
	}
	writeBoolean(e) {
		return this.writeUint8(e ? 255 : 0), this;
	}
	writeInt8(e) {
		return this.ensureAvailable(1), this._data.setInt8(this.offset++, e), this._updateLastWrittenByte(), this;
	}
	writeUint8(e) {
		return this.ensureAvailable(1), this._data.setUint8(this.offset++, e), this._updateLastWrittenByte(), this;
	}
	writeByte(e) {
		return this.writeUint8(e);
	}
	writeBytes(e) {
		this.ensureAvailable(e.length);
		for (let t = 0; t < e.length; t++) this._data.setUint8(this.offset++, e[t]);
		return this._updateLastWrittenByte(), this;
	}
	writeInt16(e) {
		return this.ensureAvailable(2), this._data.setInt16(this.offset, e, this.littleEndian), this.offset += 2, this._updateLastWrittenByte(), this;
	}
	writeUint16(e) {
		return this.ensureAvailable(2), this._data.setUint16(this.offset, e, this.littleEndian), this.offset += 2, this._updateLastWrittenByte(), this;
	}
	writeInt32(e) {
		return this.ensureAvailable(4), this._data.setInt32(this.offset, e, this.littleEndian), this.offset += 4, this._updateLastWrittenByte(), this;
	}
	writeUint32(e) {
		return this.ensureAvailable(4), this._data.setUint32(this.offset, e, this.littleEndian), this.offset += 4, this._updateLastWrittenByte(), this;
	}
	writeFloat32(e) {
		return this.ensureAvailable(4), this._data.setFloat32(this.offset, e, this.littleEndian), this.offset += 4, this._updateLastWrittenByte(), this;
	}
	writeFloat64(e) {
		return this.ensureAvailable(8), this._data.setFloat64(this.offset, e, this.littleEndian), this.offset += 8, this._updateLastWrittenByte(), this;
	}
	writeBigInt64(e) {
		return this.ensureAvailable(8), this._data.setBigInt64(this.offset, e, this.littleEndian), this.offset += 8, this._updateLastWrittenByte(), this;
	}
	writeBigUint64(e) {
		return this.ensureAvailable(8), this._data.setBigUint64(this.offset, e, this.littleEndian), this.offset += 8, this._updateLastWrittenByte(), this;
	}
	writeChar(e) {
		return this.writeUint8(e.charCodeAt(0));
	}
	writeChars(e) {
		for (let t = 0; t < e.length; t++) this.writeUint8(e.charCodeAt(t));
		return this;
	}
	writeUtf8(e) {
		return this.writeBytes(Ne(e));
	}
	toArray() {
		return new Uint8Array(this.buffer, this.byteOffset, this.lastWrittenByte);
	}
	getWrittenByteLength() {
		return this.lastWrittenByte - this.byteOffset;
	}
	_updateLastWrittenByte() {
		this.offset > this.lastWrittenByte && (this.lastWrittenByte = this.offset);
	}
}, J = 4, Re = 0, ze = 1, Be = 2;
function Ve(e) {
	let t = e.length;
	for (; --t >= 0;) e[t] = 0;
}
var He = 29, Ue = 256, We = 286, Ge = 30, Ke = 19, qe = 573, Je = 15, Ye = 16, Xe = 7, Ze = 256, Qe = 16, $e = 17, et = 18, tt = new Uint8Array([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0
]), nt = new Uint8Array([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13
]), rt = new Uint8Array([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2,
	3,
	7
]), it = new Uint8Array([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]), at = 512, ot = Array(576);
Ve(ot);
var st = Array(60);
Ve(st);
var ct = Array(at);
Ve(ct);
var lt = Array(256);
Ve(lt);
var ut = Array(He);
Ve(ut);
var dt = Array(Ge);
Ve(dt);
function ft(e, t, n, r, i) {
	this.static_tree = e, this.extra_bits = t, this.extra_base = n, this.elems = r, this.max_length = i, this.has_stree = e && e.length;
}
var pt, mt, ht;
function gt(e, t) {
	this.dyn_tree = e, this.max_code = 0, this.stat_desc = t;
}
var _t = (e) => e < 256 ? ct[e] : ct[256 + (e >>> 7)], vt = (e, t) => {
	e.pending_buf[e.pending++] = t & 255, e.pending_buf[e.pending++] = t >>> 8 & 255;
}, yt = (e, t, n) => {
	e.bi_valid > Ye - n ? (e.bi_buf |= t << e.bi_valid & 65535, vt(e, e.bi_buf), e.bi_buf = t >> Ye - e.bi_valid, e.bi_valid += n - Ye) : (e.bi_buf |= t << e.bi_valid & 65535, e.bi_valid += n);
}, bt = (e, t, n) => {
	yt(e, n[t * 2], n[t * 2 + 1]);
}, xt = (e, t) => {
	let n = 0;
	do
		n |= e & 1, e >>>= 1, n <<= 1;
	while (--t > 0);
	return n >>> 1;
}, St = (e) => {
	e.bi_valid === 16 ? (vt(e, e.bi_buf), e.bi_buf = 0, e.bi_valid = 0) : e.bi_valid >= 8 && (e.pending_buf[e.pending++] = e.bi_buf & 255, e.bi_buf >>= 8, e.bi_valid -= 8);
}, Ct = (e, t) => {
	let n = t.dyn_tree, r = t.max_code, i = t.stat_desc.static_tree, a = t.stat_desc.has_stree, o = t.stat_desc.extra_bits, s = t.stat_desc.extra_base, c = t.stat_desc.max_length, l, u, d, f, p, m, h = 0;
	for (f = 0; f <= Je; f++) e.bl_count[f] = 0;
	for (n[e.heap[e.heap_max] * 2 + 1] = 0, l = e.heap_max + 1; l < qe; l++) u = e.heap[l], f = n[n[u * 2 + 1] * 2 + 1] + 1, f > c && (f = c, h++), n[u * 2 + 1] = f, u > r || (e.bl_count[f]++, p = 0, u >= s && (p = o[u - s]), m = n[u * 2], e.opt_len += m * (f + p), a && (e.static_len += m * (i[u * 2 + 1] + p)));
	if (h !== 0) {
		do {
			for (f = c - 1; e.bl_count[f] === 0;) f--;
			e.bl_count[f]--, e.bl_count[f + 1] += 2, e.bl_count[c]--, h -= 2;
		} while (h > 0);
		for (f = c; f !== 0; f--) for (u = e.bl_count[f]; u !== 0;) d = e.heap[--l], d > r || (n[d * 2 + 1] !== f && (e.opt_len += (f - n[d * 2 + 1]) * n[d * 2], n[d * 2 + 1] = f), u--);
	}
}, wt = (e, t, n) => {
	let r = Array(16), i = 0, a, o;
	for (a = 1; a <= Je; a++) i = i + n[a - 1] << 1, r[a] = i;
	for (o = 0; o <= t; o++) {
		let t = e[o * 2 + 1];
		t !== 0 && (e[o * 2] = xt(r[t]++, t));
	}
}, Y = () => {
	let e, t, n, r, i, a = Array(16);
	for (n = 0, r = 0; r < 28; r++) for (ut[r] = n, e = 0; e < 1 << tt[r]; e++) lt[n++] = r;
	for (lt[n - 1] = r, i = 0, r = 0; r < 16; r++) for (dt[r] = i, e = 0; e < 1 << nt[r]; e++) ct[i++] = r;
	for (i >>= 7; r < Ge; r++) for (dt[r] = i << 7, e = 0; e < 1 << nt[r] - 7; e++) ct[256 + i++] = r;
	for (t = 0; t <= Je; t++) a[t] = 0;
	for (e = 0; e <= 143;) ot[e * 2 + 1] = 8, e++, a[8]++;
	for (; e <= 255;) ot[e * 2 + 1] = 9, e++, a[9]++;
	for (; e <= 279;) ot[e * 2 + 1] = 7, e++, a[7]++;
	for (; e <= 287;) ot[e * 2 + 1] = 8, e++, a[8]++;
	for (wt(ot, 287, a), e = 0; e < Ge; e++) st[e * 2 + 1] = 5, st[e * 2] = xt(e, 5);
	pt = new ft(ot, tt, 257, We, Je), mt = new ft(st, nt, 0, Ge, Je), ht = new ft([], rt, 0, Ke, Xe);
}, Tt = (e) => {
	let t = 0;
	for (; t < We; t++) e.dyn_ltree[t * 2] = 0;
	for (t = 0; t < Ge; t++) e.dyn_dtree[t * 2] = 0;
	for (t = 0; t < Ke; t++) e.bl_tree[t * 2] = 0;
	e.dyn_ltree[Ze * 2] = 1, e.opt_len = e.static_len = 0, e.sym_next = e.matches = 0;
}, Et = (e) => {
	e.bi_valid > 8 ? vt(e, e.bi_buf) : e.bi_valid > 0 && (e.pending_buf[e.pending++] = e.bi_buf), e.bi_buf = 0, e.bi_valid = 0;
}, Dt = (e, t, n, r) => {
	let i = t * 2, a = n * 2;
	return e[i] < e[a] || e[i] === e[a] && r[t] <= r[n];
}, Ot = (e, t, n) => {
	let r = e.heap[n], i = n << 1;
	for (; i <= e.heap_len && (i < e.heap_len && Dt(t, e.heap[i + 1], e.heap[i], e.depth) && i++, !Dt(t, r, e.heap[i], e.depth));) e.heap[n] = e.heap[i], n = i, i <<= 1;
	e.heap[n] = r;
}, kt = (e, t, n) => {
	let r, i, a = 0, o, s;
	if (e.sym_next !== 0) do
		r = e.pending_buf[e.sym_buf + a++] & 255, r += (e.pending_buf[e.sym_buf + a++] & 255) << 8, i = e.pending_buf[e.sym_buf + a++], r === 0 ? bt(e, i, t) : (o = lt[i], bt(e, o + Ue + 1, t), s = tt[o], s !== 0 && (i -= ut[o], yt(e, i, s)), r--, o = _t(r), bt(e, o, n), s = nt[o], s !== 0 && (r -= dt[o], yt(e, r, s)));
	while (a < e.sym_next);
	bt(e, Ze, t);
}, At = (e, t) => {
	let n = t.dyn_tree, r = t.stat_desc.static_tree, i = t.stat_desc.has_stree, a = t.stat_desc.elems, o, s, c = -1, l;
	for (e.heap_len = 0, e.heap_max = qe, o = 0; o < a; o++) n[o * 2] === 0 ? n[o * 2 + 1] = 0 : (e.heap[++e.heap_len] = c = o, e.depth[o] = 0);
	for (; e.heap_len < 2;) l = e.heap[++e.heap_len] = c < 2 ? ++c : 0, n[l * 2] = 1, e.depth[l] = 0, e.opt_len--, i && (e.static_len -= r[l * 2 + 1]);
	for (t.max_code = c, o = e.heap_len >> 1; o >= 1; o--) Ot(e, n, o);
	l = a;
	do
		o = e.heap[1], e.heap[1] = e.heap[e.heap_len--], Ot(e, n, 1), s = e.heap[1], e.heap[--e.heap_max] = o, e.heap[--e.heap_max] = s, n[l * 2] = n[o * 2] + n[s * 2], e.depth[l] = (e.depth[o] >= e.depth[s] ? e.depth[o] : e.depth[s]) + 1, n[o * 2 + 1] = n[s * 2 + 1] = l, e.heap[1] = l++, Ot(e, n, 1);
	while (e.heap_len >= 2);
	e.heap[--e.heap_max] = e.heap[1], Ct(e, t), wt(n, c, e.bl_count);
}, jt = (e, t, n) => {
	let r, i = -1, a, o = t[1], s = 0, c = 7, l = 4;
	for (o === 0 && (c = 138, l = 3), t[(n + 1) * 2 + 1] = 65535, r = 0; r <= n; r++) a = o, o = t[(r + 1) * 2 + 1], ++s < c && a === o || (s < l ? e.bl_tree[a * 2] += s : a === 0 ? s <= 10 ? e.bl_tree[34]++ : e.bl_tree[36]++ : (a !== i && e.bl_tree[a * 2]++, e.bl_tree[32]++), s = 0, i = a, o === 0 ? (c = 138, l = 3) : a === o ? (c = 6, l = 3) : (c = 7, l = 4));
}, Mt = (e, t, n) => {
	let r, i = -1, a, o = t[1], s = 0, c = 7, l = 4;
	for (o === 0 && (c = 138, l = 3), r = 0; r <= n; r++) if (a = o, o = t[(r + 1) * 2 + 1], !(++s < c && a === o)) {
		if (s < l) do
			bt(e, a, e.bl_tree);
		while (--s !== 0);
		else a === 0 ? s <= 10 ? (bt(e, $e, e.bl_tree), yt(e, s - 3, 3)) : (bt(e, et, e.bl_tree), yt(e, s - 11, 7)) : (a !== i && (bt(e, a, e.bl_tree), s--), bt(e, Qe, e.bl_tree), yt(e, s - 3, 2));
		s = 0, i = a, o === 0 ? (c = 138, l = 3) : a === o ? (c = 6, l = 3) : (c = 7, l = 4);
	}
}, Nt = (e) => {
	let t;
	for (jt(e, e.dyn_ltree, e.l_desc.max_code), jt(e, e.dyn_dtree, e.d_desc.max_code), At(e, e.bl_desc), t = 18; t >= 3 && e.bl_tree[it[t] * 2 + 1] === 0; t--);
	return e.opt_len += 3 * (t + 1) + 5 + 5 + 4, t;
}, Pt = (e, t, n, r) => {
	let i;
	for (yt(e, t - 257, 5), yt(e, n - 1, 5), yt(e, r - 4, 4), i = 0; i < r; i++) yt(e, e.bl_tree[it[i] * 2 + 1], 3);
	Mt(e, e.dyn_ltree, t - 1), Mt(e, e.dyn_dtree, n - 1);
}, Ft = (e) => {
	let t = 4093624447, n = 0;
	for (; n <= 31; n++, t >>>= 1) if (t & 1 && e.dyn_ltree[n * 2] !== 0) return Re;
	if (e.dyn_ltree[18] !== 0 || e.dyn_ltree[20] !== 0 || e.dyn_ltree[26] !== 0) return ze;
	for (n = 32; n < Ue; n++) if (e.dyn_ltree[n * 2] !== 0) return ze;
	return Re;
}, It = !1, Lt = (e) => {
	It ||= (Y(), !0), e.l_desc = new gt(e.dyn_ltree, pt), e.d_desc = new gt(e.dyn_dtree, mt), e.bl_desc = new gt(e.bl_tree, ht), e.bi_buf = 0, e.bi_valid = 0, Tt(e);
}, Rt = (e, t, n, r) => {
	yt(e, 0 + +!!r, 3), Et(e), vt(e, n), vt(e, ~n), n && e.pending_buf.set(e.window.subarray(t, t + n), e.pending), e.pending += n;
}, zt = {
	_tr_init: Lt,
	_tr_stored_block: Rt,
	_tr_flush_block: (e, t, n, r) => {
		let i, a, o = 0;
		e.level > 0 ? (e.strm.data_type === Be && (e.strm.data_type = Ft(e)), At(e, e.l_desc), At(e, e.d_desc), o = Nt(e), i = e.opt_len + 3 + 7 >>> 3, a = e.static_len + 3 + 7 >>> 3, a <= i && (i = a)) : i = a = n + 5, n + 4 <= i && t !== -1 ? Rt(e, t, n, r) : e.strategy === J || a === i ? (yt(e, 2 + +!!r, 3), kt(e, ot, st)) : (yt(e, 4 + +!!r, 3), Pt(e, e.l_desc.max_code + 1, e.d_desc.max_code + 1, o + 1), kt(e, e.dyn_ltree, e.dyn_dtree)), Tt(e), r && Et(e);
	},
	_tr_tally: (e, t, n) => (e.pending_buf[e.sym_buf + e.sym_next++] = t, e.pending_buf[e.sym_buf + e.sym_next++] = t >> 8, e.pending_buf[e.sym_buf + e.sym_next++] = n, t === 0 ? e.dyn_ltree[n * 2]++ : (e.matches++, t--, e.dyn_ltree[(lt[n] + Ue + 1) * 2]++, e.dyn_dtree[_t(t) * 2]++), e.sym_next === e.sym_end),
	_tr_align: (e) => {
		yt(e, 2, 3), bt(e, Ze, ot), St(e);
	}
}, Bt = (e, t, n, r) => {
	let i = e & 65535, a = e >>> 16 & 65535, o = 0;
	for (; n !== 0;) {
		o = n > 2e3 ? 2e3 : n, n -= o;
		do
			i = i + t[r++] | 0, a = a + i | 0;
		while (--o);
		i %= 65521, a %= 65521;
	}
	return i | a << 16;
}, Vt = new Uint32Array((() => {
	let e, t = [];
	for (var n = 0; n < 256; n++) {
		e = n;
		for (var r = 0; r < 8; r++) e = e & 1 ? 3988292384 ^ e >>> 1 : e >>> 1;
		t[n] = e;
	}
	return t;
})()), Ht = (e, t, n, r) => {
	let i = Vt, a = r + n;
	e ^= -1;
	for (let n = r; n < a; n++) e = e >>> 8 ^ i[(e ^ t[n]) & 255];
	return e ^ -1;
}, Ut = {
	2: "need dictionary",
	1: "stream end",
	0: "",
	"-1": "file error",
	"-2": "stream error",
	"-3": "data error",
	"-4": "insufficient memory",
	"-5": "buffer error",
	"-6": "incompatible version"
}, Wt = {
	Z_NO_FLUSH: 0,
	Z_PARTIAL_FLUSH: 1,
	Z_SYNC_FLUSH: 2,
	Z_FULL_FLUSH: 3,
	Z_FINISH: 4,
	Z_BLOCK: 5,
	Z_TREES: 6,
	Z_OK: 0,
	Z_STREAM_END: 1,
	Z_NEED_DICT: 2,
	Z_ERRNO: -1,
	Z_STREAM_ERROR: -2,
	Z_DATA_ERROR: -3,
	Z_MEM_ERROR: -4,
	Z_BUF_ERROR: -5,
	Z_NO_COMPRESSION: 0,
	Z_BEST_SPEED: 1,
	Z_BEST_COMPRESSION: 9,
	Z_DEFAULT_COMPRESSION: -1,
	Z_FILTERED: 1,
	Z_HUFFMAN_ONLY: 2,
	Z_RLE: 3,
	Z_FIXED: 4,
	Z_DEFAULT_STRATEGY: 0,
	Z_BINARY: 0,
	Z_TEXT: 1,
	Z_UNKNOWN: 2,
	Z_DEFLATED: 8
}, { _tr_init: Gt, _tr_stored_block: Kt, _tr_flush_block: qt, _tr_tally: Jt, _tr_align: Yt } = zt, { Z_NO_FLUSH: Xt, Z_PARTIAL_FLUSH: Zt, Z_FULL_FLUSH: Qt, Z_FINISH: $t, Z_BLOCK: en, Z_OK: tn, Z_STREAM_END: nn, Z_STREAM_ERROR: rn, Z_DATA_ERROR: an, Z_BUF_ERROR: on, Z_DEFAULT_COMPRESSION: sn, Z_FILTERED: cn, Z_HUFFMAN_ONLY: ln, Z_RLE: un, Z_FIXED: dn, Z_DEFAULT_STRATEGY: fn, Z_UNKNOWN: pn, Z_DEFLATED: mn } = Wt, hn = 9, gn = 15, _n = 8, vn = 573, yn = 3, bn = 258, xn = 262, Sn = 32, Cn = 42, wn = 57, Tn = 69, En = 73, Dn = 91, On = 103, kn = 113, An = 666, jn = 1, Mn = 2, Nn = 3, Pn = 4, Fn = 3, In = (e, t) => (e.msg = Ut[t], t), Ln = (e) => e * 2 - (e > 4 ? 9 : 0), Rn = (e) => {
	let t = e.length;
	for (; --t >= 0;) e[t] = 0;
}, zn = (e) => {
	let t, n, r, i = e.w_size;
	t = e.hash_size, r = t;
	do
		n = e.head[--r], e.head[r] = n >= i ? n - i : 0;
	while (--t);
	t = i, r = t;
	do
		n = e.prev[--r], e.prev[r] = n >= i ? n - i : 0;
	while (--t);
}, Bn = (e, t, n) => (t << e.hash_shift ^ n) & e.hash_mask, Vn = (e) => {
	let t = e.state, n = t.pending;
	n > e.avail_out && (n = e.avail_out), n !== 0 && (e.output.set(t.pending_buf.subarray(t.pending_out, t.pending_out + n), e.next_out), e.next_out += n, t.pending_out += n, e.total_out += n, e.avail_out -= n, t.pending -= n, t.pending === 0 && (t.pending_out = 0));
}, Hn = (e, t) => {
	qt(e, e.block_start >= 0 ? e.block_start : -1, e.strstart - e.block_start, t), e.block_start = e.strstart, Vn(e.strm);
}, Un = (e, t) => {
	e.pending_buf[e.pending++] = t;
}, Wn = (e, t) => {
	e.pending_buf[e.pending++] = t >>> 8 & 255, e.pending_buf[e.pending++] = t & 255;
}, Gn = (e, t, n, r) => {
	let i = e.avail_in;
	return i > r && (i = r), i === 0 ? 0 : (e.avail_in -= i, t.set(e.input.subarray(e.next_in, e.next_in + i), n), e.state.wrap === 1 ? e.adler = Bt(e.adler, t, i, n) : e.state.wrap === 2 && (e.adler = Ht(e.adler, t, i, n)), e.next_in += i, e.total_in += i, i);
}, Kn = (e, t) => {
	let n = e.max_chain_length, r = e.strstart, i, a, o = e.prev_length, s = e.nice_match, c = e.strstart > e.w_size - xn ? e.strstart - (e.w_size - xn) : 0, l = e.window, u = e.w_mask, d = e.prev, f = e.strstart + bn, p = l[r + o - 1], m = l[r + o];
	e.prev_length >= e.good_match && (n >>= 2), s > e.lookahead && (s = e.lookahead);
	do
		if (i = t, l[i + o] === m && l[i + o - 1] === p && l[i] === l[r] && l[++i] === l[r + 1]) {
			r += 2, i++;
			do;
			while (l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && l[++r] === l[++i] && r < f);
			if (a = bn - (f - r), r = f - bn, a > o) {
				if (e.match_start = t, o = a, a >= s) break;
				p = l[r + o - 1], m = l[r + o];
			}
		}
	while ((t = d[t & u]) > c && --n !== 0);
	return o <= e.lookahead ? o : e.lookahead;
}, qn = (e) => {
	let t = e.w_size, n, r, i;
	do {
		if (r = e.window_size - e.lookahead - e.strstart, e.strstart >= t + (t - xn) && (e.window.set(e.window.subarray(t, t + t - r), 0), e.match_start -= t, e.strstart -= t, e.block_start -= t, e.insert > e.strstart && (e.insert = e.strstart), zn(e), r += t), e.strm.avail_in === 0) break;
		if (n = Gn(e.strm, e.window, e.strstart + e.lookahead, r), e.lookahead += n, e.lookahead + e.insert >= yn) for (i = e.strstart - e.insert, e.ins_h = e.window[i], e.ins_h = Bn(e, e.ins_h, e.window[i + 1]); e.insert && (e.ins_h = Bn(e, e.ins_h, e.window[i + yn - 1]), e.prev[i & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = i, i++, e.insert--, !(e.lookahead + e.insert < yn)););
	} while (e.lookahead < xn && e.strm.avail_in !== 0);
}, Jn = (e, t) => {
	let n = e.pending_buf_size - 5 > e.w_size ? e.w_size : e.pending_buf_size - 5, r, i, a, o = 0, s = e.strm.avail_in;
	do {
		if (r = 65535, a = e.bi_valid + 42 >> 3, e.strm.avail_out < a || (a = e.strm.avail_out - a, i = e.strstart - e.block_start, r > i + e.strm.avail_in && (r = i + e.strm.avail_in), r > a && (r = a), r < n && (r === 0 && t !== $t || t === Xt || r !== i + e.strm.avail_in))) break;
		o = +(t === $t && r === i + e.strm.avail_in), Kt(e, 0, 0, o), e.pending_buf[e.pending - 4] = r, e.pending_buf[e.pending - 3] = r >> 8, e.pending_buf[e.pending - 2] = ~r, e.pending_buf[e.pending - 1] = ~r >> 8, Vn(e.strm), i && (i > r && (i = r), e.strm.output.set(e.window.subarray(e.block_start, e.block_start + i), e.strm.next_out), e.strm.next_out += i, e.strm.avail_out -= i, e.strm.total_out += i, e.block_start += i, r -= i), r && (Gn(e.strm, e.strm.output, e.strm.next_out, r), e.strm.next_out += r, e.strm.avail_out -= r, e.strm.total_out += r);
	} while (o === 0);
	return s -= e.strm.avail_in, s && (s >= e.w_size ? (e.matches = 2, e.window.set(e.strm.input.subarray(e.strm.next_in - e.w_size, e.strm.next_in), 0), e.strstart = e.w_size, e.insert = e.strstart) : (e.window_size - e.strstart <= s && (e.strstart -= e.w_size, e.window.set(e.window.subarray(e.w_size, e.w_size + e.strstart), 0), e.matches < 2 && e.matches++, e.insert > e.strstart && (e.insert = e.strstart)), e.window.set(e.strm.input.subarray(e.strm.next_in - s, e.strm.next_in), e.strstart), e.strstart += s, e.insert += s > e.w_size - e.insert ? e.w_size - e.insert : s), e.block_start = e.strstart), e.high_water < e.strstart && (e.high_water = e.strstart), o ? Pn : t !== Xt && t !== $t && e.strm.avail_in === 0 && e.strstart === e.block_start ? Mn : (a = e.window_size - e.strstart, e.strm.avail_in > a && e.block_start >= e.w_size && (e.block_start -= e.w_size, e.strstart -= e.w_size, e.window.set(e.window.subarray(e.w_size, e.w_size + e.strstart), 0), e.matches < 2 && e.matches++, a += e.w_size, e.insert > e.strstart && (e.insert = e.strstart)), a > e.strm.avail_in && (a = e.strm.avail_in), a && (Gn(e.strm, e.window, e.strstart, a), e.strstart += a, e.insert += a > e.w_size - e.insert ? e.w_size - e.insert : a), e.high_water < e.strstart && (e.high_water = e.strstart), a = e.bi_valid + 42 >> 3, a = e.pending_buf_size - a > 65535 ? 65535 : e.pending_buf_size - a, n = a > e.w_size ? e.w_size : a, i = e.strstart - e.block_start, (i >= n || (i || t === $t) && t !== Xt && e.strm.avail_in === 0 && i <= a) && (r = i > a ? a : i, o = +(t === $t && e.strm.avail_in === 0 && r === i), Kt(e, e.block_start, r, o), e.block_start += r, Vn(e.strm)), o ? Nn : jn);
}, Yn = (e, t) => {
	let n, r;
	for (;;) {
		if (e.lookahead < xn) {
			if (qn(e), e.lookahead < xn && t === Xt) return jn;
			if (e.lookahead === 0) break;
		}
		if (n = 0, e.lookahead >= yn && (e.ins_h = Bn(e, e.ins_h, e.window[e.strstart + yn - 1]), n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), n !== 0 && e.strstart - n <= e.w_size - xn && (e.match_length = Kn(e, n)), e.match_length >= yn) {
			if (r = Jt(e, e.strstart - e.match_start, e.match_length - yn), e.lookahead -= e.match_length, e.match_length <= e.max_lazy_match && e.lookahead >= yn) {
				e.match_length--;
				do
					e.strstart++, e.ins_h = Bn(e, e.ins_h, e.window[e.strstart + yn - 1]), n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart;
				while (--e.match_length !== 0);
				e.strstart++;
			} else e.strstart += e.match_length, e.match_length = 0, e.ins_h = e.window[e.strstart], e.ins_h = Bn(e, e.ins_h, e.window[e.strstart + 1]);
		} else r = Jt(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++;
		if (r && (Hn(e, !1), e.strm.avail_out === 0)) return jn;
	}
	return e.insert = e.strstart < 2 ? e.strstart : 2, t === $t ? (Hn(e, !0), e.strm.avail_out === 0 ? Nn : Pn) : e.sym_next && (Hn(e, !1), e.strm.avail_out === 0) ? jn : Mn;
}, Xn = (e, t) => {
	let n, r, i;
	for (;;) {
		if (e.lookahead < xn) {
			if (qn(e), e.lookahead < xn && t === Xt) return jn;
			if (e.lookahead === 0) break;
		}
		if (n = 0, e.lookahead >= yn && (e.ins_h = Bn(e, e.ins_h, e.window[e.strstart + yn - 1]), n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), e.prev_length = e.match_length, e.prev_match = e.match_start, e.match_length = 2, n !== 0 && e.prev_length < e.max_lazy_match && e.strstart - n <= e.w_size - xn && (e.match_length = Kn(e, n), e.match_length <= 5 && (e.strategy === cn || e.match_length === yn && e.strstart - e.match_start > 4096) && (e.match_length = 2)), e.prev_length >= yn && e.match_length <= e.prev_length) {
			i = e.strstart + e.lookahead - yn, r = Jt(e, e.strstart - 1 - e.prev_match, e.prev_length - yn), e.lookahead -= e.prev_length - 1, e.prev_length -= 2;
			do
				++e.strstart <= i && (e.ins_h = Bn(e, e.ins_h, e.window[e.strstart + yn - 1]), n = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart);
			while (--e.prev_length !== 0);
			if (e.match_available = 0, e.match_length = 2, e.strstart++, r && (Hn(e, !1), e.strm.avail_out === 0)) return jn;
		} else if (e.match_available) {
			if (r = Jt(e, 0, e.window[e.strstart - 1]), r && Hn(e, !1), e.strstart++, e.lookahead--, e.strm.avail_out === 0) return jn;
		} else e.match_available = 1, e.strstart++, e.lookahead--;
	}
	return e.match_available &&= (r = Jt(e, 0, e.window[e.strstart - 1]), 0), e.insert = e.strstart < 2 ? e.strstart : 2, t === $t ? (Hn(e, !0), e.strm.avail_out === 0 ? Nn : Pn) : e.sym_next && (Hn(e, !1), e.strm.avail_out === 0) ? jn : Mn;
}, Zn = (e, t) => {
	let n, r, i, a, o = e.window;
	for (;;) {
		if (e.lookahead <= bn) {
			if (qn(e), e.lookahead <= bn && t === Xt) return jn;
			if (e.lookahead === 0) break;
		}
		if (e.match_length = 0, e.lookahead >= yn && e.strstart > 0 && (i = e.strstart - 1, r = o[i], r === o[++i] && r === o[++i] && r === o[++i])) {
			a = e.strstart + bn;
			do;
			while (r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && r === o[++i] && i < a);
			e.match_length = bn - (a - i), e.match_length > e.lookahead && (e.match_length = e.lookahead);
		}
		if (e.match_length >= yn ? (n = Jt(e, 1, e.match_length - yn), e.lookahead -= e.match_length, e.strstart += e.match_length, e.match_length = 0) : (n = Jt(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++), n && (Hn(e, !1), e.strm.avail_out === 0)) return jn;
	}
	return e.insert = 0, t === $t ? (Hn(e, !0), e.strm.avail_out === 0 ? Nn : Pn) : e.sym_next && (Hn(e, !1), e.strm.avail_out === 0) ? jn : Mn;
}, Qn = (e, t) => {
	let n;
	for (;;) {
		if (e.lookahead === 0 && (qn(e), e.lookahead === 0)) {
			if (t === Xt) return jn;
			break;
		}
		if (e.match_length = 0, n = Jt(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++, n && (Hn(e, !1), e.strm.avail_out === 0)) return jn;
	}
	return e.insert = 0, t === $t ? (Hn(e, !0), e.strm.avail_out === 0 ? Nn : Pn) : e.sym_next && (Hn(e, !1), e.strm.avail_out === 0) ? jn : Mn;
};
function $n(e, t, n, r, i) {
	this.good_length = e, this.max_lazy = t, this.nice_length = n, this.max_chain = r, this.func = i;
}
var er = [
	new $n(0, 0, 0, 0, Jn),
	new $n(4, 4, 8, 4, Yn),
	new $n(4, 5, 16, 8, Yn),
	new $n(4, 6, 32, 32, Yn),
	new $n(4, 4, 16, 16, Xn),
	new $n(8, 16, 32, 32, Xn),
	new $n(8, 16, 128, 128, Xn),
	new $n(8, 32, 128, 256, Xn),
	new $n(32, 128, 258, 1024, Xn),
	new $n(32, 258, 258, 4096, Xn)
], tr = (e) => {
	e.window_size = 2 * e.w_size, Rn(e.head), e.max_lazy_match = er[e.level].max_lazy, e.good_match = er[e.level].good_length, e.nice_match = er[e.level].nice_length, e.max_chain_length = er[e.level].max_chain, e.strstart = 0, e.block_start = 0, e.lookahead = 0, e.insert = 0, e.match_length = e.prev_length = 2, e.match_available = 0, e.ins_h = 0;
};
function nr() {
	this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = mn, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new Uint16Array(vn * 2), this.dyn_dtree = /* @__PURE__ */ new Uint16Array(122), this.bl_tree = /* @__PURE__ */ new Uint16Array(78), Rn(this.dyn_ltree), Rn(this.dyn_dtree), Rn(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = /* @__PURE__ */ new Uint16Array(16), this.heap = /* @__PURE__ */ new Uint16Array(573), Rn(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = /* @__PURE__ */ new Uint16Array(573), Rn(this.depth), this.sym_buf = 0, this.lit_bufsize = 0, this.sym_next = 0, this.sym_end = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0;
}
var rr = (e) => {
	if (!e) return 1;
	let t = e.state;
	return +(!t || t.strm !== e || t.status !== Cn && t.status !== wn && t.status !== Tn && t.status !== En && t.status !== Dn && t.status !== On && t.status !== kn && t.status !== An);
}, ir = (e) => {
	if (rr(e)) return In(e, rn);
	e.total_in = e.total_out = 0, e.data_type = pn;
	let t = e.state;
	return t.pending = 0, t.pending_out = 0, t.wrap < 0 && (t.wrap = -t.wrap), t.status = t.wrap === 2 ? wn : t.wrap ? Cn : kn, e.adler = t.wrap === 2 ? 0 : 1, t.last_flush = -2, Gt(t), tn;
}, ar = (e) => {
	let t = ir(e);
	return t === tn && tr(e.state), t;
}, or = (e, t) => rr(e) || e.state.wrap !== 2 ? rn : (e.state.gzhead = t, tn), sr = (e, t, n, r, i, a) => {
	if (!e) return rn;
	let o = 1;
	if (t === sn && (t = 6), r < 0 ? (o = 0, r = -r) : r > 15 && (o = 2, r -= 16), i < 1 || i > hn || n !== mn || r < 8 || r > 15 || t < 0 || t > 9 || a < 0 || a > dn || r === 8 && o !== 1) return In(e, rn);
	r === 8 && (r = 9);
	let s = new nr();
	return e.state = s, s.strm = e, s.status = Cn, s.wrap = o, s.gzhead = null, s.w_bits = r, s.w_size = 1 << s.w_bits, s.w_mask = s.w_size - 1, s.hash_bits = i + 7, s.hash_size = 1 << s.hash_bits, s.hash_mask = s.hash_size - 1, s.hash_shift = ~~((s.hash_bits + yn - 1) / yn), s.window = new Uint8Array(s.w_size * 2), s.head = new Uint16Array(s.hash_size), s.prev = new Uint16Array(s.w_size), s.lit_bufsize = 1 << i + 6, s.pending_buf_size = s.lit_bufsize * 4, s.pending_buf = new Uint8Array(s.pending_buf_size), s.sym_buf = s.lit_bufsize, s.sym_end = (s.lit_bufsize - 1) * 3, s.level = t, s.strategy = a, s.method = n, ar(e);
}, cr = {
	deflateInit: (e, t) => sr(e, t, mn, gn, _n, fn),
	deflateInit2: sr,
	deflateReset: ar,
	deflateResetKeep: ir,
	deflateSetHeader: or,
	deflate: (e, t) => {
		if (rr(e) || t > en || t < 0) return e ? In(e, rn) : rn;
		let n = e.state;
		if (!e.output || e.avail_in !== 0 && !e.input || n.status === An && t !== $t) return In(e, e.avail_out === 0 ? on : rn);
		let r = n.last_flush;
		if (n.last_flush = t, n.pending !== 0) {
			if (Vn(e), e.avail_out === 0) return n.last_flush = -1, tn;
		} else if (e.avail_in === 0 && Ln(t) <= Ln(r) && t !== $t) return In(e, on);
		if (n.status === An && e.avail_in !== 0) return In(e, on);
		if (n.status === Cn && n.wrap === 0 && (n.status = kn), n.status === Cn) {
			let t = mn + (n.w_bits - 8 << 4) << 8, r = -1;
			if (r = n.strategy >= ln || n.level < 2 ? 0 : n.level < 6 ? 1 : n.level === 6 ? 2 : 3, t |= r << 6, n.strstart !== 0 && (t |= Sn), t += 31 - t % 31, Wn(n, t), n.strstart !== 0 && (Wn(n, e.adler >>> 16), Wn(n, e.adler & 65535)), e.adler = 1, n.status = kn, Vn(e), n.pending !== 0) return n.last_flush = -1, tn;
		}
		if (n.status === wn) {
			if (e.adler = 0, Un(n, 31), Un(n, 139), Un(n, 8), n.gzhead) Un(n, +!!n.gzhead.text + (n.gzhead.hcrc ? 2 : 0) + (n.gzhead.extra ? 4 : 0) + (n.gzhead.name ? 8 : 0) + (n.gzhead.comment ? 16 : 0)), Un(n, n.gzhead.time & 255), Un(n, n.gzhead.time >> 8 & 255), Un(n, n.gzhead.time >> 16 & 255), Un(n, n.gzhead.time >> 24 & 255), Un(n, n.level === 9 ? 2 : n.strategy >= ln || n.level < 2 ? 4 : 0), Un(n, n.gzhead.os & 255), n.gzhead.extra && n.gzhead.extra.length && (Un(n, n.gzhead.extra.length & 255), Un(n, n.gzhead.extra.length >> 8 & 255)), n.gzhead.hcrc && (e.adler = Ht(e.adler, n.pending_buf, n.pending, 0)), n.gzindex = 0, n.status = Tn;
			else if (Un(n, 0), Un(n, 0), Un(n, 0), Un(n, 0), Un(n, 0), Un(n, n.level === 9 ? 2 : n.strategy >= ln || n.level < 2 ? 4 : 0), Un(n, Fn), n.status = kn, Vn(e), n.pending !== 0) return n.last_flush = -1, tn;
		}
		if (n.status === Tn) {
			if (n.gzhead.extra) {
				let t = n.pending, r = (n.gzhead.extra.length & 65535) - n.gzindex;
				for (; n.pending + r > n.pending_buf_size;) {
					let i = n.pending_buf_size - n.pending;
					if (n.pending_buf.set(n.gzhead.extra.subarray(n.gzindex, n.gzindex + i), n.pending), n.pending = n.pending_buf_size, n.gzhead.hcrc && n.pending > t && (e.adler = Ht(e.adler, n.pending_buf, n.pending - t, t)), n.gzindex += i, Vn(e), n.pending !== 0) return n.last_flush = -1, tn;
					t = 0, r -= i;
				}
				let i = new Uint8Array(n.gzhead.extra);
				n.pending_buf.set(i.subarray(n.gzindex, n.gzindex + r), n.pending), n.pending += r, n.gzhead.hcrc && n.pending > t && (e.adler = Ht(e.adler, n.pending_buf, n.pending - t, t)), n.gzindex = 0;
			}
			n.status = En;
		}
		if (n.status === En) {
			if (n.gzhead.name) {
				let t = n.pending, r;
				do {
					if (n.pending === n.pending_buf_size) {
						if (n.gzhead.hcrc && n.pending > t && (e.adler = Ht(e.adler, n.pending_buf, n.pending - t, t)), Vn(e), n.pending !== 0) return n.last_flush = -1, tn;
						t = 0;
					}
					r = n.gzindex < n.gzhead.name.length ? n.gzhead.name.charCodeAt(n.gzindex++) & 255 : 0, Un(n, r);
				} while (r !== 0);
				n.gzhead.hcrc && n.pending > t && (e.adler = Ht(e.adler, n.pending_buf, n.pending - t, t)), n.gzindex = 0;
			}
			n.status = Dn;
		}
		if (n.status === Dn) {
			if (n.gzhead.comment) {
				let t = n.pending, r;
				do {
					if (n.pending === n.pending_buf_size) {
						if (n.gzhead.hcrc && n.pending > t && (e.adler = Ht(e.adler, n.pending_buf, n.pending - t, t)), Vn(e), n.pending !== 0) return n.last_flush = -1, tn;
						t = 0;
					}
					r = n.gzindex < n.gzhead.comment.length ? n.gzhead.comment.charCodeAt(n.gzindex++) & 255 : 0, Un(n, r);
				} while (r !== 0);
				n.gzhead.hcrc && n.pending > t && (e.adler = Ht(e.adler, n.pending_buf, n.pending - t, t));
			}
			n.status = On;
		}
		if (n.status === On) {
			if (n.gzhead.hcrc) {
				if (n.pending + 2 > n.pending_buf_size && (Vn(e), n.pending !== 0)) return n.last_flush = -1, tn;
				Un(n, e.adler & 255), Un(n, e.adler >> 8 & 255), e.adler = 0;
			}
			if (n.status = kn, Vn(e), n.pending !== 0) return n.last_flush = -1, tn;
		}
		if (e.avail_in !== 0 || n.lookahead !== 0 || t !== Xt && n.status !== An) {
			let r = n.level === 0 ? Jn(n, t) : n.strategy === ln ? Qn(n, t) : n.strategy === un ? Zn(n, t) : er[n.level].func(n, t);
			if ((r === Nn || r === Pn) && (n.status = An), r === jn || r === Nn) return e.avail_out === 0 && (n.last_flush = -1), tn;
			if (r === Mn && (t === Zt ? Yt(n) : t !== en && (Kt(n, 0, 0, !1), t === Qt && (Rn(n.head), n.lookahead === 0 && (n.strstart = 0, n.block_start = 0, n.insert = 0))), Vn(e), e.avail_out === 0)) return n.last_flush = -1, tn;
		}
		return t === $t ? n.wrap <= 0 ? nn : (n.wrap === 2 ? (Un(n, e.adler & 255), Un(n, e.adler >> 8 & 255), Un(n, e.adler >> 16 & 255), Un(n, e.adler >> 24 & 255), Un(n, e.total_in & 255), Un(n, e.total_in >> 8 & 255), Un(n, e.total_in >> 16 & 255), Un(n, e.total_in >> 24 & 255)) : (Wn(n, e.adler >>> 16), Wn(n, e.adler & 65535)), Vn(e), n.wrap > 0 && (n.wrap = -n.wrap), n.pending === 0 ? nn : tn) : tn;
	},
	deflateEnd: (e) => {
		if (rr(e)) return rn;
		let t = e.state.status;
		return e.state = null, t === kn ? In(e, an) : tn;
	},
	deflateSetDictionary: (e, t) => {
		let n = t.length;
		if (rr(e)) return rn;
		let r = e.state, i = r.wrap;
		if (i === 2 || i === 1 && r.status !== Cn || r.lookahead) return rn;
		if (i === 1 && (e.adler = Bt(e.adler, t, n, 0)), r.wrap = 0, n >= r.w_size) {
			i === 0 && (Rn(r.head), r.strstart = 0, r.block_start = 0, r.insert = 0);
			let e = new Uint8Array(r.w_size);
			e.set(t.subarray(n - r.w_size, n), 0), t = e, n = r.w_size;
		}
		let a = e.avail_in, o = e.next_in, s = e.input;
		for (e.avail_in = n, e.next_in = 0, e.input = t, qn(r); r.lookahead >= yn;) {
			let e = r.strstart, t = r.lookahead - 2;
			do
				r.ins_h = Bn(r, r.ins_h, r.window[e + yn - 1]), r.prev[e & r.w_mask] = r.head[r.ins_h], r.head[r.ins_h] = e, e++;
			while (--t);
			r.strstart = e, r.lookahead = 2, qn(r);
		}
		return r.strstart += r.lookahead, r.block_start = r.strstart, r.insert = r.lookahead, r.lookahead = 0, r.match_length = r.prev_length = 2, r.match_available = 0, e.next_in = o, e.input = s, e.avail_in = a, r.wrap = i, tn;
	},
	deflateInfo: "pako deflate (from Nodeca project)"
}, lr = (e, t) => Object.prototype.hasOwnProperty.call(e, t), ur = {
	assign: function(e) {
		let t = Array.prototype.slice.call(arguments, 1);
		for (; t.length;) {
			let n = t.shift();
			if (n) {
				if (typeof n != "object") throw TypeError(n + "must be non-object");
				for (let t in n) lr(n, t) && (e[t] = n[t]);
			}
		}
		return e;
	},
	flattenChunks: (e) => {
		let t = 0;
		for (let n = 0, r = e.length; n < r; n++) t += e[n].length;
		let n = new Uint8Array(t);
		for (let t = 0, r = 0, i = e.length; t < i; t++) {
			let i = e[t];
			n.set(i, r), r += i.length;
		}
		return n;
	}
}, dr = !0;
try {
	String.fromCharCode.apply(null, /* @__PURE__ */ new Uint8Array(1));
} catch {
	dr = !1;
}
var fr = /* @__PURE__ */ new Uint8Array(256);
for (let e = 0; e < 256; e++) fr[e] = e >= 252 ? 6 : e >= 248 ? 5 : e >= 240 ? 4 : e >= 224 ? 3 : e >= 192 ? 2 : 1;
fr[254] = fr[254] = 1;
var pr = (e) => {
	if (typeof TextEncoder == "function" && TextEncoder.prototype.encode) return new TextEncoder().encode(e);
	let t, n, r, i, a, o = e.length, s = 0;
	for (i = 0; i < o; i++) n = e.charCodeAt(i), (n & 64512) == 55296 && i + 1 < o && (r = e.charCodeAt(i + 1), (r & 64512) == 56320 && (n = 65536 + (n - 55296 << 10) + (r - 56320), i++)), s += n < 128 ? 1 : n < 2048 ? 2 : n < 65536 ? 3 : 4;
	for (t = new Uint8Array(s), a = 0, i = 0; a < s; i++) n = e.charCodeAt(i), (n & 64512) == 55296 && i + 1 < o && (r = e.charCodeAt(i + 1), (r & 64512) == 56320 && (n = 65536 + (n - 55296 << 10) + (r - 56320), i++)), n < 128 ? t[a++] = n : n < 2048 ? (t[a++] = 192 | n >>> 6, t[a++] = 128 | n & 63) : n < 65536 ? (t[a++] = 224 | n >>> 12, t[a++] = 128 | n >>> 6 & 63, t[a++] = 128 | n & 63) : (t[a++] = 240 | n >>> 18, t[a++] = 128 | n >>> 12 & 63, t[a++] = 128 | n >>> 6 & 63, t[a++] = 128 | n & 63);
	return t;
}, mr = (e, t) => {
	if (t < 65534 && e.subarray && dr) return String.fromCharCode.apply(null, e.length === t ? e : e.subarray(0, t));
	let n = "";
	for (let r = 0; r < t; r++) n += String.fromCharCode(e[r]);
	return n;
}, hr = {
	string2buf: pr,
	buf2string: (e, t) => {
		let n = t || e.length;
		if (typeof TextDecoder == "function" && TextDecoder.prototype.decode) return new TextDecoder().decode(e.subarray(0, t));
		let r, i, a = Array(n * 2);
		for (i = 0, r = 0; r < n;) {
			let t = e[r++];
			if (t < 128) {
				a[i++] = t;
				continue;
			}
			let o = fr[t];
			if (o > 4) a[i++] = 65533, r += o - 1;
			else {
				for (t &= o === 2 ? 31 : o === 3 ? 15 : 7; o > 1 && r < n;) t = t << 6 | e[r++] & 63, o--;
				o > 1 ? a[i++] = 65533 : t < 65536 ? a[i++] = t : (t -= 65536, a[i++] = 55296 | t >> 10 & 1023, a[i++] = 56320 | t & 1023);
			}
		}
		return mr(a, i);
	},
	utf8border: (e, t) => {
		t ||= e.length, t > e.length && (t = e.length);
		let n = t - 1;
		for (; n >= 0 && (e[n] & 192) == 128;) n--;
		return n < 0 || n === 0 ? t : n + fr[e[n]] > t ? n : t;
	}
};
function gr() {
	this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0;
}
var _r = gr, vr = Object.prototype.toString, { Z_NO_FLUSH: yr, Z_SYNC_FLUSH: br, Z_FULL_FLUSH: xr, Z_FINISH: Sr, Z_OK: Cr, Z_STREAM_END: wr, Z_DEFAULT_COMPRESSION: Tr, Z_DEFAULT_STRATEGY: Er, Z_DEFLATED: Dr } = Wt;
function Or(e) {
	this.options = ur.assign({
		level: Tr,
		method: Dr,
		chunkSize: 16384,
		windowBits: 15,
		memLevel: 8,
		strategy: Er
	}, e || {});
	let t = this.options;
	t.raw && t.windowBits > 0 ? t.windowBits = -t.windowBits : t.gzip && t.windowBits > 0 && t.windowBits < 16 && (t.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new _r(), this.strm.avail_out = 0;
	let n = cr.deflateInit2(this.strm, t.level, t.method, t.windowBits, t.memLevel, t.strategy);
	if (n !== Cr) throw Error(Ut[n]);
	if (t.header && cr.deflateSetHeader(this.strm, t.header), t.dictionary) {
		let e;
		if (e = typeof t.dictionary == "string" ? hr.string2buf(t.dictionary) : vr.call(t.dictionary) === "[object ArrayBuffer]" ? new Uint8Array(t.dictionary) : t.dictionary, n = cr.deflateSetDictionary(this.strm, e), n !== Cr) throw Error(Ut[n]);
		this._dict_set = !0;
	}
}
Or.prototype.push = function(e, t) {
	let n = this.strm, r = this.options.chunkSize, i, a;
	if (this.ended) return !1;
	for (a = t === ~~t ? t : t === !0 ? Sr : yr, n.input = typeof e == "string" ? hr.string2buf(e) : vr.call(e) === "[object ArrayBuffer]" ? new Uint8Array(e) : e, n.next_in = 0, n.avail_in = n.input.length;;) if (n.avail_out === 0 && (n.output = new Uint8Array(r), n.next_out = 0, n.avail_out = r), (a === br || a === xr) && n.avail_out <= 6) this.onData(n.output.subarray(0, n.next_out)), n.avail_out = 0;
	else {
		if (i = cr.deflate(n, a), i === wr) return n.next_out > 0 && this.onData(n.output.subarray(0, n.next_out)), i = cr.deflateEnd(this.strm), this.onEnd(i), this.ended = !0, i === Cr;
		if (n.avail_out === 0) this.onData(n.output);
		else if (a > 0 && n.next_out > 0) this.onData(n.output.subarray(0, n.next_out)), n.avail_out = 0;
		else if (n.avail_in === 0) break;
	}
	return !0;
}, Or.prototype.onData = function(e) {
	this.chunks.push(e);
}, Or.prototype.onEnd = function(e) {
	e === Cr && (this.result = ur.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
};
function kr(e, t) {
	let n = new Or(t);
	if (n.push(e, !0), n.err) throw n.msg || Ut[n.err];
	return n.result;
}
function Ar(e, t) {
	return t ||= {}, t.raw = !0, kr(e, t);
}
function jr(e, t) {
	return t ||= {}, t.gzip = !0, kr(e, t);
}
var Mr = {
	Deflate: Or,
	deflate: kr,
	deflateRaw: Ar,
	gzip: jr,
	constants: Wt
}, Nr = 16209, Pr = 16191, Fr = function(e, t) {
	let n, r, i, a, o, s, c, l, u, d, f, p, m, h, g, _, v, y, b, x, S, C, w, T, E = e.state;
	n = e.next_in, w = e.input, r = n + (e.avail_in - 5), i = e.next_out, T = e.output, a = i - (t - e.avail_out), o = i + (e.avail_out - 257), s = E.dmax, c = E.wsize, l = E.whave, u = E.wnext, d = E.window, f = E.hold, p = E.bits, m = E.lencode, h = E.distcode, g = (1 << E.lenbits) - 1, _ = (1 << E.distbits) - 1;
	top: do {
		p < 15 && (f += w[n++] << p, p += 8, f += w[n++] << p, p += 8), v = m[f & g];
		dolen: for (;;) {
			if (y = v >>> 24, f >>>= y, p -= y, y = v >>> 16 & 255, y === 0) T[i++] = v & 65535;
			else if (y & 16) {
				b = v & 65535, y &= 15, y && (p < y && (f += w[n++] << p, p += 8), b += f & (1 << y) - 1, f >>>= y, p -= y), p < 15 && (f += w[n++] << p, p += 8, f += w[n++] << p, p += 8), v = h[f & _];
				dodist: for (;;) {
					if (y = v >>> 24, f >>>= y, p -= y, y = v >>> 16 & 255, y & 16) {
						if (x = v & 65535, y &= 15, p < y && (f += w[n++] << p, p += 8, p < y && (f += w[n++] << p, p += 8)), x += f & (1 << y) - 1, x > s) {
							e.msg = "invalid distance too far back", E.mode = Nr;
							break top;
						}
						if (f >>>= y, p -= y, y = i - a, x > y) {
							if (y = x - y, y > l && E.sane) {
								e.msg = "invalid distance too far back", E.mode = Nr;
								break top;
							}
							if (S = 0, C = d, u === 0) {
								if (S += c - y, y < b) {
									b -= y;
									do
										T[i++] = d[S++];
									while (--y);
									S = i - x, C = T;
								}
							} else if (u < y) {
								if (S += c + u - y, y -= u, y < b) {
									b -= y;
									do
										T[i++] = d[S++];
									while (--y);
									if (S = 0, u < b) {
										y = u, b -= y;
										do
											T[i++] = d[S++];
										while (--y);
										S = i - x, C = T;
									}
								}
							} else if (S += u - y, y < b) {
								b -= y;
								do
									T[i++] = d[S++];
								while (--y);
								S = i - x, C = T;
							}
							for (; b > 2;) T[i++] = C[S++], T[i++] = C[S++], T[i++] = C[S++], b -= 3;
							b && (T[i++] = C[S++], b > 1 && (T[i++] = C[S++]));
						} else {
							S = i - x;
							do
								T[i++] = T[S++], T[i++] = T[S++], T[i++] = T[S++], b -= 3;
							while (b > 2);
							b && (T[i++] = T[S++], b > 1 && (T[i++] = T[S++]));
						}
					} else if (y & 64) {
						e.msg = "invalid distance code", E.mode = Nr;
						break top;
					} else {
						v = h[(v & 65535) + (f & (1 << y) - 1)];
						continue dodist;
					}
					break;
				}
			} else if (!(y & 64)) {
				v = m[(v & 65535) + (f & (1 << y) - 1)];
				continue dolen;
			} else if (y & 32) {
				E.mode = Pr;
				break top;
			} else {
				e.msg = "invalid literal/length code", E.mode = Nr;
				break top;
			}
			break;
		}
	} while (n < r && i < o);
	b = p >> 3, n -= b, p -= b << 3, f &= (1 << p) - 1, e.next_in = n, e.next_out = i, e.avail_in = n < r ? 5 + (r - n) : 5 - (n - r), e.avail_out = i < o ? 257 + (o - i) : 257 - (i - o), E.hold = f, E.bits = p;
}, Ir = 15, Lr = 852, Rr = 592, zr = 0, Br = 1, Vr = 2, Hr = new Uint16Array([
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	11,
	13,
	15,
	17,
	19,
	23,
	27,
	31,
	35,
	43,
	51,
	59,
	67,
	83,
	99,
	115,
	131,
	163,
	195,
	227,
	258,
	0,
	0
]), Ur = new Uint8Array([
	16,
	16,
	16,
	16,
	16,
	16,
	16,
	16,
	17,
	17,
	17,
	17,
	18,
	18,
	18,
	18,
	19,
	19,
	19,
	19,
	20,
	20,
	20,
	20,
	21,
	21,
	21,
	21,
	16,
	72,
	78
]), Wr = new Uint16Array([
	1,
	2,
	3,
	4,
	5,
	7,
	9,
	13,
	17,
	25,
	33,
	49,
	65,
	97,
	129,
	193,
	257,
	385,
	513,
	769,
	1025,
	1537,
	2049,
	3073,
	4097,
	6145,
	8193,
	12289,
	16385,
	24577,
	0,
	0
]), Gr = new Uint8Array([
	16,
	16,
	16,
	16,
	17,
	17,
	18,
	18,
	19,
	19,
	20,
	20,
	21,
	21,
	22,
	22,
	23,
	23,
	24,
	24,
	25,
	25,
	26,
	26,
	27,
	27,
	28,
	28,
	29,
	29,
	64,
	64
]), Kr = (e, t, n, r, i, a, o, s) => {
	let c = s.bits, l = 0, u = 0, d = 0, f = 0, p = 0, m = 0, h = 0, g = 0, _ = 0, v = 0, y, b, x, S, C, w = null, T, E = /* @__PURE__ */ new Uint16Array(16), D = /* @__PURE__ */ new Uint16Array(16), O = null, k, A, j;
	for (l = 0; l <= Ir; l++) E[l] = 0;
	for (u = 0; u < r; u++) E[t[n + u]]++;
	for (p = c, f = Ir; f >= 1 && E[f] === 0; f--);
	if (p > f && (p = f), f === 0) return i[a++] = 20971520, i[a++] = 20971520, s.bits = 1, 0;
	for (d = 1; d < f && E[d] === 0; d++);
	for (p < d && (p = d), g = 1, l = 1; l <= Ir; l++) if (g <<= 1, g -= E[l], g < 0) return -1;
	if (g > 0 && (e === zr || f !== 1)) return -1;
	for (D[1] = 0, l = 1; l < Ir; l++) D[l + 1] = D[l] + E[l];
	for (u = 0; u < r; u++) t[n + u] !== 0 && (o[D[t[n + u]]++] = u);
	if (e === zr ? (w = O = o, T = 20) : e === Br ? (w = Hr, O = Ur, T = 257) : (w = Wr, O = Gr, T = 0), v = 0, u = 0, l = d, C = a, m = p, h = 0, x = -1, _ = 1 << p, S = _ - 1, e === Br && _ > Lr || e === Vr && _ > Rr) return 1;
	for (;;) {
		k = l - h, o[u] + 1 < T ? (A = 0, j = o[u]) : o[u] >= T ? (A = O[o[u] - T], j = w[o[u] - T]) : (A = 96, j = 0), y = 1 << l - h, b = 1 << m, d = b;
		do
			b -= y, i[C + (v >> h) + b] = k << 24 | A << 16 | j;
		while (b !== 0);
		for (y = 1 << l - 1; v & y;) y >>= 1;
		if (y === 0 ? v = 0 : (v &= y - 1, v += y), u++, --E[l] === 0) {
			if (l === f) break;
			l = t[n + o[u]];
		}
		if (l > p && (v & S) !== x) {
			for (h === 0 && (h = p), C += d, m = l - h, g = 1 << m; m + h < f && (g -= E[m + h], !(g <= 0));) m++, g <<= 1;
			if (_ += 1 << m, e === Br && _ > Lr || e === Vr && _ > Rr) return 1;
			x = v & S, i[x] = p << 24 | m << 16 | C - a;
		}
	}
	return v !== 0 && (i[C + v] = l - h << 24 | 4194304), s.bits = p, 0;
}, qr = 0, Jr = 1, Yr = 2, { Z_FINISH: Xr, Z_BLOCK: Zr, Z_TREES: Qr, Z_OK: $r, Z_STREAM_END: ei, Z_NEED_DICT: ti, Z_STREAM_ERROR: ni, Z_DATA_ERROR: ri, Z_MEM_ERROR: ii, Z_BUF_ERROR: ai, Z_DEFLATED: oi } = Wt, si = 16180, ci = 16181, li = 16182, ui = 16183, di = 16184, fi = 16185, pi = 16186, mi = 16187, hi = 16188, gi = 16189, _i = 16190, vi = 16191, yi = 16192, bi = 16193, xi = 16194, Si = 16195, Ci = 16196, wi = 16197, Ti = 16198, Ei = 16199, Di = 16200, Oi = 16201, ki = 16202, Ai = 16203, ji = 16204, Mi = 16205, Ni = 16206, Pi = 16207, Fi = 16208, Ii = 16209, Li = 16210, Ri = 16211, zi = 852, Bi = 592, Vi = 15, Hi = (e) => (e >>> 24 & 255) + (e >>> 8 & 65280) + ((e & 65280) << 8) + ((e & 255) << 24);
function Ui() {
	this.strm = null, this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = /* @__PURE__ */ new Uint16Array(320), this.work = /* @__PURE__ */ new Uint16Array(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0;
}
var Wi = (e) => {
	if (!e) return 1;
	let t = e.state;
	return +(!t || t.strm !== e || t.mode < si || t.mode > Ri);
}, Gi = (e) => {
	if (Wi(e)) return ni;
	let t = e.state;
	return e.total_in = e.total_out = t.total = 0, e.msg = "", t.wrap && (e.adler = t.wrap & 1), t.mode = si, t.last = 0, t.havedict = 0, t.flags = -1, t.dmax = 32768, t.head = null, t.hold = 0, t.bits = 0, t.lencode = t.lendyn = new Int32Array(zi), t.distcode = t.distdyn = new Int32Array(Bi), t.sane = 1, t.back = -1, $r;
}, Ki = (e) => {
	if (Wi(e)) return ni;
	let t = e.state;
	return t.wsize = 0, t.whave = 0, t.wnext = 0, Gi(e);
}, qi = (e, t) => {
	let n;
	if (Wi(e)) return ni;
	let r = e.state;
	return t < 0 ? (n = 0, t = -t) : (n = (t >> 4) + 5, t < 48 && (t &= 15)), t && (t < 8 || t > 15) ? ni : (r.window !== null && r.wbits !== t && (r.window = null), r.wrap = n, r.wbits = t, Ki(e));
}, Ji = (e, t) => {
	if (!e) return ni;
	let n = new Ui();
	e.state = n, n.strm = e, n.window = null, n.mode = si;
	let r = qi(e, t);
	return r !== $r && (e.state = null), r;
}, Yi = (e) => Ji(e, Vi), Xi = !0, Zi, Qi, $i = (e) => {
	if (Xi) {
		Zi = /* @__PURE__ */ new Int32Array(512), Qi = /* @__PURE__ */ new Int32Array(32);
		let t = 0;
		for (; t < 144;) e.lens[t++] = 8;
		for (; t < 256;) e.lens[t++] = 9;
		for (; t < 280;) e.lens[t++] = 7;
		for (; t < 288;) e.lens[t++] = 8;
		for (Kr(Jr, e.lens, 0, 288, Zi, 0, e.work, { bits: 9 }), t = 0; t < 32;) e.lens[t++] = 5;
		Kr(Yr, e.lens, 0, 32, Qi, 0, e.work, { bits: 5 }), Xi = !1;
	}
	e.lencode = Zi, e.lenbits = 9, e.distcode = Qi, e.distbits = 5;
}, ea = (e, t, n, r) => {
	let i, a = e.state;
	return a.window === null && (a.wsize = 1 << a.wbits, a.wnext = 0, a.whave = 0, a.window = new Uint8Array(a.wsize)), r >= a.wsize ? (a.window.set(t.subarray(n - a.wsize, n), 0), a.wnext = 0, a.whave = a.wsize) : (i = a.wsize - a.wnext, i > r && (i = r), a.window.set(t.subarray(n - r, n - r + i), a.wnext), r -= i, r ? (a.window.set(t.subarray(n - r, n), 0), a.wnext = r, a.whave = a.wsize) : (a.wnext += i, a.wnext === a.wsize && (a.wnext = 0), a.whave < a.wsize && (a.whave += i))), 0;
}, ta = {
	inflateReset: Ki,
	inflateReset2: qi,
	inflateResetKeep: Gi,
	inflateInit: Yi,
	inflateInit2: Ji,
	inflate: (e, t) => {
		let n, r, i, a, o, s, c, l, u, d, f, p, m, h, g = 0, _, v, y, b, x, S, C, w, T = /* @__PURE__ */ new Uint8Array(4), E, D, O = new Uint8Array([
			16,
			17,
			18,
			0,
			8,
			7,
			9,
			6,
			10,
			5,
			11,
			4,
			12,
			3,
			13,
			2,
			14,
			1,
			15
		]);
		if (Wi(e) || !e.output || !e.input && e.avail_in !== 0) return ni;
		n = e.state, n.mode === vi && (n.mode = yi), o = e.next_out, i = e.output, c = e.avail_out, a = e.next_in, r = e.input, s = e.avail_in, l = n.hold, u = n.bits, d = s, f = c, w = $r;
		inf_leave: for (;;) switch (n.mode) {
			case si:
				if (n.wrap === 0) {
					n.mode = yi;
					break;
				}
				for (; u < 16;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if (n.wrap & 2 && l === 35615) {
					n.wbits === 0 && (n.wbits = 15), n.check = 0, T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = Ht(n.check, T, 2, 0), l = 0, u = 0, n.mode = ci;
					break;
				}
				if (n.head && (n.head.done = !1), !(n.wrap & 1) || (((l & 255) << 8) + (l >> 8)) % 31) {
					e.msg = "incorrect header check", n.mode = Ii;
					break;
				}
				if ((l & 15) !== oi) {
					e.msg = "unknown compression method", n.mode = Ii;
					break;
				}
				if (l >>>= 4, u -= 4, C = (l & 15) + 8, n.wbits === 0 && (n.wbits = C), C > 15 || C > n.wbits) {
					e.msg = "invalid window size", n.mode = Ii;
					break;
				}
				n.dmax = 1 << n.wbits, n.flags = 0, e.adler = n.check = 1, n.mode = l & 512 ? gi : vi, l = 0, u = 0;
				break;
			case ci:
				for (; u < 16;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if (n.flags = l, (n.flags & 255) !== oi) {
					e.msg = "unknown compression method", n.mode = Ii;
					break;
				}
				if (n.flags & 57344) {
					e.msg = "unknown header flags set", n.mode = Ii;
					break;
				}
				n.head && (n.head.text = l >> 8 & 1), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = Ht(n.check, T, 2, 0)), l = 0, u = 0, n.mode = li;
			case li:
				for (; u < 32;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				n.head && (n.head.time = l), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, T[2] = l >>> 16 & 255, T[3] = l >>> 24 & 255, n.check = Ht(n.check, T, 4, 0)), l = 0, u = 0, n.mode = ui;
			case ui:
				for (; u < 16;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				n.head && (n.head.xflags = l & 255, n.head.os = l >> 8), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = Ht(n.check, T, 2, 0)), l = 0, u = 0, n.mode = di;
			case di:
				if (n.flags & 1024) {
					for (; u < 16;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					n.length = l, n.head && (n.head.extra_len = l), n.flags & 512 && n.wrap & 4 && (T[0] = l & 255, T[1] = l >>> 8 & 255, n.check = Ht(n.check, T, 2, 0)), l = 0, u = 0;
				} else n.head && (n.head.extra = null);
				n.mode = fi;
			case fi:
				if (n.flags & 1024 && (p = n.length, p > s && (p = s), p && (n.head && (C = n.head.extra_len - n.length, n.head.extra || (n.head.extra = new Uint8Array(n.head.extra_len)), n.head.extra.set(r.subarray(a, a + p), C)), n.flags & 512 && n.wrap & 4 && (n.check = Ht(n.check, r, p, a)), s -= p, a += p, n.length -= p), n.length)) break inf_leave;
				n.length = 0, n.mode = pi;
			case pi:
				if (n.flags & 2048) {
					if (s === 0) break inf_leave;
					p = 0;
					do
						C = r[a + p++], n.head && C && n.length < 65536 && (n.head.name += String.fromCharCode(C));
					while (C && p < s);
					if (n.flags & 512 && n.wrap & 4 && (n.check = Ht(n.check, r, p, a)), s -= p, a += p, C) break inf_leave;
				} else n.head && (n.head.name = null);
				n.length = 0, n.mode = mi;
			case mi:
				if (n.flags & 4096) {
					if (s === 0) break inf_leave;
					p = 0;
					do
						C = r[a + p++], n.head && C && n.length < 65536 && (n.head.comment += String.fromCharCode(C));
					while (C && p < s);
					if (n.flags & 512 && n.wrap & 4 && (n.check = Ht(n.check, r, p, a)), s -= p, a += p, C) break inf_leave;
				} else n.head && (n.head.comment = null);
				n.mode = hi;
			case hi:
				if (n.flags & 512) {
					for (; u < 16;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					if (n.wrap & 4 && l !== (n.check & 65535)) {
						e.msg = "header crc mismatch", n.mode = Ii;
						break;
					}
					l = 0, u = 0;
				}
				n.head && (n.head.hcrc = n.flags >> 9 & 1, n.head.done = !0), e.adler = n.check = 0, n.mode = vi;
				break;
			case gi:
				for (; u < 32;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				e.adler = n.check = Hi(l), l = 0, u = 0, n.mode = _i;
			case _i:
				if (n.havedict === 0) return e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, n.hold = l, n.bits = u, ti;
				e.adler = n.check = 1, n.mode = vi;
			case vi: if (t === Zr || t === Qr) break inf_leave;
			case yi:
				if (n.last) {
					l >>>= u & 7, u -= u & 7, n.mode = Ni;
					break;
				}
				for (; u < 3;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				switch (n.last = l & 1, l >>>= 1, --u, l & 3) {
					case 0:
						n.mode = bi;
						break;
					case 1:
						if ($i(n), n.mode = Ei, t === Qr) {
							l >>>= 2, u -= 2;
							break inf_leave;
						}
						break;
					case 2:
						n.mode = Ci;
						break;
					case 3: e.msg = "invalid block type", n.mode = Ii;
				}
				l >>>= 2, u -= 2;
				break;
			case bi:
				for (l >>>= u & 7, u -= u & 7; u < 32;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if ((l & 65535) != (l >>> 16 ^ 65535)) {
					e.msg = "invalid stored block lengths", n.mode = Ii;
					break;
				}
				if (n.length = l & 65535, l = 0, u = 0, n.mode = xi, t === Qr) break inf_leave;
			case xi: n.mode = Si;
			case Si:
				if (p = n.length, p) {
					if (p > s && (p = s), p > c && (p = c), p === 0) break inf_leave;
					i.set(r.subarray(a, a + p), o), s -= p, a += p, c -= p, o += p, n.length -= p;
					break;
				}
				n.mode = vi;
				break;
			case Ci:
				for (; u < 14;) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if (n.nlen = (l & 31) + 257, l >>>= 5, u -= 5, n.ndist = (l & 31) + 1, l >>>= 5, u -= 5, n.ncode = (l & 15) + 4, l >>>= 4, u -= 4, n.nlen > 286 || n.ndist > 30) {
					e.msg = "too many length or distance symbols", n.mode = Ii;
					break;
				}
				n.have = 0, n.mode = wi;
			case wi:
				for (; n.have < n.ncode;) {
					for (; u < 3;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					n.lens[O[n.have++]] = l & 7, l >>>= 3, u -= 3;
				}
				for (; n.have < 19;) n.lens[O[n.have++]] = 0;
				if (n.lencode = n.lendyn, n.lenbits = 7, E = { bits: n.lenbits }, w = Kr(qr, n.lens, 0, 19, n.lencode, 0, n.work, E), n.lenbits = E.bits, w) {
					e.msg = "invalid code lengths set", n.mode = Ii;
					break;
				}
				n.have = 0, n.mode = Ti;
			case Ti:
				for (; n.have < n.nlen + n.ndist;) {
					for (; g = n.lencode[l & (1 << n.lenbits) - 1], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(_ <= u);) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					if (y < 16) l >>>= _, u -= _, n.lens[n.have++] = y;
					else {
						if (y === 16) {
							for (D = _ + 2; u < D;) {
								if (s === 0) break inf_leave;
								s--, l += r[a++] << u, u += 8;
							}
							if (l >>>= _, u -= _, n.have === 0) {
								e.msg = "invalid bit length repeat", n.mode = Ii;
								break;
							}
							C = n.lens[n.have - 1], p = 3 + (l & 3), l >>>= 2, u -= 2;
						} else if (y === 17) {
							for (D = _ + 3; u < D;) {
								if (s === 0) break inf_leave;
								s--, l += r[a++] << u, u += 8;
							}
							l >>>= _, u -= _, C = 0, p = 3 + (l & 7), l >>>= 3, u -= 3;
						} else {
							for (D = _ + 7; u < D;) {
								if (s === 0) break inf_leave;
								s--, l += r[a++] << u, u += 8;
							}
							l >>>= _, u -= _, C = 0, p = 11 + (l & 127), l >>>= 7, u -= 7;
						}
						if (n.have + p > n.nlen + n.ndist) {
							e.msg = "invalid bit length repeat", n.mode = Ii;
							break;
						}
						for (; p--;) n.lens[n.have++] = C;
					}
				}
				if (n.mode === Ii) break;
				if (n.lens[256] === 0) {
					e.msg = "invalid code -- missing end-of-block", n.mode = Ii;
					break;
				}
				if (n.lenbits = 9, E = { bits: n.lenbits }, w = Kr(Jr, n.lens, 0, n.nlen, n.lencode, 0, n.work, E), n.lenbits = E.bits, w) {
					e.msg = "invalid literal/lengths set", n.mode = Ii;
					break;
				}
				if (n.distbits = 6, n.distcode = n.distdyn, E = { bits: n.distbits }, w = Kr(Yr, n.lens, n.nlen, n.ndist, n.distcode, 0, n.work, E), n.distbits = E.bits, w) {
					e.msg = "invalid distances set", n.mode = Ii;
					break;
				}
				if (n.mode = Ei, t === Qr) break inf_leave;
			case Ei: n.mode = Di;
			case Di:
				if (s >= 6 && c >= 258) {
					e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, n.hold = l, n.bits = u, Fr(e, f), o = e.next_out, i = e.output, c = e.avail_out, a = e.next_in, r = e.input, s = e.avail_in, l = n.hold, u = n.bits, n.mode === vi && (n.back = -1);
					break;
				}
				for (n.back = 0; g = n.lencode[l & (1 << n.lenbits) - 1], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(_ <= u);) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if (v && !(v & 240)) {
					for (b = _, x = v, S = y; g = n.lencode[S + ((l & (1 << b + x) - 1) >> b)], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(b + _ <= u);) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					l >>>= b, u -= b, n.back += b;
				}
				if (l >>>= _, u -= _, n.back += _, n.length = y, v === 0) {
					n.mode = Mi;
					break;
				}
				if (v & 32) {
					n.back = -1, n.mode = vi;
					break;
				}
				if (v & 64) {
					e.msg = "invalid literal/length code", n.mode = Ii;
					break;
				}
				n.extra = v & 15, n.mode = Oi;
			case Oi:
				if (n.extra) {
					for (D = n.extra; u < D;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					n.length += l & (1 << n.extra) - 1, l >>>= n.extra, u -= n.extra, n.back += n.extra;
				}
				n.was = n.length, n.mode = ki;
			case ki:
				for (; g = n.distcode[l & (1 << n.distbits) - 1], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(_ <= u);) {
					if (s === 0) break inf_leave;
					s--, l += r[a++] << u, u += 8;
				}
				if (!(v & 240)) {
					for (b = _, x = v, S = y; g = n.distcode[S + ((l & (1 << b + x) - 1) >> b)], _ = g >>> 24, v = g >>> 16 & 255, y = g & 65535, !(b + _ <= u);) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					l >>>= b, u -= b, n.back += b;
				}
				if (l >>>= _, u -= _, n.back += _, v & 64) {
					e.msg = "invalid distance code", n.mode = Ii;
					break;
				}
				n.offset = y, n.extra = v & 15, n.mode = Ai;
			case Ai:
				if (n.extra) {
					for (D = n.extra; u < D;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					n.offset += l & (1 << n.extra) - 1, l >>>= n.extra, u -= n.extra, n.back += n.extra;
				}
				if (n.offset > n.dmax) {
					e.msg = "invalid distance too far back", n.mode = Ii;
					break;
				}
				n.mode = ji;
			case ji:
				if (c === 0) break inf_leave;
				if (p = f - c, n.offset > p) {
					if (p = n.offset - p, p > n.whave && n.sane) {
						e.msg = "invalid distance too far back", n.mode = Ii;
						break;
					}
					p > n.wnext ? (p -= n.wnext, m = n.wsize - p) : m = n.wnext - p, p > n.length && (p = n.length), h = n.window;
				} else h = i, m = o - n.offset, p = n.length;
				p > c && (p = c), c -= p, n.length -= p;
				do
					i[o++] = h[m++];
				while (--p);
				n.length === 0 && (n.mode = Di);
				break;
			case Mi:
				if (c === 0) break inf_leave;
				i[o++] = n.length, c--, n.mode = Di;
				break;
			case Ni:
				if (n.wrap) {
					for (; u < 32;) {
						if (s === 0) break inf_leave;
						s--, l |= r[a++] << u, u += 8;
					}
					if (f -= c, e.total_out += f, n.total += f, n.wrap & 4 && f && (e.adler = n.check = n.flags ? Ht(n.check, i, f, o - f) : Bt(n.check, i, f, o - f)), f = c, n.wrap & 4 && (n.flags ? l : Hi(l)) !== n.check) {
						e.msg = "incorrect data check", n.mode = Ii;
						break;
					}
					l = 0, u = 0;
				}
				n.mode = Pi;
			case Pi:
				if (n.wrap && n.flags) {
					for (; u < 32;) {
						if (s === 0) break inf_leave;
						s--, l += r[a++] << u, u += 8;
					}
					if (n.wrap & 4 && l !== (n.total | 0)) {
						e.msg = "incorrect length check", n.mode = Ii;
						break;
					}
					l = 0, u = 0;
				}
				n.mode = Fi;
			case Fi:
				w = ei;
				break inf_leave;
			case Ii:
				w = ri;
				break inf_leave;
			case Li: return ii;
			case Ri:
			default: return ni;
		}
		return e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, n.hold = l, n.bits = u, (n.wsize || f !== e.avail_out && n.mode < Ii && (n.mode < Ni || t !== Xr)) && ea(e, e.output, e.next_out, f - e.avail_out), d -= e.avail_in, f -= e.avail_out, e.total_in += d, e.total_out += f, n.total += f, n.wrap & 4 && f && (e.adler = n.check = n.flags ? Ht(n.check, i, f, e.next_out - f) : Bt(n.check, i, f, e.next_out - f)), e.data_type = n.bits + (n.last ? 64 : 0) + (n.mode === vi ? 128 : 0) + (n.mode === Ei || n.mode === xi ? 256 : 0), (d === 0 && f === 0 || t === Xr) && w === $r && (w = ai), w;
	},
	inflateEnd: (e) => {
		if (Wi(e)) return ni;
		let t = e.state;
		return t.window &&= null, e.state = null, $r;
	},
	inflateGetHeader: (e, t) => {
		if (Wi(e)) return ni;
		let n = e.state;
		return n.wrap & 2 ? (n.head = t, t.done = !1, $r) : ni;
	},
	inflateSetDictionary: (e, t) => {
		let n = t.length, r, i, a;
		return Wi(e) || (r = e.state, r.wrap !== 0 && r.mode !== _i) ? ni : r.mode === _i && (i = 1, i = Bt(i, t, n, 0), i !== r.check) ? ri : (a = ea(e, t, n, n), a ? (r.mode = Li, ii) : (r.havedict = 1, $r));
	},
	inflateInfo: "pako inflate (from Nodeca project)"
};
function na() {
	this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = !1;
}
var ra = na, ia = Object.prototype.toString, { Z_NO_FLUSH: aa, Z_FINISH: oa, Z_OK: sa, Z_STREAM_END: ca, Z_NEED_DICT: la, Z_STREAM_ERROR: ua, Z_DATA_ERROR: da, Z_MEM_ERROR: fa } = Wt;
function pa(e) {
	this.options = ur.assign({
		chunkSize: 65536,
		windowBits: 15,
		to: ""
	}, e || {});
	let t = this.options;
	t.raw && t.windowBits >= 0 && t.windowBits < 16 && (t.windowBits = -t.windowBits, t.windowBits === 0 && (t.windowBits = -15)), t.windowBits >= 0 && t.windowBits < 16 && !(e && e.windowBits) && (t.windowBits += 32), t.windowBits > 15 && t.windowBits < 48 && (t.windowBits & 15 || (t.windowBits |= 15)), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new _r(), this.strm.avail_out = 0;
	let n = ta.inflateInit2(this.strm, t.windowBits);
	if (n !== sa || (this.header = new ra(), ta.inflateGetHeader(this.strm, this.header), t.dictionary && (typeof t.dictionary == "string" ? t.dictionary = hr.string2buf(t.dictionary) : ia.call(t.dictionary) === "[object ArrayBuffer]" && (t.dictionary = new Uint8Array(t.dictionary)), t.raw && (n = ta.inflateSetDictionary(this.strm, t.dictionary), n !== sa)))) throw Error(Ut[n]);
}
pa.prototype.push = function(e, t) {
	let n = this.strm, r = this.options.chunkSize, i = this.options.dictionary, a, o, s;
	if (this.ended) return !1;
	for (o = t === ~~t ? t : t === !0 ? oa : aa, n.input = ia.call(e) === "[object ArrayBuffer]" ? new Uint8Array(e) : e, n.next_in = 0, n.avail_in = n.input.length;;) {
		for (n.avail_out === 0 && (n.output = new Uint8Array(r), n.next_out = 0, n.avail_out = r), a = ta.inflate(n, o), a === la && i && (a = ta.inflateSetDictionary(n, i), a === sa ? a = ta.inflate(n, o) : a === da && (a = la)); n.avail_in > 0 && a === ca && n.state.wrap > 0 && e[n.next_in] !== 0;) ta.inflateReset(n), a = ta.inflate(n, o);
		switch (a) {
			case ua:
			case da:
			case la:
			case fa: return this.onEnd(a), this.ended = !0, !1;
		}
		if (s = n.avail_out, n.next_out && (n.avail_out === 0 || a === ca)) {
			if (this.options.to === "string") {
				let e = hr.utf8border(n.output, n.next_out), t = n.next_out - e, i = hr.buf2string(n.output, e);
				n.next_out = t, n.avail_out = r - t, t && n.output.set(n.output.subarray(e, e + t), 0), this.onData(i);
			} else this.onData(n.output.length === n.next_out ? n.output : n.output.subarray(0, n.next_out));
		}
		if (a !== sa || s !== 0) {
			if (a === ca) return a = ta.inflateEnd(this.strm), this.onEnd(a), this.ended = !0, !0;
			if (n.avail_in === 0) break;
		}
	}
	return !0;
}, pa.prototype.onData = function(e) {
	this.chunks.push(e);
}, pa.prototype.onEnd = function(e) {
	e === sa && (this.result = this.options.to === "string" ? this.chunks.join("") : ur.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg;
};
function ma(e, t) {
	let n = new pa(t);
	if (n.push(e), n.err) throw n.msg || Ut[n.err];
	return n.result;
}
function ha(e, t) {
	return t ||= {}, t.raw = !0, ma(e, t);
}
var ga = {
	Inflate: pa,
	inflate: ma,
	inflateRaw: ha,
	ungzip: ma,
	constants: Wt
}, { Deflate: _a, deflate: va, deflateRaw: ya, gzip: ba } = Mr, { Inflate: xa, inflate: Sa, inflateRaw: Ca, ungzip: wa } = ga, Ta = xa, Ea = Sa, Da = [];
for (let e = 0; e < 256; e++) {
	let t = e;
	for (let e = 0; e < 8; e++) t & 1 ? t = 3988292384 ^ t >>> 1 : t >>>= 1;
	Da[e] = t;
}
var Oa = 4294967295;
function ka(e, t, n) {
	let r = e;
	for (let e = 0; e < n; e++) r = Da[(r ^ t[e]) & 255] ^ r >>> 8;
	return r;
}
function Aa(e, t) {
	return (ka(Oa, e, t) ^ Oa) >>> 0;
}
function ja(e, t, n) {
	let r = e.readUint32(), i = Aa(new Uint8Array(e.buffer, e.byteOffset + e.offset - t - 4, t), t);
	if (i !== r) throw Error(`CRC mismatch for chunk ${n}. Expected ${r}, found ${i}`);
}
// node_modules/fast-png/lib-esm/helpers/unfilter.js
function Ma(e, t, n) {
	for (let r = 0; r < n; r++) t[r] = e[r];
}
function Na(e, t, n, r) {
	let i = 0;
	for (; i < r; i++) t[i] = e[i];
	for (; i < n; i++) t[i] = e[i] + t[i - r] & 255;
}
function Pa(e, t, n, r) {
	let i = 0;
	if (n.length === 0) for (; i < r; i++) t[i] = e[i];
	else for (; i < r; i++) t[i] = e[i] + n[i] & 255;
}
function Fa(e, t, n, r, i) {
	let a = 0;
	if (n.length === 0) {
		for (; a < i; a++) t[a] = e[a];
		for (; a < r; a++) t[a] = e[a] + (t[a - i] >> 1) & 255;
	} else {
		for (; a < i; a++) t[a] = e[a] + (n[a] >> 1) & 255;
		for (; a < r; a++) t[a] = e[a] + (t[a - i] + n[a] >> 1) & 255;
	}
}
function Ia(e, t, n, r, i) {
	let a = 0;
	if (n.length === 0) {
		for (; a < i; a++) t[a] = e[a];
		for (; a < r; a++) t[a] = e[a] + t[a - i] & 255;
	} else {
		for (; a < i; a++) t[a] = e[a] + n[a] & 255;
		for (; a < r; a++) t[a] = e[a] + La(t[a - i], n[a], n[a - i]) & 255;
	}
}
function La(e, t, n) {
	let r = e + t - n, i = Math.abs(r - e), a = Math.abs(r - t), o = Math.abs(r - n);
	return i <= a && i <= o ? e : a <= o ? t : n;
}
// node_modules/fast-png/lib-esm/helpers/applyUnfilter.js
function Ra(e, t, n, r, i, a) {
	switch (e) {
		case 0:
			Ma(t, n, i);
			break;
		case 1:
			Na(t, n, i, a);
			break;
		case 2:
			Pa(t, n, r, i);
			break;
		case 3:
			Fa(t, n, r, i, a);
			break;
		case 4:
			Ia(t, n, r, i, a);
			break;
		default: throw Error(`Unsupported filter: ${e}`);
	}
}
// node_modules/fast-png/lib-esm/helpers/decodeInterlaceAdam7.js
var za = new Uint16Array([255]), Ba = new Uint8Array(za.buffer)[0] === 255;
function Va(e) {
	let { data: t, width: n, height: r, channels: i, depth: a } = e, o = [
		{
			x: 0,
			y: 0,
			xStep: 8,
			yStep: 8
		},
		{
			x: 4,
			y: 0,
			xStep: 8,
			yStep: 8
		},
		{
			x: 0,
			y: 4,
			xStep: 4,
			yStep: 8
		},
		{
			x: 2,
			y: 0,
			xStep: 4,
			yStep: 4
		},
		{
			x: 0,
			y: 2,
			xStep: 2,
			yStep: 4
		},
		{
			x: 1,
			y: 0,
			xStep: 2,
			yStep: 2
		},
		{
			x: 0,
			y: 1,
			xStep: 1,
			yStep: 2
		}
	], s = Math.ceil(a / 8) * i, c = new Uint8Array(r * n * s), l = 0;
	for (let e = 0; e < 7; e++) {
		let i = o[e], a = Math.ceil((n - i.x) / i.xStep), u = Math.ceil((r - i.y) / i.yStep);
		if (a <= 0 || u <= 0) continue;
		let d = a * s, f = new Uint8Array(d);
		for (let e = 0; e < u; e++) {
			let o = t[l++], u = t.subarray(l, l + d);
			l += d;
			let p = new Uint8Array(d);
			Ra(o, u, p, f, d, s), f.set(p);
			for (let t = 0; t < a; t++) {
				let a = i.x + t * i.xStep, o = i.y + e * i.yStep;
				if (!(a >= n || o >= r)) for (let e = 0; e < s; e++) c[(o * n + a) * s + e] = p[t * s + e];
			}
		}
	}
	if (a === 16) {
		let e = new Uint16Array(c.buffer);
		if (Ba) for (let t = 0; t < e.length; t++) e[t] = Ha(e[t]);
		return e;
	}
	return c;
}
function Ha(e) {
	return (e & 255) << 8 | e >> 8 & 255;
}
// node_modules/fast-png/lib-esm/helpers/decodeInterlaceNull.js
var Ua = new Uint16Array([255]), Wa = new Uint8Array(Ua.buffer)[0] === 255, Ga = /* @__PURE__ */ new Uint8Array();
function Ka(e) {
	let { data: t, width: n, height: r, channels: i, depth: a } = e, o = Math.ceil(a / 8) * i, s = Math.ceil(a / 8 * i * n), c = new Uint8Array(r * s), l = Ga, u = 0, d, f;
	for (let e = 0; e < r; e++) {
		switch (d = t.subarray(u + 1, u + 1 + s), f = c.subarray(e * s, (e + 1) * s), t[u]) {
			case 0:
				Ma(d, f, s);
				break;
			case 1:
				Na(d, f, s, o);
				break;
			case 2:
				Pa(d, f, l, s);
				break;
			case 3:
				Fa(d, f, l, s, o);
				break;
			case 4:
				Ia(d, f, l, s, o);
				break;
			default: throw Error(`Unsupported filter: ${t[u]}`);
		}
		l = f, u += s + 1;
	}
	if (a === 16) {
		let e = new Uint16Array(c.buffer);
		if (Wa) for (let t = 0; t < e.length; t++) e[t] = qa(e[t]);
		return e;
	}
	return c;
}
function qa(e) {
	return (e & 255) << 8 | e >> 8 & 255;
}
// node_modules/fast-png/lib-esm/helpers/signature.js
var Ja = Uint8Array.of(137, 80, 78, 71, 13, 10, 26, 10);
function Ya(e) {
	if (!Xa(e.readBytes(Ja.length))) throw Error("wrong PNG signature");
}
function Xa(e) {
	if (e.length < Ja.length) return !1;
	for (let t = 0; t < Ja.length; t++) if (e[t] !== Ja[t]) return !1;
	return !0;
}
// node_modules/fast-png/lib-esm/helpers/text.js
var Za = "tEXt", Qa = 0, $a = new TextDecoder("latin1");
function eo(e) {
	if (no(e), e.length === 0 || e.length > 79) throw Error("keyword length must be between 1 and 79");
}
var to = /^[\u0000-\u00FF]*$/;
function no(e) {
	if (!to.test(e)) throw Error("invalid latin1 text");
}
function ro(e, t, n) {
	let r = io(t);
	e[r] = ao(t, n - r.length - 1);
}
function io(e) {
	for (e.mark(); e.readByte() !== Qa;);
	let t = e.offset;
	e.reset();
	let n = $a.decode(e.readBytes(t - e.offset - 1));
	return e.skip(1), eo(n), n;
}
function ao(e, t) {
	return $a.decode(e.readBytes(t));
}
// node_modules/fast-png/lib-esm/internalTypes.js
var oo = {
	UNKNOWN: -1,
	GREYSCALE: 0,
	TRUECOLOUR: 2,
	INDEXED_COLOUR: 3,
	GREYSCALE_ALPHA: 4,
	TRUECOLOUR_ALPHA: 6
}, so = {
	UNKNOWN: -1,
	DEFLATE: 0
}, co = {
	UNKNOWN: -1,
	ADAPTIVE: 0
}, lo = {
	UNKNOWN: -1,
	NO_INTERLACE: 0,
	ADAM7: 1
}, uo = {
	NONE: 0,
	BACKGROUND: 1,
	PREVIOUS: 2
}, fo = {
	SOURCE: 0,
	OVER: 1
}, po = class extends Le {
	_checkCrc;
	_inflator;
	_png;
	_apng;
	_end;
	_hasPalette;
	_palette;
	_hasTransparency;
	_transparency;
	_compressionMethod;
	_filterMethod;
	_interlaceMethod;
	_colorType;
	_isAnimated;
	_numberOfFrames;
	_numberOfPlays;
	_frames;
	_writingDataChunks;
	constructor(e, t = {}) {
		super(e);
		let { checkCrc: n = !1 } = t;
		this._checkCrc = n, this._inflator = new Ta(), this._png = {
			width: -1,
			height: -1,
			channels: -1,
			data: /* @__PURE__ */ new Uint8Array(),
			depth: 1,
			text: {}
		}, this._apng = {
			width: -1,
			height: -1,
			channels: -1,
			depth: 1,
			numberOfFrames: 1,
			numberOfPlays: 0,
			text: {},
			frames: []
		}, this._end = !1, this._hasPalette = !1, this._palette = [], this._hasTransparency = !1, this._transparency = /* @__PURE__ */ new Uint16Array(), this._compressionMethod = so.UNKNOWN, this._filterMethod = co.UNKNOWN, this._interlaceMethod = lo.UNKNOWN, this._colorType = oo.UNKNOWN, this._isAnimated = !1, this._numberOfFrames = 1, this._numberOfPlays = 0, this._frames = [], this._writingDataChunks = !1, this.setBigEndian();
	}
	decode() {
		for (Ya(this); !this._end;) {
			let e = this.readUint32(), t = this.readChars(4);
			this.decodeChunk(e, t);
		}
		return this.decodeImage(), this._png;
	}
	decodeApng() {
		for (Ya(this); !this._end;) {
			let e = this.readUint32(), t = this.readChars(4);
			this.decodeApngChunk(e, t);
		}
		return this.decodeApngImage(), this._apng;
	}
	decodeChunk(e, t) {
		let n = this.offset;
		switch (t) {
			case "IHDR":
				this.decodeIHDR();
				break;
			case "PLTE":
				this.decodePLTE(e);
				break;
			case "IDAT":
				this.decodeIDAT(e);
				break;
			case "IEND":
				this._end = !0;
				break;
			case "tRNS":
				this.decodetRNS(e);
				break;
			case "iCCP":
				this.decodeiCCP(e);
				break;
			case Za:
				ro(this._png.text, this, e);
				break;
			case "pHYs":
				this.decodepHYs();
				break;
			default: this.skip(e);
		}
		if (this.offset - n !== e) throw Error(`Length mismatch while decoding chunk ${t}`);
		this._checkCrc ? ja(this, e + 4, t) : this.skip(4);
	}
	decodeApngChunk(e, t) {
		let n = this.offset;
		switch (t !== "fdAT" && t !== "IDAT" && this._writingDataChunks && this.pushDataToFrame(), t) {
			case "acTL":
				this.decodeACTL();
				break;
			case "fcTL":
				this.decodeFCTL();
				break;
			case "fdAT":
				this.decodeFDAT(e);
				break;
			default: this.decodeChunk(e, t), this.offset = n + e;
		}
		if (this.offset - n !== e) throw Error(`Length mismatch while decoding chunk ${t}`);
		this._checkCrc ? ja(this, e + 4, t) : this.skip(4);
	}
	decodeIHDR() {
		let e = this._png;
		e.width = this.readUint32(), e.height = this.readUint32(), e.depth = mo(this.readUint8());
		let t = this.readUint8();
		this._colorType = t;
		let n;
		switch (t) {
			case oo.GREYSCALE:
				n = 1;
				break;
			case oo.TRUECOLOUR:
				n = 3;
				break;
			case oo.INDEXED_COLOUR:
				n = 1;
				break;
			case oo.GREYSCALE_ALPHA:
				n = 2;
				break;
			case oo.TRUECOLOUR_ALPHA:
				n = 4;
				break;
			case oo.UNKNOWN:
			default: throw Error(`Unknown color type: ${t}`);
		}
		if (this._png.channels = n, this._compressionMethod = this.readUint8(), this._compressionMethod !== so.DEFLATE) throw Error(`Unsupported compression method: ${this._compressionMethod}`);
		this._filterMethod = this.readUint8(), this._interlaceMethod = this.readUint8();
	}
	decodeACTL() {
		this._numberOfFrames = this.readUint32(), this._numberOfPlays = this.readUint32(), this._isAnimated = !0;
	}
	decodeFCTL() {
		let e = {
			sequenceNumber: this.readUint32(),
			width: this.readUint32(),
			height: this.readUint32(),
			xOffset: this.readUint32(),
			yOffset: this.readUint32(),
			delayNumber: this.readUint16(),
			delayDenominator: this.readUint16(),
			disposeOp: this.readUint8(),
			blendOp: this.readUint8(),
			data: /* @__PURE__ */ new Uint8Array()
		};
		this._frames.push(e);
	}
	decodePLTE(e) {
		if (e % 3 != 0) throw RangeError(`PLTE field length must be a multiple of 3. Got ${e}`);
		let t = e / 3;
		this._hasPalette = !0;
		let n = [];
		this._palette = n;
		for (let e = 0; e < t; e++) n.push([
			this.readUint8(),
			this.readUint8(),
			this.readUint8()
		]);
	}
	decodeIDAT(e) {
		this._writingDataChunks = !0;
		let t = e, n = this.offset + this.byteOffset;
		if (this._inflator.push(new Uint8Array(this.buffer, n, t)), this._inflator.err) throw Error(`Error while decompressing the data: ${this._inflator.err}`);
		this.skip(e);
	}
	decodeFDAT(e) {
		this._writingDataChunks = !0;
		let t = e, n = this.offset + this.byteOffset;
		if (n += 4, t -= 4, this._inflator.push(new Uint8Array(this.buffer, n, t)), this._inflator.err) throw Error(`Error while decompressing the data: ${this._inflator.err}`);
		this.skip(e);
	}
	decodetRNS(e) {
		switch (this._colorType) {
			case oo.GREYSCALE:
			case oo.TRUECOLOUR:
				if (e % 2 != 0) throw RangeError(`tRNS chunk length must be a multiple of 2. Got ${e}`);
				if (e / 2 > this._png.width * this._png.height) throw Error(`tRNS chunk contains more alpha values than there are pixels (${e / 2} vs ${this._png.width * this._png.height})`);
				this._hasTransparency = !0, this._transparency = new Uint16Array(e / 2);
				for (let t = 0; t < e / 2; t++) this._transparency[t] = this.readUint16();
				break;
			case oo.INDEXED_COLOUR: {
				if (e > this._palette.length) throw Error(`tRNS chunk contains more alpha values than there are palette colors (${e} vs ${this._palette.length})`);
				let t = 0;
				for (; t < e; t++) {
					let e = this.readByte();
					this._palette[t].push(e);
				}
				for (; t < this._palette.length; t++) this._palette[t].push(255);
				break;
			}
			case oo.UNKNOWN:
			case oo.GREYSCALE_ALPHA:
			case oo.TRUECOLOUR_ALPHA:
			default: throw Error(`tRNS chunk is not supported for color type ${this._colorType}`);
		}
	}
	decodeiCCP(e) {
		let t = io(this), n = this.readUint8();
		if (n !== so.DEFLATE) throw Error(`Unsupported iCCP compression method: ${n}`);
		let r = this.readBytes(e - t.length - 2);
		this._png.iccEmbeddedProfile = {
			name: t,
			profile: Ea(r)
		};
	}
	decodepHYs() {
		let e = this.readUint32(), t = this.readUint32(), n = this.readByte();
		this._png.resolution = {
			x: e,
			y: t,
			unit: n
		};
	}
	decodeApngImage() {
		this._apng.width = this._png.width, this._apng.height = this._png.height, this._apng.channels = this._png.channels, this._apng.depth = this._png.depth, this._apng.numberOfFrames = this._numberOfFrames, this._apng.numberOfPlays = this._numberOfPlays, this._apng.text = this._png.text, this._apng.resolution = this._png.resolution;
		for (let e = 0; e < this._numberOfFrames; e++) {
			let t = {
				sequenceNumber: this._frames[e].sequenceNumber,
				delayNumber: this._frames[e].delayNumber,
				delayDenominator: this._frames[e].delayDenominator,
				data: this._apng.depth === 8 ? new Uint8Array(this._apng.width * this._apng.height * this._apng.channels) : new Uint16Array(this._apng.width * this._apng.height * this._apng.channels)
			}, n = this._frames.at(e);
			if (n) {
				if (n.data = Ka({
					data: n.data,
					width: n.width,
					height: n.height,
					channels: this._apng.channels,
					depth: this._apng.depth
				}), this._hasPalette && (this._apng.palette = this._palette), this._hasTransparency && (this._apng.transparency = this._transparency), e === 0 || n.xOffset === 0 && n.yOffset === 0 && n.width === this._png.width && n.height === this._png.height) t.data = n.data;
				else {
					let r = this._apng.frames.at(e - 1);
					this.disposeFrame(n, r, t), this.addFrameDataToCanvas(t, n);
				}
				this._apng.frames.push(t);
			}
		}
		return this._apng;
	}
	disposeFrame(e, t, n) {
		switch (e.disposeOp) {
			case uo.NONE: break;
			case uo.BACKGROUND:
				for (let t = 0; t < this._png.height; t++) for (let r = 0; r < this._png.width; r++) {
					let i = (t * e.width + r) * this._png.channels;
					for (let e = 0; e < this._png.channels; e++) n.data[i + e] = 0;
				}
				break;
			case uo.PREVIOUS:
				n.data.set(t.data);
				break;
			default: throw Error("Unknown disposeOp");
		}
	}
	addFrameDataToCanvas(e, t) {
		let n = 1 << this._png.depth, r = (e, n) => ({
			index: ((e + t.yOffset) * this._png.width + t.xOffset + n) * this._png.channels,
			frameIndex: (e * t.width + n) * this._png.channels
		});
		switch (t.blendOp) {
			case fo.SOURCE:
				for (let n = 0; n < t.height; n++) for (let i = 0; i < t.width; i++) {
					let { index: a, frameIndex: o } = r(n, i);
					for (let n = 0; n < this._png.channels; n++) e.data[a + n] = t.data[o + n];
				}
				break;
			case fo.OVER:
				for (let i = 0; i < t.height; i++) for (let a = 0; a < t.width; a++) {
					let { index: o, frameIndex: s } = r(i, a);
					for (let r = 0; r < this._png.channels; r++) {
						let i = t.data[s + this._png.channels - 1] / n, a = r % (this._png.channels - 1) == 0 ? 1 : t.data[s + r], c = Math.floor(i * a + (1 - i) * e.data[o + r]);
						e.data[o + r] += c;
					}
				}
				break;
			default: throw Error("Unknown blendOp");
		}
	}
	decodeImage() {
		if (this._inflator.err) throw Error(`Error while decompressing the data: ${this._inflator.err}`);
		let e = this._isAnimated ? (this._frames?.at(0)).data : this._inflator.result;
		if (this._filterMethod !== co.ADAPTIVE) throw Error(`Filter method ${this._filterMethod} not supported`);
		if (this._interlaceMethod === lo.NO_INTERLACE) this._png.data = Ka({
			data: e,
			width: this._png.width,
			height: this._png.height,
			channels: this._png.channels,
			depth: this._png.depth
		});
		else if (this._interlaceMethod === lo.ADAM7) this._png.data = Va({
			data: e,
			width: this._png.width,
			height: this._png.height,
			channels: this._png.channels,
			depth: this._png.depth
		});
		else throw Error(`Interlace method ${this._interlaceMethod} not supported`);
		this._hasPalette && (this._png.palette = this._palette), this._hasTransparency && (this._png.transparency = this._transparency);
	}
	pushDataToFrame() {
		let e = this._inflator.result, t = this._frames.at(-1);
		t ? t.data = e : this._frames.push({
			sequenceNumber: 0,
			width: this._png.width,
			height: this._png.height,
			xOffset: 0,
			yOffset: 0,
			delayNumber: 0,
			delayDenominator: 0,
			disposeOp: uo.NONE,
			blendOp: fo.SOURCE,
			data: e
		}), this._inflator = new Ta(), this._writingDataChunks = !1;
	}
};
function mo(e) {
	if (e !== 1 && e !== 2 && e !== 4 && e !== 8 && e !== 16) throw Error(`invalid bit depth: ${e}`);
	return e;
}
// node_modules/fast-png/lib-esm/types.js
var ho;
(function(e) {
	e[e.UNKNOWN = 0] = "UNKNOWN", e[e.METRE = 1] = "METRE";
})(ho ||= {});
// node_modules/fast-png/lib-esm/index.js
function go(e, t) {
	return new po(e, t).decode();
}
// node_modules/jspdf/dist/jspdf.es.min.js
var X = function() {
	return typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : this;
}();
function _o() {
	X.console && typeof X.console.log == "function" && X.console.log.apply(X.console, arguments);
}
var vo = {
	log: _o,
	warn: function(e) {
		X.console && (typeof X.console.warn == "function" ? X.console.warn.apply(X.console, arguments) : _o.call(null, arguments));
	},
	error: function(e) {
		X.console && (typeof X.console.error == "function" ? X.console.error.apply(X.console, arguments) : _o(e));
	}
};
function yo(e, t, n) {
	var r = new XMLHttpRequest();
	r.open("GET", e), r.responseType = "blob", r.onload = function() {
		So(r.response, t, n);
	}, r.onerror = function() {
		vo.error("could not download file");
	}, r.send();
}
function bo(e) {
	var t = new XMLHttpRequest();
	t.open("HEAD", e, !1);
	try {
		t.send();
	} catch {}
	return t.status >= 200 && t.status <= 299;
}
function xo(e) {
	try {
		e.dispatchEvent(new MouseEvent("click"));
	} catch {
		var t = document.createEvent("MouseEvents");
		t.initMouseEvent("click", !0, !0, window, 0, 0, 0, 80, 20, !1, !1, !1, !1, 0, null), e.dispatchEvent(t);
	}
}
var So = X.saveAs || ((typeof window > "u" ? "undefined" : t(window)) !== "object" || window !== X ? function() {} : typeof HTMLAnchorElement < "u" && "download" in HTMLAnchorElement.prototype ? function(e, t, n) {
	var r = X.URL || X.webkitURL, i = document.createElement("a");
	t = t || e.name || "download", i.download = t, i.rel = "noopener", typeof e == "string" ? (i.href = e, i.origin === location.origin ? xo(i) : bo(i.href) ? yo(e, t, n) : xo(i, i.target = "_blank")) : (i.href = r.createObjectURL(e), setTimeout(function() {
		r.revokeObjectURL(i.href);
	}, 4e4), setTimeout(function() {
		xo(i);
	}, 0));
} : "msSaveOrOpenBlob" in navigator ? function(e, n, r) {
	if (n = n || e.name || "download", typeof e == "string") {
		if (bo(e)) yo(e, n, r);
		else {
			var i = document.createElement("a");
			i.href = e, i.target = "_blank", setTimeout(function() {
				xo(i);
			});
		}
	} else navigator.msSaveOrOpenBlob(function(e, n) {
		return n === void 0 ? n = { autoBom: !1 } : t(n) !== "object" && (vo.warn("Deprecated: Expected third argument to be a object"), n = { autoBom: !n }), n.autoBom && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(e.type) ? new Blob(["﻿", e], { type: e.type }) : e;
	}(e, r), n);
} : function(e, n, r, i) {
	if ((i ||= open("", "_blank")) && (i.document.title = i.document.body.innerText = "downloading..."), typeof e == "string") return yo(e, n, r);
	var a = e.type === "application/octet-stream", o = /constructor/i.test(X.HTMLElement) || X.safari, s = /CriOS\/[\d]+/.test(navigator.userAgent);
	if ((s || a && o) && (typeof FileReader > "u" ? "undefined" : t(FileReader)) === "object") {
		var c = new FileReader();
		c.onloadend = function() {
			var e = c.result;
			e = s ? e : e.replace(/^data:[^;]*;/, "data:attachment/file;"), i ? i.location.href = e : location = e, i = null;
		}, c.readAsDataURL(e);
	} else {
		var l = X.URL || X.webkitURL, u = l.createObjectURL(e);
		i ? i.location = u : location.href = u, i = null, setTimeout(function() {
			l.revokeObjectURL(u);
		}, 4e4);
	}
});
function Co(e) {
	var t;
	e ||= "", this.ok = !1, e.charAt(0) == "#" && (e = e.substr(1, 6)), e = {
		aliceblue: "f0f8ff",
		antiquewhite: "faebd7",
		aqua: "00ffff",
		aquamarine: "7fffd4",
		azure: "f0ffff",
		beige: "f5f5dc",
		bisque: "ffe4c4",
		black: "000000",
		blanchedalmond: "ffebcd",
		blue: "0000ff",
		blueviolet: "8a2be2",
		brown: "a52a2a",
		burlywood: "deb887",
		cadetblue: "5f9ea0",
		chartreuse: "7fff00",
		chocolate: "d2691e",
		coral: "ff7f50",
		cornflowerblue: "6495ed",
		cornsilk: "fff8dc",
		crimson: "dc143c",
		cyan: "00ffff",
		darkblue: "00008b",
		darkcyan: "008b8b",
		darkgoldenrod: "b8860b",
		darkgray: "a9a9a9",
		darkgreen: "006400",
		darkkhaki: "bdb76b",
		darkmagenta: "8b008b",
		darkolivegreen: "556b2f",
		darkorange: "ff8c00",
		darkorchid: "9932cc",
		darkred: "8b0000",
		darksalmon: "e9967a",
		darkseagreen: "8fbc8f",
		darkslateblue: "483d8b",
		darkslategray: "2f4f4f",
		darkturquoise: "00ced1",
		darkviolet: "9400d3",
		deeppink: "ff1493",
		deepskyblue: "00bfff",
		dimgray: "696969",
		dodgerblue: "1e90ff",
		feldspar: "d19275",
		firebrick: "b22222",
		floralwhite: "fffaf0",
		forestgreen: "228b22",
		fuchsia: "ff00ff",
		gainsboro: "dcdcdc",
		ghostwhite: "f8f8ff",
		gold: "ffd700",
		goldenrod: "daa520",
		gray: "808080",
		green: "008000",
		greenyellow: "adff2f",
		honeydew: "f0fff0",
		hotpink: "ff69b4",
		indianred: "cd5c5c",
		indigo: "4b0082",
		ivory: "fffff0",
		khaki: "f0e68c",
		lavender: "e6e6fa",
		lavenderblush: "fff0f5",
		lawngreen: "7cfc00",
		lemonchiffon: "fffacd",
		lightblue: "add8e6",
		lightcoral: "f08080",
		lightcyan: "e0ffff",
		lightgoldenrodyellow: "fafad2",
		lightgrey: "d3d3d3",
		lightgreen: "90ee90",
		lightpink: "ffb6c1",
		lightsalmon: "ffa07a",
		lightseagreen: "20b2aa",
		lightskyblue: "87cefa",
		lightslateblue: "8470ff",
		lightslategray: "778899",
		lightsteelblue: "b0c4de",
		lightyellow: "ffffe0",
		lime: "00ff00",
		limegreen: "32cd32",
		linen: "faf0e6",
		magenta: "ff00ff",
		maroon: "800000",
		mediumaquamarine: "66cdaa",
		mediumblue: "0000cd",
		mediumorchid: "ba55d3",
		mediumpurple: "9370d8",
		mediumseagreen: "3cb371",
		mediumslateblue: "7b68ee",
		mediumspringgreen: "00fa9a",
		mediumturquoise: "48d1cc",
		mediumvioletred: "c71585",
		midnightblue: "191970",
		mintcream: "f5fffa",
		mistyrose: "ffe4e1",
		moccasin: "ffe4b5",
		navajowhite: "ffdead",
		navy: "000080",
		oldlace: "fdf5e6",
		olive: "808000",
		olivedrab: "6b8e23",
		orange: "ffa500",
		orangered: "ff4500",
		orchid: "da70d6",
		palegoldenrod: "eee8aa",
		palegreen: "98fb98",
		paleturquoise: "afeeee",
		palevioletred: "d87093",
		papayawhip: "ffefd5",
		peachpuff: "ffdab9",
		peru: "cd853f",
		pink: "ffc0cb",
		plum: "dda0dd",
		powderblue: "b0e0e6",
		purple: "800080",
		red: "ff0000",
		rosybrown: "bc8f8f",
		royalblue: "4169e1",
		saddlebrown: "8b4513",
		salmon: "fa8072",
		sandybrown: "f4a460",
		seagreen: "2e8b57",
		seashell: "fff5ee",
		sienna: "a0522d",
		silver: "c0c0c0",
		skyblue: "87ceeb",
		slateblue: "6a5acd",
		slategray: "708090",
		snow: "fffafa",
		springgreen: "00ff7f",
		steelblue: "4682b4",
		tan: "d2b48c",
		teal: "008080",
		thistle: "d8bfd8",
		tomato: "ff6347",
		turquoise: "40e0d0",
		violet: "ee82ee",
		violetred: "d02090",
		wheat: "f5deb3",
		white: "ffffff",
		whitesmoke: "f5f5f5",
		yellow: "ffff00",
		yellowgreen: "9acd32"
	}[e = (e = e.replace(/ /g, "")).toLowerCase()] || e;
	for (var n = [
		{
			re: /^rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$/,
			example: ["rgb(123, 234, 45)", "rgb(255,234,245)"],
			process: function(e) {
				return [
					parseInt(e[1]),
					parseInt(e[2]),
					parseInt(e[3])
				];
			}
		},
		{
			re: /^(\w{2})(\w{2})(\w{2})$/,
			example: ["#00ff00", "336699"],
			process: function(e) {
				return [
					parseInt(e[1], 16),
					parseInt(e[2], 16),
					parseInt(e[3], 16)
				];
			}
		},
		{
			re: /^(\w{1})(\w{1})(\w{1})$/,
			example: ["#fb0", "f0f"],
			process: function(e) {
				return [
					parseInt(e[1] + e[1], 16),
					parseInt(e[2] + e[2], 16),
					parseInt(e[3] + e[3], 16)
				];
			}
		}
	], r = 0; r < n.length; r++) {
		var i = n[r].re, a = n[r].process, o = i.exec(e);
		o && (t = a(o), this.r = t[0], this.g = t[1], this.b = t[2], this.ok = !0);
	}
	this.r = this.r < 0 || isNaN(this.r) ? 0 : this.r > 255 ? 255 : this.r, this.g = this.g < 0 || isNaN(this.g) ? 0 : this.g > 255 ? 255 : this.g, this.b = this.b < 0 || isNaN(this.b) ? 0 : this.b > 255 ? 255 : this.b, this.toRGB = function() {
		return "rgb(" + this.r + ", " + this.g + ", " + this.b + ")";
	}, this.toHex = function() {
		var e = this.r.toString(16), t = this.g.toString(16), n = this.b.toString(16);
		return e.length == 1 && (e = "0" + e), t.length == 1 && (t = "0" + t), n.length == 1 && (n = "0" + n), "#" + e + t + n;
	};
}
var wo = X.atob.bind(X), To = X.btoa.bind(X);
function Eo(e, t) {
	var n = e[0], r = e[1], i = e[2], a = e[3];
	n = Oo(n, r, i, a, t[0], 7, -680876936), a = Oo(a, n, r, i, t[1], 12, -389564586), i = Oo(i, a, n, r, t[2], 17, 606105819), r = Oo(r, i, a, n, t[3], 22, -1044525330), n = Oo(n, r, i, a, t[4], 7, -176418897), a = Oo(a, n, r, i, t[5], 12, 1200080426), i = Oo(i, a, n, r, t[6], 17, -1473231341), r = Oo(r, i, a, n, t[7], 22, -45705983), n = Oo(n, r, i, a, t[8], 7, 1770035416), a = Oo(a, n, r, i, t[9], 12, -1958414417), i = Oo(i, a, n, r, t[10], 17, -42063), r = Oo(r, i, a, n, t[11], 22, -1990404162), n = Oo(n, r, i, a, t[12], 7, 1804603682), a = Oo(a, n, r, i, t[13], 12, -40341101), i = Oo(i, a, n, r, t[14], 17, -1502002290), n = ko(n, r = Oo(r, i, a, n, t[15], 22, 1236535329), i, a, t[1], 5, -165796510), a = ko(a, n, r, i, t[6], 9, -1069501632), i = ko(i, a, n, r, t[11], 14, 643717713), r = ko(r, i, a, n, t[0], 20, -373897302), n = ko(n, r, i, a, t[5], 5, -701558691), a = ko(a, n, r, i, t[10], 9, 38016083), i = ko(i, a, n, r, t[15], 14, -660478335), r = ko(r, i, a, n, t[4], 20, -405537848), n = ko(n, r, i, a, t[9], 5, 568446438), a = ko(a, n, r, i, t[14], 9, -1019803690), i = ko(i, a, n, r, t[3], 14, -187363961), r = ko(r, i, a, n, t[8], 20, 1163531501), n = ko(n, r, i, a, t[13], 5, -1444681467), a = ko(a, n, r, i, t[2], 9, -51403784), i = ko(i, a, n, r, t[7], 14, 1735328473), n = Ao(n, r = ko(r, i, a, n, t[12], 20, -1926607734), i, a, t[5], 4, -378558), a = Ao(a, n, r, i, t[8], 11, -2022574463), i = Ao(i, a, n, r, t[11], 16, 1839030562), r = Ao(r, i, a, n, t[14], 23, -35309556), n = Ao(n, r, i, a, t[1], 4, -1530992060), a = Ao(a, n, r, i, t[4], 11, 1272893353), i = Ao(i, a, n, r, t[7], 16, -155497632), r = Ao(r, i, a, n, t[10], 23, -1094730640), n = Ao(n, r, i, a, t[13], 4, 681279174), a = Ao(a, n, r, i, t[0], 11, -358537222), i = Ao(i, a, n, r, t[3], 16, -722521979), r = Ao(r, i, a, n, t[6], 23, 76029189), n = Ao(n, r, i, a, t[9], 4, -640364487), a = Ao(a, n, r, i, t[12], 11, -421815835), i = Ao(i, a, n, r, t[15], 16, 530742520), n = jo(n, r = Ao(r, i, a, n, t[2], 23, -995338651), i, a, t[0], 6, -198630844), a = jo(a, n, r, i, t[7], 10, 1126891415), i = jo(i, a, n, r, t[14], 15, -1416354905), r = jo(r, i, a, n, t[5], 21, -57434055), n = jo(n, r, i, a, t[12], 6, 1700485571), a = jo(a, n, r, i, t[3], 10, -1894986606), i = jo(i, a, n, r, t[10], 15, -1051523), r = jo(r, i, a, n, t[1], 21, -2054922799), n = jo(n, r, i, a, t[8], 6, 1873313359), a = jo(a, n, r, i, t[15], 10, -30611744), i = jo(i, a, n, r, t[6], 15, -1560198380), r = jo(r, i, a, n, t[13], 21, 1309151649), n = jo(n, r, i, a, t[4], 6, -145523070), a = jo(a, n, r, i, t[11], 10, -1120210379), i = jo(i, a, n, r, t[2], 15, 718787259), r = jo(r, i, a, n, t[9], 21, -343485551), e[0] = zo(n, e[0]), e[1] = zo(r, e[1]), e[2] = zo(i, e[2]), e[3] = zo(a, e[3]);
}
function Do(e, t, n, r, i, a) {
	return t = zo(zo(t, e), zo(r, a)), zo(t << i | t >>> 32 - i, n);
}
function Oo(e, t, n, r, i, a, o) {
	return Do(t & n | ~t & r, e, t, i, a, o);
}
function ko(e, t, n, r, i, a, o) {
	return Do(t & r | n & ~r, e, t, i, a, o);
}
function Ao(e, t, n, r, i, a, o) {
	return Do(t ^ n ^ r, e, t, i, a, o);
}
function jo(e, t, n, r, i, a, o) {
	return Do(n ^ (t | ~r), e, t, i, a, o);
}
function Mo(e) {
	var t, n = e.length, r = [
		1732584193,
		-271733879,
		-1732584194,
		271733878
	];
	for (t = 64; t <= e.length; t += 64) Eo(r, No(e.substring(t - 64, t)));
	e = e.substring(t - 64);
	var i = [
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	];
	for (t = 0; t < e.length; t++) i[t >> 2] |= e.charCodeAt(t) << (t % 4 << 3);
	if (i[t >> 2] |= 128 << (t % 4 << 3), t > 55) for (Eo(r, i), t = 0; t < 16; t++) i[t] = 0;
	return i[14] = 8 * n, Eo(r, i), r;
}
function No(e) {
	var t, n = [];
	for (t = 0; t < 64; t += 4) n[t >> 2] = e.charCodeAt(t) + (e.charCodeAt(t + 1) << 8) + (e.charCodeAt(t + 2) << 16) + (e.charCodeAt(t + 3) << 24);
	return n;
}
var Po = "0123456789abcdef".split("");
function Fo(e) {
	for (var t = "", n = 0; n < 4; n++) t += Po[e >> 8 * n + 4 & 15] + Po[e >> 8 * n & 15];
	return t;
}
function Io(e) {
	return String.fromCharCode(255 & e, (65280 & e) >> 8, (16711680 & e) >> 16, (4278190080 & e) >> 24);
}
function Lo(e) {
	return Mo(e).map(Io).join("");
}
var Ro = function(e) {
	for (var t = 0; t < e.length; t++) e[t] = Fo(e[t]);
	return e.join("");
}(Mo("hello")) != "5d41402abc4b2a76b9719d911017c592";
function zo(e, t) {
	if (Ro) {
		var n = (65535 & e) + (65535 & t);
		return (e >> 16) + (t >> 16) + (n >> 16) << 16 | 65535 & n;
	}
	return e + t | 0;
}
function Bo(e, t) {
	var n, r, i, a;
	if (e !== n) {
		for (var o = (i = e, a = 1 + (256 / e.length | 0), Array(a + 1).join(i)), s = [], c = 0; c < 256; c++) s[c] = c;
		var l = 0;
		for (c = 0; c < 256; c++) {
			var u = s[c];
			l = (l + u + o.charCodeAt(c)) % 256, s[c] = s[l], s[l] = u;
		}
		n = e, r = s;
	} else s = r;
	var d = t.length, f = 0, p = 0, m = "";
	for (c = 0; c < d; c++) p = (p + (u = s[f = (f + 1) % 256])) % 256, s[f] = s[p], s[p] = u, o = s[(s[f] + s[p]) % 256], m += String.fromCharCode(t.charCodeAt(c) ^ o);
	return m;
}
var Vo = {
	print: 4,
	modify: 8,
	copy: 16,
	"annot-forms": 32
};
function Ho(e, t, n, r) {
	this.v = 1, this.r = 2;
	var i = 192;
	e.forEach(function(e) {
		if (Vo.perm !== void 0) throw Error("Invalid permission: " + e);
		i += Vo[e];
	}), this.padding = "(¿N^NuAd\0NVÿú\b..\0¶Ðh>/\f©þdSiz";
	var a = (t + this.padding).substr(0, 32), o = (n + this.padding).substr(0, 32);
	this.O = this.processOwnerPassword(a, o), this.P = -(1 + (255 ^ i)), this.encryptionKey = Lo(a + this.O + this.lsbFirstWord(this.P) + this.hexToBytes(r)).substr(0, 5), this.U = Bo(this.encryptionKey, this.padding);
}
function Uo(e) {
	if (/[^\u0000-\u00ff]/.test(e)) throw Error("Invalid PDF Name Object: " + e + ", Only accept ASCII characters.");
	for (var t = "", n = e.length, r = 0; r < n; r++) {
		var i = e.charCodeAt(r);
		t += i < 33 || i === 35 || i === 37 || i === 40 || i === 41 || i === 47 || i === 60 || i === 62 || i === 91 || i === 93 || i === 123 || i === 125 || i > 126 ? "#" + ("0" + i.toString(16)).slice(-2) : e[r];
	}
	return t;
}
function Wo(e) {
	if (t(e) !== "object") throw Error("Invalid Context passed to initialize PubSub (jsPDF-module)");
	var n = {};
	this.subscribe = function(e, t, r) {
		if (r ||= !1, typeof e != "string" || typeof t != "function" || typeof r != "boolean") throw Error("Invalid arguments passed to PubSub.subscribe (jsPDF-module)");
		n.hasOwnProperty(e) || (n[e] = {});
		var i = Math.random().toString(35);
		return n[e][i] = [t, !!r], i;
	}, this.unsubscribe = function(e) {
		for (var t in n) if (n[t][e]) return delete n[t][e], Object.keys(n[t]).length === 0 && delete n[t], !0;
		return !1;
	}, this.publish = function(t) {
		if (n.hasOwnProperty(t)) {
			var r = Array.prototype.slice.call(arguments, 1), i = [];
			for (var a in n[t]) {
				var o = n[t][a];
				try {
					o[0].apply(e, r);
				} catch (e) {
					X.console && vo.error("jsPDF PubSub Error", e.message, e);
				}
				o[1] && i.push(a);
			}
			i.length && i.forEach(this.unsubscribe);
		}
	}, this.getTopics = function() {
		return n;
	};
}
function Go(e) {
	if (!(this instanceof Go)) return new Go(e);
	var t = "opacity,stroke-opacity".split(",");
	for (var n in e) e.hasOwnProperty(n) && t.indexOf(n) >= 0 && (this[n] = e[n]);
	this.id = "", this.objectNumber = -1;
}
function Ko(e, t) {
	this.gState = e, this.matrix = t, this.id = "", this.objectNumber = -1;
}
function qo(e, t, n, r, i) {
	if (!(this instanceof qo)) return new qo(e, t, n, r, i);
	this.type = e === "axial" ? 2 : 3, this.coords = t, this.colors = n, Ko.call(this, r, i);
}
function Jo(e, t, n, r, i) {
	if (!(this instanceof Jo)) return new Jo(e, t, n, r, i);
	this.boundingBox = e, this.xStep = t, this.yStep = n, this.stream = "", this.cloneIndex = 0, Ko.call(this, r, i);
}
function Z(e) {
	var n, r = typeof arguments[0] == "string" ? arguments[0] : "p", i = arguments[1], a = arguments[2], o = arguments[3], s = [], c = 1, l = 16, u = "S", d = null;
	t(e ||= {}) === "object" && (r = e.orientation, i = e.unit || i, a = e.format || a, o = e.compress || e.compressPdf || o, (d = e.encryption || null) !== null && (d.userPassword = d.userPassword || "", d.ownerPassword = d.ownerPassword || "", d.userPermissions = d.userPermissions || []), c = typeof e.userUnit == "number" ? Math.abs(e.userUnit) : 1, e.precision !== void 0 && (n = e.precision), e.floatPrecision !== void 0 && (l = e.floatPrecision), u = e.defaultPathOperation || "S"), s = e.filters || (!0 === o ? ["FlateEncode"] : s), i ||= "mm", r = ("" + (r || "P")).toLowerCase();
	var f = e.putOnlyUsedFonts || !1, p = {}, m = {
		internal: {},
		__private__: {}
	};
	m.__private__.PubSub = Wo;
	var h = "1.3", g = m.__private__.getPdfVersion = function() {
		return h;
	};
	m.__private__.setPdfVersion = function(e) {
		h = e;
	};
	var _ = {
		a0: [2383.94, 3370.39],
		a1: [1683.78, 2383.94],
		a2: [1190.55, 1683.78],
		a3: [841.89, 1190.55],
		a4: [595.28, 841.89],
		a5: [419.53, 595.28],
		a6: [297.64, 419.53],
		a7: [209.76, 297.64],
		a8: [147.4, 209.76],
		a9: [104.88, 147.4],
		a10: [73.7, 104.88],
		b0: [2834.65, 4008.19],
		b1: [2004.09, 2834.65],
		b2: [1417.32, 2004.09],
		b3: [1000.63, 1417.32],
		b4: [708.66, 1000.63],
		b5: [498.9, 708.66],
		b6: [354.33, 498.9],
		b7: [249.45, 354.33],
		b8: [175.75, 249.45],
		b9: [124.72, 175.75],
		b10: [87.87, 124.72],
		c0: [2599.37, 3676.54],
		c1: [1836.85, 2599.37],
		c2: [1298.27, 1836.85],
		c3: [918.43, 1298.27],
		c4: [649.13, 918.43],
		c5: [459.21, 649.13],
		c6: [323.15, 459.21],
		c7: [229.61, 323.15],
		c8: [161.57, 229.61],
		c9: [113.39, 161.57],
		c10: [79.37, 113.39],
		dl: [311.81, 623.62],
		letter: [612, 792],
		"government-letter": [576, 756],
		legal: [612, 1008],
		"junior-legal": [576, 360],
		ledger: [1224, 792],
		tabloid: [792, 1224],
		"credit-card": [153, 243]
	};
	m.__private__.getPageFormats = function() {
		return _;
	};
	var v = m.__private__.getPageFormat = function(e) {
		return _[e];
	};
	a ||= "a4";
	var y = "compat", b = "advanced", x = y;
	function S() {
		this.saveGraphicsState(), K(new J(be, 0, 0, -be, 0, bn() * be).toString() + " cm"), this.setFontSize(this.getFontSize() / be), u = "n", x = b;
	}
	function C() {
		this.restoreGraphicsState(), u = "S", x = y;
	}
	var w = m.__private__.combineFontStyleAndFontWeight = function(e, t) {
		if (e == "bold" && t == "normal" || e == "bold" && t == 400 || e == "normal" && t == "italic" || e == "bold" && t == "italic") throw Error("Invalid Combination of fontweight and fontstyle");
		return t && (e = t == 400 || t === "normal" ? e === "italic" ? "italic" : "normal" : t != 700 && t !== "bold" || e !== "normal" ? (t == 700 ? "bold" : t) + "" + e : "bold"), e;
	};
	m.advancedAPI = function(e) {
		var t = x === y;
		return t && S.call(this), typeof e != "function" || (e(this), t && C.call(this)), this;
	}, m.compatAPI = function(e) {
		var t = x === b;
		return t && C.call(this), typeof e != "function" || (e(this), t && S.call(this)), this;
	}, m.isAdvancedAPI = function() {
		return x === b;
	};
	var T, E = function(e) {
		if (x !== b) throw Error(e + " is only available in 'advanced' API mode. You need to call advancedAPI() first.");
	}, D = m.roundToPrecision = m.__private__.roundToPrecision = function(e, t) {
		var r = n || t;
		if (isNaN(e) || isNaN(r)) throw Error("Invalid argument passed to jsPDF.roundToPrecision");
		return e.toFixed(r).replace(/0+$/, "");
	};
	T = m.hpf = m.__private__.hpf = typeof l == "number" ? function(e) {
		if (isNaN(e)) throw Error("Invalid argument passed to jsPDF.hpf");
		return D(e, l);
	} : l === "smart" ? function(e) {
		if (isNaN(e)) throw Error("Invalid argument passed to jsPDF.hpf");
		return D(e, e > -1 && e < 1 ? 16 : 5);
	} : function(e) {
		if (isNaN(e)) throw Error("Invalid argument passed to jsPDF.hpf");
		return D(e, 16);
	};
	var O = m.f2 = m.__private__.f2 = function(e) {
		if (isNaN(e)) throw Error("Invalid argument passed to jsPDF.f2");
		return D(e, 2);
	}, k = m.__private__.f3 = function(e) {
		if (isNaN(e)) throw Error("Invalid argument passed to jsPDF.f3");
		return D(e, 3);
	}, A = m.scale = m.__private__.scale = function(e) {
		if (isNaN(e)) throw Error("Invalid argument passed to jsPDF.scale");
		return x === y ? e * be : x === b ? e : void 0;
	}, j = function(e) {
		return A(function(e) {
			return x === y ? bn() - e : x === b ? e : void 0;
		}(e));
	};
	m.__private__.setPrecision = m.setPrecision = function(e) {
		typeof parseInt(e, 10) == "number" && (n = parseInt(e, 10));
	};
	var M, N = "00000000000000000000000000000000", P = m.__private__.getFileId = function() {
		return N;
	}, F = m.__private__.setFileId = function(e) {
		return N = e !== void 0 && /^[a-fA-F0-9]{32}$/.test(e) ? e.toUpperCase() : N.split("").map(function() {
			return "ABCDEF0123456789".charAt(Math.floor(16 * Math.random()));
		}).join(""), d !== null && (Tt = new Ho(d.userPermissions, d.userPassword, d.ownerPassword, N)), N;
	};
	m.setFileId = function(e) {
		return F(e), this;
	}, m.getFileId = function() {
		return P();
	};
	var I = m.__private__.convertDateToPDFDate = function(e) {
		var t = e.getTimezoneOffset(), n = t < 0 ? "+" : "-", r = Math.floor(Math.abs(t / 60)), i = Math.abs(t % 60), a = [
			n,
			B(r),
			"'",
			B(i),
			"'"
		].join("");
		return [
			"D:",
			e.getFullYear(),
			B(e.getMonth() + 1),
			B(e.getDate()),
			B(e.getHours()),
			B(e.getMinutes()),
			B(e.getSeconds()),
			a
		].join("");
	}, L = m.__private__.convertPDFDateToDate = function(e) {
		var t = parseInt(e.substr(2, 4), 10), n = parseInt(e.substr(6, 2), 10) - 1, r = parseInt(e.substr(8, 2), 10), i = parseInt(e.substr(10, 2), 10), a = parseInt(e.substr(12, 2), 10), o = parseInt(e.substr(14, 2), 10);
		return new Date(t, n, r, i, a, o, 0);
	}, ee = m.__private__.setCreationDate = function(e) {
		var t;
		if (e === void 0 && (e = /* @__PURE__ */ new Date()), e instanceof Date) t = I(e);
		else {
			if (!/^D:(20[0-2][0-9]|203[0-7]|19[7-9][0-9])(0[0-9]|1[0-2])([0-2][0-9]|3[0-1])(0[0-9]|1[0-9]|2[0-3])(0[0-9]|[1-5][0-9])(0[0-9]|[1-5][0-9])(\+0[0-9]|\+1[0-4]|-0[0-9]|-1[0-1])'(0[0-9]|[1-5][0-9])'?$/.test(e)) throw Error("Invalid argument passed to jsPDF.setCreationDate");
			t = e;
		}
		return M = t;
	}, R = m.__private__.getCreationDate = function(e) {
		var t = M;
		return e === "jsDate" && (t = L(M)), t;
	};
	m.setCreationDate = function(e) {
		return ee(e), this;
	}, m.getCreationDate = function(e) {
		return R(e);
	};
	var z, B = m.__private__.padd2 = function(e) {
		return ("0" + parseInt(e)).slice(-2);
	}, te = m.__private__.padd2Hex = function(e) {
		return ("00" + (e = e.toString())).substr(e.length);
	}, V = 0, H = [], U = [], ne = 0, W = [], G = [], re = !1, ie = U;
	m.__private__.setCustomOutputDestination = function(e) {
		re = !0, ie = e;
	};
	var ae = function(e) {
		re || (ie = e);
	};
	m.__private__.resetCustomOutputDestination = function() {
		re = !1, ie = U;
	};
	var K = m.__private__.out = function(e) {
		return e = e.toString(), ne += e.length + 1, ie.push(e), ie;
	}, oe = m.__private__.write = function(e) {
		return K(arguments.length === 1 ? e.toString() : Array.prototype.join.call(arguments, " "));
	}, se = m.__private__.getArrayBuffer = function(e) {
		for (var t = e.length, n = new ArrayBuffer(t), r = new Uint8Array(n); t--;) r[t] = e.charCodeAt(t);
		return n;
	}, ce = [
		[
			"Helvetica",
			"helvetica",
			"normal",
			"WinAnsiEncoding"
		],
		[
			"Helvetica-Bold",
			"helvetica",
			"bold",
			"WinAnsiEncoding"
		],
		[
			"Helvetica-Oblique",
			"helvetica",
			"italic",
			"WinAnsiEncoding"
		],
		[
			"Helvetica-BoldOblique",
			"helvetica",
			"bolditalic",
			"WinAnsiEncoding"
		],
		[
			"Courier",
			"courier",
			"normal",
			"WinAnsiEncoding"
		],
		[
			"Courier-Bold",
			"courier",
			"bold",
			"WinAnsiEncoding"
		],
		[
			"Courier-Oblique",
			"courier",
			"italic",
			"WinAnsiEncoding"
		],
		[
			"Courier-BoldOblique",
			"courier",
			"bolditalic",
			"WinAnsiEncoding"
		],
		[
			"Times-Roman",
			"times",
			"normal",
			"WinAnsiEncoding"
		],
		[
			"Times-Bold",
			"times",
			"bold",
			"WinAnsiEncoding"
		],
		[
			"Times-Italic",
			"times",
			"italic",
			"WinAnsiEncoding"
		],
		[
			"Times-BoldItalic",
			"times",
			"bolditalic",
			"WinAnsiEncoding"
		],
		[
			"ZapfDingbats",
			"zapfdingbats",
			"normal",
			null
		],
		[
			"Symbol",
			"symbol",
			"normal",
			null
		]
	];
	m.__private__.getStandardFonts = function() {
		return ce;
	};
	var le = e.fontSize || 16;
	m.__private__.setFontSize = m.setFontSize = function(e) {
		return le = x === b ? e / be : e, this;
	};
	var ue, de = m.__private__.getFontSize = m.getFontSize = function() {
		return x === y ? le : le * be;
	}, fe = e.R2L || !1;
	m.__private__.setR2L = m.setR2L = function(e) {
		return fe = e, this;
	}, m.__private__.getR2L = m.getR2L = function() {
		return fe;
	};
	var pe, me = m.__private__.setZoomMode = function(e) {
		if (/^(?:\d+\.\d*|\d*\.\d+|\d+)%$/.test(e)) ue = e;
		else if (isNaN(e)) {
			if ([
				void 0,
				null,
				"fullwidth",
				"fullheight",
				"fullpage",
				"original"
			].indexOf(e) === -1) throw Error("zoom must be Integer (e.g. 2), a percentage Value (e.g. 300%) or fullwidth, fullheight, fullpage, original. \"" + e + "\" is not recognized.");
			ue = e;
		} else ue = parseInt(e, 10);
	};
	m.__private__.getZoomMode = function() {
		return ue;
	};
	var he, ge = m.__private__.setPageMode = function(e) {
		if ([
			void 0,
			null,
			"UseNone",
			"UseOutlines",
			"UseThumbs",
			"FullScreen"
		].indexOf(e) == -1) throw Error("Page mode must be one of UseNone, UseOutlines, UseThumbs, or FullScreen. \"" + e + "\" is not recognized.");
		pe = e;
	};
	m.__private__.getPageMode = function() {
		return pe;
	};
	var _e = m.__private__.setLayoutMode = function(e) {
		if ([
			void 0,
			null,
			"continuous",
			"single",
			"twoleft",
			"tworight",
			"two"
		].indexOf(e) == -1) throw Error("Layout mode must be one of continuous, single, twoleft, tworight. \"" + e + "\" is not recognized.");
		he = e;
	};
	m.__private__.getLayoutMode = function() {
		return he;
	}, m.__private__.setDisplayMode = m.setDisplayMode = function(e, t, n) {
		return me(e), _e(t), ge(n), this;
	};
	var ve = {
		title: "",
		subject: "",
		author: "",
		keywords: "",
		creator: ""
	};
	m.__private__.getDocumentProperty = function(e) {
		if (Object.keys(ve).indexOf(e) === -1) throw Error("Invalid argument passed to jsPDF.getDocumentProperty");
		return ve[e];
	}, m.__private__.getDocumentProperties = function() {
		return ve;
	}, m.__private__.setDocumentProperties = m.setProperties = m.setDocumentProperties = function(e) {
		for (var t in ve) ve.hasOwnProperty(t) && e[t] && (ve[t] = e[t]);
		return this;
	}, m.__private__.setDocumentProperty = function(e, t) {
		if (Object.keys(ve).indexOf(e) === -1) throw Error("Invalid arguments passed to jsPDF.setDocumentProperty");
		return ve[e] = t;
	};
	var ye, be, xe, Se, Ce, we = {}, Te = {}, Ee = [], De = {}, Oe = {}, ke = {}, Ae = {}, je = null, Me = 0, q = [], Ne = new Wo(m), Pe = e.hotfixes || [], Fe = {}, Ie = {}, Le = [], J = function e(t, n, r, i, a, o) {
		if (!(this instanceof e)) return new e(t, n, r, i, a, o);
		isNaN(t) && (t = 1), isNaN(n) && (n = 0), isNaN(r) && (r = 0), isNaN(i) && (i = 1), isNaN(a) && (a = 0), isNaN(o) && (o = 0), this._matrix = [
			t,
			n,
			r,
			i,
			a,
			o
		];
	};
	Object.defineProperty(J.prototype, "sx", {
		get: function() {
			return this._matrix[0];
		},
		set: function(e) {
			this._matrix[0] = e;
		}
	}), Object.defineProperty(J.prototype, "shy", {
		get: function() {
			return this._matrix[1];
		},
		set: function(e) {
			this._matrix[1] = e;
		}
	}), Object.defineProperty(J.prototype, "shx", {
		get: function() {
			return this._matrix[2];
		},
		set: function(e) {
			this._matrix[2] = e;
		}
	}), Object.defineProperty(J.prototype, "sy", {
		get: function() {
			return this._matrix[3];
		},
		set: function(e) {
			this._matrix[3] = e;
		}
	}), Object.defineProperty(J.prototype, "tx", {
		get: function() {
			return this._matrix[4];
		},
		set: function(e) {
			this._matrix[4] = e;
		}
	}), Object.defineProperty(J.prototype, "ty", {
		get: function() {
			return this._matrix[5];
		},
		set: function(e) {
			this._matrix[5] = e;
		}
	}), Object.defineProperty(J.prototype, "a", {
		get: function() {
			return this._matrix[0];
		},
		set: function(e) {
			this._matrix[0] = e;
		}
	}), Object.defineProperty(J.prototype, "b", {
		get: function() {
			return this._matrix[1];
		},
		set: function(e) {
			this._matrix[1] = e;
		}
	}), Object.defineProperty(J.prototype, "c", {
		get: function() {
			return this._matrix[2];
		},
		set: function(e) {
			this._matrix[2] = e;
		}
	}), Object.defineProperty(J.prototype, "d", {
		get: function() {
			return this._matrix[3];
		},
		set: function(e) {
			this._matrix[3] = e;
		}
	}), Object.defineProperty(J.prototype, "e", {
		get: function() {
			return this._matrix[4];
		},
		set: function(e) {
			this._matrix[4] = e;
		}
	}), Object.defineProperty(J.prototype, "f", {
		get: function() {
			return this._matrix[5];
		},
		set: function(e) {
			this._matrix[5] = e;
		}
	}), Object.defineProperty(J.prototype, "rotation", { get: function() {
		return Math.atan2(this.shx, this.sx);
	} }), Object.defineProperty(J.prototype, "scaleX", { get: function() {
		return this.decompose().scale.sx;
	} }), Object.defineProperty(J.prototype, "scaleY", { get: function() {
		return this.decompose().scale.sy;
	} }), Object.defineProperty(J.prototype, "isIdentity", { get: function() {
		return this.sx === 1 && this.shy === 0 && this.shx === 0 && this.sy === 1 && this.tx === 0 && this.ty === 0;
	} }), J.prototype.join = function(e) {
		return [
			this.sx,
			this.shy,
			this.shx,
			this.sy,
			this.tx,
			this.ty
		].map(T).join(e);
	}, J.prototype.multiply = function(e) {
		return new J(e.sx * this.sx + e.shy * this.shx, e.sx * this.shy + e.shy * this.sy, e.shx * this.sx + e.sy * this.shx, e.shx * this.shy + e.sy * this.sy, e.tx * this.sx + e.ty * this.shx + this.tx, e.tx * this.shy + e.ty * this.sy + this.ty);
	}, J.prototype.decompose = function() {
		var e = this.sx, t = this.shy, n = this.shx, r = this.sy, i = this.tx, a = this.ty, o = Math.sqrt(e * e + t * t), s = (e /= o) * n + (t /= o) * r;
		n -= e * s, r -= t * s;
		var c = Math.sqrt(n * n + r * r);
		return s /= c, e * (r /= c) < t * (n /= c) && (e = -e, t = -t, s = -s, o = -o), {
			scale: new J(o, 0, 0, c, 0, 0),
			translate: new J(1, 0, 0, 1, i, a),
			rotate: new J(e, t, -t, e, 0, 0),
			skew: new J(1, 0, s, 1, 0, 0)
		};
	}, J.prototype.toString = function(e) {
		return this.join(" ");
	}, J.prototype.inversed = function() {
		var e = this.sx, t = this.shy, n = this.shx, r = this.sy, i = this.tx, a = this.ty, o = 1 / (e * r - t * n), s = r * o, c = -t * o, l = -n * o, u = e * o;
		return new J(s, c, l, u, -s * i - l * a, -c * i - u * a);
	}, J.prototype.applyToPoint = function(e) {
		return new ln(e.x * this.sx + e.y * this.shx + this.tx, e.x * this.shy + e.y * this.sy + this.ty);
	}, J.prototype.applyToRectangle = function(e) {
		var t = this.applyToPoint(e), n = this.applyToPoint(new ln(e.x + e.w, e.y + e.h));
		return new un(t.x, t.y, n.x - t.x, n.y - t.y);
	}, J.prototype.clone = function() {
		var e = this.sx, t = this.shy, n = this.shx, r = this.sy, i = this.tx, a = this.ty;
		return new J(e, t, n, r, i, a);
	}, m.Matrix = J;
	var Re = m.matrixMult = function(e, t) {
		return t.multiply(e);
	}, ze = new J(1, 0, 0, 1, 0, 0);
	m.unitMatrix = m.identityMatrix = ze;
	var Be = function(e, t) {
		if (!Oe[e]) {
			var n = (t instanceof qo ? "Sh" : "P") + (Object.keys(De).length + 1).toString(10);
			t.id = n, Oe[e] = n, De[n] = t, Ne.publish("addPattern", t);
		}
	};
	m.ShadingPattern = qo, m.TilingPattern = Jo, m.addShadingPattern = function(e, t) {
		return E("addShadingPattern()"), Be(e, t), this;
	}, m.beginTilingPattern = function(e) {
		E("beginTilingPattern()"), fn(e.boundingBox[0], e.boundingBox[1], e.boundingBox[2] - e.boundingBox[0], e.boundingBox[3] - e.boundingBox[1], e.matrix);
	}, m.endTilingPattern = function(e, t) {
		E("endTilingPattern()"), t.stream = G[z].join("\n"), Be(e, t), Ne.publish("endTilingPattern", t), Le.pop().restore();
	};
	var Ve, He = m.__private__.newObject = function() {
		var e = Ue();
		return We(e, !0), e;
	}, Ue = m.__private__.newObjectDeferred = function() {
		return V++, H[V] = function() {
			return ne;
		}, V;
	}, We = function(e, t) {
		return t = typeof t == "boolean" && t, H[e] = ne, t && K(e + " 0 obj"), e;
	}, Ge = m.__private__.newAdditionalObject = function() {
		var e = {
			objId: Ue(),
			content: ""
		};
		return W.push(e), e;
	}, Ke = Ue(), qe = Ue(), Je = m.__private__.decodeColorString = function(e) {
		var t = e.split(" ");
		if (t.length !== 2 || t[1] !== "g" && t[1] !== "G") t.length !== 5 || t[4] !== "k" && t[4] !== "K" || (t = [
			(1 - t[0]) * (1 - t[3]),
			(1 - t[1]) * (1 - t[3]),
			(1 - t[2]) * (1 - t[3]),
			"r"
		]);
		else {
			var n = parseFloat(t[0]);
			t = [
				n,
				n,
				n,
				"r"
			];
		}
		for (var r = "#", i = 0; i < 3; i++) r += ("0" + Math.floor(255 * parseFloat(t[i])).toString(16)).slice(-2);
		return r;
	}, Ye = m.__private__.encodeColorString = function(e) {
		var n;
		typeof e == "string" && (e = { ch1: e });
		var r = e.ch1, i = e.ch2, a = e.ch3, o = e.ch4, s = e.pdfColorType === "draw" ? [
			"G",
			"RG",
			"K"
		] : [
			"g",
			"rg",
			"k"
		];
		if (typeof r == "string" && r.charAt(0) !== "#") {
			var c = new Co(r);
			if (c.ok) r = c.toHex();
			else if (!/^\d*\.?\d*$/.test(r)) throw Error("Invalid color \"" + r + "\" passed to jsPDF.encodeColorString.");
		}
		if (typeof r == "string" && /^#[0-9A-Fa-f]{3}$/.test(r) && (r = "#" + r[1] + r[1] + r[2] + r[2] + r[3] + r[3]), typeof r == "string" && /^#[0-9A-Fa-f]{6}$/.test(r)) {
			var l = parseInt(r.substr(1), 16);
			r = l >> 16 & 255, i = l >> 8 & 255, a = 255 & l;
		}
		if (i === void 0 || o === void 0 && r === i && i === a) n = typeof r == "string" ? r + " " + s[0] : e.precision === 2 ? O(r / 255) + " " + s[0] : k(r / 255) + " " + s[0];
		else if (o === void 0 || t(o) === "object") {
			if (o && !isNaN(o.a) && o.a === 0) return [
				"1.",
				"1.",
				"1.",
				s[1]
			].join(" ");
			n = typeof r == "string" ? [
				r,
				i,
				a,
				s[1]
			].join(" ") : e.precision === 2 ? [
				O(r / 255),
				O(i / 255),
				O(a / 255),
				s[1]
			].join(" ") : [
				k(r / 255),
				k(i / 255),
				k(a / 255),
				s[1]
			].join(" ");
		} else n = typeof r == "string" ? [
			r,
			i,
			a,
			o,
			s[2]
		].join(" ") : e.precision === 2 ? [
			O(r),
			O(i),
			O(a),
			O(o),
			s[2]
		].join(" ") : [
			k(r),
			k(i),
			k(a),
			k(o),
			s[2]
		].join(" ");
		return n;
	}, Xe = m.__private__.getFilters = function() {
		return s;
	}, Ze = m.__private__.putStream = function(e) {
		var t = (e ||= {}).data || "", n = e.filters || Xe(), r = e.alreadyAppliedFilters || [], i = e.addLength1 || !1, a = t.length, o = e.objectId, s = function(e) {
			return e;
		};
		if (d !== null && o === void 0) throw Error("ObjectId must be passed to putStream for file encryption");
		d !== null && (s = Tt.encryptor(o, 0));
		var c = {};
		!0 === n && (n = ["FlateEncode"]);
		var l = e.additionalKeyValues || [], u = (c = Z.API.processDataByFilters === void 0 ? {
			data: t,
			reverseChain: []
		} : Z.API.processDataByFilters(t, n)).reverseChain + (Array.isArray(r) ? r.join(" ") : r.toString());
		if (c.data.length !== 0 && (l.push({
			key: "Length",
			value: c.data.length
		}), !0 === i && l.push({
			key: "Length1",
			value: a
		})), u.length != 0) {
			if (u.split("/").length - 1 == 1) l.push({
				key: "Filter",
				value: u
			});
			else {
				l.push({
					key: "Filter",
					value: "[" + u + "]"
				});
				for (var f = 0; f < l.length; f += 1) if (l[f].key === "DecodeParms") {
					for (var p = [], m = 0; m < c.reverseChain.split("/").length - 1; m += 1) p.push("null");
					p.push(l[f].value), l[f].value = "[" + p.join(" ") + "]";
				}
			}
		}
		K("<<");
		for (var h = 0; h < l.length; h++) K("/" + l[h].key + " " + l[h].value);
		K(">>"), c.data.length !== 0 && (K("stream"), K(s(c.data)), K("endstream"));
	}, Qe = m.__private__.putPage = function(e) {
		var t = e.number, n = e.data, r = e.objId, i = e.contentsObjId;
		We(r, !0), K("<</Type /Page"), K("/Parent " + e.rootDictionaryObjId + " 0 R"), K("/Resources " + e.resourceDictionaryObjId + " 0 R"), K("/MediaBox [" + parseFloat(T(e.mediaBox.bottomLeftX)) + " " + parseFloat(T(e.mediaBox.bottomLeftY)) + " " + T(e.mediaBox.topRightX) + " " + T(e.mediaBox.topRightY) + "]"), e.cropBox !== null && K("/CropBox [" + T(e.cropBox.bottomLeftX) + " " + T(e.cropBox.bottomLeftY) + " " + T(e.cropBox.topRightX) + " " + T(e.cropBox.topRightY) + "]"), e.bleedBox !== null && K("/BleedBox [" + T(e.bleedBox.bottomLeftX) + " " + T(e.bleedBox.bottomLeftY) + " " + T(e.bleedBox.topRightX) + " " + T(e.bleedBox.topRightY) + "]"), e.trimBox !== null && K("/TrimBox [" + T(e.trimBox.bottomLeftX) + " " + T(e.trimBox.bottomLeftY) + " " + T(e.trimBox.topRightX) + " " + T(e.trimBox.topRightY) + "]"), e.artBox !== null && K("/ArtBox [" + T(e.artBox.bottomLeftX) + " " + T(e.artBox.bottomLeftY) + " " + T(e.artBox.topRightX) + " " + T(e.artBox.topRightY) + "]"), typeof e.userUnit == "number" && e.userUnit !== 1 && K("/UserUnit " + e.userUnit), Ne.publish("putPage", {
			objId: r,
			pageContext: q[t],
			pageNumber: t,
			page: n
		}), K("/Contents " + i + " 0 R"), K(">>"), K("endobj");
		var a = n.join("\n");
		return x === b && (a += "\nQ"), We(i, !0), Ze({
			data: a,
			filters: Xe(),
			objectId: i
		}), K("endobj"), r;
	}, $e = m.__private__.putPages = function() {
		var e, t, n = [];
		for (e = 1; e <= Me; e++) q[e].objId = Ue(), q[e].contentsObjId = Ue();
		for (e = 1; e <= Me; e++) n.push(Qe({
			number: e,
			data: G[e],
			objId: q[e].objId,
			contentsObjId: q[e].contentsObjId,
			mediaBox: q[e].mediaBox,
			cropBox: q[e].cropBox,
			bleedBox: q[e].bleedBox,
			trimBox: q[e].trimBox,
			artBox: q[e].artBox,
			userUnit: q[e].userUnit,
			rootDictionaryObjId: Ke,
			resourceDictionaryObjId: qe
		}));
		We(Ke, !0), K("<</Type /Pages");
		var r = "/Kids [";
		for (t = 0; t < Me; t++) r += n[t] + " 0 R ";
		K(r + "]"), K("/Count " + Me), K(">>"), K("endobj"), Ne.publish("postPutPages");
	}, et = function(e) {
		Ne.publish("putFont", {
			font: e,
			out: K,
			newObject: He,
			putStream: Ze
		}), !0 !== e.isAlreadyPutted && (e.objectNumber = He(), K("<<"), K("/Type /Font"), K("/BaseFont /" + Uo(e.postScriptName)), K("/Subtype /Type1"), typeof e.encoding == "string" && K("/Encoding /" + e.encoding), K("/FirstChar 32"), K("/LastChar 255"), K(">>"), K("endobj"));
	}, tt = function(e) {
		e.objectNumber = He();
		var t = [];
		t.push({
			key: "Type",
			value: "/XObject"
		}), t.push({
			key: "Subtype",
			value: "/Form"
		}), t.push({
			key: "BBox",
			value: "[" + [
				T(e.x),
				T(e.y),
				T(e.x + e.width),
				T(e.y + e.height)
			].join(" ") + "]"
		}), t.push({
			key: "Matrix",
			value: "[" + e.matrix.toString() + "]"
		}), Ze({
			data: e.pages[1].join("\n"),
			additionalKeyValues: t,
			objectId: e.objectNumber
		}), K("endobj");
	}, nt = function(e, t) {
		t ||= 21;
		var n = He(), r = function(e, t) {
			var n, r = [], i = 1 / (t - 1);
			for (n = 0; n < 1; n += i) r.push(n);
			if (r.push(1), e[0].offset != 0) {
				var a = {
					offset: 0,
					color: e[0].color
				};
				e.unshift(a);
			}
			if (e[e.length - 1].offset != 1) {
				var o = {
					offset: 1,
					color: e[e.length - 1].color
				};
				e.push(o);
			}
			for (var s = "", c = 0, l = 0; l < r.length; l++) {
				for (n = r[l]; n > e[c + 1].offset;) c++;
				var u = e[c].offset, d = (n - u) / (e[c + 1].offset - u), f = e[c].color, p = e[c + 1].color;
				s += te(Math.round((1 - d) * f[0] + d * p[0]).toString(16)) + te(Math.round((1 - d) * f[1] + d * p[1]).toString(16)) + te(Math.round((1 - d) * f[2] + d * p[2]).toString(16));
			}
			return s.trim();
		}(e.colors, t), i = [];
		i.push({
			key: "FunctionType",
			value: "0"
		}), i.push({
			key: "Domain",
			value: "[0.0 1.0]"
		}), i.push({
			key: "Size",
			value: "[" + t + "]"
		}), i.push({
			key: "BitsPerSample",
			value: "8"
		}), i.push({
			key: "Range",
			value: "[0.0 1.0 0.0 1.0 0.0 1.0]"
		}), i.push({
			key: "Decode",
			value: "[0.0 1.0 0.0 1.0 0.0 1.0]"
		}), Ze({
			data: r,
			additionalKeyValues: i,
			alreadyAppliedFilters: ["/ASCIIHexDecode"],
			objectId: n
		}), K("endobj"), e.objectNumber = He(), K("<< /ShadingType " + e.type), K("/ColorSpace /DeviceRGB");
		var a = "/Coords [" + T(parseFloat(e.coords[0])) + " " + T(parseFloat(e.coords[1])) + " ";
		e.type === 2 ? a += T(parseFloat(e.coords[2])) + " " + T(parseFloat(e.coords[3])) : a += T(parseFloat(e.coords[2])) + " " + T(parseFloat(e.coords[3])) + " " + T(parseFloat(e.coords[4])) + " " + T(parseFloat(e.coords[5])), K(a += "]"), e.matrix && K("/Matrix [" + e.matrix.toString() + "]"), K("/Function " + n + " 0 R"), K("/Extend [true true]"), K(">>"), K("endobj");
	}, rt = function(e, t) {
		var n = Ue(), r = He();
		t.push({
			resourcesOid: n,
			objectOid: r
		}), e.objectNumber = r;
		var i = [];
		i.push({
			key: "Type",
			value: "/Pattern"
		}), i.push({
			key: "PatternType",
			value: "1"
		}), i.push({
			key: "PaintType",
			value: "1"
		}), i.push({
			key: "TilingType",
			value: "1"
		}), i.push({
			key: "BBox",
			value: "[" + e.boundingBox.map(T).join(" ") + "]"
		}), i.push({
			key: "XStep",
			value: T(e.xStep)
		}), i.push({
			key: "YStep",
			value: T(e.yStep)
		}), i.push({
			key: "Resources",
			value: n + " 0 R"
		}), e.matrix && i.push({
			key: "Matrix",
			value: "[" + e.matrix.toString() + "]"
		}), Ze({
			data: e.stream,
			additionalKeyValues: i,
			objectId: e.objectNumber
		}), K("endobj");
	}, it = function(e) {
		for (var t in e.objectNumber = He(), K("<<"), e) switch (t) {
			case "opacity":
				K("/ca " + O(e[t]));
				break;
			case "stroke-opacity": K("/CA " + O(e[t]));
		}
		K(">>"), K("endobj");
	}, at = function(e) {
		We(e.resourcesOid, !0), K("<<"), K("/ProcSet [/PDF /Text /ImageB /ImageC /ImageI]"), function() {
			for (var e in K("/Font <<"), we) we.hasOwnProperty(e) && (!1 === f || !0 === f && p.hasOwnProperty(e)) && K("/" + e + " " + we[e].objectNumber + " 0 R");
			K(">>");
		}(), function() {
			if (Object.keys(De).length > 0) {
				for (var e in K("/Shading <<"), De) De.hasOwnProperty(e) && De[e] instanceof qo && De[e].objectNumber >= 0 && K("/" + e + " " + De[e].objectNumber + " 0 R");
				Ne.publish("putShadingPatternDict"), K(">>");
			}
		}(), function(e) {
			if (Object.keys(De).length > 0) {
				for (var t in K("/Pattern <<"), De) De.hasOwnProperty(t) && De[t] instanceof m.TilingPattern && De[t].objectNumber >= 0 && De[t].objectNumber < e && K("/" + t + " " + De[t].objectNumber + " 0 R");
				Ne.publish("putTilingPatternDict"), K(">>");
			}
		}(e.objectOid), function() {
			if (Object.keys(ke).length > 0) {
				for (var e in K("/ExtGState <<"), ke) ke.hasOwnProperty(e) && ke[e].objectNumber >= 0 && K("/" + e + " " + ke[e].objectNumber + " 0 R");
				Ne.publish("putGStateDict"), K(">>");
			}
		}(), function() {
			for (var e in K("/XObject <<"), Fe) Fe.hasOwnProperty(e) && Fe[e].objectNumber >= 0 && K("/" + e + " " + Fe[e].objectNumber + " 0 R");
			Ne.publish("putXobjectDict"), K(">>");
		}(), K(">>"), K("endobj");
	}, ot = function(e) {
		Te[e.fontName] = Te[e.fontName] || {}, Te[e.fontName][e.fontStyle] = e.id;
	}, st = function(e, t, n, r, i) {
		var a = {
			id: "F" + (Object.keys(we).length + 1).toString(10),
			postScriptName: e,
			fontName: t,
			fontStyle: n,
			encoding: r,
			isStandardFont: i || !1,
			metadata: {}
		};
		return Ne.publish("addFont", {
			font: a,
			instance: this
		}), we[a.id] = a, ot(a), a.id;
	}, ct = m.__private__.pdfEscape = m.pdfEscape = function(e, t) {
		return function(e, t) {
			var n, r, i = (t ||= {}).sourceEncoding || "Unicode", a, o = t.outputEncoding, s, c, l, u;
			if ((t.autoencode || o) && we[ye].metadata && we[ye].metadata[i] && we[ye].metadata[i].encoding && (a = we[ye].metadata[i].encoding, !o && we[ye].encoding && (o = we[ye].encoding), !o && a.codePages && (o = a.codePages[0]), typeof o == "string" && (o = a[o]), o)) {
				for (c = !1, s = [], n = 0, r = e.length; n < r; n++) (l = o[e.charCodeAt(n)]) ? s.push(String.fromCharCode(l)) : s.push(e[n]), s[n].charCodeAt(0) >> 8 && (c = !0);
				e = s.join("");
			}
			for (n = e.length; c === void 0 && n !== 0;) e.charCodeAt(n - 1) >> 8 && (c = !0), n--;
			if (!c) return e;
			for (s = t.noBOM ? [] : [254, 255], n = 0, r = e.length; n < r; n++) {
				if ((u = (l = e.charCodeAt(n)) >> 8) >> 8) throw Error("Character at position " + n + " of string '" + e + "' exceeds 16bits. Cannot be encoded into UCS-2 BE");
				s.push(u), s.push(l - (u << 8));
			}
			return String.fromCharCode.apply(void 0, s);
		}(e, t).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
	}, lt = m.__private__.beginPage = function(e) {
		G[++Me] = [], q[Me] = {
			objId: 0,
			contentsObjId: 0,
			userUnit: Number(c),
			artBox: null,
			bleedBox: null,
			cropBox: null,
			trimBox: null,
			mediaBox: {
				bottomLeftX: 0,
				bottomLeftY: 0,
				topRightX: Number(e[0]),
				topRightY: Number(e[1])
			}
		}, ft(Me), ae(G[z]);
	}, ut = function(e, t) {
		var n, i, o;
		switch (r = t || r, typeof e == "string" && (n = v(e.toLowerCase()), Array.isArray(n) && (i = n[0], o = n[1])), Array.isArray(e) && (i = e[0] * be, o = e[1] * be), isNaN(i) && (i = a[0], o = a[1]), (i > 14400 || o > 14400) && (vo.warn("A page in a PDF can not be wider or taller than 14400 userUnit. jsPDF limits the width/height to 14400"), i = Math.min(14400, i), o = Math.min(14400, o)), a = [i, o], r.substr(0, 1)) {
			case "l":
				o > i && (a = [o, i]);
				break;
			case "p": i > o && (a = [o, i]);
		}
		lt(a), Gt(Ut), K($t), on !== 0 && K(on + " J"), sn !== 0 && K(sn + " j"), Ne.publish("addPage", { pageNumber: Me });
	}, dt = function(e) {
		e > 0 && e <= Me && (G.splice(e, 1), q.splice(e, 1), Me--, z > Me && (z = Me), this.setPage(z));
	}, ft = function(e) {
		e > 0 && e <= Me && (z = e);
	}, pt = m.__private__.getNumberOfPages = m.getNumberOfPages = function() {
		return G.length - 1;
	}, mt = function(e, t, n) {
		var r, i = void 0;
		return n ||= {}, e = e === void 0 ? we[ye].fontName : e, t = t === void 0 ? we[ye].fontStyle : t, r = e.toLowerCase(), Te[r] !== void 0 && Te[r][t] !== void 0 ? i = Te[r][t] : Te[e] !== void 0 && Te[e][t] !== void 0 ? i = Te[e][t] : !1 === n.disableWarning && vo.warn("Unable to look up font label for font '" + e + "', '" + t + "'. Refer to getFontList() for available fonts."), i || n.noFallback || ((i = Te.times[t]) ?? (i = Te.times.normal)), i;
	}, ht = m.__private__.putInfo = function() {
		var e = He(), t = function(e) {
			return e;
		};
		for (var n in d !== null && (t = Tt.encryptor(e, 0)), K("<<"), K("/Producer (" + ct(t("jsPDF " + Z.version)) + ")"), ve) ve.hasOwnProperty(n) && ve[n] && K("/" + n.substr(0, 1).toUpperCase() + n.substr(1) + " (" + ct(t(ve[n])) + ")");
		K("/CreationDate (" + ct(t(M)) + ")"), K(">>"), K("endobj");
	}, gt = m.__private__.putCatalog = function(e) {
		var t = (e ||= {}).rootDictionaryObjId || Ke;
		switch (He(), K("<<"), K("/Type /Catalog"), K("/Pages " + t + " 0 R"), ue ||= "fullwidth", ue) {
			case "fullwidth":
				K("/OpenAction [3 0 R /FitH null]");
				break;
			case "fullheight":
				K("/OpenAction [3 0 R /FitV null]");
				break;
			case "fullpage":
				K("/OpenAction [3 0 R /Fit]");
				break;
			case "original":
				K("/OpenAction [3 0 R /XYZ null null 1]");
				break;
			default:
				var n = "" + ue;
				n.substr(n.length - 1) === "%" && (ue = parseInt(ue) / 100), typeof ue == "number" && K("/OpenAction [3 0 R /XYZ null null " + O(ue) + "]");
		}
		switch (he ||= "continuous", he) {
			case "continuous":
				K("/PageLayout /OneColumn");
				break;
			case "single":
				K("/PageLayout /SinglePage");
				break;
			case "two":
			case "twoleft":
				K("/PageLayout /TwoColumnLeft");
				break;
			case "tworight": K("/PageLayout /TwoColumnRight");
		}
		pe && K("/PageMode /" + pe), Ne.publish("putCatalog"), K(">>"), K("endobj");
	}, _t = m.__private__.putTrailer = function() {
		K("trailer"), K("<<"), K("/Size " + (V + 1)), K("/Root " + V + " 0 R"), K("/Info " + (V - 1) + " 0 R"), d !== null && K("/Encrypt " + Tt.oid + " 0 R"), K("/ID [ <" + N + "> <" + N + "> ]"), K(">>");
	}, vt = m.__private__.putHeader = function() {
		K("%PDF-" + h), K("%ºß¬à");
	}, yt = m.__private__.putXRef = function() {
		var e = "0000000000";
		K("xref"), K("0 " + (V + 1)), K("0000000000 65535 f ");
		for (var t = 1; t <= V; t++) typeof H[t] == "function" ? K((e + H[t]()).slice(-10) + " 00000 n ") : H[t] === void 0 ? K("0000000000 00000 n ") : K((e + H[t]).slice(-10) + " 00000 n ");
	}, bt = m.__private__.buildDocument = function() {
		var e;
		V = 0, ne = 0, U = [], H = [], W = [], Ke = Ue(), qe = Ue(), ae(U), Ne.publish("buildDocument"), vt(), $e(), function() {
			Ne.publish("putAdditionalObjects");
			for (var e = 0; e < W.length; e++) {
				var t = W[e];
				We(t.objId, !0), K(t.content), K("endobj");
			}
			Ne.publish("postPutAdditionalObjects");
		}(), e = [], function() {
			for (var e in we) we.hasOwnProperty(e) && (!1 === f || !0 === f && p.hasOwnProperty(e)) && et(we[e]);
		}(), function() {
			for (var e in ke) ke.hasOwnProperty(e) && it(ke[e]);
		}(), function() {
			for (var e in Fe) Fe.hasOwnProperty(e) && tt(Fe[e]);
		}(), function(e) {
			for (var t in De) De.hasOwnProperty(t) && (De[t] instanceof qo ? nt(De[t]) : De[t] instanceof Jo && rt(De[t], e));
		}(e), Ne.publish("putResources"), e.forEach(at), at({
			resourcesOid: qe,
			objectOid: 2 ** 53 - 1
		}), Ne.publish("postPutResources"), d !== null && (Tt.oid = He(), K("<<"), K("/Filter /Standard"), K("/V " + Tt.v), K("/R " + Tt.r), K("/U <" + Tt.toHexString(Tt.U) + ">"), K("/O <" + Tt.toHexString(Tt.O) + ">"), K("/P " + Tt.P), K(">>"), K("endobj")), ht(), gt();
		var t = ne;
		return yt(), _t(), K("startxref"), K("" + t), K("%%EOF"), ae(G[z]), U.join("\n");
	}, xt = m.__private__.getBlob = function(e) {
		return new Blob([se(e)], { type: "application/pdf" });
	}, St = function(e) {
		for (; e.firstChild;) e.removeChild(e.firstChild);
	}, Ct = function(e) {
		var t, n = e.document, r = n.documentElement, i = n.head, a = n.body;
		return i || (i = n.createElement("head"), r.appendChild(i)), a || (a = n.createElement("body"), r.appendChild(a)), St(i), St(a), (t = n.createElement("style")).appendChild(n.createTextNode("html, body { padding: 0; margin: 0; } iframe { width: 100%; height: 100%; border: 0;}")), i.appendChild(t), {
			document: n,
			body: a
		};
	}, wt = m.output = m.__private__.output = (Ve = function(e, t) {
		switch (typeof (t ||= {}) == "string" ? t = { filename: t } : t.filename = t.filename || "generated.pdf", e) {
			case void 0: return bt();
			case "save":
				m.save(t.filename);
				break;
			case "arraybuffer": return se(bt());
			case "blob": return xt(bt());
			case "bloburi":
			case "bloburl":
				if (X.URL !== void 0 && typeof X.URL.createObjectURL == "function") return X.URL && X.URL.createObjectURL(xt(bt())) || void 0;
				vo.warn("bloburl is not supported by your system, because URL.createObjectURL is not supported by your browser.");
				break;
			case "datauristring":
			case "dataurlstring":
				var n = "", r = bt();
				try {
					n = To(r);
				} catch {
					n = To(unescape(encodeURIComponent(r)));
				}
				return "data:application/pdf;filename=" + encodeURIComponent(t.filename) + ";base64," + n;
			case "pdfobjectnewwindow":
				if (Object.prototype.toString.call(X) === "[object Window]") {
					var i = "https://cdnjs.cloudflare.com/ajax/libs/pdfobject/2.1.1/pdfobject.min.js", a = !t.pdfObjectUrl;
					a || (i = t.pdfObjectUrl);
					var o = X.open();
					if (o !== null) {
						var s = Ct(o), c = s.document.createElement("script"), l = this;
						c.src = i, a && (c.integrity = "sha512-4ze/a9/4jqu+tX9dfOqJYSvyYd5M6qum/3HpCLr+/Jqf0whc37VUbkpNGHR7/8pSnCFw47T1fmIpwBV7UySh3g==", c.crossOrigin = "anonymous"), c.onload = function() {
							o.PDFObject.embed(l.output("dataurlstring"), t);
						}, s.body.appendChild(c);
					}
					return o;
				}
				throw Error("The option pdfobjectnewwindow just works in a browser-environment.");
			case "pdfjsnewwindow":
				if (Object.prototype.toString.call(X) === "[object Window]") {
					var u = t.pdfJsUrl || "examples/PDF.js/web/viewer.html", d = X.open();
					if (d !== null) {
						var f = Ct(d), p = f.document.createElement("iframe"), h = u.indexOf("?") === -1 ? "?" : "&";
						l = this, p.id = "pdfViewer", p.width = "500px", p.height = "400px", p.src = u + h + "file=&downloadName=" + encodeURIComponent(t.filename), p.onload = function() {
							d.document.title = t.filename, p.contentWindow.PDFViewerApplication.open(l.output("bloburl"));
						}, f.body.appendChild(p);
					}
					return d;
				}
				throw Error("The option pdfjsnewwindow just works in a browser-environment.");
			case "dataurlnewwindow":
				if (Object.prototype.toString.call(X) !== "[object Window]") throw Error("The option dataurlnewwindow just works in a browser-environment.");
				var g = X.open();
				if (g !== null) {
					var _ = Ct(g), v = _.document.createElement("iframe");
					v.src = this.output("datauristring", t), _.body.appendChild(v), g.document.title = t.filename;
				}
				if (g || typeof safari > "u") return g;
				break;
			case "datauri":
			case "dataurl": return X.document.location.href = this.output("datauristring", t);
			default: return null;
		}
	}, Ve.foo = function() {
		try {
			return Ve.apply(this, arguments);
		} catch (n) {
			var e = n.stack || "";
			~e.indexOf(" at ") && (e = e.split(" at ")[1]);
			var t = "Error in function " + e.split("\n")[0].split("<")[0] + ": " + n.message;
			if (!X.console) throw Error(t);
			X.console.error(t, n), X.alert && alert(t);
		}
	}, Ve.foo.bar = Ve, Ve.foo), Y = function(e) {
		return !0 === Array.isArray(Pe) && Pe.indexOf(e) > -1;
	};
	switch (i) {
		case "pt":
			be = 1;
			break;
		case "mm":
			be = 72 / 25.4;
			break;
		case "cm":
			be = 72 / 2.54;
			break;
		case "in":
			be = 72;
			break;
		case "px":
			be = Y("px_scaling") == 1 ? .75 : 96 / 72;
			break;
		case "pc":
		case "em":
			be = 12;
			break;
		case "ex":
			be = 6;
			break;
		default:
			if (typeof i != "number") throw Error("Invalid unit: " + i);
			be = i;
	}
	var Tt = null;
	ee(), F();
	var Et = m.__private__.getPageInfo = m.getPageInfo = function(e) {
		if (isNaN(e) || e % 1 != 0) throw Error("Invalid argument passed to jsPDF.getPageInfo");
		return {
			objId: q[e].objId,
			pageNumber: e,
			pageContext: q[e]
		};
	}, Dt = m.__private__.getPageInfoByObjId = function(e) {
		if (isNaN(e) || e % 1 != 0) throw Error("Invalid argument passed to jsPDF.getPageInfoByObjId");
		for (var t in q) if (q[t].objId === e) break;
		return Et(t);
	}, Ot = m.__private__.getCurrentPageInfo = m.getCurrentPageInfo = function() {
		return {
			objId: q[z].objId,
			pageNumber: z,
			pageContext: q[z]
		};
	};
	m.addPage = function() {
		return ut.apply(this, arguments), this;
	}, m.setPage = function() {
		return ft.apply(this, arguments), ae.call(this, G[z]), this;
	}, m.insertPage = function(e) {
		return this.addPage(), this.movePage(z, e), this;
	}, m.movePage = function(e, t) {
		var n, r;
		if (e > t) {
			n = G[e], r = q[e];
			for (var i = e; i > t; i--) G[i] = G[i - 1], q[i] = q[i - 1];
			G[t] = n, q[t] = r, this.setPage(t);
		} else if (e < t) {
			n = G[e], r = q[e];
			for (var a = e; a < t; a++) G[a] = G[a + 1], q[a] = q[a + 1];
			G[t] = n, q[t] = r, this.setPage(t);
		}
		return this;
	}, m.deletePage = function() {
		return dt.apply(this, arguments), this;
	}, m.__private__.text = m.text = function(e, n, r, i, a) {
		var o, s, c, l, u, d, f, m, h, g = (i ||= {}).scope || this;
		if (typeof e == "number" && typeof n == "number" && (typeof r == "string" || Array.isArray(r))) {
			var _ = r;
			r = n, n = e, e = _;
		}
		if (arguments[3] instanceof J == 0 ? (c = arguments[4], l = arguments[5], t(f = arguments[3]) === "object" && f !== null || (typeof c == "string" && (l = c, c = null), typeof f == "string" && (l = f, f = null), typeof f == "number" && (c = f, f = null), i = {
			flags: f,
			angle: c,
			align: l
		})) : (E("The transform parameter of text() with a Matrix value"), h = a), isNaN(n) || isNaN(r) || e == null) throw Error("Invalid arguments passed to jsPDF.text");
		if (e.length === 0) return g;
		var v, y = "", S = typeof i.lineHeightFactor == "number" ? i.lineHeightFactor : Ht, C = g.internal.scaleFactor;
		function w(e) {
			return e = e.split("	").join(Array(i.TabLen || 9).join(" ")), ct(e, f);
		}
		function D(e) {
			for (var t, n = e.concat(), r = [], i = n.length; i--;) typeof (t = n.shift()) == "string" ? r.push(t) : Array.isArray(e) && (t.length === 1 || t[1] === void 0 && t[2] === void 0) ? r.push(t[0]) : r.push([
				t[0],
				t[1],
				t[2]
			]);
			return r;
		}
		function O(e, t) {
			var n;
			if (typeof e == "string") n = t(e)[0];
			else if (Array.isArray(e)) {
				for (var r, i, a = e.concat(), o = [], s = a.length; s--;) typeof (r = a.shift()) == "string" ? o.push(t(r)[0]) : Array.isArray(r) && typeof r[0] == "string" && (i = t(r[0], r[1], r[2]), o.push([
					i[0],
					i[1],
					i[2]
				]));
				n = o;
			}
			return n;
		}
		var k = !1, j = !0;
		if (typeof e == "string") k = !0;
		else if (Array.isArray(e)) {
			var M = e.concat();
			s = [];
			for (var N, P = M.length; P--;) (typeof (N = M.shift()) != "string" || Array.isArray(N) && typeof N[0] != "string") && (j = !1);
			k = j;
		}
		if (!1 === k) throw Error("Type of text must be string or Array. \"" + e + "\" is not recognized.");
		typeof e == "string" && (e = e.match(/[\r?\n]/) ? e.split(/\r\n|\r|\n/g) : [e]);
		var F = le / g.internal.scaleFactor, I = F * (S - 1);
		switch (i.baseline) {
			case "bottom":
				r -= I;
				break;
			case "top":
				r += F - I;
				break;
			case "hanging":
				r += F - 2 * I;
				break;
			case "middle": r += F / 2 - I;
		}
		if ((d = i.maxWidth || 0) > 0 && (typeof e == "string" ? e = g.splitTextToSize(e, d) : Object.prototype.toString.call(e) === "[object Array]" && (e = e.reduce(function(e, t) {
			return e.concat(g.splitTextToSize(t, d));
		}, []))), o = {
			text: e,
			x: n,
			y: r,
			options: i,
			mutex: {
				pdfEscape: ct,
				activeFontKey: ye,
				fonts: we,
				activeFontSize: le
			}
		}, Ne.publish("preProcessText", o), e = o.text, c = (i = o.options).angle, h instanceof J == 0 && c && typeof c == "number") {
			c *= Math.PI / 180, i.rotationDirection === 0 && (c = -c), x === b && (c = -c);
			var L = Math.cos(c), ee = Math.sin(c);
			h = new J(L, ee, -ee, L, 0, 0);
		} else c && c instanceof J && (h = c);
		x !== b || h || (h = ze), (u = i.charSpace || rn) !== void 0 && (y += T(A(u)) + " Tc\n", this.setCharSpace(this.getCharSpace() || 0)), (m = i.horizontalScale) !== void 0 && (y += T(100 * m) + " Tz\n"), i.lang;
		var R = -1, z = i.renderingMode === void 0 ? i.stroke : i.renderingMode, B = g.internal.getCurrentPageInfo().pageContext;
		switch (z) {
			case 0:
			case !1:
			case "fill":
				R = 0;
				break;
			case 1:
			case !0:
			case "stroke":
				R = 1;
				break;
			case 2:
			case "fillThenStroke":
				R = 2;
				break;
			case 3:
			case "invisible":
				R = 3;
				break;
			case 4:
			case "fillAndAddForClipping":
				R = 4;
				break;
			case 5:
			case "strokeAndAddPathForClipping":
				R = 5;
				break;
			case 6:
			case "fillThenStrokeAndAddToPathForClipping":
				R = 6;
				break;
			case 7:
			case "addToPathForClipping": R = 7;
		}
		var te = B.usedRenderingMode === void 0 ? -1 : B.usedRenderingMode;
		R === -1 ? te !== -1 && (y += "0 Tr\n") : y += R + " Tr\n", R !== -1 && (B.usedRenderingMode = R), l = i.align || "left";
		var V, H = le * S, U = g.internal.pageSize.getWidth(), ne = we[ye];
		u = i.charSpace || rn, d = i.maxWidth || 0, f = Object.assign({
			autoencode: !0,
			noBOM: !0
		}, i.flags);
		var W = [], G = function(e) {
			return g.getStringUnitWidth(e, {
				font: ne,
				charSpace: u,
				fontSize: le,
				doKerning: !1
			}) * le / C;
		};
		if (Object.prototype.toString.call(e) === "[object Array]") {
			var re;
			s = D(e), l !== "left" && (V = s.map(G));
			var ie, ae = 0;
			if (l === "right") {
				n -= V[0], e = [], P = s.length;
				for (var oe = 0; oe < P; oe++) oe === 0 ? (ie = Yt(n), re = Xt(r)) : (ie = A(ae - V[oe]), re = -H), e.push([
					s[oe],
					ie,
					re
				]), ae = V[oe];
			} else if (l === "center") {
				n -= V[0] / 2, e = [], P = s.length;
				for (var se = 0; se < P; se++) se === 0 ? (ie = Yt(n), re = Xt(r)) : (ie = A((ae - V[se]) / 2), re = -H), e.push([
					s[se],
					ie,
					re
				]), ae = V[se];
			} else if (l === "left") {
				e = [], P = s.length;
				for (var ce = 0; ce < P; ce++) e.push(s[ce]);
			} else if (l === "justify" && ne.encoding === "Identity-H") {
				e = [], P = s.length, d = d === 0 ? U : d;
				for (var ue = 0, de = 0; de < P; de++) if (re = de === 0 ? Xt(r) : -H, ie = de === 0 ? Yt(n) : ue, de < P - 1) {
					var pe = A((d - V[de]) / (s[de].split(" ").length - 1)), me = s[de].split(" ");
					e.push([
						me[0] + " ",
						ie,
						re
					]), ue = 0;
					for (var he = 1; he < me.length; he++) {
						var ge = (G(me[he - 1] + " " + me[he]) - G(me[he])) * C + pe;
						he == me.length - 1 ? e.push([
							me[he],
							ge,
							0
						]) : e.push([
							me[he] + " ",
							ge,
							0
						]), ue -= ge;
					}
				} else e.push([
					s[de],
					ie,
					re
				]);
				e.push([
					"",
					ue,
					0
				]);
			} else {
				if (l !== "justify") throw Error("Unrecognized alignment option, use \"left\", \"center\", \"right\" or \"justify\".");
				for (e = [], P = s.length, d = d === 0 ? U : d, de = 0; de < P; de++) {
					re = de === 0 ? Xt(r) : -H, ie = de === 0 ? Yt(n) : 0;
					var _e = s[de].split(" ").length - 1, ve = _e > 0 ? (d - V[de]) / _e : 0;
					de < P - 1 ? W.push(T(A(ve))) : W.push(0), e.push([
						s[de],
						ie,
						re
					]);
				}
			}
		}
		!0 === (typeof i.R2L == "boolean" ? i.R2L : fe) && (e = O(e, function(e, t, n) {
			return [
				e.split("").reverse().join(""),
				t,
				n
			];
		})), o = {
			text: e,
			x: n,
			y: r,
			options: i,
			mutex: {
				pdfEscape: ct,
				activeFontKey: ye,
				fonts: we,
				activeFontSize: le
			}
		}, Ne.publish("postProcessText", o), e = o.text, v = o.mutex.isHex || !1;
		var be = we[ye].encoding;
		be !== "WinAnsiEncoding" && be !== "StandardEncoding" || (e = O(e, function(e, t, n) {
			return [
				w(e),
				t,
				n
			];
		})), s = D(e), e = [];
		for (var xe, Se, Ce, Te = +!!Array.isArray(s[0]), Ee = "", De = function(e, t, n) {
			var r = "";
			return n instanceof J ? (n = typeof i.angle == "number" ? Re(n, new J(1, 0, 0, 1, e, t)) : Re(new J(1, 0, 0, 1, e, t), n), x === b && (n = Re(new J(1, 0, 0, -1, 0, 0), n)), r = n.join(" ") + " Tm\n") : r = T(e) + " " + T(t) + " Td\n", r;
		}, Oe = 0; Oe < s.length; Oe++) {
			switch (Ee = "", Te) {
				case 1:
					Ce = (v ? "<" : "(") + s[Oe][0] + (v ? ">" : ")"), xe = parseFloat(s[Oe][1]), Se = parseFloat(s[Oe][2]);
					break;
				case 0: Ce = (v ? "<" : "(") + s[Oe] + (v ? ">" : ")"), xe = Yt(n), Se = Xt(r);
			}
			W !== void 0 && W[Oe] !== void 0 && (Ee = W[Oe] + " Tw\n"), Oe === 0 ? e.push(Ee + De(xe, Se, h) + Ce) : Te === 0 ? e.push(Ee + Ce) : Te === 1 && e.push(Ee + De(xe, Se, h) + Ce);
		}
		e = Te === 0 ? e.join(" Tj\nT* ") : e.join(" Tj\n"), e += " Tj\n";
		var ke = "BT\n/";
		return ke += ye + " " + le + " Tf\n", ke += T(le * S) + " TL\n", ke += tn + "\n", ke += y, ke += e, K(ke += "ET"), p[ye] = !0, g;
	};
	var kt = m.__private__.clip = m.clip = function(e) {
		return K(e === "evenodd" ? "W*" : "W"), this;
	};
	m.clipEvenOdd = function() {
		return kt("evenodd");
	}, m.__private__.discardPath = m.discardPath = function() {
		return K("n"), this;
	};
	var At = m.__private__.isValidStyle = function(e) {
		var t = !1;
		return [
			void 0,
			null,
			"S",
			"D",
			"F",
			"DF",
			"FD",
			"f",
			"f*",
			"B",
			"B*",
			"n"
		].indexOf(e) !== -1 && (t = !0), t;
	};
	m.__private__.setDefaultPathOperation = m.setDefaultPathOperation = function(e) {
		return At(e) && (u = e), this;
	};
	var jt = m.__private__.getStyle = m.getStyle = function(e) {
		var t = u;
		switch (e) {
			case "D":
			case "S":
				t = "S";
				break;
			case "F":
				t = "f";
				break;
			case "FD":
			case "DF":
				t = "B";
				break;
			case "f":
			case "f*":
			case "B":
			case "B*": t = e;
		}
		return t;
	}, Mt = m.close = function() {
		return K("h"), this;
	};
	m.stroke = function() {
		return K("S"), this;
	}, m.fill = function(e) {
		return Nt("f", e), this;
	}, m.fillEvenOdd = function(e) {
		return Nt("f*", e), this;
	}, m.fillStroke = function(e) {
		return Nt("B", e), this;
	}, m.fillStrokeEvenOdd = function(e) {
		return Nt("B*", e), this;
	};
	var Nt = function(e, n) {
		t(n) === "object" ? It(n, e) : K(e);
	}, Pt = function(e) {
		e === null || x === b && e === void 0 || (e = jt(e), K(e));
	};
	function Ft(e, t, n, r, i) {
		var a = new Jo(t || this.boundingBox, n || this.xStep, r || this.yStep, this.gState, i || this.matrix);
		return a.stream = this.stream, Be(e + "$$" + this.cloneIndex++ + "$$", a), a;
	}
	var It = function(e, t) {
		var n = Oe[e.key], r = De[n];
		if (r instanceof qo) K("q"), K(Lt(t)), r.gState && m.setGState(r.gState), K(e.matrix.toString() + " cm"), K("/" + n + " sh"), K("Q");
		else if (r instanceof Jo) {
			var i = new J(1, 0, 0, -1, 0, bn());
			e.matrix && (i = i.multiply(e.matrix || ze), n = Ft.call(r, e.key, e.boundingBox, e.xStep, e.yStep, i).id), K("q"), K("/Pattern cs"), K("/" + n + " scn"), r.gState && m.setGState(r.gState), K(t), K("Q");
		}
	}, Lt = function(e) {
		switch (e) {
			case "f":
			case "F":
			case "n": return "W n";
			case "f*": return "W* n";
			case "B":
			case "S": return "W S";
			case "B*": return "W* S";
		}
	}, Rt = m.moveTo = function(e, t) {
		return K(T(A(e)) + " " + T(j(t)) + " m"), this;
	}, zt = m.lineTo = function(e, t) {
		return K(T(A(e)) + " " + T(j(t)) + " l"), this;
	}, Bt = m.curveTo = function(e, t, n, r, i, a) {
		return K([
			T(A(e)),
			T(j(t)),
			T(A(n)),
			T(j(r)),
			T(A(i)),
			T(j(a)),
			"c"
		].join(" ")), this;
	};
	m.__private__.line = m.line = function(e, t, n, r, i) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r) || !At(i)) throw Error("Invalid arguments passed to jsPDF.line");
		return x === y ? this.lines([[n - e, r - t]], e, t, [1, 1], i || "S") : this.lines([[n - e, r - t]], e, t, [1, 1]).stroke();
	}, m.__private__.lines = m.lines = function(e, t, n, r, i, a) {
		var o, s, c, l, u, d, f, p, m, h, g, _;
		if (typeof e == "number" && (_ = n, n = t, t = e, e = _), r ||= [1, 1], a ||= !1, isNaN(t) || isNaN(n) || !Array.isArray(e) || !Array.isArray(r) || !At(i) || typeof a != "boolean") throw Error("Invalid arguments passed to jsPDF.lines");
		for (Rt(t, n), o = r[0], s = r[1], l = e.length, h = t, g = n, c = 0; c < l; c++) (u = e[c]).length === 2 ? (h = u[0] * o + h, g = u[1] * s + g, zt(h, g)) : (d = u[0] * o + h, f = u[1] * s + g, p = u[2] * o + h, m = u[3] * s + g, h = u[4] * o + h, g = u[5] * s + g, Bt(d, f, p, m, h, g));
		return a && Mt(), Pt(i), this;
	}, m.path = function(e) {
		for (var t = 0; t < e.length; t++) {
			var n = e[t], r = n.c;
			switch (n.op) {
				case "m":
					Rt(r[0], r[1]);
					break;
				case "l":
					zt(r[0], r[1]);
					break;
				case "c":
					Bt.apply(this, r);
					break;
				case "h": Mt();
			}
		}
		return this;
	}, m.__private__.rect = m.rect = function(e, t, n, r, i) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r) || !At(i)) throw Error("Invalid arguments passed to jsPDF.rect");
		return x === y && (r = -r), K([
			T(A(e)),
			T(j(t)),
			T(A(n)),
			T(A(r)),
			"re"
		].join(" ")), Pt(i), this;
	}, m.__private__.triangle = m.triangle = function(e, t, n, r, i, a, o) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r) || isNaN(i) || isNaN(a) || !At(o)) throw Error("Invalid arguments passed to jsPDF.triangle");
		return this.lines([
			[n - e, r - t],
			[i - n, a - r],
			[e - i, t - a]
		], e, t, [1, 1], o, !0), this;
	}, m.__private__.roundedRect = m.roundedRect = function(e, t, n, r, i, a, o) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r) || isNaN(i) || isNaN(a) || !At(o)) throw Error("Invalid arguments passed to jsPDF.roundedRect");
		var s = 4 / 3 * (Math.SQRT2 - 1);
		return i = Math.min(i, .5 * n), a = Math.min(a, .5 * r), this.lines([
			[n - 2 * i, 0],
			[
				i * s,
				0,
				i,
				a - a * s,
				i,
				a
			],
			[0, r - 2 * a],
			[
				0,
				a * s,
				-i * s,
				a,
				-i,
				a
			],
			[2 * i - n, 0],
			[
				-i * s,
				0,
				-i,
				-a * s,
				-i,
				-a
			],
			[0, 2 * a - r],
			[
				0,
				-a * s,
				i * s,
				-a,
				i,
				-a
			]
		], e + i, t, [1, 1], o, !0), this;
	}, m.__private__.ellipse = m.ellipse = function(e, t, n, r, i) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r) || !At(i)) throw Error("Invalid arguments passed to jsPDF.ellipse");
		var a = 4 / 3 * (Math.SQRT2 - 1) * n, o = 4 / 3 * (Math.SQRT2 - 1) * r;
		return Rt(e + n, t), Bt(e + n, t - o, e + a, t - r, e, t - r), Bt(e - a, t - r, e - n, t - o, e - n, t), Bt(e - n, t + o, e - a, t + r, e, t + r), Bt(e + a, t + r, e + n, t + o, e + n, t), Pt(i), this;
	}, m.__private__.circle = m.circle = function(e, t, n, r) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || !At(r)) throw Error("Invalid arguments passed to jsPDF.circle");
		return this.ellipse(e, t, n, n, r);
	}, m.setFont = function(e, t, n) {
		return n && (t = w(t, n)), ye = mt(e, t, { disableWarning: !1 }), this;
	};
	var Vt = m.__private__.getFont = m.getFont = function() {
		return we[mt.apply(m, arguments)];
	};
	m.__private__.getFontList = m.getFontList = function() {
		var e, t, n = {};
		for (e in Te) if (Te.hasOwnProperty(e)) for (t in n[e] = [], Te[e]) Te[e].hasOwnProperty(t) && n[e].push(t);
		return n;
	}, m.addFont = function(e, t, n, r, i) {
		var a = [
			"StandardEncoding",
			"MacRomanEncoding",
			"Identity-H",
			"WinAnsiEncoding"
		];
		return arguments[3] && a.indexOf(arguments[3]) !== -1 ? i = arguments[3] : arguments[3] && a.indexOf(arguments[3]) == -1 && (n = w(n, r)), st.call(this, e, t, n, i ||= "Identity-H");
	};
	var Ht, Ut = e.lineWidth || .200025, Wt = m.__private__.getLineWidth = m.getLineWidth = function() {
		return Ut;
	}, Gt = m.__private__.setLineWidth = m.setLineWidth = function(e) {
		return Ut = e, K(T(A(e)) + " w"), this;
	};
	m.__private__.setLineDash = Z.API.setLineDash = Z.API.setLineDashPattern = function(e, t) {
		if (e ||= [], t ||= 0, isNaN(t) || !Array.isArray(e)) throw Error("Invalid arguments passed to jsPDF.setLineDash");
		return e = e.map(function(e) {
			return T(A(e));
		}).join(" "), t = T(A(t)), K("[" + e + "] " + t + " d"), this;
	};
	var Kt = m.__private__.getLineHeight = m.getLineHeight = function() {
		return le * Ht;
	};
	m.__private__.getLineHeight = m.getLineHeight = function() {
		return le * Ht;
	};
	var qt = m.__private__.setLineHeightFactor = m.setLineHeightFactor = function(e) {
		return typeof (e ||= 1.15) == "number" && (Ht = e), this;
	}, Jt = m.__private__.getLineHeightFactor = m.getLineHeightFactor = function() {
		return Ht;
	};
	qt(e.lineHeight);
	var Yt = m.__private__.getHorizontalCoordinate = function(e) {
		return A(e);
	}, Xt = m.__private__.getVerticalCoordinate = function(e) {
		return x === b ? e : q[z].mediaBox.topRightY - q[z].mediaBox.bottomLeftY - A(e);
	}, Zt = m.__private__.getHorizontalCoordinateString = m.getHorizontalCoordinateString = function(e) {
		return T(Yt(e));
	}, Qt = m.__private__.getVerticalCoordinateString = m.getVerticalCoordinateString = function(e) {
		return T(Xt(e));
	}, $t = e.strokeColor || "0 G";
	m.__private__.getStrokeColor = m.getDrawColor = function() {
		return Je($t);
	}, m.__private__.setStrokeColor = m.setDrawColor = function(e, t, n, r) {
		return $t = Ye({
			ch1: e,
			ch2: t,
			ch3: n,
			ch4: r,
			pdfColorType: "draw",
			precision: 2
		}), K($t), this;
	};
	var en = e.fillColor || "0 g";
	m.__private__.getFillColor = m.getFillColor = function() {
		return Je(en);
	}, m.__private__.setFillColor = m.setFillColor = function(e, t, n, r) {
		return en = Ye({
			ch1: e,
			ch2: t,
			ch3: n,
			ch4: r,
			pdfColorType: "fill",
			precision: 2
		}), K(en), this;
	};
	var tn = e.textColor || "0 g", nn = m.__private__.getTextColor = m.getTextColor = function() {
		return Je(tn);
	};
	m.__private__.setTextColor = m.setTextColor = function(e, t, n, r) {
		return tn = Ye({
			ch1: e,
			ch2: t,
			ch3: n,
			ch4: r,
			pdfColorType: "text",
			precision: 3
		}), this;
	};
	var rn = e.charSpace, an = m.__private__.getCharSpace = m.getCharSpace = function() {
		return parseFloat(rn || 0);
	};
	m.__private__.setCharSpace = m.setCharSpace = function(e) {
		if (isNaN(e)) throw Error("Invalid argument passed to jsPDF.setCharSpace");
		return rn = e, this;
	};
	var on = 0;
	m.CapJoinStyles = {
		0: 0,
		butt: 0,
		but: 0,
		miter: 0,
		1: 1,
		round: 1,
		rounded: 1,
		circle: 1,
		2: 2,
		projecting: 2,
		project: 2,
		square: 2,
		bevel: 2
	}, m.__private__.setLineCap = m.setLineCap = function(e) {
		var t = m.CapJoinStyles[e];
		if (t === void 0) throw Error("Line cap style of '" + e + "' is not recognized. See or extend .CapJoinStyles property for valid styles");
		return on = t, K(t + " J"), this;
	};
	var sn = 0;
	m.__private__.setLineJoin = m.setLineJoin = function(e) {
		var t = m.CapJoinStyles[e];
		if (t === void 0) throw Error("Line join style of '" + e + "' is not recognized. See or extend .CapJoinStyles property for valid styles");
		return sn = t, K(t + " j"), this;
	}, m.__private__.setLineMiterLimit = m.__private__.setMiterLimit = m.setLineMiterLimit = m.setMiterLimit = function(e) {
		if (e ||= 0, isNaN(e)) throw Error("Invalid argument passed to jsPDF.setLineMiterLimit");
		return K(T(A(e)) + " M"), this;
	}, m.GState = Go, m.setGState = function(e) {
		(e = typeof e == "string" ? ke[Ae[e]] : cn(null, e)).equals(je) || (K("/" + e.id + " gs"), je = e);
	};
	var cn = function(e, t) {
		if (!e || !Ae[e]) {
			var n = !1;
			for (var r in ke) if (ke.hasOwnProperty(r) && ke[r].equals(t)) {
				n = !0;
				break;
			}
			if (n) t = ke[r];
			else {
				var i = "GS" + (Object.keys(ke).length + 1).toString(10);
				ke[i] = t, t.id = i;
			}
			return e && (Ae[e] = t.id), Ne.publish("addGState", t), t;
		}
	};
	m.addGState = function(e, t) {
		return cn(e, t), this;
	}, m.saveGraphicsState = function() {
		return K("q"), Ee.push({
			key: ye,
			size: le,
			color: tn
		}), this;
	}, m.restoreGraphicsState = function() {
		K("Q");
		var e = Ee.pop();
		return ye = e.key, le = e.size, tn = e.color, je = null, this;
	}, m.setCurrentTransformationMatrix = function(e) {
		return K(e.toString() + " cm"), this;
	}, m.comment = function(e) {
		return K("#" + e), this;
	};
	var ln = function(e, t) {
		var n = e || 0;
		Object.defineProperty(this, "x", {
			enumerable: !0,
			get: function() {
				return n;
			},
			set: function(e) {
				isNaN(e) || (n = parseFloat(e));
			}
		});
		var r = t || 0;
		Object.defineProperty(this, "y", {
			enumerable: !0,
			get: function() {
				return r;
			},
			set: function(e) {
				isNaN(e) || (r = parseFloat(e));
			}
		});
		var i = "pt";
		return Object.defineProperty(this, "type", {
			enumerable: !0,
			get: function() {
				return i;
			},
			set: function(e) {
				i = e.toString();
			}
		}), this;
	}, un = function(e, t, n, r) {
		ln.call(this, e, t), this.type = "rect";
		var i = n || 0;
		Object.defineProperty(this, "w", {
			enumerable: !0,
			get: function() {
				return i;
			},
			set: function(e) {
				isNaN(e) || (i = parseFloat(e));
			}
		});
		var a = r || 0;
		return Object.defineProperty(this, "h", {
			enumerable: !0,
			get: function() {
				return a;
			},
			set: function(e) {
				isNaN(e) || (a = parseFloat(e));
			}
		}), this;
	}, dn = function() {
		this.page = Me, this.currentPage = z, this.pages = G.slice(0), this.pagesContext = q.slice(0), this.x = xe, this.y = Se, this.matrix = Ce, this.width = mn(z), this.height = gn(z), this.outputDestination = ie, this.id = "", this.objectNumber = -1;
	};
	dn.prototype.restore = function() {
		Me = this.page, z = this.currentPage, q = this.pagesContext, G = this.pages, xe = this.x, Se = this.y, Ce = this.matrix, hn(z, this.width), _n(z, this.height), ie = this.outputDestination;
	};
	var fn = function(e, t, n, r, i) {
		Le.push(new dn()), Me = z = 0, G = [], xe = e, Se = t, Ce = i, lt([n, r]);
	};
	for (var pn in m.beginFormObject = function(e, t, n, r, i) {
		return fn(e, t, n, r, i), this;
	}, m.endFormObject = function(e) {
		return function(e) {
			if (Ie[e]) Le.pop().restore();
			else {
				var t = new dn(), n = "Xo" + (Object.keys(Fe).length + 1).toString(10);
				t.id = n, Ie[e] = n, Fe[n] = t, Ne.publish("addFormObject", t), Le.pop().restore();
			}
		}(e), this;
	}, m.doFormObject = function(e, t) {
		var n = Fe[Ie[e]];
		return K("q"), K(t.toString() + " cm"), K("/" + n.id + " Do"), K("Q"), this;
	}, m.getFormObject = function(e) {
		var t = Fe[Ie[e]];
		return {
			x: t.x,
			y: t.y,
			width: t.width,
			height: t.height,
			matrix: t.matrix
		};
	}, m.save = function(e, t) {
		return e ||= "generated.pdf", (t ||= {}).returnPromise = t.returnPromise || !1, !1 === t.returnPromise ? (So(xt(bt()), e), typeof So.unload == "function" && X.setTimeout && setTimeout(So.unload, 911), this) : new Promise(function(t, n) {
			try {
				var r = So(xt(bt()), e);
				typeof So.unload == "function" && X.setTimeout && setTimeout(So.unload, 911), t(r);
			} catch (e) {
				n(e.message);
			}
		});
	}, Z.API) Z.API.hasOwnProperty(pn) && (pn === "events" && Z.API.events.length ? function(e, t) {
		for (var n, r, i = t.length - 1; i !== -1; i--) n = t[i][0], r = t[i][1], e.subscribe.apply(e, [n].concat(typeof r == "function" ? [r] : r));
	}(Ne, Z.API.events) : m[pn] = Z.API[pn]);
	function mn(e) {
		return q[e].mediaBox.topRightX - q[e].mediaBox.bottomLeftX;
	}
	function hn(e, t) {
		q[e].mediaBox.topRightX = t + q[e].mediaBox.bottomLeftX;
	}
	function gn(e) {
		return q[e].mediaBox.topRightY - q[e].mediaBox.bottomLeftY;
	}
	function _n(e, t) {
		q[e].mediaBox.topRightY = t + q[e].mediaBox.bottomLeftY;
	}
	var vn = m.getPageWidth = function(e) {
		return mn(e ||= z) / be;
	}, yn = m.setPageWidth = function(e, t) {
		hn(e, t * be);
	}, bn = m.getPageHeight = function(e) {
		return gn(e ||= z) / be;
	}, xn = m.setPageHeight = function(e, t) {
		_n(e, t * be);
	};
	return m.internal = {
		pdfEscape: ct,
		getStyle: jt,
		getFont: Vt,
		getFontSize: de,
		getCharSpace: an,
		getTextColor: nn,
		getLineHeight: Kt,
		getLineHeightFactor: Jt,
		getLineWidth: Wt,
		write: oe,
		getHorizontalCoordinate: Yt,
		getVerticalCoordinate: Xt,
		getCoordinateString: Zt,
		getVerticalCoordinateString: Qt,
		collections: {},
		newObject: He,
		newAdditionalObject: Ge,
		newObjectDeferred: Ue,
		newObjectDeferredBegin: We,
		getFilters: Xe,
		putStream: Ze,
		events: Ne,
		scaleFactor: be,
		pageSize: {
			getWidth: function() {
				return vn(z);
			},
			setWidth: function(e) {
				yn(z, e);
			},
			getHeight: function() {
				return bn(z);
			},
			setHeight: function(e) {
				xn(z, e);
			}
		},
		encryptionOptions: d,
		encryption: Tt,
		getEncryptor: function(e) {
			return d === null ? function(e) {
				return e;
			} : Tt.encryptor(e, 0);
		},
		output: wt,
		getNumberOfPages: pt,
		get pages() {
			return G;
		},
		out: K,
		f2: O,
		f3: k,
		getPageInfo: Et,
		getPageInfoByObjId: Dt,
		getCurrentPageInfo: Ot,
		getPDFVersion: g,
		Point: ln,
		Rectangle: un,
		Matrix: J,
		hasHotfix: Y
	}, Object.defineProperty(m.internal.pageSize, "width", {
		get: function() {
			return vn(z);
		},
		set: function(e) {
			yn(z, e);
		},
		enumerable: !0,
		configurable: !0
	}), Object.defineProperty(m.internal.pageSize, "height", {
		get: function() {
			return bn(z);
		},
		set: function(e) {
			xn(z, e);
		},
		enumerable: !0,
		configurable: !0
	}), function(e) {
		for (var t = 0, n = ce.length; t < n; t++) {
			var r = st.call(this, e[t][0], e[t][1], e[t][2], ce[t][3], !0);
			!1 === f && (p[r] = !0);
			var i = e[t][0].split("-");
			ot({
				id: r,
				fontName: i[0],
				fontStyle: i[1] || ""
			});
		}
		Ne.publish("addFonts", {
			fonts: we,
			dictionary: Te
		});
	}.call(m, ce), ye = "F1", ut(a, r), Ne.publish("initialized"), m;
}
Ho.prototype.lsbFirstWord = function(e) {
	return String.fromCharCode(255 & e, e >> 8 & 255, e >> 16 & 255, e >> 24 & 255);
}, Ho.prototype.toHexString = function(e) {
	return e.split("").map(function(e) {
		return ("0" + (255 & e.charCodeAt(0)).toString(16)).slice(-2);
	}).join("");
}, Ho.prototype.hexToBytes = function(e) {
	for (var t = [], n = 0; n < e.length; n += 2) t.push(String.fromCharCode(parseInt(e.substr(n, 2), 16)));
	return t.join("");
}, Ho.prototype.processOwnerPassword = function(e, t) {
	return Bo(Lo(t).substr(0, 5), e);
}, Ho.prototype.encryptor = function(e, t) {
	var n = Lo(this.encryptionKey + String.fromCharCode(255 & e, e >> 8 & 255, e >> 16 & 255, 255 & t, t >> 8 & 255)).substr(0, 10);
	return function(e) {
		return Bo(n, e);
	};
}, Go.prototype.equals = function(e) {
	var n, r = "id,objectNumber,equals";
	if (!e || t(e) !== t(this)) return !1;
	var i = 0;
	for (n in this) if (!(r.indexOf(n) >= 0)) {
		if (this.hasOwnProperty(n) && !e.hasOwnProperty(n) || this[n] !== e[n]) return !1;
		i++;
	}
	for (n in e) e.hasOwnProperty(n) && r.indexOf(n) < 0 && i--;
	return i === 0;
}, Z.API = { events: [] }, Z.version = "4.2.1";
var Yo = Z.API, Xo = 1, Zo = function(e) {
	return e.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}, Qo = function(e) {
	return e.replace(/\\\\/g, "\\").replace(/\\\(/g, "(").replace(/\\\)/g, ")");
}, $o = function(e) {
	return e.toString().replace(/#/g, "#23").replace(/[\s\n\r()<>[\]{}\/%]/g, function(e) {
		var t = e.charCodeAt(0).toString(16).toUpperCase();
		return "#" + (t.length === 1 ? "0" + t : t);
	});
}, Q = function(e) {
	return e.toFixed(2);
}, es = function(e) {
	return e.toFixed(5);
};
Yo.__acroform__ = {};
var ts = function(e, t) {
	e.prototype = Object.create(t.prototype), e.prototype.constructor = e;
}, ns = function(e) {
	return e * Xo;
}, rs = function(e) {
	var t = new bs(), n = $.internal.getHeight(e) || 0, r = $.internal.getWidth(e) || 0;
	return t.BBox = [
		0,
		0,
		Number(Q(r)),
		Number(Q(n))
	], t;
}, is = Yo.__acroform__.setBit = function(e, t) {
	if (e ||= 0, t ||= 0, isNaN(e) || isNaN(t)) throw Error("Invalid arguments passed to jsPDF.API.__acroform__.setBit");
	return e | 1 << t;
}, as = Yo.__acroform__.clearBit = function(e, t) {
	if (e ||= 0, t ||= 0, isNaN(e) || isNaN(t)) throw Error("Invalid arguments passed to jsPDF.API.__acroform__.clearBit");
	return e & ~(1 << t);
}, os = Yo.__acroform__.getBit = function(e, t) {
	if (isNaN(e) || isNaN(t)) throw Error("Invalid arguments passed to jsPDF.API.__acroform__.getBit");
	return e & 1 << t ? 1 : 0;
}, ss = Yo.__acroform__.getBitForPdf = function(e, t) {
	if (isNaN(e) || isNaN(t)) throw Error("Invalid arguments passed to jsPDF.API.__acroform__.getBitForPdf");
	return os(e, t - 1);
}, cs = Yo.__acroform__.setBitForPdf = function(e, t) {
	if (isNaN(e) || isNaN(t)) throw Error("Invalid arguments passed to jsPDF.API.__acroform__.setBitForPdf");
	return is(e, t - 1);
}, ls = Yo.__acroform__.clearBitForPdf = function(e, t) {
	if (isNaN(e) || isNaN(t)) throw Error("Invalid arguments passed to jsPDF.API.__acroform__.clearBitForPdf");
	return as(e, t - 1);
}, us = Yo.__acroform__.calculateCoordinates = function(e, t) {
	var n = t.internal.getHorizontalCoordinate, r = t.internal.getVerticalCoordinate, i = e[0], a = e[1], o = e[2], s = e[3], c = {};
	return c.lowerLeft_X = n(i) || 0, c.lowerLeft_Y = r(a + s) || 0, c.upperRight_X = n(i + o) || 0, c.upperRight_Y = r(a) || 0, [
		Number(Q(c.lowerLeft_X)),
		Number(Q(c.lowerLeft_Y)),
		Number(Q(c.upperRight_X)),
		Number(Q(c.upperRight_Y))
	];
}, ds = function(e) {
	if (e.appearanceStreamContent) return e.appearanceStreamContent;
	if (e.V || e.DV) {
		var t = [], n = fs(e, e._V || e.DV), r = e.scope.internal.getFont(e.fontName, e.fontStyle).id;
		t.push("/Tx BMC"), t.push("q"), t.push("BT"), t.push(e.scope.__private__.encodeColorString(e.color)), t.push("/" + r + " " + Q(n.fontSize) + " Tf"), t.push("1 0 0 1 0 0 Tm"), t.push(n.text), t.push("ET"), t.push("Q"), t.push("EMC");
		var i = rs(e);
		return i.scope = e.scope, i.stream = t.join("\n"), i;
	}
}, fs = function(e, t) {
	var n = e.fontSize === 0 ? e.maxFontSize : e.fontSize, r = {
		text: "",
		fontSize: ""
	}, i = (t = (t = t.substr(0, 1) == "(" ? t.substr(1) : t).substr(t.length - 1) == ")" ? t.substr(0, t.length - 1) : t).split(" ");
	i = e.multiline ? i.map(function(e) {
		return e.split("\n");
	}) : i.map(function(e) {
		return [e];
	});
	var a = n, o = $.internal.getHeight(e) || 0;
	o = o < 0 ? -o : o;
	var s = $.internal.getWidth(e) || 0;
	s = s < 0 ? -s : s;
	var c = function(t, n, r) {
		return t + 1 < i.length && ps(n + " " + i[t + 1][0], e, r).width <= s - 4;
	};
	a++;
	t: for (; a > 0;) {
		t = "", a--;
		var l, u, d = ps("3", e, a).height, f = e.multiline ? o - a : (o - d) / 2, p = f += 2, m = 0, h = 0, g = 0;
		if (a <= 0) {
			t = "(...) Tj\n", t += "% Width of Text: " + ps(t, e, a = 12).width + ", FieldWidth:" + s + "\n";
			break;
		}
		for (var _ = "", v = 0, y = 0; y < i.length; y++) if (i.hasOwnProperty(y)) {
			var b = !1;
			if (i[y].length !== 1 && g !== i[y].length - 1) {
				if ((d + 2) * (v + 2) + 2 > o) continue t;
				_ += i[y][g], b = !0, h = y, y--;
			} else {
				_ = (_ += i[y][g] + " ").substr(_.length - 1) == " " ? _.substr(0, _.length - 1) : _;
				var x = parseInt(y), S = c(x, _, a), C = y >= i.length - 1;
				if (S && !C) {
					_ += " ", g = 0;
					continue;
				}
				if (S || C) {
					if (C) h = x;
					else if (e.multiline && (d + 2) * (v + 2) + 2 > o) continue t;
				} else {
					if (!e.multiline || (d + 2) * (v + 2) + 2 > o) continue t;
					h = x;
				}
			}
			for (var w = "", T = m; T <= h; T++) {
				var E = i[T];
				if (e.multiline) {
					if (T === h) {
						w += E[g] + " ", g = (g + 1) % E.length;
						continue;
					}
					if (T === m) {
						w += E[E.length - 1] + " ";
						continue;
					}
				}
				w += E[0] + " ";
			}
			switch (w = w.substr(w.length - 1) == " " ? w.substr(0, w.length - 1) : w, u = ps(w, e, a).width, e.textAlign) {
				case "right":
					l = s - u - 2;
					break;
				case "center":
					l = (s - u) / 2;
					break;
				default: l = 2;
			}
			t += Q(l) + " " + Q(p) + " Td\n", t += "(" + Zo(w) + ") Tj\n", t += -Q(l) + " 0 Td\n", p = -(a + 2), u = 0, m = b ? h : h + 1, v++, _ = "";
		}
		break;
	}
	return r.text = t, r.fontSize = a, r;
}, ps = function(e, t, n) {
	var r = t.scope.internal.getFont(t.fontName, t.fontStyle), i = t.scope.getStringUnitWidth(e, {
		font: r,
		fontSize: parseFloat(n),
		charSpace: 0
	}) * parseFloat(n);
	return {
		height: t.scope.getStringUnitWidth("3", {
			font: r,
			fontSize: parseFloat(n),
			charSpace: 0
		}) * parseFloat(n) * 1.5,
		width: i
	};
}, ms = {
	fields: [],
	xForms: [],
	acroFormDictionaryRoot: null,
	printedOut: !1,
	internal: null,
	isInitialized: !1
}, hs = function(e, t) {
	var n = {
		type: "reference",
		object: e
	};
	t.internal.getPageInfo(e.page).pageContext.annotations.find(function(e) {
		return e.type === n.type && e.object === n.object;
	}) === void 0 && t.internal.getPageInfo(e.page).pageContext.annotations.push(n);
}, gs = function(e, n) {
	if (n.scope = e, e.internal !== void 0 && (e.internal.acroformPlugin === void 0 || !1 === e.internal.acroformPlugin.isInitialized)) {
		if (Ss.FieldNum = 0, e.internal.acroformPlugin = JSON.parse(JSON.stringify(ms)), e.internal.acroformPlugin.acroFormDictionaryRoot) throw Error("Exception while creating AcroformDictionary");
		Xo = e.internal.scaleFactor, e.internal.acroformPlugin.acroFormDictionaryRoot = new xs(), e.internal.acroformPlugin.acroFormDictionaryRoot.scope = e, e.internal.acroformPlugin.acroFormDictionaryRoot._eventID = e.internal.events.subscribe("postPutResources", function() {
			(function(e) {
				e.internal.events.unsubscribe(e.internal.acroformPlugin.acroFormDictionaryRoot._eventID), delete e.internal.acroformPlugin.acroFormDictionaryRoot._eventID, e.internal.acroformPlugin.printedOut = !0;
			})(e);
		}), e.internal.events.subscribe("buildDocument", function() {
			(function(e) {
				e.internal.acroformPlugin.acroFormDictionaryRoot.objId = void 0;
				var t = e.internal.acroformPlugin.acroFormDictionaryRoot.Fields;
				for (var n in t) if (t.hasOwnProperty(n)) {
					var r = t[n];
					r.objId = void 0, r.hasAnnotation && hs(r, e);
				}
			})(e);
		}), e.internal.events.subscribe("putCatalog", function() {
			(function(e) {
				if (e.internal.acroformPlugin.acroFormDictionaryRoot === void 0) throw Error("putCatalogCallback: Root missing.");
				e.internal.write("/AcroForm " + e.internal.acroformPlugin.acroFormDictionaryRoot.objId + " 0 R");
			})(e);
		}), e.internal.events.subscribe("postPutPages", function(n) {
			(function(e, n) {
				var r = !e;
				for (var i in e || (n.internal.newObjectDeferredBegin(n.internal.acroformPlugin.acroFormDictionaryRoot.objId, !0), n.internal.acroformPlugin.acroFormDictionaryRoot.putStream()), e ||= n.internal.acroformPlugin.acroFormDictionaryRoot.Kids) if (e.hasOwnProperty(i)) {
					var a = e[i], o = [], s = a.Rect;
					if (a.Rect &&= us(a.Rect, n), n.internal.newObjectDeferredBegin(a.objId, !0), a.DA = $.createDefaultAppearanceStream(a), t(a) === "object" && typeof a.getKeyValueListForStream == "function" && (o = a.getKeyValueListForStream()), a.Rect = s, a.hasAppearanceStream && !a.appearanceStreamContent) {
						var c = ds(a);
						o.push({
							key: "AP",
							value: "<</N " + c + ">>"
						}), n.internal.acroformPlugin.xForms.push(c);
					}
					if (a.appearanceStreamContent) {
						var l = "";
						for (var u in a.appearanceStreamContent) if (a.appearanceStreamContent.hasOwnProperty(u)) {
							var d = a.appearanceStreamContent[u];
							if (l += "/" + u + " ", l += "<<", Object.keys(d).length >= 1 || Array.isArray(d)) {
								for (var i in d) if (d.hasOwnProperty(i)) {
									var f = d[i];
									typeof f == "function" && (f = f.call(n, a)), l += "/" + i + " " + f + " ", n.internal.acroformPlugin.xForms.indexOf(f) >= 0 || n.internal.acroformPlugin.xForms.push(f);
								}
							} else typeof (f = d) == "function" && (f = f.call(n, a)), l += "/" + i + " " + f, n.internal.acroformPlugin.xForms.indexOf(f) >= 0 || n.internal.acroformPlugin.xForms.push(f);
							l += ">>";
						}
						o.push({
							key: "AP",
							value: "<<\n" + l + ">>"
						});
					}
					n.internal.putStream({
						additionalKeyValues: o,
						objectId: a.objId
					}), n.internal.out("endobj");
				}
				r && function(e, n) {
					for (var r in e) if (e.hasOwnProperty(r)) {
						var i = r, a = e[r];
						n.internal.newObjectDeferredBegin(a.objId, !0), t(a) === "object" && typeof a.putStream == "function" && a.putStream(), delete e[i];
					}
				}(n.internal.acroformPlugin.xForms, n);
			})(n, e);
		}), e.internal.acroformPlugin.isInitialized = !0;
	}
}, _s = Yo.__acroform__.arrayToPdfArray = function(e, n, r) {
	var i = function(e) {
		return e;
	};
	if (Array.isArray(e)) {
		for (var a = "[", o = 0; o < e.length; o++) switch (o !== 0 && (a += " "), t(e[o])) {
			case "boolean":
			case "number":
			case "object":
				a += e[o].toString();
				break;
			case "string": e[o].substr(0, 1) === "/" ? a += "/" + $o(e[o].substr(1)) : (n !== void 0 && r && (i = r.internal.getEncryptor(n)), a += "(" + Zo(i(e[o].toString())) + ")");
		}
		return a + "]";
	}
	throw Error("Invalid argument passed to jsPDF.__acroform__.arrayToPdfArray");
}, vs = function(e, t, n) {
	var r = function(e) {
		return e;
	};
	return t !== void 0 && n && (r = n.internal.getEncryptor(t)), (e ||= "").toString(), "(" + Zo(r(e)) + ")";
}, ys = function() {
	this._objId = void 0, this._scope = void 0, Object.defineProperty(this, "objId", {
		get: function() {
			if (this._objId === void 0) {
				if (this.scope === void 0) return;
				this._objId = this.scope.internal.newObjectDeferred();
			}
			return this._objId;
		},
		set: function(e) {
			this._objId = e;
		}
	}), Object.defineProperty(this, "scope", {
		value: this._scope,
		writable: !0
	});
};
ys.prototype.toString = function() {
	return this.objId + " 0 R";
}, ys.prototype.putStream = function() {
	var e = this.getKeyValueListForStream();
	this.scope.internal.putStream({
		data: this.stream,
		additionalKeyValues: e,
		objectId: this.objId
	}), this.scope.internal.out("endobj");
}, ys.prototype.getKeyValueListForStream = function() {
	var e = [], t = Object.getOwnPropertyNames(this).filter(function(e) {
		return e != "content" && e != "appearanceStreamContent" && e != "scope" && e != "objId" && e.substring(0, 1) != "_";
	});
	for (var n in t) if (!1 === Object.getOwnPropertyDescriptor(this, t[n]).configurable) {
		var r = t[n], i = this[r];
		i && (Array.isArray(i) ? e.push({
			key: r,
			value: _s(i, this.objId, this.scope)
		}) : i instanceof ys ? (i.scope = this.scope, e.push({
			key: r,
			value: i.objId + " 0 R"
		})) : typeof i != "function" && e.push({
			key: r,
			value: i
		}));
	}
	return e;
};
var bs = function() {
	ys.call(this), Object.defineProperty(this, "Type", {
		value: "/XObject",
		configurable: !1,
		writable: !0
	}), Object.defineProperty(this, "Subtype", {
		value: "/Form",
		configurable: !1,
		writable: !0
	}), Object.defineProperty(this, "FormType", {
		value: 1,
		configurable: !1,
		writable: !0
	});
	var e, t = [];
	Object.defineProperty(this, "BBox", {
		configurable: !1,
		get: function() {
			return t;
		},
		set: function(e) {
			t = e;
		}
	}), Object.defineProperty(this, "Resources", {
		value: "2 0 R",
		configurable: !1,
		writable: !0
	}), Object.defineProperty(this, "stream", {
		enumerable: !1,
		configurable: !0,
		set: function(t) {
			e = t.trim();
		},
		get: function() {
			return e || null;
		}
	});
};
ts(bs, ys);
var xs = function() {
	ys.call(this);
	var e, t = [];
	Object.defineProperty(this, "Kids", {
		enumerable: !1,
		configurable: !0,
		get: function() {
			return t.length > 0 ? t : void 0;
		}
	}), Object.defineProperty(this, "Fields", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return t;
		}
	}), Object.defineProperty(this, "DA", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			if (e) {
				var t = function(e) {
					return e;
				};
				return this.scope && (t = this.scope.internal.getEncryptor(this.objId)), "(" + Zo(t(e)) + ")";
			}
		},
		set: function(t) {
			e = t;
		}
	});
};
ts(xs, ys);
var Ss = function e() {
	ys.call(this);
	var t = 4;
	Object.defineProperty(this, "F", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return t;
		},
		set: function(e) {
			if (isNaN(e)) throw Error("Invalid value \"" + e + "\" for attribute F supplied.");
			t = e;
		}
	}), Object.defineProperty(this, "showWhenPrinted", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(t, 3);
		},
		set: function(e) {
			this.F = !!e == 1 ? cs(t, 3) : ls(t, 3);
		}
	});
	var n = 0;
	Object.defineProperty(this, "Ff", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return n;
		},
		set: function(e) {
			if (isNaN(e)) throw Error("Invalid value \"" + e + "\" for attribute Ff supplied.");
			n = e;
		}
	});
	var r = [];
	Object.defineProperty(this, "Rect", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			if (r.length !== 0) return r;
		},
		set: function(e) {
			r = e === void 0 ? [] : e;
		}
	}), Object.defineProperty(this, "x", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !r || isNaN(r[0]) ? 0 : r[0];
		},
		set: function(e) {
			r[0] = e;
		}
	}), Object.defineProperty(this, "y", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !r || isNaN(r[1]) ? 0 : r[1];
		},
		set: function(e) {
			r[1] = e;
		}
	}), Object.defineProperty(this, "width", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !r || isNaN(r[2]) ? 0 : r[2];
		},
		set: function(e) {
			r[2] = e;
		}
	}), Object.defineProperty(this, "height", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !r || isNaN(r[3]) ? 0 : r[3];
		},
		set: function(e) {
			r[3] = e;
		}
	});
	var i = "";
	Object.defineProperty(this, "FT", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return i;
		},
		set: function(e) {
			switch (e) {
				case "/Btn":
				case "/Tx":
				case "/Ch":
				case "/Sig":
					i = e;
					break;
				default: throw Error("Invalid value \"" + e + "\" for attribute FT supplied.");
			}
		}
	});
	var a = null;
	Object.defineProperty(this, "T", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			if (!a || a.length < 1) {
				if (this instanceof As) return;
				a = "FieldObject" + e.FieldNum++;
			}
			var t = function(e) {
				return e;
			};
			return this.scope && (t = this.scope.internal.getEncryptor(this.objId)), "(" + Zo(t(a)) + ")";
		},
		set: function(e) {
			a = e.toString();
		}
	}), Object.defineProperty(this, "fieldName", {
		configurable: !0,
		enumerable: !0,
		get: function() {
			return a;
		},
		set: function(e) {
			a = e;
		}
	});
	var o = "helvetica";
	Object.defineProperty(this, "fontName", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return o;
		},
		set: function(e) {
			o = e;
		}
	});
	var s = "normal";
	Object.defineProperty(this, "fontStyle", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return s;
		},
		set: function(e) {
			s = e;
		}
	});
	var c = 0;
	Object.defineProperty(this, "fontSize", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return c;
		},
		set: function(e) {
			c = e;
		}
	});
	var l = void 0;
	Object.defineProperty(this, "maxFontSize", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return l === void 0 ? 50 / Xo : l;
		},
		set: function(e) {
			l = e;
		}
	});
	var u = "black";
	Object.defineProperty(this, "color", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return u;
		},
		set: function(e) {
			u = e;
		}
	});
	var d = "/F1 0 Tf 0 g";
	Object.defineProperty(this, "DA", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			if (!(!d || this instanceof As || this instanceof Ms)) return vs(d, this.objId, this.scope);
		},
		set: function(e) {
			e = e.toString(), d = e;
		}
	});
	var f = null;
	Object.defineProperty(this, "DV", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			if (f) return this instanceof Ds == 0 ? vs(f, this.objId, this.scope) : f;
		},
		set: function(e) {
			e = e.toString(), f = this instanceof Ds == 0 ? e.substr(0, 1) === "(" ? Qo(e.substr(1, e.length - 2)) : Qo(e) : e;
		}
	}), Object.defineProperty(this, "defaultValue", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return this instanceof Ds == 1 ? Qo(f.substr(1, f.length - 1)) : f;
		},
		set: function(e) {
			e = e.toString(), f = this instanceof Ds == 1 ? "/" + $o(e) : e;
		}
	});
	var p = null;
	Object.defineProperty(this, "_V", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			if (p) return p;
		},
		set: function(e) {
			this.V = e;
		}
	}), Object.defineProperty(this, "V", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			if (p) return this instanceof Ds == 0 ? vs(p, this.objId, this.scope) : p;
		},
		set: function(e) {
			e = e.toString(), p = this instanceof Ds == 0 ? e.substr(0, 1) === "(" ? Qo(e.substr(1, e.length - 2)) : Qo(e) : e;
		}
	}), Object.defineProperty(this, "value", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return this instanceof Ds == 1 ? Qo(p.substr(1, p.length - 1)) : p;
		},
		set: function(e) {
			e = e.toString(), p = this instanceof Ds == 1 ? "/" + $o(e) : e;
		}
	}), Object.defineProperty(this, "hasAnnotation", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return this.Rect;
		}
	}), Object.defineProperty(this, "Type", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return this.hasAnnotation ? "/Annot" : null;
		}
	}), Object.defineProperty(this, "Subtype", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return this.hasAnnotation ? "/Widget" : null;
		}
	});
	var m, h = !1;
	Object.defineProperty(this, "hasAppearanceStream", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return h;
		},
		set: function(e) {
			e = !!e, h = e;
		}
	}), Object.defineProperty(this, "page", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			if (m) return m;
		},
		set: function(e) {
			m = e;
		}
	}), Object.defineProperty(this, "readOnly", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 1);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 1) : ls(this.Ff, 1);
		}
	}), Object.defineProperty(this, "required", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 2);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 2) : ls(this.Ff, 2);
		}
	}), Object.defineProperty(this, "noExport", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 3);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 3) : ls(this.Ff, 3);
		}
	});
	var g = null;
	Object.defineProperty(this, "Q", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			if (g !== null) return g;
		},
		set: function(e) {
			if ([
				0,
				1,
				2
			].indexOf(e) === -1) throw Error("Invalid value \"" + e + "\" for attribute Q supplied.");
			g = e;
		}
	}), Object.defineProperty(this, "textAlign", {
		get: function() {
			var e;
			switch (g) {
				case 0:
				default:
					e = "left";
					break;
				case 1:
					e = "center";
					break;
				case 2: e = "right";
			}
			return e;
		},
		configurable: !0,
		enumerable: !0,
		set: function(e) {
			switch (e) {
				case "right":
				case 2:
					g = 2;
					break;
				case "center":
				case 1:
					g = 1;
					break;
				default: g = 0;
			}
		}
	});
};
ts(Ss, ys);
var Cs = function() {
	Ss.call(this), this.FT = "/Ch", this.V = "()", this.fontName = "zapfdingbats";
	var e = 0;
	Object.defineProperty(this, "TI", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return e;
		},
		set: function(t) {
			e = t;
		}
	}), Object.defineProperty(this, "topIndex", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return e;
		},
		set: function(t) {
			e = t;
		}
	});
	var t = [];
	Object.defineProperty(this, "Opt", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return _s(t, this.objId, this.scope);
		},
		set: function(e) {
			var n, r = [];
			typeof (n = e) == "string" && (r = function(e, t, n) {
				n ||= 1;
				for (var r, i = []; r = t.exec(e);) i.push(r[n]);
				return i;
			}(n, /\((.*?)\)/g)), t = r;
		}
	}), this.getOptions = function() {
		return t;
	}, this.setOptions = function(e) {
		t = e, this.sort && t.sort();
	}, this.addOption = function(e) {
		e = (e ||= "").toString(), t.push(e), this.sort && t.sort();
	}, this.removeOption = function(e, n) {
		for (n ||= !1, e = (e ||= "").toString(); t.indexOf(e) !== -1 && (t.splice(t.indexOf(e), 1), !1 !== n););
	}, Object.defineProperty(this, "combo", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 18);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 18) : ls(this.Ff, 18);
		}
	}), Object.defineProperty(this, "edit", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 19);
		},
		set: function(e) {
			!0 === this.combo && (this.Ff = !!e == 1 ? cs(this.Ff, 19) : ls(this.Ff, 19));
		}
	}), Object.defineProperty(this, "sort", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 20);
		},
		set: function(e) {
			!!e == 1 ? (this.Ff = cs(this.Ff, 20), t.sort()) : this.Ff = ls(this.Ff, 20);
		}
	}), Object.defineProperty(this, "multiSelect", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 22);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 22) : ls(this.Ff, 22);
		}
	}), Object.defineProperty(this, "doNotSpellCheck", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 23);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 23) : ls(this.Ff, 23);
		}
	}), Object.defineProperty(this, "commitOnSelChange", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 27);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 27) : ls(this.Ff, 27);
		}
	}), this.hasAppearanceStream = !1;
};
ts(Cs, Ss);
var ws = function() {
	Cs.call(this), this.fontName = "helvetica", this.combo = !1;
};
ts(ws, Cs);
var Ts = function() {
	ws.call(this), this.combo = !0;
};
ts(Ts, ws);
var Es = function() {
	Ts.call(this), this.edit = !0;
};
ts(Es, Ts);
var Ds = function() {
	Ss.call(this), this.FT = "/Btn", Object.defineProperty(this, "noToggleToOff", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 15);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 15) : ls(this.Ff, 15);
		}
	}), Object.defineProperty(this, "radio", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 16);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 16) : ls(this.Ff, 16);
		}
	}), Object.defineProperty(this, "pushButton", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 17);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 17) : ls(this.Ff, 17);
		}
	}), Object.defineProperty(this, "radioIsUnison", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 26);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 26) : ls(this.Ff, 26);
		}
	});
	var e, n = {};
	Object.defineProperty(this, "MK", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			var e = function(e) {
				return e;
			};
			if (this.scope && (e = this.scope.internal.getEncryptor(this.objId)), Object.keys(n).length !== 0) {
				var t, r = [];
				for (t in r.push("<<"), n) r.push("/" + t + " (" + Zo(e(n[t])) + ")");
				return r.push(">>"), r.join("\n");
			}
		},
		set: function(e) {
			t(e) === "object" && (n = e);
		}
	}), Object.defineProperty(this, "caption", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return n.CA || "";
		},
		set: function(e) {
			typeof e == "string" && (n.CA = e);
		}
	}), Object.defineProperty(this, "AS", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return e;
		},
		set: function(t) {
			var n = t == null ? "" : t.toString();
			n.substr(0, 1) === "/" && (n = n.substr(1)), e = "/" + $o(n);
		}
	}), Object.defineProperty(this, "appearanceState", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return e.substr(1, e.length - 1);
		},
		set: function(t) {
			e = "/" + $o(t);
		}
	});
};
ts(Ds, Ss);
var Os = function() {
	Ds.call(this), this.pushButton = !0;
};
ts(Os, Ds);
var ks = function() {
	Ds.call(this), this.radio = !0, this.pushButton = !1;
	var e = [];
	Object.defineProperty(this, "Kids", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return e;
		},
		set: function(t) {
			e = t === void 0 ? [] : t;
		}
	});
};
ts(ks, Ds);
var As = function() {
	var e, n;
	Ss.call(this), Object.defineProperty(this, "Parent", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return e;
		},
		set: function(t) {
			e = t;
		}
	}), Object.defineProperty(this, "optionName", {
		enumerable: !1,
		configurable: !0,
		get: function() {
			return n;
		},
		set: function(e) {
			n = e;
		}
	});
	var r, i = {};
	Object.defineProperty(this, "MK", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			var e = function(e) {
				return e;
			};
			this.scope && (e = this.scope.internal.getEncryptor(this.objId));
			var t, n = [];
			for (t in n.push("<<"), i) n.push("/" + t + " (" + Zo(e(i[t])) + ")");
			return n.push(">>"), n.join("\n");
		},
		set: function(e) {
			t(e) === "object" && (i = e);
		}
	}), Object.defineProperty(this, "caption", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return i.CA || "";
		},
		set: function(e) {
			typeof e == "string" && (i.CA = e);
		}
	}), Object.defineProperty(this, "AS", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return r;
		},
		set: function(e) {
			var t = e == null ? "" : e.toString();
			t.substr(0, 1) === "/" && (t = t.substr(1)), r = "/" + $o(t);
		}
	}), Object.defineProperty(this, "appearanceState", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return r.substr(1, r.length - 1);
		},
		set: function(e) {
			var t = e == null ? "" : e.toString();
			t.substr(0, 1) === "/" && (t = t.substr(1)), r = "/" + $o(t);
		}
	}), this.caption = "l", this.appearanceState = "Off", this._AppearanceType = $.RadioButton.Circle, this.appearanceStreamContent = this._AppearanceType.createAppearanceStream(this.optionName);
};
ts(As, Ss), ks.prototype.setAppearance = function(e) {
	if (!("createAppearanceStream" in e) || !("getCA" in e)) throw Error("Couldn't assign Appearance to RadioButton. Appearance was Invalid!");
	for (var t in this.Kids) if (this.Kids.hasOwnProperty(t)) {
		var n = this.Kids[t];
		n.appearanceStreamContent = e.createAppearanceStream(n.optionName), n.caption = e.getCA();
	}
}, ks.prototype.createOption = function(e) {
	var t = new As();
	return t.Parent = this, t.optionName = e, this.Kids.push(t), Ps.call(this.scope, t), t;
};
var js = function() {
	Ds.call(this), this.fontName = "zapfdingbats", this.caption = "3", this.appearanceState = "On", this.value = "On", this.textAlign = "center", this.appearanceStreamContent = $.CheckBox.createAppearanceStream();
};
ts(js, Ds);
var Ms = function() {
	Ss.call(this), this.FT = "/Tx", Object.defineProperty(this, "multiline", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 13);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 13) : ls(this.Ff, 13);
		}
	}), Object.defineProperty(this, "fileSelect", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 21);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 21) : ls(this.Ff, 21);
		}
	}), Object.defineProperty(this, "doNotSpellCheck", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 23);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 23) : ls(this.Ff, 23);
		}
	}), Object.defineProperty(this, "doNotScroll", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 24);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 24) : ls(this.Ff, 24);
		}
	}), Object.defineProperty(this, "comb", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 25);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 25) : ls(this.Ff, 25);
		}
	}), Object.defineProperty(this, "richText", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 26);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 26) : ls(this.Ff, 26);
		}
	});
	var e = null;
	Object.defineProperty(this, "MaxLen", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return e;
		},
		set: function(t) {
			e = t;
		}
	}), Object.defineProperty(this, "maxLength", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return e;
		},
		set: function(t) {
			Number.isInteger(t) && (e = t);
		}
	}), Object.defineProperty(this, "hasAppearanceStream", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return this.V || this.DV;
		}
	});
};
ts(Ms, Ss);
var Ns = function() {
	Ms.call(this), Object.defineProperty(this, "password", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !!ss(this.Ff, 14);
		},
		set: function(e) {
			this.Ff = !!e == 1 ? cs(this.Ff, 14) : ls(this.Ff, 14);
		}
	}), this.password = !0;
};
ts(Ns, Ms);
var $ = {
	CheckBox: {
		createAppearanceStream: function() {
			return {
				N: { On: $.CheckBox.YesNormal },
				D: {
					On: $.CheckBox.YesPushDown,
					Off: $.CheckBox.OffPushDown
				}
			};
		},
		YesPushDown: function(e) {
			var t = rs(e);
			t.scope = e.scope;
			var n = [], r = e.scope.internal.getFont(e.fontName, e.fontStyle).id, i = e.scope.__private__.encodeColorString(e.color), a = fs(e, e.caption);
			return n.push("0.749023 g"), n.push("0 0 " + Q($.internal.getWidth(e)) + " " + Q($.internal.getHeight(e)) + " re"), n.push("f"), n.push("BMC"), n.push("q"), n.push("0 0 1 rg"), n.push("/" + r + " " + Q(a.fontSize) + " Tf " + i), n.push("BT"), n.push(a.text), n.push("ET"), n.push("Q"), n.push("EMC"), t.stream = n.join("\n"), t;
		},
		YesNormal: function(e) {
			var t = rs(e);
			t.scope = e.scope;
			var n = e.scope.internal.getFont(e.fontName, e.fontStyle).id, r = e.scope.__private__.encodeColorString(e.color), i = [], a = $.internal.getHeight(e), o = $.internal.getWidth(e), s = fs(e, e.caption);
			return i.push("1 g"), i.push("0 0 " + Q(o) + " " + Q(a) + " re"), i.push("f"), i.push("q"), i.push("0 0 1 rg"), i.push("0 0 " + Q(o - 1) + " " + Q(a - 1) + " re"), i.push("W"), i.push("n"), i.push("0 g"), i.push("BT"), i.push("/" + n + " " + Q(s.fontSize) + " Tf " + r), i.push(s.text), i.push("ET"), i.push("Q"), t.stream = i.join("\n"), t;
		},
		OffPushDown: function(e) {
			var t = rs(e);
			t.scope = e.scope;
			var n = [];
			return n.push("0.749023 g"), n.push("0 0 " + Q($.internal.getWidth(e)) + " " + Q($.internal.getHeight(e)) + " re"), n.push("f"), t.stream = n.join("\n"), t;
		}
	},
	RadioButton: {
		Circle: {
			createAppearanceStream: function(e) {
				var t = {
					D: { Off: $.RadioButton.Circle.OffPushDown },
					N: {}
				};
				return t.N[e] = $.RadioButton.Circle.YesNormal, t.D[e] = $.RadioButton.Circle.YesPushDown, t;
			},
			getCA: function() {
				return "l";
			},
			YesNormal: function(e) {
				var t = rs(e);
				t.scope = e.scope;
				var n = [], r = $.internal.getWidth(e) <= $.internal.getHeight(e) ? $.internal.getWidth(e) / 4 : $.internal.getHeight(e) / 4;
				r = Number((.9 * r).toFixed(5));
				var i = $.internal.Bezier_C, a = Number((r * i).toFixed(5));
				return n.push("q"), n.push("1 0 0 1 " + es($.internal.getWidth(e) / 2) + " " + es($.internal.getHeight(e) / 2) + " cm"), n.push(r + " 0 m"), n.push(r + " " + a + " " + a + " " + r + " 0 " + r + " c"), n.push("-" + a + " " + r + " -" + r + " " + a + " -" + r + " 0 c"), n.push("-" + r + " -" + a + " -" + a + " -" + r + " 0 -" + r + " c"), n.push(a + " -" + r + " " + r + " -" + a + " " + r + " 0 c"), n.push("f"), n.push("Q"), t.stream = n.join("\n"), t;
			},
			YesPushDown: function(e) {
				var t = rs(e);
				t.scope = e.scope;
				var n = [], r = $.internal.getWidth(e) <= $.internal.getHeight(e) ? $.internal.getWidth(e) / 4 : $.internal.getHeight(e) / 4;
				r = Number((.9 * r).toFixed(5));
				var i = Number((2 * r).toFixed(5)), a = Number((i * $.internal.Bezier_C).toFixed(5)), o = Number((r * $.internal.Bezier_C).toFixed(5));
				return n.push("0.749023 g"), n.push("q"), n.push("1 0 0 1 " + es($.internal.getWidth(e) / 2) + " " + es($.internal.getHeight(e) / 2) + " cm"), n.push(i + " 0 m"), n.push(i + " " + a + " " + a + " " + i + " 0 " + i + " c"), n.push("-" + a + " " + i + " -" + i + " " + a + " -" + i + " 0 c"), n.push("-" + i + " -" + a + " -" + a + " -" + i + " 0 -" + i + " c"), n.push(a + " -" + i + " " + i + " -" + a + " " + i + " 0 c"), n.push("f"), n.push("Q"), n.push("0 g"), n.push("q"), n.push("1 0 0 1 " + es($.internal.getWidth(e) / 2) + " " + es($.internal.getHeight(e) / 2) + " cm"), n.push(r + " 0 m"), n.push(r + " " + o + " " + o + " " + r + " 0 " + r + " c"), n.push("-" + o + " " + r + " -" + r + " " + o + " -" + r + " 0 c"), n.push("-" + r + " -" + o + " -" + o + " -" + r + " 0 -" + r + " c"), n.push(o + " -" + r + " " + r + " -" + o + " " + r + " 0 c"), n.push("f"), n.push("Q"), t.stream = n.join("\n"), t;
			},
			OffPushDown: function(e) {
				var t = rs(e);
				t.scope = e.scope;
				var n = [], r = $.internal.getWidth(e) <= $.internal.getHeight(e) ? $.internal.getWidth(e) / 4 : $.internal.getHeight(e) / 4;
				r = Number((.9 * r).toFixed(5));
				var i = Number((2 * r).toFixed(5)), a = Number((i * $.internal.Bezier_C).toFixed(5));
				return n.push("0.749023 g"), n.push("q"), n.push("1 0 0 1 " + es($.internal.getWidth(e) / 2) + " " + es($.internal.getHeight(e) / 2) + " cm"), n.push(i + " 0 m"), n.push(i + " " + a + " " + a + " " + i + " 0 " + i + " c"), n.push("-" + a + " " + i + " -" + i + " " + a + " -" + i + " 0 c"), n.push("-" + i + " -" + a + " -" + a + " -" + i + " 0 -" + i + " c"), n.push(a + " -" + i + " " + i + " -" + a + " " + i + " 0 c"), n.push("f"), n.push("Q"), t.stream = n.join("\n"), t;
			}
		},
		Cross: {
			createAppearanceStream: function(e) {
				var t = {
					D: { Off: $.RadioButton.Cross.OffPushDown },
					N: {}
				};
				return t.N[e] = $.RadioButton.Cross.YesNormal, t.D[e] = $.RadioButton.Cross.YesPushDown, t;
			},
			getCA: function() {
				return "8";
			},
			YesNormal: function(e) {
				var t = rs(e);
				t.scope = e.scope;
				var n = [], r = $.internal.calculateCross(e);
				return n.push("q"), n.push("1 1 " + Q($.internal.getWidth(e) - 2) + " " + Q($.internal.getHeight(e) - 2) + " re"), n.push("W"), n.push("n"), n.push(Q(r.x1.x) + " " + Q(r.x1.y) + " m"), n.push(Q(r.x2.x) + " " + Q(r.x2.y) + " l"), n.push(Q(r.x4.x) + " " + Q(r.x4.y) + " m"), n.push(Q(r.x3.x) + " " + Q(r.x3.y) + " l"), n.push("s"), n.push("Q"), t.stream = n.join("\n"), t;
			},
			YesPushDown: function(e) {
				var t = rs(e);
				t.scope = e.scope;
				var n = $.internal.calculateCross(e), r = [];
				return r.push("0.749023 g"), r.push("0 0 " + Q($.internal.getWidth(e)) + " " + Q($.internal.getHeight(e)) + " re"), r.push("f"), r.push("q"), r.push("1 1 " + Q($.internal.getWidth(e) - 2) + " " + Q($.internal.getHeight(e) - 2) + " re"), r.push("W"), r.push("n"), r.push(Q(n.x1.x) + " " + Q(n.x1.y) + " m"), r.push(Q(n.x2.x) + " " + Q(n.x2.y) + " l"), r.push(Q(n.x4.x) + " " + Q(n.x4.y) + " m"), r.push(Q(n.x3.x) + " " + Q(n.x3.y) + " l"), r.push("s"), r.push("Q"), t.stream = r.join("\n"), t;
			},
			OffPushDown: function(e) {
				var t = rs(e);
				t.scope = e.scope;
				var n = [];
				return n.push("0.749023 g"), n.push("0 0 " + Q($.internal.getWidth(e)) + " " + Q($.internal.getHeight(e)) + " re"), n.push("f"), t.stream = n.join("\n"), t;
			}
		}
	},
	createDefaultAppearanceStream: function(e) {
		var t = e.scope.internal.getFont(e.fontName, e.fontStyle).id, n = e.scope.__private__.encodeColorString(e.color);
		return "/" + t + " " + e.fontSize + " Tf " + n;
	}
};
$.internal = {
	Bezier_C: .551915024494,
	calculateCross: function(e) {
		var t = $.internal.getWidth(e), n = $.internal.getHeight(e), r = Math.min(t, n);
		return {
			x1: {
				x: (t - r) / 2,
				y: (n - r) / 2 + r
			},
			x2: {
				x: (t - r) / 2 + r,
				y: (n - r) / 2
			},
			x3: {
				x: (t - r) / 2,
				y: (n - r) / 2
			},
			x4: {
				x: (t - r) / 2 + r,
				y: (n - r) / 2 + r
			}
		};
	}
}, $.internal.getWidth = function(e) {
	var n = 0;
	return t(e) === "object" && (n = ns(e.Rect[2])), n;
}, $.internal.getHeight = function(e) {
	var n = 0;
	return t(e) === "object" && (n = ns(e.Rect[3])), n;
};
var Ps = Yo.addField = function(e) {
	if (gs(this, e), !(e instanceof Ss)) throw Error("Invalid argument passed to jsPDF.addField.");
	var t;
	return (t = e).scope.internal.acroformPlugin.printedOut && (t.scope.internal.acroformPlugin.printedOut = !1, t.scope.internal.acroformPlugin.acroFormDictionaryRoot = null), t.scope.internal.acroformPlugin.acroFormDictionaryRoot.Fields.push(t), e.page = e.scope.internal.getCurrentPageInfo().pageNumber, this;
};
Yo.AcroFormChoiceField = Cs, Yo.AcroFormListBox = ws, Yo.AcroFormComboBox = Ts, Yo.AcroFormEditBox = Es, Yo.AcroFormButton = Ds, Yo.AcroFormPushButton = Os, Yo.AcroFormRadioButton = ks, Yo.AcroFormCheckBox = js, Yo.AcroFormTextField = Ms, Yo.AcroFormPasswordField = Ns, Yo.AcroFormAppearance = $, Yo.AcroForm = {
	ChoiceField: Cs,
	ListBox: ws,
	ComboBox: Ts,
	EditBox: Es,
	Button: Ds,
	PushButton: Os,
	RadioButton: ks,
	CheckBox: js,
	TextField: Ms,
	PasswordField: Ns,
	Appearance: $
}, Z.AcroForm = {
	ChoiceField: Cs,
	ListBox: ws,
	ComboBox: Ts,
	EditBox: Es,
	Button: Ds,
	PushButton: Os,
	RadioButton: ks,
	CheckBox: js,
	TextField: Ms,
	PasswordField: Ns,
	Appearance: $
}, Z.AcroForm;
function Fs(e) {
	return e.reduce(function(e, t, n) {
		return e[t] = n, e;
	}, {});
}
(function(e) {
	var n = "addImage_";
	e.__addimage__ = {};
	var r = "UNKNOWN", i = {
		PNG: [[
			137,
			80,
			78,
			71
		]],
		TIFF: [[
			77,
			77,
			0,
			42
		], [
			73,
			73,
			42,
			0
		]],
		JPEG: [
			[
				255,
				216,
				255,
				224,
				void 0,
				void 0,
				74,
				70,
				73,
				70,
				0
			],
			[
				255,
				216,
				255,
				225,
				void 0,
				void 0,
				69,
				120,
				105,
				102,
				0,
				0
			],
			[
				255,
				216,
				255,
				219
			],
			[
				255,
				216,
				255,
				238
			]
		],
		JPEG2000: [[
			0,
			0,
			0,
			12,
			106,
			80,
			32,
			32
		]],
		GIF87a: [[
			71,
			73,
			70,
			56,
			55,
			97
		]],
		GIF89a: [[
			71,
			73,
			70,
			56,
			57,
			97
		]],
		WEBP: [[
			82,
			73,
			70,
			70,
			void 0,
			void 0,
			void 0,
			void 0,
			87,
			69,
			66,
			80
		]],
		BMP: [
			[66, 77],
			[66, 65],
			[67, 73],
			[67, 80],
			[73, 67],
			[80, 84]
		]
	}, a = e.__addimage__.getImageFileTypeByImageData = function(e, t) {
		var n, a, o, s, c, l = r;
		if ((t ||= r) === "RGBA" || e.data !== void 0 && e.data instanceof Uint8ClampedArray && "height" in e && "width" in e) return "RGBA";
		if (C(e)) for (c in i) for (o = i[c], n = 0; n < o.length; n += 1) {
			for (s = !0, a = 0; a < o[n].length; a += 1) if (o[n][a] !== void 0 && o[n][a] !== e[a]) {
				s = !1;
				break;
			}
			if (!0 === s) {
				l = c;
				break;
			}
		}
		else for (c in i) for (o = i[c], n = 0; n < o.length; n += 1) {
			for (s = !0, a = 0; a < o[n].length; a += 1) if (o[n][a] !== void 0 && o[n][a] !== e.charCodeAt(a)) {
				s = !1;
				break;
			}
			if (!0 === s) {
				l = c;
				break;
			}
		}
		return l === r && t !== r && (l = t), l;
	}, o = function e(t) {
		for (var n = this.internal.write, r = this.internal.putStream, i = (0, this.internal.getFilters)(); i.indexOf("FlateEncode") !== -1;) i.splice(i.indexOf("FlateEncode"), 1);
		t.objectId = this.internal.newObject();
		var a = [];
		if (a.push({
			key: "Type",
			value: "/XObject"
		}), a.push({
			key: "Subtype",
			value: "/Image"
		}), a.push({
			key: "Width",
			value: t.width
		}), a.push({
			key: "Height",
			value: t.height
		}), t.colorSpace === v.INDEXED ? a.push({
			key: "ColorSpace",
			value: "[/Indexed /DeviceRGB " + (t.palette.length / 3 - 1) + " " + ("sMask" in t && t.sMask !== void 0 ? t.objectId + 2 : t.objectId + 1) + " 0 R]"
		}) : (a.push({
			key: "ColorSpace",
			value: "/" + t.colorSpace
		}), t.colorSpace === v.DEVICE_CMYK && a.push({
			key: "Decode",
			value: "[1 0 1 0 1 0 1 0]"
		})), a.push({
			key: "BitsPerComponent",
			value: t.bitsPerComponent
		}), "decodeParameters" in t && t.decodeParameters !== void 0 && a.push({
			key: "DecodeParms",
			value: "<<" + t.decodeParameters + ">>"
		}), "transparency" in t && Array.isArray(t.transparency) && t.transparency.length > 0) {
			for (var o = "", s = 0, c = t.transparency.length; s < c; s++) o += t.transparency[s] + " " + t.transparency[s] + " ";
			a.push({
				key: "Mask",
				value: "[" + o + "]"
			});
		}
		t.sMask !== void 0 && a.push({
			key: "SMask",
			value: t.objectId + 1 + " 0 R"
		});
		var l = t.filter === void 0 ? void 0 : ["/" + t.filter];
		if (r({
			data: t.data,
			additionalKeyValues: a,
			alreadyAppliedFilters: l,
			objectId: t.objectId
		}), n("endobj"), "sMask" in t && t.sMask !== void 0) {
			var u = t.sMaskBitsPerComponent ?? t.bitsPerComponent, d = {
				width: t.width,
				height: t.height,
				colorSpace: "DeviceGray",
				bitsPerComponent: u,
				data: t.sMask
			};
			"filter" in t && (d.decodeParameters = `/Predictor ${t.predictor} /Colors 1 /BitsPerComponent ${u} /Columns ${t.width}`, d.filter = t.filter), e.call(this, d);
		}
		if (t.colorSpace === v.INDEXED) {
			var f = this.internal.newObject();
			r({
				data: T(new Uint8Array(t.palette)),
				objectId: f
			}), n("endobj");
		}
	}, s = function() {
		var e = this.internal.collections[n + "images"];
		for (var t in e) o.call(this, e[t]);
	}, c = function() {
		var e, t = this.internal.collections[n + "images"], r = this.internal.write;
		for (var i in t) r("/I" + (e = t[i]).index, e.objectId, "0", "R");
	}, l = function() {
		this.internal.collections[n + "images"] || (this.internal.collections[n + "images"] = {}, this.internal.events.subscribe("putResources", s), this.internal.events.subscribe("putXobjectDict", c));
	}, u = function() {
		var e = this.internal.collections[n + "images"];
		return l.call(this), e;
	}, d = function() {
		return Object.keys(this.internal.collections[n + "images"]).length;
	}, f = function(t) {
		return typeof e["process" + t.toUpperCase()] == "function";
	}, p = function(e) {
		return t(e) === "object" && e.nodeType === 1;
	}, m = function(t, n) {
		if (t.nodeName === "IMG" && t.hasAttribute("src")) {
			var r = "" + t.getAttribute("src");
			if (r.indexOf("data:image/") === 0) return wo(unescape(r).split("base64,").pop());
			var i = e.loadFile(r, !0);
			if (i !== void 0) return i;
		}
		if (t.nodeName === "CANVAS") {
			if (t.width === 0 || t.height === 0) throw Error("Given canvas must have data. Canvas width: " + t.width + ", height: " + t.height);
			var a;
			switch (n) {
				case "PNG":
					a = "image/png";
					break;
				case "WEBP":
					a = "image/webp";
					break;
				default: a = "image/jpeg";
			}
			return wo(t.toDataURL(a, 1).split("base64,").pop());
		}
	}, h = function(e) {
		var t = this.internal.collections[n + "images"];
		if (t) {
			for (var r in t) if (e === t[r].alias) return t[r];
		}
	}, g = function(e, t, n) {
		return e || t || (e = -96, t = -96), e < 0 && (e = -1 * n.width * 72 / e / this.internal.scaleFactor), t < 0 && (t = -1 * n.height * 72 / t / this.internal.scaleFactor), e === 0 && (e = t * n.width / n.height), t === 0 && (t = e * n.height / n.width), [e, t];
	}, _ = function(e, t, n, r, i, a) {
		var o = g.call(this, n, r, i), s = this.internal.getCoordinateString, c = this.internal.getVerticalCoordinateString, l = u.call(this);
		if (n = o[0], r = o[1], l[i.index] = i, a) {
			a *= Math.PI / 180;
			var d = Math.cos(a), f = Math.sin(a), p = function(e) {
				return e.toFixed(4);
			}, m = [
				p(d),
				p(f),
				p(-1 * f),
				p(d),
				0,
				0,
				"cm"
			];
		}
		this.internal.write("q"), a ? (this.internal.write([
			1,
			"0",
			"0",
			1,
			s(e),
			c(t + r),
			"cm"
		].join(" ")), this.internal.write(m.join(" ")), this.internal.write([
			s(n),
			"0",
			"0",
			s(r),
			"0",
			"0",
			"cm"
		].join(" "))) : this.internal.write([
			s(n),
			"0",
			"0",
			s(r),
			s(e),
			c(t + r),
			"cm"
		].join(" ")), this.isAdvancedAPI() && this.internal.write("1 0 0 -1 0 0 cm"), this.internal.write("/I" + i.index + " Do"), this.internal.write("Q");
	}, v = e.color_spaces = {
		DEVICE_RGB: "DeviceRGB",
		DEVICE_GRAY: "DeviceGray",
		DEVICE_CMYK: "DeviceCMYK",
		CAL_GREY: "CalGray",
		CAL_RGB: "CalRGB",
		LAB: "Lab",
		ICC_BASED: "ICCBased",
		INDEXED: "Indexed",
		PATTERN: "Pattern",
		SEPARATION: "Separation",
		DEVICE_N: "DeviceN"
	};
	e.decode = {
		DCT_DECODE: "DCTDecode",
		FLATE_DECODE: "FlateDecode",
		LZW_DECODE: "LZWDecode",
		JPX_DECODE: "JPXDecode",
		JBIG2_DECODE: "JBIG2Decode",
		ASCII85_DECODE: "ASCII85Decode",
		ASCII_HEX_DECODE: "ASCIIHexDecode",
		RUN_LENGTH_DECODE: "RunLengthDecode",
		CCITT_FAX_DECODE: "CCITTFaxDecode"
	};
	var y = e.image_compression = {
		NONE: "NONE",
		FAST: "FAST",
		MEDIUM: "MEDIUM",
		SLOW: "SLOW"
	}, b = e.__addimage__.sHashCode = function(e) {
		var t, n, r = 0;
		if (typeof e == "string") for (n = e.length, t = 0; t < n; t++) r = (r << 5) - r + e.charCodeAt(t), r |= 0;
		else if (C(e)) for (n = e.byteLength / 2, t = 0; t < n; t++) r = (r << 5) - r + e[t], r |= 0;
		return r;
	}, x = e.__addimage__.validateStringAsBase64 = function(e) {
		(e ||= "").toString().trim();
		var t = !0;
		return e.length === 0 && (t = !1), e.length % 4 != 0 && (t = !1), !1 === /^[A-Za-z0-9+/]+$/.test(e.substr(0, e.length - 2)) && (t = !1), !1 === /^[A-Za-z0-9/][A-Za-z0-9+/]|[A-Za-z0-9+/]=|==$/.test(e.substr(-2)) && (t = !1), t;
	}, S = e.__addimage__.extractImageFromDataUrl = function(e) {
		if (e == null || !(e = e.trim()).startsWith("data:")) return null;
		var t = e.indexOf(",");
		return t < 0 ? null : e.substring(0, t).trim().endsWith("base64") ? e.substring(t + 1) : null;
	};
	e.__addimage__.isArrayBuffer = function(e) {
		return e instanceof ArrayBuffer;
	};
	var C = e.__addimage__.isArrayBufferView = function(e) {
		return e instanceof Int8Array || e instanceof Uint8Array || e instanceof Uint8ClampedArray || e instanceof Int16Array || e instanceof Uint16Array || e instanceof Int32Array || e instanceof Uint32Array || e instanceof Float32Array || e instanceof Float64Array;
	}, w = e.__addimage__.binaryStringToUint8Array = function(e) {
		for (var t = e.length, n = new Uint8Array(t), r = 0; r < t; r++) n[r] = e.charCodeAt(r);
		return n;
	}, T = e.__addimage__.arrayBufferToBinaryString = function(e) {
		for (var t = "", n = C(e) ? e : new Uint8Array(e), r = 0; r < n.length; r += 8192) t += String.fromCharCode.apply(null, n.subarray(r, r + 8192));
		return t;
	};
	e.addImage = function() {
		var e, n, i, a, o, s, c, u, d;
		if (typeof arguments[1] == "number" ? (n = r, i = arguments[1], a = arguments[2], o = arguments[3], s = arguments[4], c = arguments[5], u = arguments[6], d = arguments[7]) : (n = arguments[1], i = arguments[2], a = arguments[3], o = arguments[4], s = arguments[5], c = arguments[6], u = arguments[7], d = arguments[8]), t(e = arguments[0]) === "object" && !p(e) && "imageData" in e) {
			var f = e;
			e = f.imageData, n = f.format || n || r, i = f.x || i || 0, a = f.y || a || 0, o = f.w || f.width || o, s = f.h || f.height || s, c = f.alias || c, u = f.compression || u, d = f.rotation || f.angle || d;
		}
		var m = this.internal.getFilters();
		if (u === void 0 && m.indexOf("FlateEncode") !== -1 && (u = "SLOW"), isNaN(i) || isNaN(a)) throw Error("Invalid coordinates passed to jsPDF.addImage");
		l.call(this);
		var h = E.call(this, e, n, c, u);
		return _.call(this, i, a, o, s, h, d), this;
	};
	var E = function(t, n, i, o) {
		var s, c, l;
		if (typeof t == "string" && a(t) === r) {
			t = unescape(t);
			var u = D(t, !1);
			(u !== "" || (u = e.loadFile(t, !0)) !== void 0) && (t = u);
		}
		if (p(t) && (t = m(t, n)), n = a(t, n), !f(n)) throw Error("addImage does not support files of type '" + n + "', please ensure that a plugin for '" + n + "' support is added.");
		if (((l = i) == null || l.length === 0) && (i = function(e) {
			return typeof e == "string" || C(e) ? b(e) : C(e.data) ? b(e.data) : null;
		}(t)), (s = h.call(this, i)) || (t instanceof Uint8Array || n === "RGBA" || (c = t, t = w(t)), s = this["process" + n.toUpperCase()](t, d.call(this), i, function(t) {
			return t && typeof t == "string" && (t = t.toUpperCase()), t in e.image_compression ? t : y.NONE;
		}(o), c)), !s) throw Error("An unknown error occurred whilst processing the image.");
		return s;
	}, D = e.__addimage__.convertBase64ToBinaryString = function(e, t) {
		t = typeof t != "boolean" || t;
		var n, r = "";
		if (typeof e == "string") {
			n = S(e) ?? e;
			try {
				r = wo(n);
			} catch (e) {
				if (t) throw x(n) ? /* @__PURE__ */ Error("atob-Error in jsPDF.convertBase64ToBinaryString " + e.message) : /* @__PURE__ */ Error("Supplied Data is not a valid base64-String jsPDF.convertBase64ToBinaryString ");
			}
		}
		return r;
	};
	e.getImageProperties = function(t) {
		var n, i, o = "";
		if (p(t) && (t = m(t)), typeof t == "string" && a(t) === r && ((o = D(t, !1)) === "" && (o = e.loadFile(t) || ""), t = o), i = a(t), !f(i)) throw Error("addImage does not support files of type '" + i + "', please ensure that a plugin for '" + i + "' support is added.");
		if (t instanceof Uint8Array || (t = w(t)), !(n = this["process" + i.toUpperCase()](t))) throw Error("An unknown error occurred whilst processing the image");
		return n.fileType = i, n;
	};
})(Z.API), function(e) {
	var t = function(e) {
		if (e !== void 0 && e != "") return !0;
	};
	Z.API.events.push(["addPage", function(e) {
		this.internal.getPageInfo(e.pageNumber).pageContext.annotations = [];
	}]), e.events.push(["putPage", function(e) {
		for (var n, r, i, a = this.internal.getCoordinateString, o = this.internal.getVerticalCoordinateString, s = this.internal.getPageInfoByObjId(e.objId), c = e.pageContext.annotations, l = !1, u = 0; u < c.length && !l; u++) switch ((n = c[u]).type) {
			case "link":
				(t(n.options.url) || t(n.options.pageNumber)) && (l = !0);
				break;
			case "reference":
			case "text":
			case "freetext": l = !0;
		}
		if (l != 0) {
			this.internal.write("/Annots [");
			for (var d = 0; d < c.length; d++) {
				n = c[d];
				var f = this.internal.pdfEscape, p = this.internal.getEncryptor(e.objId);
				switch (n.type) {
					case "reference":
						this.internal.write(" " + n.object.objId + " 0 R ");
						break;
					case "text":
						var m = this.internal.newAdditionalObject(), h = this.internal.newAdditionalObject(), g = this.internal.getEncryptor(m.objId), _ = n.title || "Note";
						i = "<</Type /Annot /Subtype /Text " + (r = "/Rect [" + a(n.bounds.x) + " " + o(n.bounds.y + n.bounds.h) + " " + a(n.bounds.x + n.bounds.w) + " " + o(n.bounds.y) + "] ") + "/Contents (" + f(g(n.contents)) + ")", i += " /Popup " + h.objId + " 0 R", i += " /P " + s.objId + " 0 R", i += " /T (" + f(g(_)) + ") >>", m.content = i;
						var v = m.objId + " 0 R";
						i = "<</Type /Annot /Subtype /Popup " + (r = "/Rect [" + a(n.bounds.x + 30) + " " + o(n.bounds.y + n.bounds.h) + " " + a(n.bounds.x + n.bounds.w + 30) + " " + o(n.bounds.y) + "] ") + " /Parent " + v, n.open && (i += " /Open true"), i += " >>", h.content = i, this.internal.write(m.objId, "0 R", h.objId, "0 R");
						break;
					case "freetext":
						r = "/Rect [" + a(n.bounds.x) + " " + o(n.bounds.y) + " " + a(n.bounds.x + n.bounds.w) + " " + o(n.bounds.y + n.bounds.h) + "] ";
						var y = "font: Helvetica,sans-serif 12.0pt; text-align:left; color:#" + (n.color || "#000000");
						i = "<</Type /Annot /Subtype /FreeText " + r + "/Contents (" + f(p(n.contents)) + ")", i += " /DS(" + f(p(y)) + ")", i += " /Border [0 0 0]", i += " >>", this.internal.write(i);
						break;
					case "link":
						if (n.options.name) {
							var b = this.annotations._nameMap[n.options.name];
							n.options.pageNumber = b.page, n.options.top = b.y;
						} else n.options.top || (n.options.top = 0);
						if (r = "/Rect [" + n.finalBounds.x + " " + n.finalBounds.y + " " + n.finalBounds.w + " " + n.finalBounds.h + "] ", i = "", n.options.url) i = "<</Type /Annot /Subtype /Link " + r + "/Border [0 0 0] /A <</S /URI /URI (" + f(p(n.options.url)) + ") >>";
						else if (n.options.pageNumber) switch (i = "<</Type /Annot /Subtype /Link " + r + "/Border [0 0 0] /Dest [" + this.internal.getPageInfo(n.options.pageNumber).objId + " 0 R", n.options.magFactor = n.options.magFactor || "XYZ", n.options.magFactor) {
							case "Fit":
								i += " /Fit]";
								break;
							case "FitH":
								i += " /FitH " + n.options.top + "]";
								break;
							case "FitV":
								n.options.left = n.options.left || 0, i += " /FitV " + n.options.left + "]";
								break;
							default:
								var x = o(n.options.top);
								n.options.left = n.options.left || 0, n.options.zoom === void 0 && (n.options.zoom = 0), i += " /XYZ " + n.options.left + " " + x + " " + n.options.zoom + "]";
						}
						i != "" && (i += " >>", this.internal.write(i));
				}
			}
			this.internal.write("]");
		}
	}]), e.createAnnotation = function(e) {
		var t = this.internal.getCurrentPageInfo();
		switch (e.type) {
			case "link":
				this.link(e.bounds.x, e.bounds.y, e.bounds.w, e.bounds.h, e);
				break;
			case "text":
			case "freetext": t.pageContext.annotations.push(e);
		}
	}, e.link = function(e, t, n, r, i) {
		var a = this.internal.getCurrentPageInfo(), o = this.internal.getCoordinateString, s = this.internal.getVerticalCoordinateString;
		a.pageContext.annotations.push({
			finalBounds: {
				x: o(e),
				y: s(t),
				w: o(e + n),
				h: s(t + r)
			},
			options: i,
			type: "link"
		});
	}, e.textWithLink = function(e, t, n, r) {
		var i, a, o = this.getTextWidth(e), s = this.internal.getLineHeight() / this.internal.scaleFactor;
		if (r.maxWidth !== void 0) {
			a = r.maxWidth;
			var c = this.splitTextToSize(e, a).length;
			i = Math.ceil(s * c);
		} else a = o, i = s;
		return this.text(e, t, n, r), n += .2 * s, r.align === "center" && (t -= o / 2), r.align === "right" && (t -= o), this.link(t, n - s, a, i, r), o;
	}, e.getTextWidth = function(e) {
		var t = this.internal.getFontSize();
		return this.getStringUnitWidth(e) * t / this.internal.scaleFactor;
	};
}(Z.API), function(e) {
	var t = {
		1569: [65152],
		1570: [65153, 65154],
		1571: [65155, 65156],
		1572: [65157, 65158],
		1573: [65159, 65160],
		1574: [
			65161,
			65162,
			65163,
			65164
		],
		1575: [65165, 65166],
		1576: [
			65167,
			65168,
			65169,
			65170
		],
		1577: [65171, 65172],
		1578: [
			65173,
			65174,
			65175,
			65176
		],
		1579: [
			65177,
			65178,
			65179,
			65180
		],
		1580: [
			65181,
			65182,
			65183,
			65184
		],
		1581: [
			65185,
			65186,
			65187,
			65188
		],
		1582: [
			65189,
			65190,
			65191,
			65192
		],
		1583: [65193, 65194],
		1584: [65195, 65196],
		1585: [65197, 65198],
		1586: [65199, 65200],
		1587: [
			65201,
			65202,
			65203,
			65204
		],
		1588: [
			65205,
			65206,
			65207,
			65208
		],
		1589: [
			65209,
			65210,
			65211,
			65212
		],
		1590: [
			65213,
			65214,
			65215,
			65216
		],
		1591: [
			65217,
			65218,
			65219,
			65220
		],
		1592: [
			65221,
			65222,
			65223,
			65224
		],
		1593: [
			65225,
			65226,
			65227,
			65228
		],
		1594: [
			65229,
			65230,
			65231,
			65232
		],
		1601: [
			65233,
			65234,
			65235,
			65236
		],
		1602: [
			65237,
			65238,
			65239,
			65240
		],
		1603: [
			65241,
			65242,
			65243,
			65244
		],
		1604: [
			65245,
			65246,
			65247,
			65248
		],
		1605: [
			65249,
			65250,
			65251,
			65252
		],
		1606: [
			65253,
			65254,
			65255,
			65256
		],
		1607: [
			65257,
			65258,
			65259,
			65260
		],
		1608: [65261, 65262],
		1609: [
			65263,
			65264,
			64488,
			64489
		],
		1610: [
			65265,
			65266,
			65267,
			65268
		],
		1649: [64336, 64337],
		1655: [64477],
		1657: [
			64358,
			64359,
			64360,
			64361
		],
		1658: [
			64350,
			64351,
			64352,
			64353
		],
		1659: [
			64338,
			64339,
			64340,
			64341
		],
		1662: [
			64342,
			64343,
			64344,
			64345
		],
		1663: [
			64354,
			64355,
			64356,
			64357
		],
		1664: [
			64346,
			64347,
			64348,
			64349
		],
		1667: [
			64374,
			64375,
			64376,
			64377
		],
		1668: [
			64370,
			64371,
			64372,
			64373
		],
		1670: [
			64378,
			64379,
			64380,
			64381
		],
		1671: [
			64382,
			64383,
			64384,
			64385
		],
		1672: [64392, 64393],
		1676: [64388, 64389],
		1677: [64386, 64387],
		1678: [64390, 64391],
		1681: [64396, 64397],
		1688: [64394, 64395],
		1700: [
			64362,
			64363,
			64364,
			64365
		],
		1702: [
			64366,
			64367,
			64368,
			64369
		],
		1705: [
			64398,
			64399,
			64400,
			64401
		],
		1709: [
			64467,
			64468,
			64469,
			64470
		],
		1711: [
			64402,
			64403,
			64404,
			64405
		],
		1713: [
			64410,
			64411,
			64412,
			64413
		],
		1715: [
			64406,
			64407,
			64408,
			64409
		],
		1722: [64414, 64415],
		1723: [
			64416,
			64417,
			64418,
			64419
		],
		1726: [
			64426,
			64427,
			64428,
			64429
		],
		1728: [64420, 64421],
		1729: [
			64422,
			64423,
			64424,
			64425
		],
		1733: [64480, 64481],
		1734: [64473, 64474],
		1735: [64471, 64472],
		1736: [64475, 64476],
		1737: [64482, 64483],
		1739: [64478, 64479],
		1740: [
			64508,
			64509,
			64510,
			64511
		],
		1744: [
			64484,
			64485,
			64486,
			64487
		],
		1746: [64430, 64431],
		1747: [64432, 64433]
	}, n = {
		65247: {
			65154: 65269,
			65156: 65271,
			65160: 65273,
			65166: 65275
		},
		65248: {
			65154: 65270,
			65156: 65272,
			65160: 65274,
			65166: 65276
		},
		65165: { 65247: { 65248: { 65258: 65010 } } },
		1617: {
			1612: 64606,
			1613: 64607,
			1614: 64608,
			1615: 64609,
			1616: 64610
		}
	}, r = {
		1612: 64606,
		1613: 64607,
		1614: 64608,
		1615: 64609,
		1616: 64610
	}, i = [
		1570,
		1571,
		1573,
		1575
	];
	e.__arabicParser__ = {};
	var a = e.__arabicParser__.isInArabicSubstitutionA = function(e) {
		return t[e.charCodeAt(0)] !== void 0;
	}, o = e.__arabicParser__.isArabicLetter = function(e) {
		return typeof e == "string" && /^[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]+$/.test(e);
	}, s = e.__arabicParser__.isArabicEndLetter = function(e) {
		return o(e) && a(e) && t[e.charCodeAt(0)].length <= 2;
	}, c = e.__arabicParser__.isArabicAlfLetter = function(e) {
		return o(e) && i.indexOf(e.charCodeAt(0)) >= 0;
	};
	e.__arabicParser__.arabicLetterHasIsolatedForm = function(e) {
		return o(e) && a(e) && t[e.charCodeAt(0)].length >= 1;
	};
	var l = e.__arabicParser__.arabicLetterHasFinalForm = function(e) {
		return o(e) && a(e) && t[e.charCodeAt(0)].length >= 2;
	};
	e.__arabicParser__.arabicLetterHasInitialForm = function(e) {
		return o(e) && a(e) && t[e.charCodeAt(0)].length >= 3;
	};
	var u = e.__arabicParser__.arabicLetterHasMedialForm = function(e) {
		return o(e) && a(e) && t[e.charCodeAt(0)].length == 4;
	}, d = e.__arabicParser__.resolveLigatures = function(e) {
		var t = 0, r = n, i = "", a = 0;
		for (t = 0; t < e.length; t += 1) r[e.charCodeAt(t)] === void 0 ? (r = n, i += e.charAt(t - a), t -= a, a = 0) : (a++, typeof (r = r[e.charCodeAt(t)]) == "number" && (i += String.fromCharCode(r), r = n, a = 0), t === e.length - 1 && (r = n, i += e.charAt(t - (a - 1)), t -= a - 1, a = 0));
		return i;
	};
	e.__arabicParser__.isArabicDiacritic = function(e) {
		return e !== void 0 && r[e.charCodeAt(0)] !== void 0;
	};
	var f = e.__arabicParser__.getCorrectForm = function(e, t, n) {
		return o(e) ? !1 === a(e) ? -1 : !l(e) || !o(t) && !o(n) || !o(n) && s(t) || s(e) && !o(t) || s(e) && c(t) || s(e) && s(t) ? 0 : u(e) && o(t) && !s(t) && o(n) && l(n) ? 3 : s(e) || !o(n) ? 1 : 2 : -1;
	}, p = function(e) {
		var n = 0, r = 0, i = 0, a = "", s = "", c = "", l = (e ||= "").split("\\s+"), u = [];
		for (n = 0; n < l.length; n += 1) {
			for (u.push(""), r = 0; r < l[n].length; r += 1) a = l[n][r], s = l[n][r - 1], c = l[n][r + 1], o(a) ? (i = f(a, s, c), u[n] += i === -1 ? a : String.fromCharCode(t[a.charCodeAt(0)][i])) : u[n] += a;
			u[n] = d(u[n]);
		}
		return u.join(" ");
	}, m = e.__arabicParser__.processArabic = e.processArabic = function() {
		var e, t = typeof arguments[0] == "string" ? arguments[0] : arguments[0].text, n = [];
		if (Array.isArray(t)) {
			var r = 0;
			for (n = [], r = 0; r < t.length; r += 1) Array.isArray(t[r]) ? n.push([
				p(t[r][0]),
				t[r][1],
				t[r][2]
			]) : n.push([p(t[r])]);
			e = n;
		} else e = p(t);
		return typeof arguments[0] == "string" ? e : (arguments[0].text = e, arguments[0]);
	};
	e.events.push(["preProcessText", m]);
}(Z.API), Z.API.autoPrint = function(e) {
	var t;
	return (e ||= {}).variant = e.variant || "non-conform", e.variant === "javascript" ? this.addJS("print({});") : (this.internal.events.subscribe("postPutResources", function() {
		t = this.internal.newObject(), this.internal.out("<<"), this.internal.out("/S /Named"), this.internal.out("/Type /Action"), this.internal.out("/N /Print"), this.internal.out(">>"), this.internal.out("endobj");
	}), this.internal.events.subscribe("putCatalog", function() {
		this.internal.out("/OpenAction " + t + " 0 R");
	})), this;
}, function(e) {
	var t = function() {
		var e = void 0;
		Object.defineProperty(this, "pdf", {
			get: function() {
				return e;
			},
			set: function(t) {
				e = t;
			}
		});
		var t = 150;
		Object.defineProperty(this, "width", {
			get: function() {
				return t;
			},
			set: function(e) {
				t = isNaN(e) || !1 === Number.isInteger(e) || e < 0 ? 150 : e, this.getContext("2d").pageWrapXEnabled && (this.getContext("2d").pageWrapX = t + 1);
			}
		});
		var n = 300;
		Object.defineProperty(this, "height", {
			get: function() {
				return n;
			},
			set: function(e) {
				n = isNaN(e) || !1 === Number.isInteger(e) || e < 0 ? 300 : e, this.getContext("2d").pageWrapYEnabled && (this.getContext("2d").pageWrapY = n + 1);
			}
		});
		var r = [];
		Object.defineProperty(this, "childNodes", {
			get: function() {
				return r;
			},
			set: function(e) {
				r = e;
			}
		});
		var i = {};
		Object.defineProperty(this, "style", {
			get: function() {
				return i;
			},
			set: function(e) {
				i = e;
			}
		}), Object.defineProperty(this, "parentNode", {});
	};
	t.prototype.getContext = function(e, t) {
		var n;
		if ((e ||= "2d") !== "2d") return null;
		for (n in t) this.pdf.context2d.hasOwnProperty(n) && (this.pdf.context2d[n] = t[n]);
		return this.pdf.context2d._canvas = this, this.pdf.context2d;
	}, t.prototype.toDataURL = function() {
		throw Error("toDataURL is not implemented.");
	}, e.events.push(["initialized", function() {
		this.canvas = new t(), this.canvas.pdf = this;
	}]);
}(Z.API), function(e) {
	var n = {
		left: 0,
		top: 0,
		bottom: 0,
		right: 0
	}, r = !1, i = function() {
		this.internal.__cell__ === void 0 && (this.internal.__cell__ = {}, this.internal.__cell__.padding = 3, this.internal.__cell__.headerFunction = void 0, this.internal.__cell__.margins = Object.assign({}, n), this.internal.__cell__.margins.width = this.getPageWidth(), a.call(this));
	}, a = function() {
		this.internal.__cell__.lastCell = new o(), this.internal.__cell__.pages = 1;
	}, o = function() {
		var e = arguments[0];
		Object.defineProperty(this, "x", {
			enumerable: !0,
			get: function() {
				return e;
			},
			set: function(t) {
				e = t;
			}
		});
		var t = arguments[1];
		Object.defineProperty(this, "y", {
			enumerable: !0,
			get: function() {
				return t;
			},
			set: function(e) {
				t = e;
			}
		});
		var n = arguments[2];
		Object.defineProperty(this, "width", {
			enumerable: !0,
			get: function() {
				return n;
			},
			set: function(e) {
				n = e;
			}
		});
		var r = arguments[3];
		Object.defineProperty(this, "height", {
			enumerable: !0,
			get: function() {
				return r;
			},
			set: function(e) {
				r = e;
			}
		});
		var i = arguments[4];
		Object.defineProperty(this, "text", {
			enumerable: !0,
			get: function() {
				return i;
			},
			set: function(e) {
				i = e;
			}
		});
		var a = arguments[5];
		Object.defineProperty(this, "lineNumber", {
			enumerable: !0,
			get: function() {
				return a;
			},
			set: function(e) {
				a = e;
			}
		});
		var o = arguments[6];
		return Object.defineProperty(this, "align", {
			enumerable: !0,
			get: function() {
				return o;
			},
			set: function(e) {
				o = e;
			}
		}), this;
	};
	o.prototype.clone = function() {
		return new o(this.x, this.y, this.width, this.height, this.text, this.lineNumber, this.align);
	}, o.prototype.toArray = function() {
		return [
			this.x,
			this.y,
			this.width,
			this.height,
			this.text,
			this.lineNumber,
			this.align
		];
	}, e.setHeaderFunction = function(e) {
		return i.call(this), this.internal.__cell__.headerFunction = typeof e == "function" ? e : void 0, this;
	}, e.getTextDimensions = function(e, t) {
		i.call(this);
		var n = (t ||= {}).fontSize || this.getFontSize(), r = t.font || this.getFont(), a = t.scaleFactor || this.internal.scaleFactor, o = 0, s = 0, c = 0, l = this;
		if (!Array.isArray(e) && typeof e != "string") {
			if (typeof e != "number") throw Error("getTextDimensions expects text-parameter to be of type String or type Number or an Array of Strings.");
			e = String(e);
		}
		var u = t.maxWidth;
		u > 0 ? typeof e == "string" ? e = this.splitTextToSize(e, u) : Object.prototype.toString.call(e) === "[object Array]" && (e = e.reduce(function(e, t) {
			return e.concat(l.splitTextToSize(t, u));
		}, [])) : e = Array.isArray(e) ? e : [e];
		for (var d = 0; d < e.length; d++) o < (c = this.getStringUnitWidth(e[d], { font: r }) * n) && (o = c);
		return o !== 0 && (s = e.length), {
			w: o /= a,
			h: Math.max((s * n * this.getLineHeightFactor() - n * (this.getLineHeightFactor() - 1)) / a, 0)
		};
	}, e.cellAddPage = function() {
		i.call(this), this.addPage();
		var e = this.internal.__cell__.margins || n;
		return this.internal.__cell__.lastCell = new o(e.left, e.top, void 0, void 0), this.internal.__cell__.pages += 1, this;
	};
	var s = e.cell = function() {
		var e = arguments[0] instanceof o ? arguments[0] : new o(arguments[0], arguments[1], arguments[2], arguments[3], arguments[4], arguments[5], arguments[6]);
		i.call(this);
		var t = this.internal.__cell__.lastCell, a = this.internal.__cell__.padding, s = this.internal.__cell__.margins || n, c = this.internal.__cell__.tableHeaderRow, l = this.internal.__cell__.printHeaders;
		return t.lineNumber !== void 0 && (t.lineNumber === e.lineNumber ? (e.x = (t.x || 0) + (t.width || 0), e.y = t.y || 0) : t.y + t.height + e.height + s.bottom > this.getPageHeight() ? (this.cellAddPage(), e.y = s.top, l && c && (this.printHeaderRow(e.lineNumber, !0), e.y += c[0].height)) : e.y = t.y + t.height || e.y), e.text[0] !== void 0 && (this.rect(e.x, e.y, e.width, e.height, !0 === r ? "FD" : void 0), e.align === "right" ? this.text(e.text, e.x + e.width - a, e.y + a, {
			align: "right",
			baseline: "top"
		}) : e.align === "center" ? this.text(e.text, e.x + e.width / 2, e.y + a, {
			align: "center",
			baseline: "top",
			maxWidth: e.width - a - a
		}) : this.text(e.text, e.x + a, e.y + a, {
			align: "left",
			baseline: "top",
			maxWidth: e.width - a - a
		})), this.internal.__cell__.lastCell = e, this;
	};
	e.table = function(e, r, l, u, d) {
		if (i.call(this), !l) throw Error("No data for PDF table.");
		var f, p, m, h, g = [], _ = [], v = [], y = {}, b = {}, x = [], S = [], C = (d ||= {}).autoSize || !1, w = !1 !== d.printHeaders, T = d.css && d.css["font-size"] !== void 0 ? 16 * d.css["font-size"] : d.fontSize || 12, E = d.margins || Object.assign({ width: this.getPageWidth() }, n), D = typeof d.padding == "number" ? d.padding : 3, O = d.headerBackgroundColor || "#c8c8c8", k = d.headerTextColor || "#000";
		if (a.call(this), this.internal.__cell__.printHeaders = w, this.internal.__cell__.margins = E, this.internal.__cell__.table_font_size = T, this.internal.__cell__.padding = D, this.internal.__cell__.headerBackgroundColor = O, this.internal.__cell__.headerTextColor = k, this.setFontSize(T), u == null) _ = g = Object.keys(l[0]), v = g.map(function() {
			return "left";
		});
		else if (Array.isArray(u) && t(u[0]) === "object") for (g = u.map(function(e) {
			return e.name;
		}), _ = u.map(function(e) {
			return e.prompt || e.name || "";
		}), v = u.map(function(e) {
			return e.align || "left";
		}), f = 0; f < u.length; f += 1) b[u[f].name] = .7499990551181103 * u[f].width;
		else Array.isArray(u) && typeof u[0] == "string" && (_ = g = u, v = g.map(function() {
			return "left";
		}));
		if (C || Array.isArray(u) && typeof u[0] == "string") for (f = 0; f < g.length; f += 1) {
			for (y[h = g[f]] = l.map(function(e) {
				return e[h];
			}), this.setFont(void 0, "bold"), x.push(this.getTextDimensions(_[f], {
				fontSize: this.internal.__cell__.table_font_size,
				scaleFactor: this.internal.scaleFactor
			}).w), p = y[h], this.setFont(void 0, "normal"), m = 0; m < p.length; m += 1) x.push(this.getTextDimensions(p[m], {
				fontSize: this.internal.__cell__.table_font_size,
				scaleFactor: this.internal.scaleFactor
			}).w);
			b[h] = Math.max.apply(null, x) + D + D, x = [];
		}
		if (w) {
			var A = {};
			for (f = 0; f < g.length; f += 1) A[g[f]] = {}, A[g[f]].text = _[f], A[g[f]].align = v[f];
			var j = c.call(this, A, b);
			S = g.map(function(t) {
				return new o(e, r, b[t], j, A[t].text, void 0, A[t].align);
			}), this.setTableHeaderRow(S), this.printHeaderRow(1, !1);
		}
		var M = u.reduce(function(e, t) {
			return e[t.name] = t.align, e;
		}, {});
		for (f = 0; f < l.length; f += 1) {
			"rowStart" in d && d.rowStart instanceof Function && d.rowStart({
				row: f,
				data: l[f]
			}, this);
			var N = c.call(this, l[f], b);
			for (m = 0; m < g.length; m += 1) {
				var P = l[f][g[m]];
				"cellStart" in d && d.cellStart instanceof Function && d.cellStart({
					row: f,
					col: m,
					data: P
				}, this), s.call(this, new o(e, r, b[g[m]], N, P, f + 2, M[g[m]]));
			}
		}
		return this.internal.__cell__.table_x = e, this.internal.__cell__.table_y = r, this;
	};
	var c = function(e, t) {
		var n = this.internal.__cell__.padding, r = this.internal.__cell__.table_font_size, i = this.internal.scaleFactor;
		return Object.keys(e).map(function(r) {
			var i = e[r];
			return this.splitTextToSize(i.hasOwnProperty("text") ? i.text : i, t[r] - n - n);
		}, this).map(function(e) {
			return this.getLineHeightFactor() * e.length * r / i + n + n;
		}, this).reduce(function(e, t) {
			return Math.max(e, t);
		}, 0);
	};
	e.setTableHeaderRow = function(e) {
		i.call(this), this.internal.__cell__.tableHeaderRow = e;
	}, e.printHeaderRow = function(e, t) {
		if (i.call(this), !this.internal.__cell__.tableHeaderRow) throw Error("Property tableHeaderRow does not exist.");
		var n;
		if (r = !0, typeof this.internal.__cell__.headerFunction == "function") {
			var a = this.internal.__cell__.headerFunction(this, this.internal.__cell__.pages);
			this.internal.__cell__.lastCell = new o(a[0], a[1], a[2], a[3], void 0, -1);
		}
		this.setFont(void 0, "bold");
		for (var c = [], l = 0; l < this.internal.__cell__.tableHeaderRow.length; l += 1) {
			n = this.internal.__cell__.tableHeaderRow[l].clone(), t && (n.y = this.internal.__cell__.margins.top || 0, c.push(n)), n.lineNumber = e;
			var u = this.getTextColor();
			this.setTextColor(this.internal.__cell__.headerTextColor), this.setFillColor(this.internal.__cell__.headerBackgroundColor), s.call(this, n), this.setTextColor(u);
		}
		c.length > 0 && this.setTableHeaderRow(c), this.setFont(void 0, "normal"), r = !1;
	};
}(Z.API);
var Is = {
	italic: [
		"italic",
		"oblique",
		"normal"
	],
	oblique: [
		"oblique",
		"italic",
		"normal"
	],
	normal: [
		"normal",
		"oblique",
		"italic"
	]
}, Ls = [
	"ultra-condensed",
	"extra-condensed",
	"condensed",
	"semi-condensed",
	"normal",
	"semi-expanded",
	"expanded",
	"extra-expanded",
	"ultra-expanded"
], Rs = Fs(Ls), zs = [
	100,
	200,
	300,
	400,
	500,
	600,
	700,
	800,
	900
], Bs = Fs(zs);
function Vs(e) {
	var t = e.family.replace(/"|'/g, "").toLowerCase(), n = function(e) {
		return Is[e ||= "normal"] ? e : "normal";
	}(e.style), r = function(e) {
		return e ? typeof e == "number" ? e >= 100 && e <= 900 && e % 100 == 0 ? e : 400 : /^\d00$/.test(e) ? parseInt(e) : e === "bold" ? 700 : 400 : 400;
	}(e.weight), i = function(e) {
		return typeof Rs[e ||= "normal"] == "number" ? e : "normal";
	}(e.stretch);
	return {
		family: t,
		style: n,
		weight: r,
		stretch: i,
		src: e.src || [],
		ref: e.ref || {
			name: t,
			style: [
				i,
				n,
				r
			].join(" ")
		}
	};
}
function Hs(e, t, n, r) {
	for (var i = n; i >= 0 && i < t.length; i += r) if (e[t[i]]) return e[t[i]];
	for (i = n; i >= 0 && i < t.length; i -= r) if (e[t[i]]) return e[t[i]];
}
var Us = {
	"sans-serif": "helvetica",
	fixed: "courier",
	monospace: "courier",
	terminal: "courier",
	cursive: "times",
	fantasy: "times",
	serif: "times"
}, Ws = {
	caption: "times",
	icon: "times",
	menu: "times",
	"message-box": "times",
	"small-caption": "times",
	"status-bar": "times"
};
function Gs(e) {
	return [
		e.stretch,
		e.style,
		e.weight,
		e.family
	].join(" ");
}
function Ks(e) {
	return e.trimLeft();
}
function qs(e, t) {
	for (var n = 0; n < e.length;) {
		if (e.charAt(n) === t) return [e.substring(0, n), e.substring(n + 1)];
		n += 1;
	}
	return null;
}
function Js(e) {
	var t = e.match(/^(-[a-z_]|[a-z_])[a-z0-9_-]*/i);
	return t === null ? null : [t[0], e.substring(t[0].length)];
}
var Ys, Xs, Zs, Qs, $s, ec = ["times"];
function tc(e, t, n, r, i) {
	var a = 4, o = ic;
	switch (i) {
		case Z.API.image_compression.FAST:
			a = 1, o = rc;
			break;
		case Z.API.image_compression.MEDIUM:
			a = 6, o = ac;
			break;
		case Z.API.image_compression.SLOW: a = 9, o = oc;
	}
	e = function(e, t, n, r) {
		for (var i, a = e.length / t, o = new Uint8Array(e.length + a), s = [
			nc,
			rc,
			ic,
			ac,
			oc
		], c = 0; c < a; c += 1) {
			var l = c * t, u = e.subarray(l, l + t);
			if (r) o.set(r(u, n, i), l + c);
			else {
				for (var d = s.length, f = [], p = 0; p < d; p += 1) f[p] = s[p](u, n, i);
				var m = cc(f.concat());
				o.set(f[m], l + c);
			}
			i = u;
		}
		return o;
	}(e, t, Math.ceil(n * r / 8), o);
	var s = we(e, { level: a });
	return Z.API.__addimage__.arrayBufferToBinaryString(s);
}
function nc(e) {
	var t = Array.apply([], e);
	return t.unshift(0), t;
}
function rc(e, t) {
	var n = e.length, r = [];
	r[0] = 1;
	for (var i = 0; i < n; i += 1) {
		var a = e[i - t] || 0;
		r[i + 1] = e[i] - a + 256 & 255;
	}
	return r;
}
function ic(e, t, n) {
	var r = e.length, i = [];
	i[0] = 2;
	for (var a = 0; a < r; a += 1) {
		var o = n && n[a] || 0;
		i[a + 1] = e[a] - o + 256 & 255;
	}
	return i;
}
function ac(e, t, n) {
	var r = e.length, i = [];
	i[0] = 3;
	for (var a = 0; a < r; a += 1) {
		var o = e[a - t] || 0, s = n && n[a] || 0;
		i[a + 1] = e[a] + 256 - (o + s >>> 1) & 255;
	}
	return i;
}
function oc(e, t, n) {
	var r = e.length, i = [];
	i[0] = 4;
	for (var a = 0; a < r; a += 1) {
		var o = sc(e[a - t] || 0, n && n[a] || 0, n && n[a - t] || 0);
		i[a + 1] = e[a] - o + 256 & 255;
	}
	return i;
}
function sc(e, t, n) {
	if (e === t && t === n) return e;
	var r = Math.abs(t - n), i = Math.abs(e - n), a = Math.abs(e + t - n - n);
	return r <= i && r <= a ? e : i <= a ? t : n;
}
function cc(e) {
	var t = e.map(function(e) {
		return e.reduce(function(e, t) {
			return e + Math.abs(t);
		}, 0);
	});
	return t.indexOf(Math.min.apply(null, t));
}
function lc(e, t, n) {
	var r = t * n, i = Math.floor(r / 8), a = 16 - (r - 8 * i + n), o = (1 << n) - 1;
	return dc(e, i) >> a & o;
}
function uc(e, t, n, r) {
	var i = n * r, a = Math.floor(i / 8), o = 16 - (i - 8 * a + r), s = (1 << r) - 1, c = (t & s) << o;
	(function(e, t, n) {
		if (t + 1 < e.byteLength) e.setUint16(t, n, !1);
		else {
			var r = n >> 8 & 255;
			e.setUint8(t, r);
		}
	})(e, a, dc(e, a) & ~(s << o) & 65535 | c);
}
function dc(e, t) {
	return t + 1 < e.byteLength ? e.getUint16(t, !1) : e.getUint8(t) << 8;
}
function fc(e) {
	var t = 0;
	if (e[t++] !== 71 || e[t++] !== 73 || e[t++] !== 70 || e[t++] !== 56 || (e[t++] + 1 & 253) != 56 || e[t++] !== 97) throw Error("Invalid GIF 87a/89a header.");
	var n = e[t++] | e[t++] << 8, r = e[t++] | e[t++] << 8, i = e[t++], a = i >> 7, o = 1 << 1 + (7 & i);
	e[t++], e[t++];
	var s = null, c = null;
	a && (s = t, c = o, t += 3 * o);
	var l = !0, u = [], d = 0, f = null, p = 0, m = null;
	for (this.width = n, this.height = r; l && t < e.length;) switch (e[t++]) {
		case 33:
			switch (e[t++]) {
				case 255:
					if (e[t] !== 11 || e[t + 1] == 78 && e[t + 2] == 69 && e[t + 3] == 84 && e[t + 4] == 83 && e[t + 5] == 67 && e[t + 6] == 65 && e[t + 7] == 80 && e[t + 8] == 69 && e[t + 9] == 50 && e[t + 10] == 46 && e[t + 11] == 48 && e[t + 12] == 3 && e[t + 13] == 1 && e[t + 16] == 0) t += 14, m = e[t++] | e[t++] << 8, t++;
					else for (t += 12;;) {
						if (!((D = e[t++]) >= 0)) throw Error("Invalid block size");
						if (D === 0) break;
						t += D;
					}
					break;
				case 249:
					if (e[t++] !== 4 || e[t + 4] !== 0) throw Error("Invalid graphics extension block.");
					var h = e[t++];
					d = e[t++] | e[t++] << 8, f = e[t++], 1 & h || (f = null), p = h >> 2 & 7, t++;
					break;
				case 254:
					for (;;) {
						if (!((D = e[t++]) >= 0)) throw Error("Invalid block size");
						if (D === 0) break;
						t += D;
					}
					break;
				default: throw Error("Unknown graphic control label: 0x" + e[t - 1].toString(16));
			}
			break;
		case 44:
			var g = e[t++] | e[t++] << 8, _ = e[t++] | e[t++] << 8, v = e[t++] | e[t++] << 8, y = e[t++] | e[t++] << 8, b = e[t++], x = b >> 6 & 1, S = 1 << 1 + (7 & b), C = s, w = c, T = !1;
			b >> 7 && (T = !0, C = t, w = S, t += 3 * S);
			var E = t;
			for (t++;;) {
				var D;
				if (!((D = e[t++]) >= 0)) throw Error("Invalid block size");
				if (D === 0) break;
				t += D;
			}
			u.push({
				x: g,
				y: _,
				width: v,
				height: y,
				has_local_palette: T,
				palette_offset: C,
				palette_size: w,
				data_offset: E,
				data_length: t - E,
				transparent_index: f,
				interlaced: !!x,
				delay: d,
				disposal: p
			});
			break;
		case 59:
			l = !1;
			break;
		default: throw Error("Unknown gif block: 0x" + e[t - 1].toString(16));
	}
	this.numFrames = function() {
		return u.length;
	}, this.loopCount = function() {
		return m;
	}, this.frameInfo = function(e) {
		if (e < 0 || e >= u.length) throw Error("Frame index out of range.");
		return u[e];
	}, this.decodeAndBlitFrameBGRA = function(t, r) {
		var i = this.frameInfo(t), a = i.width * i.height;
		if (a > 536870912) throw Error("Image dimensions exceed 512MB, which is too large.");
		var o = new Uint8Array(a);
		pc(e, i.data_offset, o, a);
		var s = i.palette_offset, c = i.transparent_index;
		c === null && (c = 256);
		var l = i.width, u = n - l, d = l, f = 4 * (i.y * n + i.x), p = 4 * ((i.y + i.height) * n + i.x), m = f, h = 4 * u;
		!0 === i.interlaced && (h += 4 * n * 7);
		for (var g = 8, _ = 0, v = o.length; _ < v; ++_) {
			var y = o[_];
			if (d === 0 && (d = l, (m += h) >= p && (h = 4 * u + 4 * n * (g - 1), m = f + (l + u) * (g << 1), g >>= 1)), y === c) m += 4;
			else {
				var b = e[s + 3 * y], x = e[s + 3 * y + 1], S = e[s + 3 * y + 2];
				r[m++] = S, r[m++] = x, r[m++] = b, r[m++] = 255;
			}
			--d;
		}
	}, this.decodeAndBlitFrameRGBA = function(t, r) {
		var i = this.frameInfo(t), a = i.width * i.height;
		if (a > 536870912) throw Error("Image dimensions exceed 512MB, which is too large.");
		var o = new Uint8Array(a);
		pc(e, i.data_offset, o, a);
		var s = i.palette_offset, c = i.transparent_index;
		c === null && (c = 256);
		var l = i.width, u = n - l, d = l, f = 4 * (i.y * n + i.x), p = 4 * ((i.y + i.height) * n + i.x), m = f, h = 4 * u;
		!0 === i.interlaced && (h += 4 * n * 7);
		for (var g = 8, _ = 0, v = o.length; _ < v; ++_) {
			var y = o[_];
			if (d === 0 && (d = l, (m += h) >= p && (h = 4 * u + 4 * n * (g - 1), m = f + (l + u) * (g << 1), g >>= 1)), y === c) m += 4;
			else {
				var b = e[s + 3 * y], x = e[s + 3 * y + 1], S = e[s + 3 * y + 2];
				r[m++] = b, r[m++] = x, r[m++] = S, r[m++] = 255;
			}
			--d;
		}
	};
}
function pc(e, t, n, r) {
	for (var i = e[t++], a = 1 << i, o = a + 1, s = o + 1, c = i + 1, l = (1 << c) - 1, u = 0, d = 0, f = 0, p = e[t++], m = /* @__PURE__ */ new Int32Array(4096), h = null;;) {
		for (; u < 16 && p !== 0;) d |= e[t++] << u, u += 8, p === 1 ? p = e[t++] : --p;
		if (u < c) break;
		var g = d & l;
		if (d >>= c, u -= c, g !== a) {
			if (g === o) break;
			for (var _ = g < s ? g : h, v = 0, y = _; y > a;) y = m[y] >> 8, ++v;
			var b = y;
			if (f + v + (_ === g ? 0 : 1) > r) return void vo.log("Warning, gif stream longer than expected.");
			n[f++] = b;
			var x = f += v;
			for (_ !== g && (n[f++] = b), y = _; v--;) y = m[y], n[--x] = 255 & y, y >>= 8;
			h !== null && s < 4096 && (m[s++] = h << 8 | b, s >= l + 1 && c < 12 && (++c, l = l << 1 | 1)), h = g;
		} else s = o + 1, l = (1 << (c = i + 1)) - 1, h = null;
	}
	return f !== r && vo.log("Warning, gif stream shorter than expected."), n;
}
function mc(e) {
	var t, n, r, i, a, o = Math.floor, s = Array(64), c = Array(64), l = Array(64), u = Array(64), d = Array(65535), f = Array(65535), p = Array(64), m = Array(64), h = [], g = 0, _ = 7, v = Array(64), y = Array(64), b = Array(64), x = Array(256), S = Array(2048), C = [
		0,
		1,
		5,
		6,
		14,
		15,
		27,
		28,
		2,
		4,
		7,
		13,
		16,
		26,
		29,
		42,
		3,
		8,
		12,
		17,
		25,
		30,
		41,
		43,
		9,
		11,
		18,
		24,
		31,
		40,
		44,
		53,
		10,
		19,
		23,
		32,
		39,
		45,
		52,
		54,
		20,
		22,
		33,
		38,
		46,
		51,
		55,
		60,
		21,
		34,
		37,
		47,
		50,
		56,
		59,
		61,
		35,
		36,
		48,
		49,
		57,
		58,
		62,
		63
	], w = [
		0,
		0,
		1,
		5,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	], T = [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11
	], E = [
		0,
		0,
		2,
		1,
		3,
		3,
		2,
		4,
		3,
		5,
		5,
		4,
		4,
		0,
		0,
		1,
		125
	], D = [
		1,
		2,
		3,
		0,
		4,
		17,
		5,
		18,
		33,
		49,
		65,
		6,
		19,
		81,
		97,
		7,
		34,
		113,
		20,
		50,
		129,
		145,
		161,
		8,
		35,
		66,
		177,
		193,
		21,
		82,
		209,
		240,
		36,
		51,
		98,
		114,
		130,
		9,
		10,
		22,
		23,
		24,
		25,
		26,
		37,
		38,
		39,
		40,
		41,
		42,
		52,
		53,
		54,
		55,
		56,
		57,
		58,
		67,
		68,
		69,
		70,
		71,
		72,
		73,
		74,
		83,
		84,
		85,
		86,
		87,
		88,
		89,
		90,
		99,
		100,
		101,
		102,
		103,
		104,
		105,
		106,
		115,
		116,
		117,
		118,
		119,
		120,
		121,
		122,
		131,
		132,
		133,
		134,
		135,
		136,
		137,
		138,
		146,
		147,
		148,
		149,
		150,
		151,
		152,
		153,
		154,
		162,
		163,
		164,
		165,
		166,
		167,
		168,
		169,
		170,
		178,
		179,
		180,
		181,
		182,
		183,
		184,
		185,
		186,
		194,
		195,
		196,
		197,
		198,
		199,
		200,
		201,
		202,
		210,
		211,
		212,
		213,
		214,
		215,
		216,
		217,
		218,
		225,
		226,
		227,
		228,
		229,
		230,
		231,
		232,
		233,
		234,
		241,
		242,
		243,
		244,
		245,
		246,
		247,
		248,
		249,
		250
	], O = [
		0,
		0,
		3,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		0,
		0,
		0
	], k = [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11
	], A = [
		0,
		0,
		2,
		1,
		2,
		4,
		4,
		3,
		4,
		7,
		5,
		4,
		4,
		0,
		1,
		2,
		119
	], j = [
		0,
		1,
		2,
		3,
		17,
		4,
		5,
		33,
		49,
		6,
		18,
		65,
		81,
		7,
		97,
		113,
		19,
		34,
		50,
		129,
		8,
		20,
		66,
		145,
		161,
		177,
		193,
		9,
		35,
		51,
		82,
		240,
		21,
		98,
		114,
		209,
		10,
		22,
		36,
		52,
		225,
		37,
		241,
		23,
		24,
		25,
		26,
		38,
		39,
		40,
		41,
		42,
		53,
		54,
		55,
		56,
		57,
		58,
		67,
		68,
		69,
		70,
		71,
		72,
		73,
		74,
		83,
		84,
		85,
		86,
		87,
		88,
		89,
		90,
		99,
		100,
		101,
		102,
		103,
		104,
		105,
		106,
		115,
		116,
		117,
		118,
		119,
		120,
		121,
		122,
		130,
		131,
		132,
		133,
		134,
		135,
		136,
		137,
		138,
		146,
		147,
		148,
		149,
		150,
		151,
		152,
		153,
		154,
		162,
		163,
		164,
		165,
		166,
		167,
		168,
		169,
		170,
		178,
		179,
		180,
		181,
		182,
		183,
		184,
		185,
		186,
		194,
		195,
		196,
		197,
		198,
		199,
		200,
		201,
		202,
		210,
		211,
		212,
		213,
		214,
		215,
		216,
		217,
		218,
		226,
		227,
		228,
		229,
		230,
		231,
		232,
		233,
		234,
		242,
		243,
		244,
		245,
		246,
		247,
		248,
		249,
		250
	];
	function M(e, t) {
		for (var n = 0, r = 0, i = [], a = 1; a <= 16; a++) {
			for (var o = 1; o <= e[a]; o++) i[t[r]] = [], i[t[r]][0] = n, i[t[r]][1] = a, r++, n++;
			n *= 2;
		}
		return i;
	}
	function N(e) {
		for (var t = e[0], n = e[1] - 1; n >= 0;) t & 1 << n && (g |= 1 << _), n--, --_ < 0 && (g == 255 ? (P(255), P(0)) : P(g), _ = 7, g = 0);
	}
	function P(e) {
		h.push(e);
	}
	function F(e) {
		P(e >> 8 & 255), P(255 & e);
	}
	function I(e, t, n, r, i) {
		for (var a, o = i[0], s = i[240], c = function(e, t) {
			var n, r, i, a, o, s, c, l, u, d, f = 0;
			for (u = 0; u < 8; ++u) {
				n = e[f], r = e[f + 1], i = e[f + 2], a = e[f + 3], o = e[f + 4], s = e[f + 5], c = e[f + 6];
				var m = n + (l = e[f + 7]), h = n - l, g = r + c, _ = r - c, v = i + s, y = i - s, b = a + o, x = a - o, S = m + b, C = m - b, w = g + v, T = g - v;
				e[f] = S + w, e[f + 4] = S - w;
				var E = .707106781 * (T + C);
				e[f + 2] = C + E, e[f + 6] = C - E;
				var D = .382683433 * ((S = x + y) - (T = _ + h)), O = .5411961 * S + D, k = 1.306562965 * T + D, A = .707106781 * (w = y + _), j = h + A, M = h - A;
				e[f + 5] = M + O, e[f + 3] = M - O, e[f + 1] = j + k, e[f + 7] = j - k, f += 8;
			}
			for (f = 0, u = 0; u < 8; ++u) {
				n = e[f], r = e[f + 8], i = e[f + 16], a = e[f + 24], o = e[f + 32], s = e[f + 40], c = e[f + 48];
				var N = n + (l = e[f + 56]), P = n - l, F = r + c, I = r - c, L = i + s, ee = i - s, R = a + o, z = a - o, B = N + R, te = N - R, V = F + L, H = F - L;
				e[f] = B + V, e[f + 32] = B - V;
				var U = .707106781 * (H + te);
				e[f + 16] = te + U, e[f + 48] = te - U;
				var ne = .382683433 * ((B = z + ee) - (H = I + P)), W = .5411961 * B + ne, G = 1.306562965 * H + ne, re = .707106781 * (V = ee + I), ie = P + re, ae = P - re;
				e[f + 40] = ae + W, e[f + 24] = ae - W, e[f + 8] = ie + G, e[f + 56] = ie - G, f++;
			}
			for (u = 0; u < 64; ++u) d = e[u] * t[u], p[u] = d > 0 ? d + .5 | 0 : d - .5 | 0;
			return p;
		}(e, t), l = 0; l < 64; ++l) m[C[l]] = c[l];
		var u = m[0] - n;
		n = m[0], u == 0 ? N(r[0]) : (N(r[f[a = 32767 + u]]), N(d[a]));
		for (var h = 63; h > 0 && m[h] == 0;) h--;
		if (h == 0) return N(o), n;
		for (var g, _ = 1; _ <= h;) {
			for (var v = _; m[_] == 0 && _ <= h;) ++_;
			var y = _ - v;
			if (y >= 16) {
				g = y >> 4;
				for (var b = 1; b <= g; ++b) N(s);
				y &= 15;
			}
			a = 32767 + m[_], N(i[(y << 4) + f[a]]), N(d[a]), _++;
		}
		return h != 63 && N(o), n;
	}
	function L(e) {
		e = Math.min(Math.max(e, 1), 100), a != e && (function(e) {
			for (var t = [
				16,
				11,
				10,
				16,
				24,
				40,
				51,
				61,
				12,
				12,
				14,
				19,
				26,
				58,
				60,
				55,
				14,
				13,
				16,
				24,
				40,
				57,
				69,
				56,
				14,
				17,
				22,
				29,
				51,
				87,
				80,
				62,
				18,
				22,
				37,
				56,
				68,
				109,
				103,
				77,
				24,
				35,
				55,
				64,
				81,
				104,
				113,
				92,
				49,
				64,
				78,
				87,
				103,
				121,
				120,
				101,
				72,
				92,
				95,
				98,
				112,
				100,
				103,
				99
			], n = 0; n < 64; n++) {
				var r = o((t[n] * e + 50) / 100);
				r = Math.min(Math.max(r, 1), 255), s[C[n]] = r;
			}
			for (var i = [
				17,
				18,
				24,
				47,
				99,
				99,
				99,
				99,
				18,
				21,
				26,
				66,
				99,
				99,
				99,
				99,
				24,
				26,
				56,
				99,
				99,
				99,
				99,
				99,
				47,
				66,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99
			], a = 0; a < 64; a++) {
				var d = o((i[a] * e + 50) / 100);
				d = Math.min(Math.max(d, 1), 255), c[C[a]] = d;
			}
			for (var f = [
				1,
				1.387039845,
				1.306562965,
				1.175875602,
				1,
				.785694958,
				.5411961,
				.275899379
			], p = 0, m = 0; m < 8; m++) for (var h = 0; h < 8; h++) l[p] = 1 / (s[C[p]] * f[m] * f[h] * 8), u[p] = 1 / (c[C[p]] * f[m] * f[h] * 8), p++;
		}(Math.floor(e < 50 ? 5e3 / e : 200 - 2 * e)), a = e);
	}
	this.encode = function(e, a) {
		a && L(a), h = [], g = 0, _ = 7, F(65496), F(65504), F(16), P(74), P(70), P(73), P(70), P(0), P(1), P(1), P(0), F(1), F(1), P(0), P(0), function() {
			F(65499), F(132), P(0);
			for (var e = 0; e < 64; e++) P(s[e]);
			P(1);
			for (var t = 0; t < 64; t++) P(c[t]);
		}(), function(e, t) {
			F(65472), F(17), P(8), F(t), F(e), P(3), P(1), P(17), P(0), P(2), P(17), P(1), P(3), P(17), P(1);
		}(e.width, e.height), function() {
			F(65476), F(418), P(0);
			for (var e = 0; e < 16; e++) P(w[e + 1]);
			for (var t = 0; t <= 11; t++) P(T[t]);
			P(16);
			for (var n = 0; n < 16; n++) P(E[n + 1]);
			for (var r = 0; r <= 161; r++) P(D[r]);
			P(1);
			for (var i = 0; i < 16; i++) P(O[i + 1]);
			for (var a = 0; a <= 11; a++) P(k[a]);
			P(17);
			for (var o = 0; o < 16; o++) P(A[o + 1]);
			for (var s = 0; s <= 161; s++) P(j[s]);
		}(), F(65498), F(12), P(3), P(1), P(0), P(2), P(17), P(3), P(17), P(0), P(63), P(0);
		var o = 0, d = 0, f = 0;
		g = 0, _ = 7, this.encode.displayName = "_encode_";
		for (var p, m, x, C, M, ee, R, z, B, te = e.data, V = e.width, H = e.height, U = 4 * V, ne = 0; ne < H;) {
			for (p = 0; p < U;) {
				for (M = U * ne + p, R = -1, z = 0, B = 0; B < 64; B++) ee = M + (z = B >> 3) * U + (R = 4 * (7 & B)), ne + z >= H && (ee -= U * (ne + 1 + z - H)), p + R >= U && (ee -= p + R - U + 4), m = te[ee++], x = te[ee++], C = te[ee++], v[B] = (S[m] + S[x + 256 | 0] + S[C + 512 | 0] >> 16) - 128, y[B] = (S[m + 768 | 0] + S[x + 1024 | 0] + S[C + 1280 | 0] >> 16) - 128, b[B] = (S[m + 1280 | 0] + S[x + 1536 | 0] + S[C + 1792 | 0] >> 16) - 128;
				o = I(v, l, o, t, r), d = I(y, u, d, n, i), f = I(b, u, f, n, i), p += 32;
			}
			ne += 8;
		}
		if (_ >= 0) {
			var W = [];
			W[1] = _ + 1, W[0] = (1 << _ + 1) - 1, N(W);
		}
		return F(65497), new Uint8Array(h);
	}, e ||= 50, function() {
		for (var e = String.fromCharCode, t = 0; t < 256; t++) x[t] = e(t);
	}(), t = M(w, T), n = M(O, k), r = M(E, D), i = M(A, j), function() {
		for (var e = 1, t = 2, n = 1; n <= 15; n++) {
			for (var r = e; r < t; r++) f[32767 + r] = n, d[32767 + r] = [], d[32767 + r][1] = n, d[32767 + r][0] = r;
			for (var i = -(t - 1); i <= -e; i++) f[32767 + i] = n, d[32767 + i] = [], d[32767 + i][1] = n, d[32767 + i][0] = t - 1 + i;
			e <<= 1, t <<= 1;
		}
	}(), function() {
		for (var e = 0; e < 256; e++) S[e] = 19595 * e, S[e + 256 | 0] = 38470 * e, S[e + 512 | 0] = 7471 * e + 32768, S[e + 768 | 0] = -11059 * e, S[e + 1024 | 0] = -21709 * e, S[e + 1280 | 0] = 32768 * e + 8421375, S[e + 1536 | 0] = -27439 * e, S[e + 1792 | 0] = -5329 * e;
	}(), L(e);
}
function hc(e, t) {
	if (this.pos = 0, this.buffer = e, this.datav = new DataView(e.buffer), this.is_with_alpha = !!t, this.bottom_up = !0, this.flag = String.fromCharCode(this.buffer[0]) + String.fromCharCode(this.buffer[1]), this.pos += 2, [
		"BM",
		"BA",
		"CI",
		"CP",
		"IC",
		"PT"
	].indexOf(this.flag) === -1) throw Error("Invalid BMP File");
	this.parseHeader(), this.parseBGR();
}
function gc(e) {
	function t(e) {
		if (!e) throw Error("assert :P");
	}
	function n(e, t, n) {
		for (var r = 0; 4 > r; r++) if (e[t + r] != n.charCodeAt(r)) return !0;
		return !1;
	}
	function r(e, t, n, r, i) {
		for (var a = 0; a < i; a++) e[t + a] = n[r + a];
	}
	function i(e, t, n, r) {
		for (var i = 0; i < r; i++) e[t + i] = n;
	}
	function a(e) {
		return new Int32Array(e);
	}
	function o(e, t) {
		for (var n = [], r = 0; r < e; r++) n.push(new t());
		return n;
	}
	function s(e, t) {
		var n = [];
		return function e(n, r, i) {
			for (var a = i[r], o = 0; o < a && (n.push(i.length > r + 1 ? [] : new t()), !(i.length < r + 1)); o++) e(n[o], r + 1, i);
		}(n, 0, e), n;
	}
	var c = function() {
		var e = this;
		function c(e, t) {
			for (var n = 1 << t - 1 >>> 0; e & n;) n >>>= 1;
			return n ? (e & n - 1) + n : e;
		}
		function l(e, n, r, i, a) {
			t(!(i % r));
			do
				e[n + (i -= r)] = a;
			while (0 < i);
		}
		function u(e, n, r, i, o) {
			if (t(2328 >= o), 512 >= o) var s = a(512);
			else if ((s = a(o)) == null) return 0;
			return function(e, n, r, i, o, s) {
				var u, f, p = n, m = 1 << r, h = a(16), g = a(16);
				for (t(o != 0), t(i != null), t(e != null), t(0 < r), f = 0; f < o; ++f) {
					if (15 < i[f]) return 0;
					++h[i[f]];
				}
				if (h[0] == o) return 0;
				for (g[1] = 0, u = 1; 15 > u; ++u) {
					if (h[u] > 1 << u) return 0;
					g[u + 1] = g[u] + h[u];
				}
				for (f = 0; f < o; ++f) u = i[f], 0 < i[f] && (s[g[u]++] = f);
				if (g[15] == 1) return (i = new d()).g = 0, i.value = s[0], l(e, p, 1, m, i), m;
				var _, v = -1, y = m - 1, b = 0, x = 1, S = 1, C = 1 << r;
				for (f = 0, u = 1, o = 2; u <= r; ++u, o <<= 1) {
					if (x += S <<= 1, 0 > (S -= h[u])) return 0;
					for (; 0 < h[u]; --h[u]) (i = new d()).g = u, i.value = s[f++], l(e, p + b, o, C, i), b = c(b, u);
				}
				for (u = r + 1, o = 2; 15 >= u; ++u, o <<= 1) {
					if (x += S <<= 1, 0 > (S -= h[u])) return 0;
					for (; 0 < h[u]; --h[u]) {
						if (i = new d(), (b & y) != v) {
							for (p += C, _ = 1 << (v = u) - r; 15 > v && !(0 >= (_ -= h[v]));) ++v, _ <<= 1;
							m += C = 1 << (_ = v - r), e[n + (v = b & y)].g = _ + r, e[n + v].value = p - n - v;
						}
						i.g = u - r, i.value = s[f++], l(e, p + (b >> r), o, C, i), b = c(b, u);
					}
				}
				return x == 2 * g[15] - 1 ? m : 0;
			}(e, n, r, i, o, s);
		}
		function d() {
			this.value = this.g = 0;
		}
		function f() {
			this.value = this.g = 0;
		}
		function p() {
			this.G = o(5, d), this.H = a(5), this.jc = this.Qb = this.qb = this.nd = 0, this.pd = o(Hn, f);
		}
		function m(e, n, r, i) {
			t(e != null), t(n != null), t(2147483648 > i), e.Ca = 254, e.I = 0, e.b = -8, e.Ka = 0, e.oa = n, e.pa = r, e.Jd = n, e.Yc = r + i, e.Zc = 4 <= i ? r + i - 4 + 1 : r, E(e);
		}
		function h(e, t) {
			for (var n = 0; 0 < t--;) n |= O(e, 128) << t;
			return n;
		}
		function g(e, t) {
			var n = h(e, t);
			return D(e) ? -n : n;
		}
		function _(e, n, r, i) {
			var a, o = 0;
			for (t(e != null), t(n != null), t(4294967288 > i), e.Sb = i, e.Ra = 0, e.u = 0, e.h = 0, 4 < i && (i = 4), a = 0; a < i; ++a) o += n[r + a] << 8 * a;
			e.Ra = o, e.bb = i, e.oa = n, e.pa = r;
		}
		function v(e) {
			for (; 8 <= e.u && e.bb < e.Sb;) e.Ra >>>= 8, e.Ra += e.oa[e.pa + e.bb] << Gn - 8 >>> 0, ++e.bb, e.u -= 8;
			C(e) && (e.h = 1, e.u = 0);
		}
		function y(e, n) {
			if (t(0 <= n), !e.h && n <= Wn) {
				var r = S(e) & Un[n];
				return e.u += n, v(e), r;
			}
			return e.h = 1, e.u = 0;
		}
		function b() {
			this.b = this.Ca = this.I = 0, this.oa = [], this.pa = 0, this.Jd = [], this.Yc = 0, this.Zc = [], this.Ka = 0;
		}
		function x() {
			this.Ra = 0, this.oa = [], this.h = this.u = this.bb = this.Sb = this.pa = 0;
		}
		function S(e) {
			return e.Ra >>> (e.u & Gn - 1) >>> 0;
		}
		function C(e) {
			return t(e.bb <= e.Sb), e.h || e.bb == e.Sb && e.u > Gn;
		}
		function w(e, t) {
			e.u = t, e.h = C(e);
		}
		function T(e) {
			e.u >= Kn && (t(e.u >= Kn), v(e));
		}
		function E(e) {
			t(e != null && e.oa != null), e.pa < e.Zc ? (e.I = (e.oa[e.pa++] | e.I << 8) >>> 0, e.b += 8) : (t(e != null && e.oa != null), e.pa < e.Yc ? (e.b += 8, e.I = e.oa[e.pa++] | e.I << 8) : e.Ka ? e.b = 0 : (e.I <<= 8, e.b += 8, e.Ka = 1));
		}
		function D(e) {
			return h(e, 1);
		}
		function O(e, t) {
			var n = e.Ca;
			0 > e.b && E(e);
			var r = e.b, i = n * t >>> 8, a = (e.I >>> r > i) + 0;
			for (a ? (n -= i, e.I -= i + 1 << r >>> 0) : n = i + 1, r = n, i = 0; 256 <= r;) i += 8, r >>= 8;
			return r = 7 ^ i + qn[r], e.b -= r, e.Ca = (n << r) - 1, a;
		}
		function k(e, t, n) {
			e[t + 0] = n >> 24 & 255, e[t + 1] = n >> 16 & 255, e[t + 2] = n >> 8 & 255, e[t + 3] = 255 & n;
		}
		function A(e, t) {
			return e[t + 0] | e[t + 1] << 8;
		}
		function j(e, t) {
			return A(e, t) | e[t + 2] << 16;
		}
		function M(e, t) {
			return A(e, t) | A(e, t + 2) << 16;
		}
		function N(e, n) {
			var r = 1 << n;
			return t(e != null), t(0 < n), e.X = a(r), e.X == null ? 0 : (e.Mb = 32 - n, e.Xa = n, 1);
		}
		function P(e, n) {
			t(e != null), t(n != null), t(e.Xa == n.Xa), r(n.X, 0, e.X, 0, 1 << n.Xa);
		}
		function F() {
			this.X = [], this.Xa = this.Mb = 0;
		}
		function I(e, n, r, i) {
			t(r != null), t(i != null);
			var a = r[0], o = i[0];
			return a == 0 && (a = (e * o + n / 2) / n), o == 0 && (o = (n * a + e / 2) / e), 0 >= a || 0 >= o ? 0 : (r[0] = a, i[0] = o, 1);
		}
		function L(e, t) {
			return e + (1 << t) - 1 >>> t;
		}
		function ee(e, t) {
			return ((4278255360 & e) + (4278255360 & t) >>> 0 & 4278255360) + ((16711935 & e) + (16711935 & t) >>> 0 & 16711935) >>> 0;
		}
		function R(t, n) {
			e[n] = function(n, r, i, a, o, s, c) {
				for (var l = 0; l < o; ++l) {
					var u = e[t](s[c + l - 1], i, a + l);
					s[c + l] = ee(n[r + l], u);
				}
			};
		}
		function z() {
			this.ud = this.hd = this.jd = 0;
		}
		function B(e, t) {
			return ((4278124286 & (e ^ t)) >>> 1) + (e & t) >>> 0;
		}
		function te(e) {
			return 0 <= e && 256 > e ? e : 0 > e ? 0 : 255 < e ? 255 : void 0;
		}
		function V(e, t) {
			return te(e + (e - t + .5 >> 1));
		}
		function H(e, t, n) {
			return Math.abs(t - n) - Math.abs(e - n);
		}
		function U(e, t, n, r, i, a, o) {
			for (r = a[o - 1], n = 0; n < i; ++n) a[o + n] = r = ee(e[t + n], r);
		}
		function ne(e, t, n, r, i) {
			for (var a = 0; a < n; ++a) {
				var o = e[t + a], s = o >> 8 & 255, c = 16711935 & (c = (c = 16711935 & o) + ((s << 16) + s));
				r[i + a] = (4278255360 & o) + c >>> 0;
			}
		}
		function W(e, t) {
			t.jd = 255 & e, t.hd = e >> 8 & 255, t.ud = e >> 16 & 255;
		}
		function G(e, t, n, r, i, a) {
			for (var o = 0; o < r; ++o) {
				var s = t[n + o], c = s >>> 8, l = s, u = 255 & (u = (u = s >>> 16) + ((e.jd << 24 >> 24) * (c << 24 >> 24) >>> 5));
				l = 255 & (l = (l += (e.hd << 24 >> 24) * (c << 24 >> 24) >>> 5) + ((e.ud << 24 >> 24) * (u << 24 >> 24) >>> 5)), i[a + o] = (4278255360 & s) + (u << 16) + l;
			}
		}
		function re(t, n, r, i, a) {
			e[n] = function(e, t, n, r, o, s, c, l, u) {
				for (r = c; r < l; ++r) for (c = 0; c < u; ++c) o[s++] = a(n[i(e[t++])]);
			}, e[t] = function(t, n, o, s, c, l, u) {
				var d = 8 >> t.b, f = t.Ea, p = t.K[0], m = t.w;
				if (8 > d) for (t = (1 << t.b) - 1, m = (1 << d) - 1; n < o; ++n) {
					var h, g = 0;
					for (h = 0; h < f; ++h) h & t || (g = i(s[c++])), l[u++] = a(p[g & m]), g >>= d;
				}
				else e["VP8LMapColor" + r](s, c, p, m, l, u, n, o, f);
			};
		}
		function ie(e, t, n, r, i) {
			for (n = t + n; t < n;) {
				var a = e[t++];
				r[i++] = a >> 16 & 255, r[i++] = a >> 8 & 255, r[i++] = 255 & a;
			}
		}
		function ae(e, t, n, r, i) {
			for (n = t + n; t < n;) {
				var a = e[t++];
				r[i++] = a >> 16 & 255, r[i++] = a >> 8 & 255, r[i++] = 255 & a, r[i++] = a >> 24 & 255;
			}
		}
		function K(e, t, n, r, i) {
			for (n = t + n; t < n;) {
				var a = (o = e[t++]) >> 16 & 240 | o >> 12 & 15, o = 240 & o | o >> 28 & 15;
				r[i++] = a, r[i++] = o;
			}
		}
		function oe(e, t, n, r, i) {
			for (n = t + n; t < n;) {
				var a = (o = e[t++]) >> 16 & 248 | o >> 13 & 7, o = o >> 5 & 224 | o >> 3 & 31;
				r[i++] = a, r[i++] = o;
			}
		}
		function se(e, t, n, r, i) {
			for (n = t + n; t < n;) {
				var a = e[t++];
				r[i++] = 255 & a, r[i++] = a >> 8 & 255, r[i++] = a >> 16 & 255;
			}
		}
		function ce(e, t, n, i, a, o) {
			if (o == 0) for (n = t + n; t < n;) k(i, ((o = e[t++])[0] >> 24 | o[1] >> 8 & 65280 | o[2] << 8 & 16711680 | o[3] << 24) >>> 0), a += 32;
			else r(i, a, e, t, n);
		}
		function le(t, n) {
			e[n][0] = e[t + "0"], e[n][1] = e[t + "1"], e[n][2] = e[t + "2"], e[n][3] = e[t + "3"], e[n][4] = e[t + "4"], e[n][5] = e[t + "5"], e[n][6] = e[t + "6"], e[n][7] = e[t + "7"], e[n][8] = e[t + "8"], e[n][9] = e[t + "9"], e[n][10] = e[t + "10"], e[n][11] = e[t + "11"], e[n][12] = e[t + "12"], e[n][13] = e[t + "13"], e[n][14] = e[t + "0"], e[n][15] = e[t + "0"];
		}
		function ue(e) {
			return e == Kr || e == qr || e == Jr || e == Yr;
		}
		function de() {
			this.eb = [], this.size = this.A = this.fb = 0;
		}
		function fe() {
			this.y = [], this.f = [], this.ea = [], this.F = [], this.Tc = this.Ed = this.Cd = this.Fd = this.lb = this.Db = this.Ab = this.fa = this.J = this.W = this.N = this.O = 0;
		}
		function pe() {
			this.Rd = this.height = this.width = this.S = 0, this.f = {}, this.f.RGBA = new de(), this.f.kb = new fe(), this.sd = null;
		}
		function me() {
			this.width = [0], this.height = [0], this.Pd = [0], this.Qd = [0], this.format = [0];
		}
		function he() {
			this.Id = this.fd = this.Md = this.hb = this.ib = this.da = this.bd = this.cd = this.j = this.v = this.Da = this.Sd = this.ob = 0;
		}
		function ge(e) {
			return alert("todo:WebPSamplerProcessPlane"), e.T;
		}
		function _e(e, t) {
			var n = e.T, i = t.ba.f.RGBA, a = i.eb, o = i.fb + e.ka * i.A, s = bi[t.ba.S], c = e.y, l = e.O, u = e.f, d = e.N, f = e.ea, p = e.W, m = t.cc, h = t.dc, g = t.Mc, _ = t.Nc, v = e.ka, y = e.ka + e.T, b = e.U, x = b + 1 >> 1;
			for (v == 0 ? s(c, l, null, null, u, d, f, p, u, d, f, p, a, o, null, null, b) : (s(t.ec, t.fc, c, l, m, h, g, _, u, d, f, p, a, o - i.A, a, o, b), ++n); v + 2 < y; v += 2) m = u, h = d, g = f, _ = p, d += e.Rc, p += e.Rc, o += 2 * i.A, s(c, (l += 2 * e.fa) - e.fa, c, l, m, h, g, _, u, d, f, p, a, o - i.A, a, o, b);
			return l += e.fa, e.j + y < e.o ? (r(t.ec, t.fc, c, l, b), r(t.cc, t.dc, u, d, x), r(t.Mc, t.Nc, f, p, x), n--) : 1 & y || s(c, l, null, null, u, d, f, p, u, d, f, p, a, o + i.A, null, null, b), n;
		}
		function ve(e, n, r) {
			var i = e.F, a = [e.J];
			if (i != null) {
				var o = e.U, s = n.ba.S, c = s == Ur || s == Jr;
				n = n.ba.f.RGBA;
				var l = [0], u = e.ka;
				l[0] = e.T, e.Kb && (u == 0 ? --l[0] : (--u, a[0] -= e.width), e.j + e.ka + e.T == e.o && (l[0] = e.o - e.j - u));
				var d = n.eb;
				u = n.fb + u * n.A, e = Or(i, a[0], e.width, o, l, d, u + (c ? 0 : 3), n.A), t(r == l), e && ue(s) && Er(d, u, c, o, l, n.A);
			}
			return 0;
		}
		function ye(e) {
			var t = e.ma, n = t.ba.S, r = 11 > n, i = n == Br || n == Hr || n == Ur || n == Wr || n == 12 || ue(n);
			if (t.memory = null, t.Ib = null, t.Jb = null, t.Nd = null, !zn(t.Oa, e, i ? 11 : 12)) return 0;
			if (i && ue(n) && Sn(), e.da) alert("todo:use_scaling");
			else {
				if (r) {
					if (t.Ib = ge, e.Kb) {
						if (n = e.U + 1 >> 1, t.memory = a(e.U + 2 * n), t.memory == null) return 0;
						t.ec = t.memory, t.fc = 0, t.cc = t.ec, t.dc = t.fc + e.U, t.Mc = t.cc, t.Nc = t.dc + n, t.Ib = _e, Sn();
					}
				} else alert("todo:EmitYUV");
				i && (t.Jb = ve, r && bn());
			}
			if (r && !Pi) {
				for (e = 0; 256 > e; ++e) Fi[e] = 89858 * (e - 128) + ki >> Oi, Ri[e] = -22014 * (e - 128) + ki, Li[e] = -45773 * (e - 128), Ii[e] = 113618 * (e - 128) + ki >> Oi;
				for (e = Ai; e < ji; ++e) t = 76283 * (e - 16) + ki >> Oi, zi[e - Ai] = Xe(t, 255), Bi[e - Ai] = Xe(t + 8 >> 4, 15);
				Pi = 1;
			}
			return 1;
		}
		function be(e) {
			var n = e.ma, r = e.U, i = e.T;
			return t(!(1 & e.ka)), 0 >= r || 0 >= i ? 0 : (r = n.Ib(e, n), n.Jb != null && n.Jb(e, n, r), n.Dc += r, 1);
		}
		function xe(e) {
			e.ma.memory = null;
		}
		function Se(e, t, n, r) {
			return y(e, 8) == 47 ? (t[0] = y(e, 14) + 1, n[0] = y(e, 14) + 1, r[0] = y(e, 1), y(e, 3) == 0 ? !e.h : 0) : 0;
		}
		function Ce(e, t) {
			if (4 > e) return e + 1;
			var n = e - 2 >> 1;
			return (2 + (1 & e) << n) + y(t, n) + 1;
		}
		function we(e, t) {
			return 120 < t ? t - 120 : 1 <= (n = ((n = ti[t - 1]) >> 4) * e + (8 - (15 & n))) ? n : 1;
			var n;
		}
		function Te(e, t, n) {
			var r = S(n), i = e[t += 255 & r].g - 8;
			return 0 < i && (w(n, n.u + 8), r = S(n), t += e[t].value, t += r & (1 << i) - 1), w(n, n.u + e[t].g), e[t].value;
		}
		function Ee(e, n, r) {
			return r.g += e.g, r.value += e.value << n >>> 0, t(8 >= r.g), e.g;
		}
		function De(e, n, r) {
			var i = e.xc;
			return t((n = i == 0 ? 0 : e.vc[e.md * (r >> i) + (n >> i)]) < e.Wb), e.Ya[n];
		}
		function Oe(e, n, i, a) {
			var o = e.ab, s = e.c * n, c = e.C;
			n = c + n;
			var l = i, u = a;
			for (a = e.Ta, i = e.Ua; 0 < o--;) {
				var d = e.gc[o], f = c, p = n, m = l, h = u, g = (u = a, l = i, d.Ea);
				switch (t(f < p), t(p <= d.nc), d.hc) {
					case 2:
						Xn(m, h, (p - f) * g, u, l);
						break;
					case 0:
						var _ = f, v = p, y = u, b = l, x = (E = d).Ea;
						_ == 0 && (Jn(m, h, null, null, 1, y, b), U(m, h + 1, 0, 0, x - 1, y, b + 1), h += x, b += x, ++_);
						for (var S = 1 << E.b, C = S - 1, w = L(x, E.b), T = E.K, E = E.w + (_ >> E.b) * w; _ < v;) {
							var D = T, O = E, k = 1;
							for (Yn(m, h, y, b - x, 1, y, b); k < x;) {
								var A = (k & ~C) + S;
								A > x && (A = x), (0, tr[D[O++] >> 8 & 15])(m, h + +k, y, b + k - x, A - k, y, b + k), k = A;
							}
							h += x, b += x, ++_ & C || (E += w);
						}
						p != d.nc && r(u, l - g, u, l + (p - f - 1) * g, g);
						break;
					case 1:
						for (g = m, v = h, x = (m = d.Ea) - (b = m & ~(y = (h = 1 << d.b) - 1)), _ = L(m, d.b), S = d.K, d = d.w + (f >> d.b) * _; f < p;) {
							for (C = S, w = d, T = new z(), E = v + b, D = v + m; v < E;) W(C[w++], T), nr(T, g, v, h, u, l), v += h, l += h;
							v < D && (W(C[w++], T), nr(T, g, v, x, u, l), v += x, l += x), ++f & y || (d += _);
						}
						break;
					case 3: if (m == u && h == l && 0 < d.b) {
						for (v = u, m = g = l + (p - f) * g - (b = (p - f) * L(d.Ea, d.b)), h = u, y = l, _ = [], b = (x = b) - 1; 0 <= b; --b) _[b] = h[y + b];
						for (b = x - 1; 0 <= b; --b) v[m + b] = _[b];
						Zn(d, f, p, u, g, u, l);
					} else Zn(d, f, p, m, h, u, l);
				}
				l = a, u = i;
			}
			u != i && r(a, i, l, u, s);
		}
		function ke(e, n) {
			var r = e.V, i = e.Ba + e.c * e.C, a = n - e.C;
			if (t(n <= e.l.o), t(16 >= a), 0 < a) {
				var o = e.l, s = e.Ta, c = e.Ua, l = o.width;
				if (Oe(e, a, r, i), a = c = [c], t((r = e.C) < (i = n)), t(o.v < o.va), i > o.o && (i = o.o), r < o.j) {
					var u = o.j - r;
					r = o.j, a[0] += u * l;
				}
				if (r >= i ? r = 0 : (a[0] += 4 * o.v, o.ka = r - o.j, o.U = o.va - o.v, o.T = i - r, r = 1), r) {
					if (c = c[0], 11 > (r = e.ca).S) {
						var d = r.f.RGBA, f = (i = r.S, a = o.U, o = o.T, u = d.eb, d.A), p = o;
						for (d = d.fb + e.Ma * d.A; 0 < p--;) {
							var m = s, h = c, g = a, _ = u, v = d;
							switch (i) {
								case zr:
									rr(m, h, g, _, v);
									break;
								case Br:
									ir(m, h, g, _, v);
									break;
								case Kr:
									ir(m, h, g, _, v), Er(_, v, 0, g, 1, 0);
									break;
								case Vr:
									sr(m, h, g, _, v);
									break;
								case Hr:
									ce(m, h, g, _, v, 1);
									break;
								case qr:
									ce(m, h, g, _, v, 1), Er(_, v, 0, g, 1, 0);
									break;
								case Ur:
									ce(m, h, g, _, v, 0);
									break;
								case Jr:
									ce(m, h, g, _, v, 0), Er(_, v, 1, g, 1, 0);
									break;
								case Wr:
									ar(m, h, g, _, v);
									break;
								case Yr:
									ar(m, h, g, _, v), Dr(_, v, g, 1, 0);
									break;
								case Gr:
									or(m, h, g, _, v);
									break;
								default: t(0);
							}
							c += l, d += f;
						}
						e.Ma += o;
					} else alert("todo:EmitRescaledRowsYUVA");
					t(e.Ma <= r.height);
				}
			}
			e.C = n, t(e.C <= e.i);
		}
		function Ae(e) {
			var t;
			if (0 < e.ua) return 0;
			for (t = 0; t < e.Wb; ++t) {
				var n = e.Ya[t].G, r = e.Ya[t].H;
				if (0 < n[1][r[1] + 0].g || 0 < n[2][r[2] + 0].g || 0 < n[3][r[3] + 0].g) return 0;
			}
			return 1;
		}
		function je(e, n, r, i, a, o) {
			if (e.Z != 0) {
				var s = e.qd, c = e.rd;
				for (t(yi[e.Z] != null); n < r; ++n) yi[e.Z](s, c, i, a, i, a, o), s = i, c = a, a += o;
				e.qd = s, e.rd = c;
			}
		}
		function Me(e, n) {
			var r = e.l.ma, i = r.Z == 0 || r.Z == 1 ? e.l.j : e.C;
			if (i = e.C < i ? i : e.C, t(n <= e.l.o), n > i) {
				var a = e.l.width, o = r.ca, s = r.tb + a * i, c = e.V, l = e.Ba + e.c * i, u = e.gc;
				t(e.ab == 1), t(u[0].hc == 3), $n(u[0], i, n, c, l, o, s), je(r, i, n, o, s, a);
			}
			e.C = e.Ma = n;
		}
		function q(e, n, r, i, a, o, s) {
			var c = e.$ / i, l = e.$ % i, u = e.m, d = e.s, f = r + e.$, p = f;
			a = r + i * a;
			var m = r + i * o, h = 280 + d.ua, g = e.Pb ? c : 16777216, _ = 0 < d.ua ? d.Wa : null, v = d.wc, y = f < m ? De(d, l, c) : null;
			t(e.C < o), t(m <= a);
			var b = !1;
			t: for (;;) {
				for (; b || f < m;) {
					var x = 0;
					if (c >= g) {
						var E = f - r;
						t((g = e).Pb), g.wd = g.m, g.xd = E, 0 < g.s.ua && P(g.s.Wa, g.s.vb), g = c + ri;
					}
					if (l & v || (y = De(d, l, c)), t(y != null), y.Qb && (n[f] = y.qb, b = !0), !b) {
						if (T(u), y.jc) {
							x = u, E = n;
							var D = f, O = y.pd[S(x) & Hn - 1];
							t(y.jc), 256 > O.g ? (w(x, x.u + O.g), E[D] = O.value, x = 0) : (w(x, x.u + O.g - 256), t(256 <= O.value), x = O.value), x == 0 && (b = !0);
						} else x = Te(y.G[0], y.H[0], u);
					}
					if (u.h) break;
					if (b || 256 > x) {
						if (!b) {
							if (y.nd) n[f] = (y.qb | x << 8) >>> 0;
							else {
								if (T(u), b = Te(y.G[1], y.H[1], u), T(u), E = Te(y.G[2], y.H[2], u), D = Te(y.G[3], y.H[3], u), u.h) break;
								n[f] = (D << 24 | b << 16 | x << 8 | E) >>> 0;
							}
						}
						if (b = !1, ++f, ++l >= i && (l = 0, ++c, s != null && c <= o && !(c % 16) && s(e, c), _ != null)) for (; p < f;) x = n[p++], _.X[(506832829 * x | 0) >>> _.Mb] = x;
					} else if (280 > x) {
						if (x = Ce(x - 256, u), E = Te(y.G[4], y.H[4], u), T(u), E = we(i, E = Ce(E, u)), u.h) break;
						if (f - r < E || a - f < x) break t;
						for (D = 0; D < x; ++D) n[f + D] = n[f + D - E];
						for (f += x, l += x; l >= i;) l -= i, ++c, s != null && c <= o && !(c % 16) && s(e, c);
						if (t(f <= a), l & v && (y = De(d, l, c)), _ != null) for (; p < f;) x = n[p++], _.X[(506832829 * x | 0) >>> _.Mb] = x;
					} else {
						if (!(x < h)) break t;
						for (b = x - 280, t(_ != null); p < f;) x = n[p++], _.X[(506832829 * x | 0) >>> _.Mb] = x;
						x = f, t(!(b >>> (E = _).Xa)), n[x] = E.X[b], b = !0;
					}
					b || t(u.h == C(u));
				}
				if (e.Pb && u.h && f < a) t(e.m.h), e.a = 5, e.m = e.wd, e.$ = e.xd, 0 < e.s.ua && P(e.s.vb, e.s.Wa);
				else {
					if (u.h) break t;
					s?.(e, c > o ? o : c), e.a = 0, e.$ = f - r;
				}
				return 1;
			}
			return e.a = 3, 0;
		}
		function Ne(e) {
			t(e != null), e.vc = null, e.yc = null, e.Ya = null;
			var n = e.Wa;
			n != null && (n.X = null), e.vb = null, t(e != null);
		}
		function Pe() {
			var t = new un();
			return t == null ? null : (t.a = 0, t.xb = vi, le("Predictor", "VP8LPredictors"), le("Predictor", "VP8LPredictors_C"), le("PredictorAdd", "VP8LPredictorsAdd"), le("PredictorAdd", "VP8LPredictorsAdd_C"), Xn = ne, nr = G, rr = ie, ir = ae, ar = K, or = oe, sr = se, e.VP8LMapColor32b = Qn, e.VP8LMapColor8b = er, t);
		}
		function Fe(e, n, r, s, c) {
			var l = 1, f = [e], m = [n], h = s.m, g = s.s, _ = null, v = 0;
			t: for (;;) {
				if (r) for (; l && y(h, 1);) {
					var b = f, x = m, C = s, E = 1, D = C.m, O = C.gc[C.ab], k = y(D, 2);
					if (C.Oc & 1 << k) l = 0;
					else {
						switch (C.Oc |= 1 << k, O.hc = k, O.Ea = b[0], O.nc = x[0], O.K = [null], ++C.ab, t(4 >= C.ab), k) {
							case 0:
							case 1:
								O.b = y(D, 3) + 2, E = Fe(L(O.Ea, O.b), L(O.nc, O.b), 0, C, O.K), O.K = O.K[0];
								break;
							case 3:
								var A, j = y(D, 8) + 1, M = 16 < j ? 0 : 4 < j ? 1 : 2 < j ? 2 : 3;
								if (b[0] = L(O.Ea, M), O.b = M, A = E = Fe(j, 1, 0, C, O.K)) {
									var P, F = j, I = O, R = 1 << (8 >> I.b), z = a(R);
									if (z == null) A = 0;
									else {
										var B = I.K[0], te = I.w;
										for (z[0] = I.K[0][0], P = 1; P < 1 * F; ++P) z[P] = ee(B[te + P], z[P - 1]);
										for (; P < 4 * R; ++P) z[P] = 0;
										I.K[0] = null, I.K[0] = z, A = 1;
									}
								}
								E = A;
								break;
							case 2: break;
							default: t(0);
						}
						l = E;
					}
				}
				if (f = f[0], m = m[0], l && y(h, 1) && !(l = 1 <= (v = y(h, 4)) && 11 >= v)) {
					s.a = 3;
					break t;
				}
				var V;
				if (V = l) e: {
					var H, U, ne, W = s, G = f, re = m, ie = v, ae = r, K = W.m, oe = W.s, se = [null], ce = 1, le = 0, ue = ni[ie];
					r: for (;;) {
						if (ae && y(K, 1)) {
							var de = y(K, 3) + 2, fe = L(G, de), pe = L(re, de), me = fe * pe;
							if (!Fe(fe, pe, 0, W, se)) break r;
							for (se = se[0], oe.xc = de, H = 0; H < me; ++H) {
								var he = se[H] >> 8 & 65535;
								se[H] = he, he >= ce && (ce = he + 1);
							}
						}
						if (K.h) break r;
						for (U = 0; 5 > U; ++U) {
							var ge = Qr[U];
							!U && 0 < ie && (ge += 1 << ie), le < ge && (le = ge);
						}
						var _e = o(ce * ue, d), ve = ce, ye = o(ve, p);
						if (ye == null) var be = null;
						else t(65536 >= ve), be = ye;
						var xe = a(le);
						if (be == null || xe == null || _e == null) {
							W.a = 1;
							break r;
						}
						var Se = _e;
						for (H = ne = 0; H < ce; ++H) {
							var Ce = be[H], we = Ce.G, Te = Ce.H, De = 0, Oe = 1, ke = 0;
							for (U = 0; 5 > U; ++U) {
								ge = Qr[U], we[U] = Se, Te[U] = ne, !U && 0 < ie && (ge += 1 << ie);
								n: {
									var Ae, je = ge, Me = W, Pe = xe, Ie = Se, Le = ne, J = 0, Re = Me.m, ze = y(Re, 1);
									if (i(Pe, 0, 0, je), ze) {
										var Be = y(Re, 1) + 1, Ve = y(Re, y(Re, 1) == 0 ? 1 : 8);
										Pe[Ve] = 1, Be == 2 && (Pe[Ve = y(Re, 8)] = 1);
										var He = 1;
									} else {
										var Ue = a(19), We = y(Re, 4) + 4;
										if (19 < We) {
											Me.a = 3;
											var Ge = 0;
											break n;
										}
										for (Ae = 0; Ae < We; ++Ae) Ue[ei[Ae]] = y(Re, 3);
										var Ke = void 0, qe = void 0, Je = Me, Ye = Ue, Xe = je, Ze = Pe, Qe = 0, $e = Je.m, et = 8, tt = o(128, d);
										i: for (; u(tt, 0, 7, Ye, 19);) {
											if (y($e, 1)) {
												if ((Ke = 2 + y($e, 2 + 2 * y($e, 3))) > Xe) break i;
											} else Ke = Xe;
											for (qe = 0; qe < Xe && Ke--;) {
												T($e);
												var nt = tt[0 + (127 & S($e))];
												w($e, $e.u + nt.g);
												var rt = nt.value;
												if (16 > rt) Ze[qe++] = rt, rt != 0 && (et = rt);
												else {
													var it = rt == 16, at = rt - 16, ot = Zr[at], st = y($e, Xr[at]) + ot;
													if (qe + st > Xe) break i;
													for (var ct = it ? et : 0; 0 < st--;) Ze[qe++] = ct;
												}
											}
											Qe = 1;
											break i;
										}
										Qe || (Je.a = 3), He = Qe;
									}
									(He &&= !Re.h) && (J = u(Ie, Le, 8, Pe, je)), He && J != 0 ? Ge = J : (Me.a = 3, Ge = 0);
								}
								if (Ge == 0) break r;
								if (Oe && $r[U] == 1 && (Oe = Se[ne].g == 0), De += Se[ne].g, ne += Ge, 3 >= U) {
									var lt, ut = xe[0];
									for (lt = 1; lt < ge; ++lt) xe[lt] > ut && (ut = xe[lt]);
									ke += ut;
								}
							}
							if (Ce.nd = Oe, Ce.Qb = 0, Oe && (Ce.qb = (we[3][Te[3] + 0].value << 24 | we[1][Te[1] + 0].value << 16 | we[2][Te[2] + 0].value) >>> 0, De == 0 && 256 > we[0][Te[0] + 0].value && (Ce.Qb = 1, Ce.qb += we[0][Te[0] + 0].value << 8)), Ce.jc = !Ce.Qb && 6 > ke, Ce.jc) {
								var dt, ft = Ce;
								for (dt = 0; dt < Hn; ++dt) {
									var pt = dt, mt = ft.pd[pt], ht = ft.G[0][ft.H[0] + pt];
									256 <= ht.value ? (mt.g = ht.g + 256, mt.value = ht.value) : (mt.g = 0, mt.value = 0, pt >>= Ee(ht, 8, mt), pt >>= Ee(ft.G[1][ft.H[1] + pt], 16, mt), pt >>= Ee(ft.G[2][ft.H[2] + pt], 0, mt), Ee(ft.G[3][ft.H[3] + pt], 24, mt));
								}
							}
						}
						oe.vc = se, oe.Wb = ce, oe.Ya = be, oe.yc = _e, V = 1;
						break e;
					}
					V = 0;
				}
				if (!(l = V)) {
					s.a = 3;
					break t;
				}
				if (0 < v) {
					if (g.ua = 1 << v, !N(g.Wa, v)) {
						s.a = 1, l = 0;
						break t;
					}
				} else g.ua = 0;
				var gt = s, _t = f, vt = m, yt = gt.s, bt = yt.xc;
				if (gt.c = _t, gt.i = vt, yt.md = L(_t, bt), yt.wc = bt == 0 ? -1 : (1 << bt) - 1, r) {
					s.xb = _i;
					break t;
				}
				if ((_ = a(f * m)) == null) {
					s.a = 1, l = 0;
					break t;
				}
				l = (l = q(s, _, 0, f, m, m, null)) && !h.h;
				break t;
			}
			return l ? (c == null ? (t(_ == null), t(r)) : c[0] = _, s.$ = 0, r || Ne(g)) : Ne(g), l;
		}
		function Ie(e, n) {
			var r = e.c * e.i, i = r + n + 16 * n;
			return t(e.c <= n), e.V = a(i), e.V == null ? (e.Ta = null, e.Ua = 0, e.a = 1, 0) : (e.Ta = e.V, e.Ua = e.Ba + r + n, 1);
		}
		function Le(e, n) {
			var r = e.C, i = n - r, a = e.V, o = e.Ba + e.c * r;
			for (t(n <= e.l.o); 0 < i;) {
				var s = 16 < i ? 16 : i, c = e.l.ma, l = e.l.width, u = l * s, d = c.ca, f = c.tb + l * r, p = e.Ta, m = e.Ua;
				Oe(e, s, a, o), kr(p, m, d, f, u), je(c, r, r + s, d, f, l), i -= s, a += s * e.c, r += s;
			}
			t(r == n), e.C = e.Ma = n;
		}
		function J() {
			this.ub = this.yd = this.td = this.Rb = 0;
		}
		function Re() {
			this.Kd = this.Ld = this.Ud = this.Td = this.i = this.c = 0;
		}
		function ze() {
			this.Fb = this.Bb = this.Cb = 0, this.Zb = a(4), this.Lb = a(4);
		}
		function Be() {
			this.Yb = function() {
				var e = [];
				return function e(t, n, r) {
					for (var i = r[n], a = 0; a < i && (t.push(r.length > n + 1 ? [] : 0), !(r.length < n + 1)); a++) e(t[a], n + 1, r);
				}(e, 0, [3, 11]), e;
			}();
		}
		function Ve() {
			this.jb = a(3), this.Wc = s([4, 8], Be), this.Xc = s([4, 17], Be);
		}
		function He() {
			this.Pc = this.wb = this.Tb = this.zd = 0, this.vd = new a(4), this.od = new a(4);
		}
		function Ue() {
			this.ld = this.La = this.dd = this.tc = 0;
		}
		function We() {
			this.Na = this.la = 0;
		}
		function Ge() {
			this.Sc = [0, 0], this.Eb = [0, 0], this.Qc = [0, 0], this.ia = this.lc = 0;
		}
		function Ke() {
			this.ad = a(384), this.Za = 0, this.Ob = a(16), this.$b = this.Ad = this.ia = this.Gc = this.Hc = this.Dd = 0;
		}
		function qe() {
			this.uc = this.M = this.Nb = 0, this.wa = Array(new Ue()), this.Y = 0, this.ya = Array(new Ke()), this.aa = 0, this.l = new Ze();
		}
		function Je() {
			this.y = a(16), this.f = a(8), this.ea = a(8);
		}
		function Ye() {
			this.cb = this.a = 0, this.sc = "", this.m = new b(), this.Od = new J(), this.Kc = new Re(), this.ed = new He(), this.Qa = new ze(), this.Ic = this.$c = this.Aa = 0, this.D = new qe(), this.Xb = this.Va = this.Hb = this.zb = this.yb = this.Ub = this.za = 0, this.Jc = o(8, b), this.ia = 0, this.pb = o(4, Ge), this.Pa = new Ve(), this.Bd = this.kc = 0, this.Ac = [], this.Bc = 0, this.zc = [
				0,
				0,
				0,
				0
			], this.Gd = Array(new Je()), this.Hd = 0, this.rb = Array(new We()), this.sb = 0, this.wa = Array(new Ue()), this.Y = 0, this.oc = [], this.pc = 0, this.sa = [], this.ta = 0, this.qa = [], this.ra = 0, this.Ha = [], this.B = this.R = this.Ia = 0, this.Ec = [], this.M = this.ja = this.Vb = this.Fc = 0, this.ya = Array(new Ke()), this.L = this.aa = 0, this.gd = s([4, 2], Ue), this.ga = null, this.Fa = [], this.Cc = this.qc = this.P = 0, this.Gb = [], this.Uc = 0, this.mb = [], this.nb = 0, this.rc = [], this.Ga = this.Vc = 0;
		}
		function Xe(e, t) {
			return 0 > e ? 0 : e > t ? t : e;
		}
		function Ze() {
			this.T = this.U = this.ka = this.height = this.width = 0, this.y = [], this.f = [], this.ea = [], this.Rc = this.fa = this.W = this.N = this.O = 0, this.ma = "void", this.put = "VP8IoPutHook", this.ac = "VP8IoSetupHook", this.bc = "VP8IoTeardownHook", this.ha = this.Kb = 0, this.data = [], this.hb = this.ib = this.da = this.o = this.j = this.va = this.v = this.Da = this.ob = this.w = 0, this.F = [], this.J = 0;
		}
		function Qe() {
			var e = new Ye();
			return e != null && (e.a = 0, e.sc = "OK", e.cb = 0, e.Xb = 0, oi ||= nt), e;
		}
		function $e(e, t, n) {
			return e.a == 0 && (e.a = t, e.sc = n, e.cb = 0), 0;
		}
		function et(e, t, n) {
			return 3 <= n && e[t + 0] == 157 && e[t + 1] == 1 && e[t + 2] == 42;
		}
		function tt(e, n) {
			if (e == null) return 0;
			if (e.a = 0, e.sc = "OK", n == null) return $e(e, 2, "null VP8Io passed to VP8GetHeaders()");
			var r = n.data, a = n.w, o = n.ha;
			if (4 > o) return $e(e, 7, "Truncated header.");
			var s = r[a + 0] | r[a + 1] << 8 | r[a + 2] << 16, c = e.Od;
			if (c.Rb = !(1 & s), c.td = s >> 1 & 7, c.yd = s >> 4 & 1, c.ub = s >> 5, 3 < c.td) return $e(e, 3, "Incorrect keyframe parameters.");
			if (!c.yd) return $e(e, 4, "Frame not displayable.");
			a += 3, o -= 3;
			var l = e.Kc;
			if (c.Rb) {
				if (7 > o) return $e(e, 7, "cannot parse picture header");
				if (!et(r, a, o)) return $e(e, 3, "Bad code word");
				l.c = 16383 & (r[a + 4] << 8 | r[a + 3]), l.Td = r[a + 4] >> 6, l.i = 16383 & (r[a + 6] << 8 | r[a + 5]), l.Ud = r[a + 6] >> 6, a += 7, o -= 7, e.za = l.c + 15 >> 4, e.Ub = l.i + 15 >> 4, n.width = l.c, n.height = l.i, n.Da = 0, n.j = 0, n.v = 0, n.va = n.width, n.o = n.height, n.da = 0, n.ib = n.width, n.hb = n.height, n.U = n.width, n.T = n.height, i((s = e.Pa).jb, 0, 255, s.jb.length), t((s = e.Qa) != null), s.Cb = 0, s.Bb = 0, s.Fb = 1, i(s.Zb, 0, 0, s.Zb.length), i(s.Lb, 0, 0, s.Lb);
			}
			if (c.ub > o) return $e(e, 7, "bad partition length");
			m(s = e.m, r, a, c.ub), a += c.ub, o -= c.ub, c.Rb && (l.Ld = D(s), l.Kd = D(s)), l = e.Qa;
			var u, d = e.Pa;
			if (t(s != null), t(l != null), l.Cb = D(s), l.Cb) {
				if (l.Bb = D(s), D(s)) {
					for (l.Fb = D(s), u = 0; 4 > u; ++u) l.Zb[u] = D(s) ? g(s, 7) : 0;
					for (u = 0; 4 > u; ++u) l.Lb[u] = D(s) ? g(s, 6) : 0;
				}
				if (l.Bb) for (u = 0; 3 > u; ++u) d.jb[u] = D(s) ? h(s, 8) : 255;
			} else l.Bb = 0;
			if (s.Ka) return $e(e, 3, "cannot parse segment header");
			if ((l = e.ed).zd = D(s), l.Tb = h(s, 6), l.wb = h(s, 3), l.Pc = D(s), l.Pc && D(s)) {
				for (d = 0; 4 > d; ++d) D(s) && (l.vd[d] = g(s, 6));
				for (d = 0; 4 > d; ++d) D(s) && (l.od[d] = g(s, 6));
			}
			if (e.L = l.Tb == 0 ? 0 : l.zd ? 1 : 2, s.Ka) return $e(e, 3, "cannot parse filter header");
			var f = o;
			if (o = u = a, a = u + f, l = f, e.Xb = (1 << h(e.m, 2)) - 1, f < 3 * (d = e.Xb)) r = 7;
			else {
				for (u += 3 * d, l -= 3 * d, f = 0; f < d; ++f) {
					var p = r[o + 0] | r[o + 1] << 8 | r[o + 2] << 16;
					p > l && (p = l), m(e.Jc[+f], r, u, p), u += p, l -= p, o += 3;
				}
				m(e.Jc[+d], r, u, l), r = u < a ? 0 : 5;
			}
			if (r != 0) return $e(e, r, "cannot parse partitions");
			for (r = h(u = e.m, 7), o = D(u) ? g(u, 4) : 0, a = D(u) ? g(u, 4) : 0, l = D(u) ? g(u, 4) : 0, d = D(u) ? g(u, 4) : 0, u = D(u) ? g(u, 4) : 0, f = e.Qa, p = 0; 4 > p; ++p) {
				if (f.Cb) {
					var _ = f.Zb[p];
					f.Fb || (_ += r);
				} else {
					if (0 < p) {
						e.pb[p] = e.pb[0];
						continue;
					}
					_ = r;
				}
				var v = e.pb[p];
				v.Sc[0] = ii[Xe(_ + o, 127)], v.Sc[1] = ai[Xe(_ + 0, 127)], v.Eb[0] = 2 * ii[Xe(_ + a, 127)], v.Eb[1] = 101581 * ai[Xe(_ + l, 127)] >> 16, 8 > v.Eb[1] && (v.Eb[1] = 8), v.Qc[0] = ii[Xe(_ + d, 117)], v.Qc[1] = ai[Xe(_ + u, 127)], v.lc = _ + u;
			}
			if (!c.Rb) return $e(e, 4, "Not a key frame.");
			for (D(s), c = e.Pa, r = 0; 4 > r; ++r) {
				for (o = 0; 8 > o; ++o) for (a = 0; 3 > a; ++a) for (l = 0; 11 > l; ++l) d = O(s, fi[r][o][a][l]) ? h(s, 8) : ui[r][o][a][l], c.Wc[r][o].Yb[a][l] = d;
				for (o = 0; 17 > o; ++o) c.Xc[r][o] = c.Wc[r][pi[o]];
			}
			return e.kc = D(s), e.kc && (e.Bd = h(s, 8)), e.cb = 1;
		}
		function nt(e, t, n, r, i, a, o) {
			var s = t[i].Yb[n];
			for (n = 0; 16 > i; ++i) {
				if (!O(e, s[n + 0])) return i;
				for (; !O(e, s[n + 1]);) if (s = t[++i].Yb[0], n = 0, i == 16) return 16;
				var c = t[i + 1].Yb;
				if (O(e, s[n + 2])) {
					var l = e, u = 0;
					if (O(l, (f = s)[(d = n) + 3])) {
						if (O(l, f[d + 6])) {
							for (s = 0, d = 2 * (u = O(l, f[d + 8])) + (f = O(l, f[d + 9 + u])), u = 0, f = si[d]; f[s]; ++s) u += u + O(l, f[s]);
							u += 3 + (8 << d);
						} else O(l, f[d + 7]) ? (u = 7 + 2 * O(l, 165), u += O(l, 145)) : u = 5 + O(l, 159);
					} else u = O(l, f[d + 4]) ? 3 + O(l, f[d + 5]) : 2;
					s = c[2];
				} else u = 1, s = c[1];
				c = o + ci[i], 0 > (l = e).b && E(l);
				var d, f = l.b, p = (d = l.Ca >> 1) - (l.I >> f) >> 31;
				--l.b, l.Ca += p, l.Ca |= 1, l.I -= (d + 1 & p) << f, a[c] = ((u ^ p) - p) * r[(0 < i) + 0];
			}
			return 16;
		}
		function rt(e) {
			var t = e.rb[e.sb - 1];
			t.la = 0, t.Na = 0, i(e.zc, 0, 0, e.zc.length), e.ja = 0;
		}
		function it(e, t, n, r, i) {
			i = e[t + n + 32 * r] + (i >> 3), e[t + n + 32 * r] = -256 & i ? 0 > i ? 0 : 255 : i;
		}
		function at(e, t, n, r, i, a) {
			it(e, t, 0, n, r + i), it(e, t, 1, n, r + a), it(e, t, 2, n, r - a), it(e, t, 3, n, r - i);
		}
		function ot(e) {
			return (20091 * e >> 16) + e;
		}
		function st(e, t, n, r) {
			var i, o = 0, s = a(16);
			for (i = 0; 4 > i; ++i) {
				var c = e[t + 0] + e[t + 8], l = e[t + 0] - e[t + 8], u = (35468 * e[t + 4] >> 16) - ot(e[t + 12]), d = ot(e[t + 4]) + (35468 * e[t + 12] >> 16);
				s[o + 0] = c + d, s[o + 1] = l + u, s[o + 2] = l - u, s[o + 3] = c - d, o += 4, t++;
			}
			for (i = o = 0; 4 > i; ++i) c = (e = s[o + 0] + 4) + s[o + 8], l = e - s[o + 8], u = (35468 * s[o + 4] >> 16) - ot(s[o + 12]), it(n, r, 0, 0, c + (d = ot(s[o + 4]) + (35468 * s[o + 12] >> 16))), it(n, r, 1, 0, l + u), it(n, r, 2, 0, l - u), it(n, r, 3, 0, c - d), o++, r += 32;
		}
		function ct(e, t, n, r) {
			var i = e[t + 0] + 4, a = 35468 * e[t + 4] >> 16, o = ot(e[t + 4]), s = 35468 * e[t + 1] >> 16;
			at(n, r, 0, i + o, e = ot(e[t + 1]), s), at(n, r, 1, i + a, e, s), at(n, r, 2, i - a, e, s), at(n, r, 3, i - o, e, s);
		}
		function lt(e, t, n, r, i) {
			st(e, t, n, r), i && st(e, t + 16, n, r + 4);
		}
		function ut(e, t, n, r) {
			lr(e, t + 0, n, r, 1), lr(e, t + 32, n, r + 128, 1);
		}
		function dt(e, t, n, r) {
			var i;
			for (e = e[t + 0] + 4, i = 0; 4 > i; ++i) for (t = 0; 4 > t; ++t) it(n, r, t, i, e);
		}
		function ft(e, t, n, r) {
			e[t + 0] && fr(e, t + 0, n, r), e[t + 16] && fr(e, t + 16, n, r + 4), e[t + 32] && fr(e, t + 32, n, r + 128), e[t + 48] && fr(e, t + 48, n, r + 128 + 4);
		}
		function pt(e, t, n, r) {
			var i, o = a(16);
			for (i = 0; 4 > i; ++i) {
				var s = e[t + 0 + i] + e[t + 12 + i], c = e[t + 4 + i] + e[t + 8 + i], l = e[t + 4 + i] - e[t + 8 + i], u = e[t + 0 + i] - e[t + 12 + i];
				o[0 + i] = s + c, o[8 + i] = s - c, o[4 + i] = u + l, o[12 + i] = u - l;
			}
			for (i = 0; 4 > i; ++i) s = (e = o[0 + 4 * i] + 3) + o[3 + 4 * i], c = o[1 + 4 * i] + o[2 + 4 * i], l = o[1 + 4 * i] - o[2 + 4 * i], u = e - o[3 + 4 * i], n[r + 0] = s + c >> 3, n[r + 16] = u + l >> 3, n[r + 32] = s - c >> 3, n[r + 48] = u - l >> 3, r += 64;
		}
		function mt(e, t, n) {
			var r, i = t - 32, a = Lr, o = 255 - e[i - 1];
			for (r = 0; r < n; ++r) {
				var s, c = a, l = o + e[t - 1];
				for (s = 0; s < n; ++s) e[t + s] = c[l + e[i + s]];
				t += 32;
			}
		}
		function ht(e, t) {
			mt(e, t, 4);
		}
		function gt(e, t) {
			mt(e, t, 8);
		}
		function _t(e, t) {
			mt(e, t, 16);
		}
		function vt(e, t) {
			for (var n = 0; 16 > n; ++n) r(e, t + 32 * n, e, t - 32, 16);
		}
		function yt(e, t) {
			for (var n = 16; 0 < n; --n) i(e, t, e[t - 1], 16), t += 32;
		}
		function bt(e, t, n) {
			for (var r = 0; 16 > r; ++r) i(t, n + 32 * r, e, 16);
		}
		function xt(e, t) {
			var n, r = 16;
			for (n = 0; 16 > n; ++n) r += e[t - 1 + 32 * n] + e[t + n - 32];
			bt(r >> 5, e, t);
		}
		function St(e, t) {
			var n, r = 8;
			for (n = 0; 16 > n; ++n) r += e[t - 1 + 32 * n];
			bt(r >> 4, e, t);
		}
		function Ct(e, t) {
			var n, r = 8;
			for (n = 0; 16 > n; ++n) r += e[t + n - 32];
			bt(r >> 4, e, t);
		}
		function wt(e, t) {
			bt(128, e, t);
		}
		function Y(e, t, n) {
			return e + 2 * t + n + 2 >> 2;
		}
		function Tt(e, t) {
			var n, i = t - 32;
			for (i = new Uint8Array([
				Y(e[i - 1], e[i + 0], e[i + 1]),
				Y(e[i + 0], e[i + 1], e[i + 2]),
				Y(e[i + 1], e[i + 2], e[i + 3]),
				Y(e[i + 2], e[i + 3], e[i + 4])
			]), n = 0; 4 > n; ++n) r(e, t + 32 * n, i, 0, i.length);
		}
		function Et(e, t) {
			var n = e[t - 1], r = e[t - 1 + 32], i = e[t - 1 + 64], a = e[t - 1 + 96];
			k(e, t + 0, 16843009 * Y(e[t - 1 - 32], n, r)), k(e, t + 32, 16843009 * Y(n, r, i)), k(e, t + 64, 16843009 * Y(r, i, a)), k(e, t + 96, 16843009 * Y(i, a, a));
		}
		function Dt(e, t) {
			var n, r = 4;
			for (n = 0; 4 > n; ++n) r += e[t + n - 32] + e[t - 1 + 32 * n];
			for (r >>= 3, n = 0; 4 > n; ++n) i(e, t + 32 * n, r, 4);
		}
		function Ot(e, t) {
			var n = e[t - 1 + 0], r = e[t - 1 + 32], i = e[t - 1 + 64], a = e[t - 1 - 32], o = e[t + 0 - 32], s = e[t + 1 - 32], c = e[t + 2 - 32], l = e[t + 3 - 32];
			e[t + 0 + 96] = Y(r, i, e[t - 1 + 96]), e[t + 1 + 96] = e[t + 0 + 64] = Y(n, r, i), e[t + 2 + 96] = e[t + 1 + 64] = e[t + 0 + 32] = Y(a, n, r), e[t + 3 + 96] = e[t + 2 + 64] = e[t + 1 + 32] = e[t + 0 + 0] = Y(o, a, n), e[t + 3 + 64] = e[t + 2 + 32] = e[t + 1 + 0] = Y(s, o, a), e[t + 3 + 32] = e[t + 2 + 0] = Y(c, s, o), e[t + 3 + 0] = Y(l, c, s);
		}
		function kt(e, t) {
			var n = e[t + 1 - 32], r = e[t + 2 - 32], i = e[t + 3 - 32], a = e[t + 4 - 32], o = e[t + 5 - 32], s = e[t + 6 - 32], c = e[t + 7 - 32];
			e[t + 0 + 0] = Y(e[t + 0 - 32], n, r), e[t + 1 + 0] = e[t + 0 + 32] = Y(n, r, i), e[t + 2 + 0] = e[t + 1 + 32] = e[t + 0 + 64] = Y(r, i, a), e[t + 3 + 0] = e[t + 2 + 32] = e[t + 1 + 64] = e[t + 0 + 96] = Y(i, a, o), e[t + 3 + 32] = e[t + 2 + 64] = e[t + 1 + 96] = Y(a, o, s), e[t + 3 + 64] = e[t + 2 + 96] = Y(o, s, c), e[t + 3 + 96] = Y(s, c, c);
		}
		function At(e, t) {
			var n = e[t - 1 + 0], r = e[t - 1 + 32], i = e[t - 1 + 64], a = e[t - 1 - 32], o = e[t + 0 - 32], s = e[t + 1 - 32], c = e[t + 2 - 32], l = e[t + 3 - 32];
			e[t + 0 + 0] = e[t + 1 + 64] = a + o + 1 >> 1, e[t + 1 + 0] = e[t + 2 + 64] = o + s + 1 >> 1, e[t + 2 + 0] = e[t + 3 + 64] = s + c + 1 >> 1, e[t + 3 + 0] = c + l + 1 >> 1, e[t + 0 + 96] = Y(i, r, n), e[t + 0 + 64] = Y(r, n, a), e[t + 0 + 32] = e[t + 1 + 96] = Y(n, a, o), e[t + 1 + 32] = e[t + 2 + 96] = Y(a, o, s), e[t + 2 + 32] = e[t + 3 + 96] = Y(o, s, c), e[t + 3 + 32] = Y(s, c, l);
		}
		function jt(e, t) {
			var n = e[t + 0 - 32], r = e[t + 1 - 32], i = e[t + 2 - 32], a = e[t + 3 - 32], o = e[t + 4 - 32], s = e[t + 5 - 32], c = e[t + 6 - 32], l = e[t + 7 - 32];
			e[t + 0 + 0] = n + r + 1 >> 1, e[t + 1 + 0] = e[t + 0 + 64] = r + i + 1 >> 1, e[t + 2 + 0] = e[t + 1 + 64] = i + a + 1 >> 1, e[t + 3 + 0] = e[t + 2 + 64] = a + o + 1 >> 1, e[t + 0 + 32] = Y(n, r, i), e[t + 1 + 32] = e[t + 0 + 96] = Y(r, i, a), e[t + 2 + 32] = e[t + 1 + 96] = Y(i, a, o), e[t + 3 + 32] = e[t + 2 + 96] = Y(a, o, s), e[t + 3 + 64] = Y(o, s, c), e[t + 3 + 96] = Y(s, c, l);
		}
		function Mt(e, t) {
			var n = e[t - 1 + 0], r = e[t - 1 + 32], i = e[t - 1 + 64], a = e[t - 1 + 96];
			e[t + 0 + 0] = n + r + 1 >> 1, e[t + 2 + 0] = e[t + 0 + 32] = r + i + 1 >> 1, e[t + 2 + 32] = e[t + 0 + 64] = i + a + 1 >> 1, e[t + 1 + 0] = Y(n, r, i), e[t + 3 + 0] = e[t + 1 + 32] = Y(r, i, a), e[t + 3 + 32] = e[t + 1 + 64] = Y(i, a, a), e[t + 3 + 64] = e[t + 2 + 64] = e[t + 0 + 96] = e[t + 1 + 96] = e[t + 2 + 96] = e[t + 3 + 96] = a;
		}
		function Nt(e, t) {
			var n = e[t - 1 + 0], r = e[t - 1 + 32], i = e[t - 1 + 64], a = e[t - 1 + 96], o = e[t - 1 - 32], s = e[t + 0 - 32], c = e[t + 1 - 32], l = e[t + 2 - 32];
			e[t + 0 + 0] = e[t + 2 + 32] = n + o + 1 >> 1, e[t + 0 + 32] = e[t + 2 + 64] = r + n + 1 >> 1, e[t + 0 + 64] = e[t + 2 + 96] = i + r + 1 >> 1, e[t + 0 + 96] = a + i + 1 >> 1, e[t + 3 + 0] = Y(s, c, l), e[t + 2 + 0] = Y(o, s, c), e[t + 1 + 0] = e[t + 3 + 32] = Y(n, o, s), e[t + 1 + 32] = e[t + 3 + 64] = Y(r, n, o), e[t + 1 + 64] = e[t + 3 + 96] = Y(i, r, n), e[t + 1 + 96] = Y(a, i, r);
		}
		function Pt(e, t) {
			for (var n = 0; 8 > n; ++n) r(e, t + 32 * n, e, t - 32, 8);
		}
		function Ft(e, t) {
			for (var n = 0; 8 > n; ++n) i(e, t, e[t - 1], 8), t += 32;
		}
		function It(e, t, n) {
			for (var r = 0; 8 > r; ++r) i(t, n + 32 * r, e, 8);
		}
		function Lt(e, t) {
			var n, r = 8;
			for (n = 0; 8 > n; ++n) r += e[t + n - 32] + e[t - 1 + 32 * n];
			It(r >> 4, e, t);
		}
		function Rt(e, t) {
			var n, r = 4;
			for (n = 0; 8 > n; ++n) r += e[t + n - 32];
			It(r >> 3, e, t);
		}
		function zt(e, t) {
			var n, r = 4;
			for (n = 0; 8 > n; ++n) r += e[t - 1 + 32 * n];
			It(r >> 3, e, t);
		}
		function Bt(e, t) {
			It(128, e, t);
		}
		function Vt(e, t, n) {
			var r = e[t - n], i = e[t + 0], a = 3 * (i - r) + Fr[1020 + e[t - 2 * n] - e[t + n]], o = Ir[112 + (a + 4 >> 3)];
			e[t - n] = Lr[255 + r + Ir[112 + (a + 3 >> 3)]], e[t + 0] = Lr[255 + i - o];
		}
		function Ht(e, t, n, r) {
			var i = e[t + 0], a = e[t + n];
			return Rr[255 + e[t - 2 * n] - e[t - n]] > r || Rr[255 + a - i] > r;
		}
		function Ut(e, t, n, r) {
			return 4 * Rr[255 + e[t - n] - e[t + 0]] + Rr[255 + e[t - 2 * n] - e[t + n]] <= r;
		}
		function Wt(e, t, n, r, i) {
			var a = e[t - 3 * n], o = e[t - 2 * n], s = e[t - n], c = e[t + 0], l = e[t + n], u = e[t + 2 * n], d = e[t + 3 * n];
			return 4 * Rr[255 + s - c] + Rr[255 + o - l] > r ? 0 : Rr[255 + e[t - 4 * n] - a] <= i && Rr[255 + a - o] <= i && Rr[255 + o - s] <= i && Rr[255 + d - u] <= i && Rr[255 + u - l] <= i && Rr[255 + l - c] <= i;
		}
		function Gt(e, t, n, r) {
			var i = 2 * r + 1;
			for (r = 0; 16 > r; ++r) Ut(e, t + r, n, i) && Vt(e, t + r, n);
		}
		function Kt(e, t, n, r) {
			var i = 2 * r + 1;
			for (r = 0; 16 > r; ++r) Ut(e, t + r * n, 1, i) && Vt(e, t + r * n, 1);
		}
		function qt(e, t, n, r) {
			for (var i = 3; 0 < i; --i) Gt(e, t += 4 * n, n, r);
		}
		function Jt(e, t, n, r) {
			for (var i = 3; 0 < i; --i) Kt(e, t += 4, n, r);
		}
		function Yt(e, t, n, r, i, a, o, s) {
			for (a = 2 * a + 1; 0 < i--;) {
				if (Wt(e, t, n, a, o)) {
					if (Ht(e, t, n, s)) Vt(e, t, n);
					else {
						var c = e, l = t, u = n, d = c[l - 2 * u], f = c[l - u], p = c[l + 0], m = c[l + u], h = c[l + 2 * u], g = 27 * (v = Fr[1020 + 3 * (p - f) + Fr[1020 + d - m]]) + 63 >> 7, _ = 18 * v + 63 >> 7, v = 9 * v + 63 >> 7;
						c[l - 3 * u] = Lr[255 + c[l - 3 * u] + v], c[l - 2 * u] = Lr[255 + d + _], c[l - u] = Lr[255 + f + g], c[l + 0] = Lr[255 + p - g], c[l + u] = Lr[255 + m - _], c[l + 2 * u] = Lr[255 + h - v];
					}
				}
				t += r;
			}
		}
		function Xt(e, t, n, r, i, a, o, s) {
			for (a = 2 * a + 1; 0 < i--;) {
				if (Wt(e, t, n, a, o)) {
					if (Ht(e, t, n, s)) Vt(e, t, n);
					else {
						var c = e, l = t, u = n, d = c[l - u], f = c[l + 0], p = c[l + u], m = Ir[112 + (4 + (h = 3 * (f - d)) >> 3)], h = Ir[112 + (h + 3 >> 3)], g = m + 1 >> 1;
						c[l - 2 * u] = Lr[255 + c[l - 2 * u] + g], c[l - u] = Lr[255 + d + h], c[l + 0] = Lr[255 + f - m], c[l + u] = Lr[255 + p - g];
					}
				}
				t += r;
			}
		}
		function Zt(e, t, n, r, i, a) {
			Yt(e, t, n, 1, 16, r, i, a);
		}
		function Qt(e, t, n, r, i, a) {
			Yt(e, t, 1, n, 16, r, i, a);
		}
		function $t(e, t, n, r, i, a) {
			for (var o = 3; 0 < o; --o) Xt(e, t += 4 * n, n, 1, 16, r, i, a);
		}
		function en(e, t, n, r, i, a) {
			for (var o = 3; 0 < o; --o) Xt(e, t += 4, 1, n, 16, r, i, a);
		}
		function tn(e, t, n, r, i, a, o, s) {
			Yt(e, t, i, 1, 8, a, o, s), Yt(n, r, i, 1, 8, a, o, s);
		}
		function nn(e, t, n, r, i, a, o, s) {
			Yt(e, t, 1, i, 8, a, o, s), Yt(n, r, 1, i, 8, a, o, s);
		}
		function rn(e, t, n, r, i, a, o, s) {
			Xt(e, t + 4 * i, i, 1, 8, a, o, s), Xt(n, r + 4 * i, i, 1, 8, a, o, s);
		}
		function an(e, t, n, r, i, a, o, s) {
			Xt(e, t + 4, 1, i, 8, a, o, s), Xt(n, r + 4, 1, i, 8, a, o, s);
		}
		function on() {
			this.ba = new pe(), this.ec = [], this.cc = [], this.Mc = [], this.Dc = this.Nc = this.dc = this.fc = 0, this.Oa = new he(), this.memory = 0, this.Ib = "OutputFunc", this.Jb = "OutputAlphaFunc", this.Nd = "OutputRowFunc";
		}
		function sn() {
			this.data = [], this.offset = this.kd = this.ha = this.w = 0, this.na = [], this.xa = this.gb = this.Ja = this.Sa = this.P = 0;
		}
		function cn() {
			this.nc = this.Ea = this.b = this.hc = 0, this.K = [], this.w = 0;
		}
		function ln() {
			this.ua = 0, this.Wa = new F(), this.vb = new F(), this.md = this.xc = this.wc = 0, this.vc = [], this.Wb = 0, this.Ya = new p(), this.yc = new d();
		}
		function un() {
			this.xb = this.a = 0, this.l = new Ze(), this.ca = new pe(), this.V = [], this.Ba = 0, this.Ta = [], this.Ua = 0, this.m = new x(), this.Pb = 0, this.wd = new x(), this.Ma = this.$ = this.C = this.i = this.c = this.xd = 0, this.s = new ln(), this.ab = 0, this.gc = o(4, cn), this.Oc = 0;
		}
		function dn() {
			this.Lc = this.Z = this.$a = this.i = this.c = 0, this.l = new Ze(), this.ic = 0, this.ca = [], this.tb = 0, this.qd = null, this.rd = 0;
		}
		function fn(e, t, n, r, i, a, o) {
			for (e = e == null ? 0 : e[t + 0], t = 0; t < o; ++t) i[a + t] = e + n[r + t] & 255, e = i[a + t];
		}
		function pn(e, t, n, r, i, a, o) {
			var s;
			if (e == null) fn(null, null, n, r, i, a, o);
			else for (s = 0; s < o; ++s) i[a + s] = e[t + s] + n[r + s] & 255;
		}
		function mn(e, t, n, r, i, a, o) {
			if (e == null) fn(null, null, n, r, i, a, o);
			else {
				var s, c = e[t + 0], l = c, u = c;
				for (s = 0; s < o; ++s) l = u + (c = e[t + s]) - l, u = n[r + s] + (-256 & l ? 0 > l ? 0 : 255 : l) & 255, l = c, i[a + s] = u;
			}
		}
		function hn(e, n, i, o) {
			var s = n.width, c = n.o;
			if (t(e != null && n != null), 0 > i || 0 >= o || i + o > c) return null;
			if (!e.Cc) {
				if (e.ga == null) {
					var l;
					if (e.ga = new dn(), (l = e.ga == null) || (l = n.width * n.o, t(e.Gb.length == 0), e.Gb = a(l), e.Uc = 0, e.Gb == null ? l = 0 : (e.mb = e.Gb, e.nb = e.Uc, e.rc = null, l = 1), l = !l), !l) {
						l = e.ga;
						var u = e.Fa, d = e.P, f = e.qc, p = e.mb, m = e.nb, h = d + 1, g = f - 1, v = l.l;
						if (t(u != null && p != null && n != null), yi[0] = null, yi[1] = fn, yi[2] = pn, yi[3] = mn, l.ca = p, l.tb = m, l.c = n.width, l.i = n.height, t(0 < l.c && 0 < l.i), 1 >= f) n = 0;
						else if (l.$a = 3 & u[d + 0], l.Z = u[d + 0] >> 2 & 3, l.Lc = u[d + 0] >> 4 & 3, d = u[d + 0] >> 6 & 3, 0 > l.$a || 1 < l.$a || 4 <= l.Z || 1 < l.Lc || d) n = 0;
						else if (v.put = be, v.ac = ye, v.bc = xe, v.ma = l, v.width = n.width, v.height = n.height, v.Da = n.Da, v.v = n.v, v.va = n.va, v.j = n.j, v.o = n.o, l.$a) t: {
							t(l.$a == 1), n = Pe();
							e: for (;;) {
								if (n == null) {
									n = 0;
									break t;
								}
								if (t(l != null), l.mc = n, n.c = l.c, n.i = l.i, n.l = l.l, n.l.ma = l, n.l.width = l.c, n.l.height = l.i, n.a = 0, _(n.m, u, h, g), !Fe(l.c, l.i, 1, n, null) || (n.ab == 1 && n.gc[0].hc == 3 && Ae(n.s) ? (l.ic = 1, u = n.c * n.i, n.Ta = null, n.Ua = 0, n.V = a(u), n.Ba = 0, n.V == null ? (n.a = 1, n = 0) : n = 1) : (l.ic = 0, n = Ie(n, l.c)), !n)) break e;
								n = 1;
								break t;
							}
							l.mc = null, n = 0;
						}
						else n = g >= l.c * l.i;
						l = !n;
					}
					if (l) return null;
					e.ga.Lc == 1 ? o = c - i : e.Ga = 0;
				}
				t(e.ga != null), t(i + o <= c);
				t: {
					if (n = (u = e.ga).c, c = u.l.o, u.$a == 0) {
						if (h = e.rc, g = e.Vc, v = e.Fa, d = e.P + 1 + i * n, f = e.mb, p = e.nb + i * n, t(d <= e.P + e.qc), u.Z != 0) for (t(yi[u.Z] != null), l = 0; l < o; ++l) yi[u.Z](h, g, v, d, f, p, n), h = f, g = p, p += n, d += n;
						else for (l = 0; l < o; ++l) r(f, p, v, d, n), h = f, g = p, p += n, d += n;
						e.rc = h, e.Vc = g;
					} else {
						if (t(u.mc != null), n = i + o, t((l = u.mc) != null), t(n <= l.i), l.C >= n) n = 1;
						else if (u.ic || bn(), u.ic) {
							u = l.V, h = l.Ba, g = l.c;
							var y = l.i, b = (v = 1, d = l.$ / g, f = l.$ % g, p = l.m, m = l.s, l.$), x = g * y, S = g * n, w = m.wc, E = b < S ? De(m, f, d) : null;
							t(b <= x), t(n <= y), t(Ae(m));
							e: for (;;) {
								for (; !p.h && b < S;) {
									if (f & w || (E = De(m, f, d)), t(E != null), T(p), 256 > (y = Te(E.G[0], E.H[0], p))) u[h + b] = y, ++b, ++f >= g && (f = 0, ++d <= n && !(d % 16) && Me(l, d));
									else {
										if (!(280 > y)) {
											v = 0;
											break e;
										}
										y = Ce(y - 256, p);
										var D, O = Te(E.G[4], E.H[4], p);
										if (T(p), !(b >= (O = we(g, O = Ce(O, p))) && x - b >= y)) {
											v = 0;
											break e;
										}
										for (D = 0; D < y; ++D) u[h + b + D] = u[h + b + D - O];
										for (b += y, f += y; f >= g;) f -= g, ++d <= n && !(d % 16) && Me(l, d);
										b < S && f & w && (E = De(m, f, d));
									}
									t(p.h == C(p));
								}
								Me(l, d > n ? n : d);
								break e;
							}
							!v || p.h && b < x ? (v = 0, l.a = p.h ? 5 : 3) : l.$ = b, n = v;
						} else n = q(l, l.V, l.Ba, l.c, l.i, n, Le);
						if (!n) {
							o = 0;
							break t;
						}
					}
					i + o >= c && (e.Cc = 1), o = 1;
				}
				if (!o) return null;
				if (e.Cc && ((o = e.ga) != null && (o.mc = null), e.ga = null, 0 < e.Ga)) return alert("todo:WebPDequantizeLevels"), null;
			}
			return e.nb + i * s;
		}
		function gn(e, t, n, r, i, a) {
			for (; 0 < i--;) {
				var o, s = e, c = t + +!!n, l = e, u = t + (n ? 0 : 3);
				for (o = 0; o < r; ++o) {
					var d = l[u + 4 * o];
					d != 255 && (d *= 32897, s[c + 4 * o + 0] = s[c + 4 * o + 0] * d >> 23, s[c + 4 * o + 1] = s[c + 4 * o + 1] * d >> 23, s[c + 4 * o + 2] = s[c + 4 * o + 2] * d >> 23);
				}
				t += a;
			}
		}
		function _n(e, t, n, r, i) {
			for (; 0 < r--;) {
				for (var a = 0; a < n; ++a) {
					var o = e[t + 2 * a + 0], s = 15 & (l = e[t + 2 * a + 1]), c = 4369 * s, l = (240 & l | l >> 4) * c >> 16;
					e[t + 2 * a + 0] = (240 & o | o >> 4) * c >> 16 & 240 | (15 & o | o << 4) * c >> 16 >> 4 & 15, e[t + 2 * a + 1] = 240 & l | s;
				}
				t += i;
			}
		}
		function vn(e, t, n, r, i, a, o, s) {
			var c, l, u = 255;
			for (l = 0; l < i; ++l) {
				for (c = 0; c < r; ++c) {
					var d = e[t + c];
					a[o + 4 * c] = d, u &= d;
				}
				t += n, o += s;
			}
			return u != 255;
		}
		function yn(e, t, n, r, i) {
			for (var a = 0; a < i; ++a) n[r + a] = e[t + a] >> 8;
		}
		function bn() {
			Er = gn, Dr = _n, Or = vn, kr = yn;
		}
		function xn(n, r, i) {
			e[n] = function(e, n, a, o, s, c, l, u, d, f, p, m, h, g, _, v, y) {
				var b, x = y - 1 >> 1, S = s[c + 0] | l[u + 0] << 16, C = d[f + 0] | p[m + 0] << 16;
				t(e != null);
				var w = 3 * S + C + 131074 >> 2;
				for (r(e[n + 0], 255 & w, w >> 16, h, g), a != null && (w = 3 * C + S + 131074 >> 2, r(a[o + 0], 255 & w, w >> 16, _, v)), b = 1; b <= x; ++b) {
					var T = s[c + b] | l[u + b] << 16, E = d[f + b] | p[m + b] << 16, D = S + T + C + E + 524296, O = D + 2 * (T + C) >> 3;
					w = O + S >> 1, S = (D = D + 2 * (S + E) >> 3) + T >> 1, r(e[n + 2 * b - 1], 255 & w, w >> 16, h, g + (2 * b - 1) * i), r(e[n + 2 * b - 0], 255 & S, S >> 16, h, g + (2 * b - 0) * i), a != null && (w = D + C >> 1, S = O + E >> 1, r(a[o + 2 * b - 1], 255 & w, w >> 16, _, v + (2 * b - 1) * i), r(a[o + 2 * b + 0], 255 & S, S >> 16, _, v + (2 * b + 0) * i)), S = T, C = E;
				}
				1 & y || (w = 3 * S + C + 131074 >> 2, r(e[n + y - 1], 255 & w, w >> 16, h, g + (y - 1) * i), a != null && (w = 3 * C + S + 131074 >> 2, r(a[o + y - 1], 255 & w, w >> 16, _, v + (y - 1) * i)));
			};
		}
		function Sn() {
			bi[zr] = xi, bi[Br] = Ci, bi[Vr] = Si, bi[Hr] = wi, bi[Ur] = Ti, bi[Wr] = Ei, bi[Gr] = Di, bi[Kr] = Ci, bi[qr] = wi, bi[Jr] = Ti, bi[Yr] = Ei;
		}
		function Cn(e) {
			return e & ~Ni ? 0 > e ? 0 : 255 : e >> Mi;
		}
		function wn(e, t) {
			return Cn((19077 * e >> 8) + (26149 * t >> 8) - 14234);
		}
		function Tn(e, t, n) {
			return Cn((19077 * e >> 8) - (6419 * t >> 8) - (13320 * n >> 8) + 8708);
		}
		function En(e, t) {
			return Cn((19077 * e >> 8) + (33050 * t >> 8) - 17685);
		}
		function Dn(e, t, n, r, i) {
			r[i + 0] = wn(e, n), r[i + 1] = Tn(e, t, n), r[i + 2] = En(e, t);
		}
		function On(e, t, n, r, i) {
			r[i + 0] = En(e, t), r[i + 1] = Tn(e, t, n), r[i + 2] = wn(e, n);
		}
		function kn(e, t, n, r, i) {
			var a = Tn(e, t, n);
			t = a << 3 & 224 | En(e, t) >> 3, r[i + 0] = 248 & wn(e, n) | a >> 5, r[i + 1] = t;
		}
		function An(e, t, n, r, i) {
			var a = 240 & En(e, t) | 15;
			r[i + 0] = 240 & wn(e, n) | Tn(e, t, n) >> 4, r[i + 1] = a;
		}
		function jn(e, t, n, r, i) {
			r[i + 0] = 255, Dn(e, t, n, r, i + 1);
		}
		function Mn(e, t, n, r, i) {
			On(e, t, n, r, i), r[i + 3] = 255;
		}
		function Nn(e, t, n, r, i) {
			Dn(e, t, n, r, i), r[i + 3] = 255;
		}
		function Pn(t, n, r) {
			e[t] = function(e, t, i, a, o, s, c, l, u) {
				for (var d = l + (-2 & u) * r; l != d;) n(e[t + 0], i[a + 0], o[s + 0], c, l), n(e[t + 1], i[a + 0], o[s + 0], c, l + r), t += 2, ++a, ++s, l += 2 * r;
				1 & u && n(e[t + 0], i[a + 0], o[s + 0], c, l);
			};
		}
		function Fn(e, t, n) {
			return n == 0 ? e == 0 ? t == 0 ? 6 : 5 : t == 0 ? 4 : 0 : n;
		}
		function In(e, t, n, r, i) {
			switch (e >>> 30) {
				case 3:
					lr(t, n, r, i, 0);
					break;
				case 2:
					ur(t, n, r, i);
					break;
				case 1: fr(t, n, r, i);
			}
		}
		function Ln(e, t) {
			var n, a, o = t.M, s = t.Nb, c = e.oc, l = e.pc + 40, u = e.oc, d = e.pc + 584, f = e.oc, p = e.pc + 600;
			for (n = 0; 16 > n; ++n) c[l + 32 * n - 1] = 129;
			for (n = 0; 8 > n; ++n) u[d + 32 * n - 1] = 129, f[p + 32 * n - 1] = 129;
			for (0 < o ? c[l - 1 - 32] = u[d - 1 - 32] = f[p - 1 - 32] = 129 : (i(c, l - 32 - 1, 127, 21), i(u, d - 32 - 1, 127, 9), i(f, p - 32 - 1, 127, 9)), a = 0; a < e.za; ++a) {
				var m = t.ya[t.aa + a];
				if (0 < a) {
					for (n = -1; 16 > n; ++n) r(c, l + 32 * n - 4, c, l + 32 * n + 12, 4);
					for (n = -1; 8 > n; ++n) r(u, d + 32 * n - 4, u, d + 32 * n + 4, 4), r(f, p + 32 * n - 4, f, p + 32 * n + 4, 4);
				}
				var h = e.Gd, g = e.Hd + a, _ = m.ad, v = m.Hc;
				if (0 < o && (r(c, l - 32, h[g].y, 0, 16), r(u, d - 32, h[g].f, 0, 8), r(f, p - 32, h[g].ea, 0, 8)), m.Za) {
					var y = c, b = l - 32 + 16;
					for (0 < o && (a >= e.za - 1 ? i(y, b, h[g].y[15], 4) : r(y, b, h[g + 1].y, 0, 4)), n = 0; 4 > n; n++) y[b + 128 + n] = y[b + 256 + n] = y[b + 384 + n] = y[b + 0 + n];
					for (n = 0; 16 > n; ++n, v <<= 2) y = c, b = l + Vi[n], hi[m.Ob[n]](y, b), In(v, _, 16 * n, y, b);
				} else if (y = Fn(a, o, m.Ob[0]), mi[y](c, l), v != 0) for (n = 0; 16 > n; ++n, v <<= 2) In(v, _, 16 * n, c, l + Vi[n]);
				for (n = m.Gc, y = Fn(a, o, m.Dd), gi[y](u, d), gi[y](f, p), v = _, y = u, b = d, 255 & (m = 0 | n) && (170 & m ? dr(v, 256, y, b) : pr(v, 256, y, b)), m = f, v = p, 255 & (n >>= 8) && (170 & n ? dr(_, 320, m, v) : pr(_, 320, m, v)), o < e.Ub - 1 && (r(h[g].y, 0, c, l + 480, 16), r(h[g].f, 0, u, d + 224, 8), r(h[g].ea, 0, f, p + 224, 8)), n = 8 * s * e.B, h = e.sa, g = e.ta + 16 * a + 16 * s * e.R, _ = e.qa, m = e.ra + 8 * a + n, v = e.Ha, y = e.Ia + 8 * a + n, n = 0; 16 > n; ++n) r(h, g + n * e.R, c, l + 32 * n, 16);
				for (n = 0; 8 > n; ++n) r(_, m + n * e.B, u, d + 32 * n, 8), r(v, y + n * e.B, f, p + 32 * n, 8);
			}
		}
		function Rn(e, r, i, a, o, s, c, l, u) {
			var d = [0], f = [0], p = 0, m = u == null ? 0 : u.kd, h = u ?? new sn();
			if (e == null || 12 > i) return 7;
			h.data = e, h.w = r, h.ha = i, r = [r], i = [i], h.gb = [h.gb];
			t: {
				var g = r, v = i, y = h.gb;
				if (t(e != null), t(v != null), t(y != null), y[0] = 0, 12 <= v[0] && !n(e, g[0], "RIFF")) {
					if (n(e, g[0] + 8, "WEBP")) {
						y = 3;
						break t;
					}
					var b = M(e, g[0] + 4);
					if (12 > b || 4294967286 < b) {
						y = 3;
						break t;
					}
					if (m && b > v[0] - 8) {
						y = 7;
						break t;
					}
					y[0] = b, g[0] += 12, v[0] -= 12;
				}
				y = 0;
			}
			if (y != 0) return y;
			for (b = 0 < h.gb[0], i = i[0];;) {
				t: {
					var S = e;
					v = r, y = i;
					var C = d, w = f, T = g = [0];
					if ((O = p = [p])[0] = 0, 8 > y[0]) y = 7;
					else {
						if (!n(S, v[0], "VP8X")) {
							if (M(S, v[0] + 4) != 10) {
								y = 3;
								break t;
							}
							if (18 > y[0]) {
								y = 7;
								break t;
							}
							var E = M(S, v[0] + 8), D = 1 + j(S, v[0] + 12);
							if (2147483648 <= D * (S = 1 + j(S, v[0] + 15))) {
								y = 3;
								break t;
							}
							T != null && (T[0] = E), C != null && (C[0] = D), w != null && (w[0] = S), v[0] += 18, y[0] -= 18, O[0] = 1;
						}
						y = 0;
					}
				}
				if (p = p[0], g = g[0], y != 0) return y;
				if (v = !!(2 & g), !b && p) return 3;
				if (s != null && (s[0] = !!(16 & g)), c != null && (c[0] = v), l != null && (l[0] = 0), c = d[0], g = f[0], p && v && u == null) {
					y = 0;
					break;
				}
				if (4 > i) {
					y = 7;
					break;
				}
				if (b && p || !b && !p && !n(e, r[0], "ALPH")) {
					i = [i], h.na = [h.na], h.P = [h.P], h.Sa = [h.Sa];
					t: {
						E = e, y = r, b = i;
						var O = h.gb;
						C = h.na, w = h.P, T = h.Sa, D = 22, t(E != null), t(b != null), S = y[0];
						var k = b[0];
						for (t(C != null), t(T != null), C[0] = null, w[0] = null, T[0] = 0;;) {
							if (y[0] = S, b[0] = k, 8 > k) {
								y = 7;
								break t;
							}
							var A = M(E, S + 4);
							if (4294967286 < A) {
								y = 3;
								break t;
							}
							var N = 8 + A + 1 & -2;
							if (D += N, 0 < O && D > O) {
								y = 3;
								break t;
							}
							if (!n(E, S, "VP8 ") || !n(E, S, "VP8L")) {
								y = 0;
								break t;
							}
							if (k[0] < N) {
								y = 7;
								break t;
							}
							n(E, S, "ALPH") || (C[0] = E, w[0] = S + 8, T[0] = A), S += N, k -= N;
						}
					}
					if (i = i[0], h.na = h.na[0], h.P = h.P[0], h.Sa = h.Sa[0], y != 0) break;
				}
				i = [i], h.Ja = [h.Ja], h.xa = [h.xa];
				t: if (O = e, y = r, b = i, C = h.gb[0], w = h.Ja, T = h.xa, E = y[0], S = !n(O, E, "VP8 "), D = !n(O, E, "VP8L"), t(O != null), t(b != null), t(w != null), t(T != null), 8 > b[0]) y = 7;
				else {
					if (S || D) {
						if (O = M(O, E + 4), 12 <= C && O > C - 12) {
							y = 3;
							break t;
						}
						if (m && O > b[0] - 8) {
							y = 7;
							break t;
						}
						w[0] = O, y[0] += 8, b[0] -= 8, T[0] = D;
					} else T[0] = 5 <= b[0] && O[E + 0] == 47 && !(O[E + 4] >> 5), w[0] = b[0];
					y = 0;
				}
				if (i = i[0], h.Ja = h.Ja[0], h.xa = h.xa[0], r = r[0], y != 0) break;
				if (4294967286 < h.Ja) return 3;
				if (l == null || v || (l[0] = h.xa ? 2 : 1), c = [c], g = [g], h.xa) {
					if (5 > i) {
						y = 7;
						break;
					}
					l = c, m = g, v = s, e == null || 5 > i ? e = 0 : 5 <= i && e[r + 0] == 47 && !(e[r + 4] >> 5) ? (b = [0], O = [0], C = [0], _(w = new x(), e, r, i), Se(w, b, O, C) ? (l != null && (l[0] = b[0]), m != null && (m[0] = O[0]), v != null && (v[0] = C[0]), e = 1) : e = 0) : e = 0;
				} else {
					if (10 > i) {
						y = 7;
						break;
					}
					l = g, e == null || 10 > i || !et(e, r + 3, i - 3) ? e = 0 : (m = e[r + 0] | e[r + 1] << 8 | e[r + 2] << 16, v = 16383 & (e[r + 7] << 8 | e[r + 6]), e = 16383 & (e[r + 9] << 8 | e[r + 8]), 1 & m || 3 < (m >> 1 & 7) || !(m >> 4 & 1) || m >> 5 >= h.Ja || !v || !e ? e = 0 : (c && (c[0] = v), l && (l[0] = e), e = 1));
				}
				if (!e || (c = c[0], g = g[0], p && (d[0] != c || f[0] != g))) return 3;
				u != null && (u[0] = h, u.offset = r - u.w, t(4294967286 > r - u.w), t(u.offset == u.ha - i));
				break;
			}
			return y == 0 || y == 7 && p && u == null ? (s != null && (s[0] |= h.na != null && 0 < h.na.length), a != null && (a[0] = c), o != null && (o[0] = g), 0) : y;
		}
		function zn(e, t, n) {
			var r = t.width, i = t.height, a = 0, o = 0, s = r, c = i;
			if (t.Da = e != null && 0 < e.Da, t.Da && (s = e.cd, c = e.bd, a = e.v, o = e.j, 11 > n || (a &= -2, o &= -2), 0 > a || 0 > o || 0 >= s || 0 >= c || a + s > r || o + c > i)) return 0;
			if (t.v = a, t.j = o, t.va = a + s, t.o = o + c, t.U = s, t.T = c, t.da = e != null && 0 < e.da, t.da) {
				if (!I(s, c, n = [e.ib], a = [e.hb])) return 0;
				t.ib = n[0], t.hb = a[0];
			}
			return t.ob = e != null && e.ob, t.Kb = e == null || !e.Sd, t.da && (t.ob = t.ib < 3 * r / 4 && t.hb < 3 * i / 4, t.Kb = 0), 1;
		}
		function Bn(e) {
			if (e == null) return 2;
			if (11 > e.S) {
				var t = e.f.RGBA;
				t.fb += (e.height - 1) * t.A, t.A = -t.A;
			} else t = e.f.kb, e = e.height, t.O += (e - 1) * t.fa, t.fa = -t.fa, t.N += (e - 1 >> 1) * t.Ab, t.Ab = -t.Ab, t.W += (e - 1 >> 1) * t.Db, t.Db = -t.Db, t.F != null && (t.J += (e - 1) * t.lb, t.lb = -t.lb);
			return 0;
		}
		function Vn(e, t, n, r) {
			if (r == null || 0 >= e || 0 >= t) return 2;
			if (n != null) {
				if (n.Da) {
					var i = n.cd, o = n.bd, s = -2 & n.v, c = -2 & n.j;
					if (0 > s || 0 > c || 0 >= i || 0 >= o || s + i > e || c + o > t) return 2;
					e = i, t = o;
				}
				if (n.da) {
					if (!I(e, t, i = [n.ib], o = [n.hb])) return 2;
					e = i[0], t = o[0];
				}
			}
			r.width = e, r.height = t;
			t: {
				var l = r.width, u = r.height;
				if (e = r.S, 0 >= l || 0 >= u || !(e >= zr && 13 > e)) e = 2;
				else {
					if (0 >= r.Rd && r.sd == null) {
						s = o = i = t = 0;
						var d = (c = l * Gi[e]) * u;
						if (11 > e || (o = (u + 1) / 2 * (t = (l + 1) / 2), e == 12 && (s = (i = l) * u)), (u = a(d + 2 * o + s)) == null) {
							e = 1;
							break t;
						}
						r.sd = u, 11 > e ? ((l = r.f.RGBA).eb = u, l.fb = 0, l.A = c, l.size = d) : ((l = r.f.kb).y = u, l.O = 0, l.fa = c, l.Fd = d, l.f = u, l.N = 0 + d, l.Ab = t, l.Cd = o, l.ea = u, l.W = 0 + d + o, l.Db = t, l.Ed = o, e == 12 && (l.F = u, l.J = 0 + d + 2 * o), l.Tc = s, l.lb = i);
					}
					if (t = 1, i = r.S, o = r.width, s = r.height, i >= zr && 13 > i) {
						if (11 > i) e = r.f.RGBA, t &= (c = Math.abs(e.A)) * (s - 1) + o <= e.size, t &= c >= o * Gi[i], t &= e.eb != null;
						else {
							e = r.f.kb, c = (o + 1) / 2, d = (s + 1) / 2, l = Math.abs(e.fa), u = Math.abs(e.Ab);
							var f = Math.abs(e.Db), p = Math.abs(e.lb), m = p * (s - 1) + o;
							t &= l * (s - 1) + o <= e.Fd, t &= u * (d - 1) + c <= e.Cd, t = (t &= f * (d - 1) + c <= e.Ed) & l >= o & u >= c & f >= c, t &= e.y != null, t &= e.f != null, t &= e.ea != null, i == 12 && (t &= p >= o, t &= m <= e.Tc, t &= e.F != null);
						}
					} else t = 0;
					e = t ? 0 : 2;
				}
			}
			return e != 0 || n != null && n.fd && (e = Bn(r)), e;
		}
		var Hn = 64, Un = [
			0,
			1,
			3,
			7,
			15,
			31,
			63,
			127,
			255,
			511,
			1023,
			2047,
			4095,
			8191,
			16383,
			32767,
			65535,
			131071,
			262143,
			524287,
			1048575,
			2097151,
			4194303,
			8388607,
			16777215
		], Wn = 24, Gn = 32, Kn = 8, qn = [
			0,
			0,
			1,
			1,
			2,
			2,
			2,
			2,
			3,
			3,
			3,
			3,
			3,
			3,
			3,
			3,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7
		];
		R("Predictor0", "PredictorAdd0"), e.Predictor0 = function() {
			return 4278190080;
		}, e.Predictor1 = function(e) {
			return e;
		}, e.Predictor2 = function(e, t, n) {
			return t[n + 0];
		}, e.Predictor3 = function(e, t, n) {
			return t[n + 1];
		}, e.Predictor4 = function(e, t, n) {
			return t[n - 1];
		}, e.Predictor5 = function(e, t, n) {
			return B(B(e, t[n + 1]), t[n + 0]);
		}, e.Predictor6 = function(e, t, n) {
			return B(e, t[n - 1]);
		}, e.Predictor7 = function(e, t, n) {
			return B(e, t[n + 0]);
		}, e.Predictor8 = function(e, t, n) {
			return B(t[n - 1], t[n + 0]);
		}, e.Predictor9 = function(e, t, n) {
			return B(t[n + 0], t[n + 1]);
		}, e.Predictor10 = function(e, t, n) {
			return B(B(e, t[n - 1]), B(t[n + 0], t[n + 1]));
		}, e.Predictor11 = function(e, t, n) {
			var r = t[n + 0];
			return 0 >= H(r >> 24 & 255, e >> 24 & 255, (t = t[n - 1]) >> 24 & 255) + H(r >> 16 & 255, e >> 16 & 255, t >> 16 & 255) + H(r >> 8 & 255, e >> 8 & 255, t >> 8 & 255) + H(255 & r, 255 & e, 255 & t) ? r : e;
		}, e.Predictor12 = function(e, t, n) {
			var r = t[n + 0];
			return (te((e >> 24 & 255) + (r >> 24 & 255) - ((t = t[n - 1]) >> 24 & 255)) << 24 | te((e >> 16 & 255) + (r >> 16 & 255) - (t >> 16 & 255)) << 16 | te((e >> 8 & 255) + (r >> 8 & 255) - (t >> 8 & 255)) << 8 | te((255 & e) + (255 & r) - (255 & t))) >>> 0;
		}, e.Predictor13 = function(e, t, n) {
			var r = t[n - 1];
			return (V((e = B(e, t[n + 0])) >> 24 & 255, r >> 24 & 255) << 24 | V(e >> 16 & 255, r >> 16 & 255) << 16 | V(e >> 8 & 255, r >> 8 & 255) << 8 | V(255 & e, 255 & r)) >>> 0;
		};
		var Jn = e.PredictorAdd0;
		e.PredictorAdd1 = U, R("Predictor2", "PredictorAdd2"), R("Predictor3", "PredictorAdd3"), R("Predictor4", "PredictorAdd4"), R("Predictor5", "PredictorAdd5"), R("Predictor6", "PredictorAdd6"), R("Predictor7", "PredictorAdd7"), R("Predictor8", "PredictorAdd8"), R("Predictor9", "PredictorAdd9"), R("Predictor10", "PredictorAdd10"), R("Predictor11", "PredictorAdd11"), R("Predictor12", "PredictorAdd12"), R("Predictor13", "PredictorAdd13");
		var Yn = e.PredictorAdd2;
		re("ColorIndexInverseTransform", "MapARGB", "32b", function(e) {
			return e >> 8 & 255;
		}, function(e) {
			return e;
		}), re("VP8LColorIndexInverseTransformAlpha", "MapAlpha", "8b", function(e) {
			return e;
		}, function(e) {
			return e >> 8 & 255;
		});
		var Xn, Zn = e.ColorIndexInverseTransform, Qn = e.MapARGB, $n = e.VP8LColorIndexInverseTransformAlpha, er = e.MapAlpha, tr = e.VP8LPredictorsAdd = [];
		tr.length = 16, (e.VP8LPredictors = []).length = 16, (e.VP8LPredictorsAdd_C = []).length = 16, (e.VP8LPredictors_C = []).length = 16;
		var nr, rr, ir, ar, or, sr, cr, lr, ur, dr, fr, pr, mr, hr, gr, _r, vr, yr, br, xr, Sr, Cr, wr, Tr, Er, Dr, Or, kr, Ar = a(511), jr = a(2041), Mr = a(225), Nr = a(767), Pr = 0, Fr = jr, Ir = Mr, Lr = Nr, Rr = Ar, zr = 0, Br = 1, Vr = 2, Hr = 3, Ur = 4, Wr = 5, Gr = 6, Kr = 7, qr = 8, Jr = 9, Yr = 10, Xr = [
			2,
			3,
			7
		], Zr = [
			3,
			3,
			11
		], Qr = [
			280,
			256,
			256,
			256,
			40
		], $r = [
			0,
			1,
			1,
			1,
			0
		], ei = [
			17,
			18,
			0,
			1,
			2,
			3,
			4,
			5,
			16,
			6,
			7,
			8,
			9,
			10,
			11,
			12,
			13,
			14,
			15
		], ti = [
			24,
			7,
			23,
			25,
			40,
			6,
			39,
			41,
			22,
			26,
			38,
			42,
			56,
			5,
			55,
			57,
			21,
			27,
			54,
			58,
			37,
			43,
			72,
			4,
			71,
			73,
			20,
			28,
			53,
			59,
			70,
			74,
			36,
			44,
			88,
			69,
			75,
			52,
			60,
			3,
			87,
			89,
			19,
			29,
			86,
			90,
			35,
			45,
			68,
			76,
			85,
			91,
			51,
			61,
			104,
			2,
			103,
			105,
			18,
			30,
			102,
			106,
			34,
			46,
			84,
			92,
			67,
			77,
			101,
			107,
			50,
			62,
			120,
			1,
			119,
			121,
			83,
			93,
			17,
			31,
			100,
			108,
			66,
			78,
			118,
			122,
			33,
			47,
			117,
			123,
			49,
			63,
			99,
			109,
			82,
			94,
			0,
			116,
			124,
			65,
			79,
			16,
			32,
			98,
			110,
			48,
			115,
			125,
			81,
			95,
			64,
			114,
			126,
			97,
			111,
			80,
			113,
			127,
			96,
			112
		], ni = [
			2954,
			2956,
			2958,
			2962,
			2970,
			2986,
			3018,
			3082,
			3212,
			3468,
			3980,
			5004
		], ri = 8, ii = [
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			10,
			11,
			12,
			13,
			14,
			15,
			16,
			17,
			17,
			18,
			19,
			20,
			20,
			21,
			21,
			22,
			22,
			23,
			23,
			24,
			25,
			25,
			26,
			27,
			28,
			29,
			30,
			31,
			32,
			33,
			34,
			35,
			36,
			37,
			37,
			38,
			39,
			40,
			41,
			42,
			43,
			44,
			45,
			46,
			46,
			47,
			48,
			49,
			50,
			51,
			52,
			53,
			54,
			55,
			56,
			57,
			58,
			59,
			60,
			61,
			62,
			63,
			64,
			65,
			66,
			67,
			68,
			69,
			70,
			71,
			72,
			73,
			74,
			75,
			76,
			76,
			77,
			78,
			79,
			80,
			81,
			82,
			83,
			84,
			85,
			86,
			87,
			88,
			89,
			91,
			93,
			95,
			96,
			98,
			100,
			101,
			102,
			104,
			106,
			108,
			110,
			112,
			114,
			116,
			118,
			122,
			124,
			126,
			128,
			130,
			132,
			134,
			136,
			138,
			140,
			143,
			145,
			148,
			151,
			154,
			157
		], ai = [
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12,
			13,
			14,
			15,
			16,
			17,
			18,
			19,
			20,
			21,
			22,
			23,
			24,
			25,
			26,
			27,
			28,
			29,
			30,
			31,
			32,
			33,
			34,
			35,
			36,
			37,
			38,
			39,
			40,
			41,
			42,
			43,
			44,
			45,
			46,
			47,
			48,
			49,
			50,
			51,
			52,
			53,
			54,
			55,
			56,
			57,
			58,
			60,
			62,
			64,
			66,
			68,
			70,
			72,
			74,
			76,
			78,
			80,
			82,
			84,
			86,
			88,
			90,
			92,
			94,
			96,
			98,
			100,
			102,
			104,
			106,
			108,
			110,
			112,
			114,
			116,
			119,
			122,
			125,
			128,
			131,
			134,
			137,
			140,
			143,
			146,
			149,
			152,
			155,
			158,
			161,
			164,
			167,
			170,
			173,
			177,
			181,
			185,
			189,
			193,
			197,
			201,
			205,
			209,
			213,
			217,
			221,
			225,
			229,
			234,
			239,
			245,
			249,
			254,
			259,
			264,
			269,
			274,
			279,
			284
		], oi = null, si = [
			[
				173,
				148,
				140,
				0
			],
			[
				176,
				155,
				140,
				135,
				0
			],
			[
				180,
				157,
				141,
				134,
				130,
				0
			],
			[
				254,
				254,
				243,
				230,
				196,
				177,
				153,
				140,
				133,
				130,
				129,
				0
			]
		], ci = [
			0,
			1,
			4,
			8,
			5,
			2,
			3,
			6,
			9,
			12,
			13,
			10,
			7,
			11,
			14,
			15
		], li = [
			-0,
			1,
			-1,
			2,
			-2,
			3,
			4,
			6,
			-3,
			5,
			-4,
			-5,
			-6,
			7,
			-7,
			8,
			-8,
			-9
		], ui = [
			[
				[
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						253,
						136,
						254,
						255,
						228,
						219,
						128,
						128,
						128,
						128,
						128
					],
					[
						189,
						129,
						242,
						255,
						227,
						213,
						255,
						219,
						128,
						128,
						128
					],
					[
						106,
						126,
						227,
						252,
						214,
						209,
						255,
						255,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						98,
						248,
						255,
						236,
						226,
						255,
						255,
						128,
						128,
						128
					],
					[
						181,
						133,
						238,
						254,
						221,
						234,
						255,
						154,
						128,
						128,
						128
					],
					[
						78,
						134,
						202,
						247,
						198,
						180,
						255,
						219,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						185,
						249,
						255,
						243,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						184,
						150,
						247,
						255,
						236,
						224,
						128,
						128,
						128,
						128,
						128
					],
					[
						77,
						110,
						216,
						255,
						236,
						230,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						101,
						251,
						255,
						241,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						170,
						139,
						241,
						252,
						236,
						209,
						255,
						255,
						128,
						128,
						128
					],
					[
						37,
						116,
						196,
						243,
						228,
						255,
						255,
						255,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						204,
						254,
						255,
						245,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						207,
						160,
						250,
						255,
						238,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						102,
						103,
						231,
						255,
						211,
						171,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						152,
						252,
						255,
						240,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						177,
						135,
						243,
						255,
						234,
						225,
						128,
						128,
						128,
						128,
						128
					],
					[
						80,
						129,
						211,
						255,
						194,
						224,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						246,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				]
			],
			[
				[
					[
						198,
						35,
						237,
						223,
						193,
						187,
						162,
						160,
						145,
						155,
						62
					],
					[
						131,
						45,
						198,
						221,
						172,
						176,
						220,
						157,
						252,
						221,
						1
					],
					[
						68,
						47,
						146,
						208,
						149,
						167,
						221,
						162,
						255,
						223,
						128
					]
				],
				[
					[
						1,
						149,
						241,
						255,
						221,
						224,
						255,
						255,
						128,
						128,
						128
					],
					[
						184,
						141,
						234,
						253,
						222,
						220,
						255,
						199,
						128,
						128,
						128
					],
					[
						81,
						99,
						181,
						242,
						176,
						190,
						249,
						202,
						255,
						255,
						128
					]
				],
				[
					[
						1,
						129,
						232,
						253,
						214,
						197,
						242,
						196,
						255,
						255,
						128
					],
					[
						99,
						121,
						210,
						250,
						201,
						198,
						255,
						202,
						128,
						128,
						128
					],
					[
						23,
						91,
						163,
						242,
						170,
						187,
						247,
						210,
						255,
						255,
						128
					]
				],
				[
					[
						1,
						200,
						246,
						255,
						234,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						109,
						178,
						241,
						255,
						231,
						245,
						255,
						255,
						128,
						128,
						128
					],
					[
						44,
						130,
						201,
						253,
						205,
						192,
						255,
						255,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						132,
						239,
						251,
						219,
						209,
						255,
						165,
						128,
						128,
						128
					],
					[
						94,
						136,
						225,
						251,
						218,
						190,
						255,
						255,
						128,
						128,
						128
					],
					[
						22,
						100,
						174,
						245,
						186,
						161,
						255,
						199,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						182,
						249,
						255,
						232,
						235,
						128,
						128,
						128,
						128,
						128
					],
					[
						124,
						143,
						241,
						255,
						227,
						234,
						128,
						128,
						128,
						128,
						128
					],
					[
						35,
						77,
						181,
						251,
						193,
						211,
						255,
						205,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						157,
						247,
						255,
						236,
						231,
						255,
						255,
						128,
						128,
						128
					],
					[
						121,
						141,
						235,
						255,
						225,
						227,
						255,
						255,
						128,
						128,
						128
					],
					[
						45,
						99,
						188,
						251,
						195,
						217,
						255,
						224,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						1,
						251,
						255,
						213,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						203,
						1,
						248,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						137,
						1,
						177,
						255,
						224,
						255,
						128,
						128,
						128,
						128,
						128
					]
				]
			],
			[
				[
					[
						253,
						9,
						248,
						251,
						207,
						208,
						255,
						192,
						128,
						128,
						128
					],
					[
						175,
						13,
						224,
						243,
						193,
						185,
						249,
						198,
						255,
						255,
						128
					],
					[
						73,
						17,
						171,
						221,
						161,
						179,
						236,
						167,
						255,
						234,
						128
					]
				],
				[
					[
						1,
						95,
						247,
						253,
						212,
						183,
						255,
						255,
						128,
						128,
						128
					],
					[
						239,
						90,
						244,
						250,
						211,
						209,
						255,
						255,
						128,
						128,
						128
					],
					[
						155,
						77,
						195,
						248,
						188,
						195,
						255,
						255,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						24,
						239,
						251,
						218,
						219,
						255,
						205,
						128,
						128,
						128
					],
					[
						201,
						51,
						219,
						255,
						196,
						186,
						128,
						128,
						128,
						128,
						128
					],
					[
						69,
						46,
						190,
						239,
						201,
						218,
						255,
						228,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						191,
						251,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						223,
						165,
						249,
						255,
						213,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						141,
						124,
						248,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						16,
						248,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						190,
						36,
						230,
						255,
						236,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						149,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						226,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						247,
						192,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						240,
						128,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						134,
						252,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						213,
						62,
						250,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						55,
						93,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				]
			],
			[
				[
					[
						202,
						24,
						213,
						235,
						186,
						191,
						220,
						160,
						240,
						175,
						255
					],
					[
						126,
						38,
						182,
						232,
						169,
						184,
						228,
						174,
						255,
						187,
						128
					],
					[
						61,
						46,
						138,
						219,
						151,
						178,
						240,
						170,
						255,
						216,
						128
					]
				],
				[
					[
						1,
						112,
						230,
						250,
						199,
						191,
						247,
						159,
						255,
						255,
						128
					],
					[
						166,
						109,
						228,
						252,
						211,
						215,
						255,
						174,
						128,
						128,
						128
					],
					[
						39,
						77,
						162,
						232,
						172,
						180,
						245,
						178,
						255,
						255,
						128
					]
				],
				[
					[
						1,
						52,
						220,
						246,
						198,
						199,
						249,
						220,
						255,
						255,
						128
					],
					[
						124,
						74,
						191,
						243,
						183,
						193,
						250,
						221,
						255,
						255,
						128
					],
					[
						24,
						71,
						130,
						219,
						154,
						170,
						243,
						182,
						255,
						255,
						128
					]
				],
				[
					[
						1,
						182,
						225,
						249,
						219,
						240,
						255,
						224,
						128,
						128,
						128
					],
					[
						149,
						150,
						226,
						252,
						216,
						205,
						255,
						171,
						128,
						128,
						128
					],
					[
						28,
						108,
						170,
						242,
						183,
						194,
						254,
						223,
						255,
						255,
						128
					]
				],
				[
					[
						1,
						81,
						230,
						252,
						204,
						203,
						255,
						192,
						128,
						128,
						128
					],
					[
						123,
						102,
						209,
						247,
						188,
						196,
						255,
						233,
						128,
						128,
						128
					],
					[
						20,
						95,
						153,
						243,
						164,
						173,
						255,
						203,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						222,
						248,
						255,
						216,
						213,
						128,
						128,
						128,
						128,
						128
					],
					[
						168,
						175,
						246,
						252,
						235,
						205,
						255,
						255,
						128,
						128,
						128
					],
					[
						47,
						116,
						215,
						255,
						211,
						212,
						255,
						255,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						121,
						236,
						253,
						212,
						214,
						255,
						255,
						128,
						128,
						128
					],
					[
						141,
						84,
						213,
						252,
						201,
						202,
						255,
						219,
						128,
						128,
						128
					],
					[
						42,
						80,
						160,
						240,
						162,
						185,
						255,
						205,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						244,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						238,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				]
			]
		], di = [
			[
				[
					231,
					120,
					48,
					89,
					115,
					113,
					120,
					152,
					112
				],
				[
					152,
					179,
					64,
					126,
					170,
					118,
					46,
					70,
					95
				],
				[
					175,
					69,
					143,
					80,
					85,
					82,
					72,
					155,
					103
				],
				[
					56,
					58,
					10,
					171,
					218,
					189,
					17,
					13,
					152
				],
				[
					114,
					26,
					17,
					163,
					44,
					195,
					21,
					10,
					173
				],
				[
					121,
					24,
					80,
					195,
					26,
					62,
					44,
					64,
					85
				],
				[
					144,
					71,
					10,
					38,
					171,
					213,
					144,
					34,
					26
				],
				[
					170,
					46,
					55,
					19,
					136,
					160,
					33,
					206,
					71
				],
				[
					63,
					20,
					8,
					114,
					114,
					208,
					12,
					9,
					226
				],
				[
					81,
					40,
					11,
					96,
					182,
					84,
					29,
					16,
					36
				]
			],
			[
				[
					134,
					183,
					89,
					137,
					98,
					101,
					106,
					165,
					148
				],
				[
					72,
					187,
					100,
					130,
					157,
					111,
					32,
					75,
					80
				],
				[
					66,
					102,
					167,
					99,
					74,
					62,
					40,
					234,
					128
				],
				[
					41,
					53,
					9,
					178,
					241,
					141,
					26,
					8,
					107
				],
				[
					74,
					43,
					26,
					146,
					73,
					166,
					49,
					23,
					157
				],
				[
					65,
					38,
					105,
					160,
					51,
					52,
					31,
					115,
					128
				],
				[
					104,
					79,
					12,
					27,
					217,
					255,
					87,
					17,
					7
				],
				[
					87,
					68,
					71,
					44,
					114,
					51,
					15,
					186,
					23
				],
				[
					47,
					41,
					14,
					110,
					182,
					183,
					21,
					17,
					194
				],
				[
					66,
					45,
					25,
					102,
					197,
					189,
					23,
					18,
					22
				]
			],
			[
				[
					88,
					88,
					147,
					150,
					42,
					46,
					45,
					196,
					205
				],
				[
					43,
					97,
					183,
					117,
					85,
					38,
					35,
					179,
					61
				],
				[
					39,
					53,
					200,
					87,
					26,
					21,
					43,
					232,
					171
				],
				[
					56,
					34,
					51,
					104,
					114,
					102,
					29,
					93,
					77
				],
				[
					39,
					28,
					85,
					171,
					58,
					165,
					90,
					98,
					64
				],
				[
					34,
					22,
					116,
					206,
					23,
					34,
					43,
					166,
					73
				],
				[
					107,
					54,
					32,
					26,
					51,
					1,
					81,
					43,
					31
				],
				[
					68,
					25,
					106,
					22,
					64,
					171,
					36,
					225,
					114
				],
				[
					34,
					19,
					21,
					102,
					132,
					188,
					16,
					76,
					124
				],
				[
					62,
					18,
					78,
					95,
					85,
					57,
					50,
					48,
					51
				]
			],
			[
				[
					193,
					101,
					35,
					159,
					215,
					111,
					89,
					46,
					111
				],
				[
					60,
					148,
					31,
					172,
					219,
					228,
					21,
					18,
					111
				],
				[
					112,
					113,
					77,
					85,
					179,
					255,
					38,
					120,
					114
				],
				[
					40,
					42,
					1,
					196,
					245,
					209,
					10,
					25,
					109
				],
				[
					88,
					43,
					29,
					140,
					166,
					213,
					37,
					43,
					154
				],
				[
					61,
					63,
					30,
					155,
					67,
					45,
					68,
					1,
					209
				],
				[
					100,
					80,
					8,
					43,
					154,
					1,
					51,
					26,
					71
				],
				[
					142,
					78,
					78,
					16,
					255,
					128,
					34,
					197,
					171
				],
				[
					41,
					40,
					5,
					102,
					211,
					183,
					4,
					1,
					221
				],
				[
					51,
					50,
					17,
					168,
					209,
					192,
					23,
					25,
					82
				]
			],
			[
				[
					138,
					31,
					36,
					171,
					27,
					166,
					38,
					44,
					229
				],
				[
					67,
					87,
					58,
					169,
					82,
					115,
					26,
					59,
					179
				],
				[
					63,
					59,
					90,
					180,
					59,
					166,
					93,
					73,
					154
				],
				[
					40,
					40,
					21,
					116,
					143,
					209,
					34,
					39,
					175
				],
				[
					47,
					15,
					16,
					183,
					34,
					223,
					49,
					45,
					183
				],
				[
					46,
					17,
					33,
					183,
					6,
					98,
					15,
					32,
					183
				],
				[
					57,
					46,
					22,
					24,
					128,
					1,
					54,
					17,
					37
				],
				[
					65,
					32,
					73,
					115,
					28,
					128,
					23,
					128,
					205
				],
				[
					40,
					3,
					9,
					115,
					51,
					192,
					18,
					6,
					223
				],
				[
					87,
					37,
					9,
					115,
					59,
					77,
					64,
					21,
					47
				]
			],
			[
				[
					104,
					55,
					44,
					218,
					9,
					54,
					53,
					130,
					226
				],
				[
					64,
					90,
					70,
					205,
					40,
					41,
					23,
					26,
					57
				],
				[
					54,
					57,
					112,
					184,
					5,
					41,
					38,
					166,
					213
				],
				[
					30,
					34,
					26,
					133,
					152,
					116,
					10,
					32,
					134
				],
				[
					39,
					19,
					53,
					221,
					26,
					114,
					32,
					73,
					255
				],
				[
					31,
					9,
					65,
					234,
					2,
					15,
					1,
					118,
					73
				],
				[
					75,
					32,
					12,
					51,
					192,
					255,
					160,
					43,
					51
				],
				[
					88,
					31,
					35,
					67,
					102,
					85,
					55,
					186,
					85
				],
				[
					56,
					21,
					23,
					111,
					59,
					205,
					45,
					37,
					192
				],
				[
					55,
					38,
					70,
					124,
					73,
					102,
					1,
					34,
					98
				]
			],
			[
				[
					125,
					98,
					42,
					88,
					104,
					85,
					117,
					175,
					82
				],
				[
					95,
					84,
					53,
					89,
					128,
					100,
					113,
					101,
					45
				],
				[
					75,
					79,
					123,
					47,
					51,
					128,
					81,
					171,
					1
				],
				[
					57,
					17,
					5,
					71,
					102,
					57,
					53,
					41,
					49
				],
				[
					38,
					33,
					13,
					121,
					57,
					73,
					26,
					1,
					85
				],
				[
					41,
					10,
					67,
					138,
					77,
					110,
					90,
					47,
					114
				],
				[
					115,
					21,
					2,
					10,
					102,
					255,
					166,
					23,
					6
				],
				[
					101,
					29,
					16,
					10,
					85,
					128,
					101,
					196,
					26
				],
				[
					57,
					18,
					10,
					102,
					102,
					213,
					34,
					20,
					43
				],
				[
					117,
					20,
					15,
					36,
					163,
					128,
					68,
					1,
					26
				]
			],
			[
				[
					102,
					61,
					71,
					37,
					34,
					53,
					31,
					243,
					192
				],
				[
					69,
					60,
					71,
					38,
					73,
					119,
					28,
					222,
					37
				],
				[
					68,
					45,
					128,
					34,
					1,
					47,
					11,
					245,
					171
				],
				[
					62,
					17,
					19,
					70,
					146,
					85,
					55,
					62,
					70
				],
				[
					37,
					43,
					37,
					154,
					100,
					163,
					85,
					160,
					1
				],
				[
					63,
					9,
					92,
					136,
					28,
					64,
					32,
					201,
					85
				],
				[
					75,
					15,
					9,
					9,
					64,
					255,
					184,
					119,
					16
				],
				[
					86,
					6,
					28,
					5,
					64,
					255,
					25,
					248,
					1
				],
				[
					56,
					8,
					17,
					132,
					137,
					255,
					55,
					116,
					128
				],
				[
					58,
					15,
					20,
					82,
					135,
					57,
					26,
					121,
					40
				]
			],
			[
				[
					164,
					50,
					31,
					137,
					154,
					133,
					25,
					35,
					218
				],
				[
					51,
					103,
					44,
					131,
					131,
					123,
					31,
					6,
					158
				],
				[
					86,
					40,
					64,
					135,
					148,
					224,
					45,
					183,
					128
				],
				[
					22,
					26,
					17,
					131,
					240,
					154,
					14,
					1,
					209
				],
				[
					45,
					16,
					21,
					91,
					64,
					222,
					7,
					1,
					197
				],
				[
					56,
					21,
					39,
					155,
					60,
					138,
					23,
					102,
					213
				],
				[
					83,
					12,
					13,
					54,
					192,
					255,
					68,
					47,
					28
				],
				[
					85,
					26,
					85,
					85,
					128,
					128,
					32,
					146,
					171
				],
				[
					18,
					11,
					7,
					63,
					144,
					171,
					4,
					4,
					246
				],
				[
					35,
					27,
					10,
					146,
					174,
					171,
					12,
					26,
					128
				]
			],
			[
				[
					190,
					80,
					35,
					99,
					180,
					80,
					126,
					54,
					45
				],
				[
					85,
					126,
					47,
					87,
					176,
					51,
					41,
					20,
					32
				],
				[
					101,
					75,
					128,
					139,
					118,
					146,
					116,
					128,
					85
				],
				[
					56,
					41,
					15,
					176,
					236,
					85,
					37,
					9,
					62
				],
				[
					71,
					30,
					17,
					119,
					118,
					255,
					17,
					18,
					138
				],
				[
					101,
					38,
					60,
					138,
					55,
					70,
					43,
					26,
					142
				],
				[
					146,
					36,
					19,
					30,
					171,
					255,
					97,
					27,
					20
				],
				[
					138,
					45,
					61,
					62,
					219,
					1,
					81,
					188,
					64
				],
				[
					32,
					41,
					20,
					117,
					151,
					142,
					20,
					21,
					163
				],
				[
					112,
					19,
					12,
					61,
					195,
					128,
					48,
					4,
					24
				]
			]
		], fi = [
			[
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						176,
						246,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						223,
						241,
						252,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						249,
						253,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						244,
						252,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						234,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						246,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						239,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						248,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						251,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						251,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						253,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						250,
						255,
						254,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				]
			],
			[
				[
					[
						217,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						225,
						252,
						241,
						253,
						255,
						255,
						254,
						255,
						255,
						255,
						255
					],
					[
						234,
						250,
						241,
						250,
						253,
						255,
						253,
						254,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						223,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						238,
						253,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						248,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						249,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						247,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						252,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						250,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				]
			],
			[
				[
					[
						186,
						251,
						250,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						234,
						251,
						244,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						251,
						251,
						243,
						253,
						254,
						255,
						254,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						236,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						251,
						253,
						253,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				]
			],
			[
				[
					[
						248,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						250,
						254,
						252,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						248,
						254,
						249,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						253,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						246,
						253,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						252,
						254,
						251,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						252,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						248,
						254,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						253,
						255,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						251,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						245,
						251,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						253,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						251,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						252,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						252,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						249,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						250,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				]
			]
		], pi = [
			0,
			1,
			2,
			3,
			6,
			4,
			5,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			7,
			0
		], mi = [], hi = [], gi = [], _i = 1, vi = 2, yi = [], bi = [];
		xn("UpsampleRgbLinePair", Dn, 3), xn("UpsampleBgrLinePair", On, 3), xn("UpsampleRgbaLinePair", Nn, 4), xn("UpsampleBgraLinePair", Mn, 4), xn("UpsampleArgbLinePair", jn, 4), xn("UpsampleRgba4444LinePair", An, 2), xn("UpsampleRgb565LinePair", kn, 2);
		var xi = e.UpsampleRgbLinePair, Si = e.UpsampleBgrLinePair, Ci = e.UpsampleRgbaLinePair, wi = e.UpsampleBgraLinePair, Ti = e.UpsampleArgbLinePair, Ei = e.UpsampleRgba4444LinePair, Di = e.UpsampleRgb565LinePair, Oi = 16, ki = 1 << Oi - 1, Ai = -227, ji = 482, Mi = 6, Ni = (256 << Mi) - 1, Pi = 0, Fi = a(256), Ii = a(256), Li = a(256), Ri = a(256), zi = a(ji - Ai), Bi = a(ji - Ai);
		Pn("YuvToRgbRow", Dn, 3), Pn("YuvToBgrRow", On, 3), Pn("YuvToRgbaRow", Nn, 4), Pn("YuvToBgraRow", Mn, 4), Pn("YuvToArgbRow", jn, 4), Pn("YuvToRgba4444Row", An, 2), Pn("YuvToRgb565Row", kn, 2);
		var Vi = [
			0,
			4,
			8,
			12,
			128,
			132,
			136,
			140,
			256,
			260,
			264,
			268,
			384,
			388,
			392,
			396
		], Hi = [
			0,
			2,
			8
		], Ui = [
			8,
			7,
			6,
			4,
			4,
			2,
			2,
			2,
			1,
			1,
			1,
			1
		], Wi = 1;
		this.WebPDecodeRGBA = function(e, n, s, c, l) {
			var u = Br, d = new on(), f = new pe();
			d.ba = f, f.S = u, f.width = [f.width], f.height = [f.height];
			var p = f.width, m = f.height, h = new me();
			if (h == null || e == null) var g = 2;
			else t(h != null), g = Rn(e, n, s, h.width, h.height, h.Pd, h.Qd, h.format, null);
			if (g == 0 ? (p != null && (p[0] = h.width[0]), m != null && (m[0] = h.height[0]), p = 1) : p = 0, p) {
				f.width = f.width[0], f.height = f.height[0], c != null && (c[0] = f.width), l != null && (l[0] = f.height);
				t: {
					if (c = new Ze(), (l = new sn()).data = e, l.w = n, l.ha = s, l.kd = 1, n = [0], t(l != null), ((e = Rn(l.data, l.w, l.ha, null, null, null, n, null, l)) == 0 || e == 7) && n[0] && (e = 4), (n = e) == 0) {
						if (t(d != null), c.data = l.data, c.w = l.w + l.offset, c.ha = l.ha - l.offset, c.put = be, c.ac = ye, c.bc = xe, c.ma = d, l.xa) {
							if ((e = Pe()) == null) {
								d = 1;
								break t;
							}
							if (function(e, n) {
								var r = [0], i = [0], a = [0];
								e: for (;;) {
									if (e == null) return 0;
									if (n == null) return e.a = 2, 0;
									if (e.l = n, e.a = 0, _(e.m, n.data, n.w, n.ha), !Se(e.m, r, i, a)) {
										e.a = 3;
										break e;
									}
									if (e.xb = vi, n.width = r[0], n.height = i[0], !Fe(r[0], i[0], 1, e, null)) break e;
									return 1;
								}
								return t(e.a != 0), 0;
							}(e, c)) {
								if (c = (n = Vn(c.width, c.height, d.Oa, d.ba)) == 0) {
									e: {
										c = e;
										r: for (;;) {
											if (c == null) {
												c = 0;
												break e;
											}
											if (t(c.s.yc != null), t(c.s.Ya != null), t(0 < c.s.Wb), t((s = c.l) != null), t((l = s.ma) != null), c.xb != 0) {
												if (c.ca = l.ba, c.tb = l.tb, t(c.ca != null), !zn(l.Oa, s, Hr)) {
													c.a = 2;
													break r;
												}
												if (!Ie(c, s.width) || s.da) break r;
												if ((s.da || ue(c.ca.S)) && bn(), 11 > c.ca.S || (alert("todo:WebPInitConvertARGBToYUV"), c.ca.f.kb.F != null && bn()), c.Pb && 0 < c.s.ua && c.s.vb.X == null && !N(c.s.vb, c.s.Wa.Xa)) {
													c.a = 1;
													break r;
												}
												c.xb = 0;
											}
											if (!q(c, c.V, c.Ba, c.c, c.i, s.o, ke)) break r;
											l.Dc = c.Ma, c = 1;
											break e;
										}
										t(c.a != 0), c = 0;
									}
									c = !c;
								}
								c && (n = e.a);
							} else n = e.a;
						} else {
							if ((e = new Qe()) == null) {
								d = 1;
								break t;
							}
							if (e.Fa = l.na, e.P = l.P, e.qc = l.Sa, tt(e, c)) {
								if ((n = Vn(c.width, c.height, d.Oa, d.ba)) == 0) {
									if (e.Aa = 0, s = d.Oa, t((l = e) != null), s != null) {
										if (0 < (p = 0 > (p = s.Md) ? 0 : 100 < p ? 255 : 255 * p / 100)) {
											for (m = h = 0; 4 > m; ++m) 12 > (g = l.pb[m]).lc && (g.ia = p * Ui[0 > g.lc ? 0 : g.lc] >> 3), h |= g.ia;
											h && (alert("todo:VP8InitRandom"), l.ia = 1);
										}
										l.Ga = s.Id, 100 < l.Ga ? l.Ga = 100 : 0 > l.Ga && (l.Ga = 0);
									}
									(function(e, n) {
										if (e == null) return 0;
										if (n == null) return $e(e, 2, "NULL VP8Io parameter in VP8Decode().");
										if (!e.cb && !tt(e, n)) return 0;
										if (t(e.cb), n.ac == null || n.ac(n)) {
											n.ob && (e.L = 0);
											var s = Hi[e.L];
											if (e.L == 2 ? (e.yb = 0, e.zb = 0) : (e.yb = n.v - s >> 4, e.zb = n.j - s >> 4, 0 > e.yb && (e.yb = 0), 0 > e.zb && (e.zb = 0)), e.Va = n.o + 15 + s >> 4, e.Hb = n.va + 15 + s >> 4, e.Hb > e.za && (e.Hb = e.za), e.Va > e.Ub && (e.Va = e.Ub), 0 < e.L) {
												var c = e.ed;
												for (s = 0; 4 > s; ++s) {
													var l;
													if (e.Qa.Cb) {
														var u = e.Qa.Lb[s];
														e.Qa.Fb || (u += c.Tb);
													} else u = c.Tb;
													for (l = 0; 1 >= l; ++l) {
														var d = e.gd[s][l], f = u;
														if (c.Pc && (f += c.vd[0], l && (f += c.od[0])), 0 < (f = 0 > f ? 0 : 63 < f ? 63 : f)) {
															var p = f;
															0 < c.wb && (p = 4 < c.wb ? p >> 2 : p >> 1) > 9 - c.wb && (p = 9 - c.wb), 1 > p && (p = 1), d.dd = p, d.tc = 2 * f + p, d.ld = 40 <= f ? 2 : +(15 <= f);
														} else d.tc = 0;
														d.La = l;
													}
												}
											}
											s = 0;
										} else $e(e, 6, "Frame setup failed"), s = e.a;
										if (s = s == 0) {
											if (s) {
												e.$c = 0, 0 < e.Aa || (e.Ic = Wi);
												e: {
													s = e.Ic, c = 4 * (p = e.za);
													var m = 32 * p, h = p + 1, g = 0 < e.L ? p * (0 < e.Aa ? 2 : 1) : 0, _ = (e.Aa == 2 ? 2 : 1) * p;
													if ((d = c + 832 + (l = 3 * (16 * s + Hi[e.L]) / 2 * m) + (u = e.Fa != null && 0 < e.Fa.length ? e.Kc.c * e.Kc.i : 0)) != d) s = 0;
													else {
														if (d > e.Vb) {
															if (e.Vb = 0, e.Ec = a(d), e.Fc = 0, e.Ec == null) {
																s = $e(e, 1, "no memory during frame initialization.");
																break e;
															}
															e.Vb = d;
														}
														d = e.Ec, f = e.Fc, e.Ac = d, e.Bc = f, f += c, e.Gd = o(m, Je), e.Hd = 0, e.rb = o(h + 1, We), e.sb = 1, e.wa = g ? o(g, Ue) : null, e.Y = 0, e.D.Nb = 0, e.D.wa = e.wa, e.D.Y = e.Y, 0 < e.Aa && (e.D.Y += p), t(!0), e.oc = d, e.pc = f, f += 832, e.ya = o(_, Ke), e.aa = 0, e.D.ya = e.ya, e.D.aa = e.aa, e.Aa == 2 && (e.D.aa += p), e.R = 16 * p, e.B = 8 * p, p = (m = Hi[e.L]) * e.R, m = m / 2 * e.B, e.sa = d, e.ta = f + p, e.qa = e.sa, e.ra = e.ta + 16 * s * e.R + m, e.Ha = e.qa, e.Ia = e.ra + 8 * s * e.B + m, e.$c = 0, f += l, e.mb = u ? d : null, e.nb = u ? f : null, t(f + u <= e.Fc + e.Vb), rt(e), i(e.Ac, e.Bc, 0, c), s = 1;
													}
												}
												if (s) {
													if (n.ka = 0, n.y = e.sa, n.O = e.ta, n.f = e.qa, n.N = e.ra, n.ea = e.Ha, n.Vd = e.Ia, n.fa = e.R, n.Rc = e.B, n.F = null, n.J = 0, !Pr) {
														for (s = -255; 255 >= s; ++s) Ar[255 + s] = 0 > s ? -s : s;
														for (s = -1020; 1020 >= s; ++s) jr[1020 + s] = -128 > s ? -128 : 127 < s ? 127 : s;
														for (s = -112; 112 >= s; ++s) Mr[112 + s] = -16 > s ? -16 : 15 < s ? 15 : s;
														for (s = -255; 510 >= s; ++s) Nr[255 + s] = 0 > s ? 0 : 255 < s ? 255 : s;
														Pr = 1;
													}
													cr = pt, lr = lt, dr = ut, fr = dt, pr = ft, ur = ct, mr = Zt, hr = Qt, gr = tn, _r = nn, vr = $t, yr = en, br = rn, xr = an, Sr = Gt, Cr = Kt, wr = qt, Tr = Jt, hi[0] = Dt, hi[1] = ht, hi[2] = Tt, hi[3] = Et, hi[4] = Ot, hi[5] = At, hi[6] = kt, hi[7] = jt, hi[8] = Nt, hi[9] = Mt, mi[0] = xt, mi[1] = _t, mi[2] = vt, mi[3] = yt, mi[4] = St, mi[5] = Ct, mi[6] = wt, gi[0] = Lt, gi[1] = gt, gi[2] = Pt, gi[3] = Ft, gi[4] = zt, gi[5] = Rt, gi[6] = Bt, s = 1;
												} else s = 0;
											}
											s &&= function(e, n) {
												for (e.M = 0; e.M < e.Va; ++e.M) {
													var o, s = e.Jc[e.M & e.Xb], c = e.m, l = e;
													for (o = 0; o < l.za; ++o) {
														var u = c, d = l, f = d.Ac, p = d.Bc + 4 * o, m = d.zc, h = d.ya[d.aa + o];
														if (d.Qa.Bb ? h.$b = O(u, d.Pa.jb[0]) ? 2 + O(u, d.Pa.jb[2]) : O(u, d.Pa.jb[1]) : h.$b = 0, d.kc && (h.Ad = O(u, d.Bd)), h.Za = !O(u, 145) + 0, h.Za) {
															var g = h.Ob, _ = 0;
															for (d = 0; 4 > d; ++d) {
																var v, y = m[0 + d];
																for (v = 0; 4 > v; ++v) {
																	y = di[f[p + v]][y];
																	for (var b = li[O(u, y[0])]; 0 < b;) b = li[2 * b + O(u, y[b])];
																	y = -b, f[p + v] = y;
																}
																r(g, _, f, p, 4), _ += 4, m[0 + d] = y;
															}
														} else y = O(u, 156) ? O(u, 128) ? 1 : 3 : O(u, 163) ? 2 : 0, h.Ob[0] = y, i(f, p, y, 4), i(m, 0, y, 4);
														h.Dd = O(u, 142) ? O(u, 114) ? O(u, 183) ? 1 : 3 : 2 : 0;
													}
													if (l.m.Ka) return $e(e, 7, "Premature end-of-partition0 encountered.");
													for (; e.ja < e.za; ++e.ja) {
														if (l = s, u = (c = e).rb[c.sb - 1], f = c.rb[c.sb + c.ja], o = c.ya[c.aa + c.ja], p = c.kc ? o.Ad : 0) u.la = f.la = 0, o.Za || (u.Na = f.Na = 0), o.Hc = 0, o.Gc = 0, o.ia = 0;
														else {
															var x, S;
															if (u = f, f = l, p = c.Pa.Xc, m = c.ya[c.aa + c.ja], h = c.pb[m.$b], d = m.ad, g = 0, _ = c.rb[c.sb - 1], y = v = 0, i(d, g, 0, 384), m.Za) var C = 0, w = p[3];
															else {
																b = a(16);
																var T = u.Na + _.Na;
																if (T = oi(f, p[1], T, h.Eb, 0, b, 0), u.Na = _.Na = (0 < T) + 0, 1 < T) cr(b, 0, d, g);
																else {
																	var E = b[0] + 3 >> 3;
																	for (b = 0; 256 > b; b += 16) d[g + b] = E;
																}
																C = 1, w = p[0];
															}
															var D = 15 & u.la, k = 15 & _.la;
															for (b = 0; 4 > b; ++b) {
																var A = 1 & k;
																for (E = S = 0; 4 > E; ++E) D = D >> 1 | (A = (T = oi(f, w, T = A + (1 & D), h.Sc, C, d, g)) > C) << 7, S = S << 2 | (3 < T ? 3 : 1 < T ? 2 : d[g + 0] != 0), g += 16;
																D >>= 4, k = k >> 1 | A << 7, v = (v << 8 | S) >>> 0;
															}
															for (w = D, C = k >> 4, x = 0; 4 > x; x += 2) {
																for (S = 0, D = u.la >> 4 + x, k = _.la >> 4 + x, b = 0; 2 > b; ++b) {
																	for (A = 1 & k, E = 0; 2 > E; ++E) T = A + (1 & D), D = D >> 1 | (A = 0 < (T = oi(f, p[2], T, h.Qc, 0, d, g))) << 3, S = S << 2 | (3 < T ? 3 : 1 < T ? 2 : d[g + 0] != 0), g += 16;
																	D >>= 2, k = k >> 1 | A << 5;
																}
																y |= S << 4 * x, w |= D << 4 << x, C |= (240 & k) << x;
															}
															u.la = w, _.la = C, m.Hc = v, m.Gc = y, m.ia = 43690 & y ? 0 : h.ia, p = !(v | y);
														}
														if (0 < c.L && (c.wa[c.Y + c.ja] = c.gd[o.$b][o.Za], c.wa[c.Y + c.ja].La |= !p), l.Ka) return $e(e, 7, "Premature end-of-file encountered.");
													}
													if (rt(e), c = n, l = 1, o = (s = e).D, u = 0 < s.L && s.M >= s.zb && s.M <= s.Va, s.Aa == 0) e: {
														if (o.M = s.M, o.uc = u, Ln(s, o), l = 1, o = (S = s.D).Nb, u = (y = Hi[s.L]) * s.R, f = y / 2 * s.B, b = 16 * o * s.R, E = 8 * o * s.B, p = s.sa, m = s.ta - u + b, h = s.qa, d = s.ra - f + E, g = s.Ha, _ = s.Ia - f + E, k = (D = S.M) == 0, v = D >= s.Va - 1, s.Aa == 2 && Ln(s, S), S.uc) for (A = (T = s).D.M, t(T.D.uc), S = T.yb; S < T.Hb; ++S) {
															C = S, w = A;
															var j = (M = (B = T).D).Nb;
															x = B.R;
															var M = M.wa[M.Y + C], N = B.sa, P = B.ta + 16 * j * x + 16 * C, F = M.dd, I = M.tc;
															if (I != 0) {
																if (t(3 <= I), B.L == 1) 0 < C && Cr(N, P, x, I + 4), M.La && Tr(N, P, x, I), 0 < w && Sr(N, P, x, I + 4), M.La && wr(N, P, x, I);
																else {
																	var L = B.B, ee = B.qa, R = B.ra + 8 * j * L + 8 * C, z = B.Ha, B = B.Ia + 8 * j * L + 8 * C;
																	j = M.ld, 0 < C && (hr(N, P, x, I + 4, F, j), _r(ee, R, z, B, L, I + 4, F, j)), M.La && (yr(N, P, x, I, F, j), xr(ee, R, z, B, L, I, F, j)), 0 < w && (mr(N, P, x, I + 4, F, j), gr(ee, R, z, B, L, I + 4, F, j)), M.La && (vr(N, P, x, I, F, j), br(ee, R, z, B, L, I, F, j));
																}
															}
														}
														if (s.ia && alert("todo:DitherRow"), c.put != null) {
															if (S = 16 * D, D = 16 * (D + 1), k ? (c.y = s.sa, c.O = s.ta + b, c.f = s.qa, c.N = s.ra + E, c.ea = s.Ha, c.W = s.Ia + E) : (S -= y, c.y = p, c.O = m, c.f = h, c.N = d, c.ea = g, c.W = _), v || (D -= y), D > c.o && (D = c.o), c.F = null, c.J = null, s.Fa != null && 0 < s.Fa.length && S < D && (c.J = hn(s, c, S, D - S), c.F = s.mb, c.F == null && c.F.length == 0)) {
																l = $e(s, 3, "Could not decode alpha data.");
																break e;
															}
															S < c.j && (y = c.j - S, S = c.j, t(!(1 & y)), c.O += s.R * y, c.N += s.B * (y >> 1), c.W += s.B * (y >> 1), c.F != null && (c.J += c.width * y)), S < D && (c.O += c.v, c.N += c.v >> 1, c.W += c.v >> 1, c.F != null && (c.J += c.v), c.ka = S - c.j, c.U = c.va - c.v, c.T = D - S, l = c.put(c));
														}
														o + 1 != s.Ic || v || (r(s.sa, s.ta - u, p, m + 16 * s.R, u), r(s.qa, s.ra - f, h, d + 8 * s.B, f), r(s.Ha, s.Ia - f, g, _ + 8 * s.B, f));
													}
													if (!l) return $e(e, 6, "Output aborted.");
												}
												return 1;
											}(e, n), n.bc != null && n.bc(n), s &= 1;
										}
										return s ? (e.cb = 0, s) : 0;
									})(e, c) || (n = e.a);
								}
							} else n = e.a;
						}
						n == 0 && d.Oa != null && d.Oa.fd && (n = Bn(d.ba));
					}
					d = n;
				}
				u = d == 0 ? 11 > u ? f.f.RGBA.eb : f.f.kb.y : null;
			} else u = null;
			return u;
		};
		var Gi = [
			3,
			4,
			3,
			4,
			4,
			2,
			2,
			4,
			4,
			4,
			2,
			1,
			1
		];
	};
	function l(e, t) {
		for (var n = "", r = 0; r < 4; r++) n += String.fromCharCode(e[t++]);
		return n;
	}
	function u(e, t) {
		return e[t + 0] | e[t + 1] << 8;
	}
	function d(e, t) {
		return (e[t + 0] | e[t + 1] << 8 | e[t + 2] << 16) >>> 0;
	}
	function f(e, t) {
		return (e[t + 0] | e[t + 1] << 8 | e[t + 2] << 16 | e[t + 3] << 24) >>> 0;
	}
	new c();
	var p = [0], m = [0], h = [], g = new c(), _ = e, v = function(e, t) {
		var n = {}, r = 0, i = !1, a = 0, o = 0;
		if (n.frames = [], !function(e, t) {
			for (var n = 0; n < 4; n++) if (e[t + n] != "RIFF".charCodeAt(n)) return !0;
			return !1;
		}(e, t)) {
			for (f(e, t += 4), t += 8; t < e.length;) {
				var s = l(e, t), c = f(e, t += 4);
				t += 4;
				var p = c + (1 & c);
				switch (s) {
					case "VP8 ":
					case "VP8L":
						n.frames[r] === void 0 && (n.frames[r] = {}), (g = n.frames[r]).src_off = i ? o : t - 8, g.src_size = a + c + 8, r++, i && (i = !1, a = 0, o = 0);
						break;
					case "VP8X":
						(g = n.header = {}).feature_flags = e[t];
						var m = t + 4;
						g.canvas_width = 1 + d(e, m), m += 3, g.canvas_height = 1 + d(e, m), m += 3;
						break;
					case "ALPH":
						i = !0, a = p + 8, o = t - 8;
						break;
					case "ANIM":
						(g = n.header).bgcolor = f(e, t), m = t + 4, g.loop_count = u(e, m), m += 2;
						break;
					case "ANMF":
						var h, g;
						(g = n.frames[r] = {}).offset_x = 2 * d(e, t), t += 3, g.offset_y = 2 * d(e, t), t += 3, g.width = 1 + d(e, t), t += 3, g.height = 1 + d(e, t), t += 3, g.duration = d(e, t), t += 3, h = e[t++], g.dispose = 1 & h, g.blend = h >> 1 & 1;
				}
				s != "ANMF" && (t += p);
			}
			return n;
		}
	}(_, 0);
	v.response = _, v.rgbaoutput = !0, v.dataurl = !1;
	var y = v.header ? v.header : null, b = v.frames ? v.frames : null;
	if (y) {
		y.loop_counter = y.loop_count, p = [y.canvas_height], m = [y.canvas_width];
		for (var x = 0; x < b.length && b[x].blend != 0; x++);
	}
	var S = b[0], C = g.WebPDecodeRGBA(_, S.src_off, S.src_size, m, p);
	S.rgba = C, S.imgwidth = m[0], S.imgheight = p[0];
	for (var w = 0; w < m[0] * p[0] * 4; w++) h[w] = C[w];
	return this.width = m, this.height = p, this.data = h, this;
}
function _c() {
	var e, t = this.internal.__metadata__.metadata, n = unescape(encodeURIComponent(t));
	e = this.internal.__metadata__.rawXml ? n : "<x:xmpmeta xmlns:x=\"adobe:ns:meta/\"><rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"><rdf:Description rdf:about=\"\" xmlns:jspdf=\"" + this.internal.__metadata__.namespaceUri + "\"><jspdf:metadata>" + n.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;") + "</jspdf:metadata></rdf:Description></rdf:RDF></x:xmpmeta>", this.internal.__metadata__.metadataObjectNumber = this.internal.newObject(), this.internal.write("<< /Type /Metadata /Subtype /XML /Length " + e.length + " >>"), this.internal.write("stream"), this.internal.write(e), this.internal.write("endstream"), this.internal.write("endobj");
}
function vc() {
	this.internal.__metadata__.metadataObjectNumber && this.internal.write("/Metadata " + this.internal.__metadata__.metadataObjectNumber + " 0 R");
}
(function(e) {
	var n, r, i, a, o, s, c, l, u, d = function(e) {
		return e ||= {}, this.isStrokeTransparent = e.isStrokeTransparent || !1, this.strokeOpacity = e.strokeOpacity || 1, this.strokeStyle = e.strokeStyle || "#000000", this.fillStyle = e.fillStyle || "#000000", this.isFillTransparent = e.isFillTransparent || !1, this.fillOpacity = e.fillOpacity || 1, this.font = e.font || "10px sans-serif", this.textBaseline = e.textBaseline || "alphabetic", this.textAlign = e.textAlign || "left", this.lineWidth = e.lineWidth || 1, this.lineJoin = e.lineJoin || "miter", this.lineCap = e.lineCap || "butt", this.path = e.path || [], this.transform = e.transform === void 0 ? new l() : e.transform.clone(), this.globalCompositeOperation = e.globalCompositeOperation || "normal", this.globalAlpha = e.globalAlpha || 1, this.clip_path = e.clip_path || [], this.currentPoint = e.currentPoint || new s(), this.miterLimit = e.miterLimit || 10, this.lastPoint = e.lastPoint || new s(), this.lineDashOffset = e.lineDashOffset || 0, this.lineDash = e.lineDash || [], this.margin = e.margin || [
			0,
			0,
			0,
			0
		], this.prevPageLastElemOffset = e.prevPageLastElemOffset || 0, this.ignoreClearRect = typeof e.ignoreClearRect != "boolean" || e.ignoreClearRect, this;
	};
	e.events.push(["initialized", function() {
		this.context2d = new f(this), n = this.internal.f2, r = this.internal.getCoordinateString, i = this.internal.getVerticalCoordinateString, a = this.internal.getHorizontalCoordinate, o = this.internal.getVerticalCoordinate, s = this.internal.Point, c = this.internal.Rectangle, l = this.internal.Matrix, u = new d();
	}]);
	var f = function(e) {
		Object.defineProperty(this, "canvas", { get: function() {
			return {
				parentNode: !1,
				style: !1
			};
		} });
		var t = e;
		Object.defineProperty(this, "pdf", { get: function() {
			return t;
		} });
		var n = !1;
		Object.defineProperty(this, "pageWrapXEnabled", {
			get: function() {
				return n;
			},
			set: function(e) {
				n = !!e;
			}
		});
		var r = !1;
		Object.defineProperty(this, "pageWrapYEnabled", {
			get: function() {
				return r;
			},
			set: function(e) {
				r = !!e;
			}
		});
		var i = 0;
		Object.defineProperty(this, "posX", {
			get: function() {
				return i;
			},
			set: function(e) {
				isNaN(e) || (i = e);
			}
		});
		var a = 0;
		Object.defineProperty(this, "posY", {
			get: function() {
				return a;
			},
			set: function(e) {
				isNaN(e) || (a = e);
			}
		}), Object.defineProperty(this, "margin", {
			get: function() {
				return u.margin;
			},
			set: function(e) {
				var t;
				typeof e == "number" ? t = [
					e,
					e,
					e,
					e
				] : ((t = [
					,
					,
					,
					,
				])[0] = e[0], t[1] = e.length >= 2 ? e[1] : t[0], t[2] = e.length >= 3 ? e[2] : t[0], t[3] = e.length >= 4 ? e[3] : t[1]), u.margin = t;
			}
		});
		var o = !1;
		Object.defineProperty(this, "autoPaging", {
			get: function() {
				return o;
			},
			set: function(e) {
				o = e;
			}
		});
		var s = 0;
		Object.defineProperty(this, "lastBreak", {
			get: function() {
				return s;
			},
			set: function(e) {
				s = e;
			}
		});
		var c = [];
		Object.defineProperty(this, "pageBreaks", {
			get: function() {
				return c;
			},
			set: function(e) {
				c = e;
			}
		}), Object.defineProperty(this, "ctx", {
			get: function() {
				return u;
			},
			set: function(e) {
				e instanceof d && (u = e);
			}
		}), Object.defineProperty(this, "path", {
			get: function() {
				return u.path;
			},
			set: function(e) {
				u.path = e;
			}
		});
		var l = [];
		Object.defineProperty(this, "ctxStack", {
			get: function() {
				return l;
			},
			set: function(e) {
				l = e;
			}
		}), Object.defineProperty(this, "fillStyle", {
			get: function() {
				return this.ctx.fillStyle;
			},
			set: function(e) {
				var t = p(e);
				this.ctx.fillStyle = t.style, this.ctx.isFillTransparent = t.a === 0, this.ctx.fillOpacity = t.a, this.pdf.setFillColor(t.r, t.g, t.b, { a: t.a }), this.pdf.setTextColor(t.r, t.g, t.b, { a: t.a });
			}
		}), Object.defineProperty(this, "strokeStyle", {
			get: function() {
				return this.ctx.strokeStyle;
			},
			set: function(e) {
				var t = p(e);
				this.ctx.strokeStyle = t.style, this.ctx.isStrokeTransparent = t.a === 0, this.ctx.strokeOpacity = t.a, t.a === 0 ? this.pdf.setDrawColor(255, 255, 255) : (t.a, this.pdf.setDrawColor(t.r, t.g, t.b));
			}
		}), Object.defineProperty(this, "lineCap", {
			get: function() {
				return this.ctx.lineCap;
			},
			set: function(e) {
				[
					"butt",
					"round",
					"square"
				].indexOf(e) !== -1 && (this.ctx.lineCap = e, this.pdf.setLineCap(e));
			}
		}), Object.defineProperty(this, "lineWidth", {
			get: function() {
				return this.ctx.lineWidth;
			},
			set: function(e) {
				isNaN(e) || (this.ctx.lineWidth = e, this.pdf.setLineWidth(e));
			}
		}), Object.defineProperty(this, "lineJoin", {
			get: function() {
				return this.ctx.lineJoin;
			},
			set: function(e) {
				[
					"bevel",
					"round",
					"miter"
				].indexOf(e) !== -1 && (this.ctx.lineJoin = e, this.pdf.setLineJoin(e));
			}
		}), Object.defineProperty(this, "miterLimit", {
			get: function() {
				return this.ctx.miterLimit;
			},
			set: function(e) {
				isNaN(e) || (this.ctx.miterLimit = e, this.pdf.setMiterLimit(e));
			}
		}), Object.defineProperty(this, "textBaseline", {
			get: function() {
				return this.ctx.textBaseline;
			},
			set: function(e) {
				this.ctx.textBaseline = e;
			}
		}), Object.defineProperty(this, "textAlign", {
			get: function() {
				return this.ctx.textAlign;
			},
			set: function(e) {
				[
					"right",
					"end",
					"center",
					"left",
					"start"
				].indexOf(e) !== -1 && (this.ctx.textAlign = e);
			}
		});
		var f = null, m = null, h = null;
		Object.defineProperty(this, "fontFaces", {
			get: function() {
				return h;
			},
			set: function(e) {
				f = null, m = null, h = e;
			}
		}), Object.defineProperty(this, "font", {
			get: function() {
				return this.ctx.font;
			},
			set: function(e) {
				var t;
				if (this.ctx.font = e, (t = /^\s*(?=(?:(?:[-a-z]+\s*){0,2}(italic|oblique))?)(?=(?:(?:[-a-z]+\s*){0,2}(small-caps))?)(?=(?:(?:[-a-z]+\s*){0,2}(bold(?:er)?|lighter|[1-9]00))?)(?:(?:normal|\1|\2|\3)\s*){0,3}((?:xx?-)?(?:small|large)|medium|smaller|larger|[.\d]+(?:\%|in|[cem]m|ex|p[ctx]))(?:\s*\/\s*(normal|[.\d]+(?:\%|in|[cem]m|ex|p[ctx])))?\s*([-_,\"\'\sa-z0-9]+?)\s*$/i.exec(e)) !== null) {
					var n = t[1];
					t[2];
					var r = t[3], i = t[4];
					t[5];
					var a = t[6], o = /^([.\d]+)((?:%|in|[cem]m|ex|p[ctx]))$/i.exec(i)[2];
					i = Math.floor(o === "px" ? parseFloat(i) * this.pdf.internal.scaleFactor : o === "em" ? parseFloat(i) * this.pdf.getFontSize() : parseFloat(i) * this.pdf.internal.scaleFactor), this.pdf.setFontSize(i);
					var s = function(e) {
						var t, n, r = [], i = e.trim();
						if (i === "") return ec;
						if (i in Ws) return [Ws[i]];
						for (; i !== "";) {
							switch (n = null, t = (i = Ks(i)).charAt(0)) {
								case "\"":
								case "'":
									n = qs(i.substring(1), t);
									break;
								default: n = Js(i);
							}
							if (n === null || (r.push(n[0]), (i = Ks(n[1])) !== "" && i.charAt(0) !== ",")) return ec;
							i = i.replace(/^,/, "");
						}
						return r;
					}(a);
					if (this.fontFaces) {
						var c = function(e, t, n) {
							for (var r = (n ||= {}).defaultFontFamily || "times", i = Object.assign({}, Us, n.genericFontFamilies || {}), a = null, o = null, s = 0; s < t.length; ++s) if (i[(a = Vs(t[s])).family] && (a.family = i[a.family]), e.hasOwnProperty(a.family)) {
								o = e[a.family];
								break;
							}
							if (!(o ||= e[r])) throw Error("Could not find a font-family for the rule '" + Gs(a) + "' and default family '" + r + "'.");
							if (o = function(e, t) {
								if (t[e]) return t[e];
								var n = Rs[e], r = Hs(t, Ls, n, n <= Rs.normal ? -1 : 1);
								if (!r) throw Error("Could not find a matching font-stretch value for " + e);
								return r;
							}(a.stretch, o), o = function(e, t) {
								if (t[e]) return t[e];
								for (var n = Is[e], r = 0; r < n.length; ++r) if (t[n[r]]) return t[n[r]];
								throw Error("Could not find a matching font-style for " + e);
							}(a.style, o), !(o = function(e, t) {
								if (t[e]) return t[e];
								if (e === 400 && t[500]) return t[500];
								if (e === 500 && t[400]) return t[400];
								var n = Bs[e], r = Hs(t, zs, n, e < 400 ? -1 : 1);
								if (!r) throw Error("Could not find a matching font-weight for value " + e);
								return r;
							}(a.weight, o))) throw Error("Failed to resolve a font for the rule '" + Gs(a) + "'.");
							return o;
						}(function(e, t) {
							var n = e.getFontList(), r = JSON.stringify(n);
							return (f === null || m !== r) && (f = function(e) {
								for (var t = {}, n = 0; n < e.length; ++n) {
									var r = Vs(e[n]), i = r.family, a = r.stretch, o = r.style, s = r.weight;
									t[i] = t[i] || {}, t[i][a] = t[i][a] || {}, t[i][a][o] = t[i][a][o] || {}, t[i][a][o][s] = r;
								}
								return t;
							}(function(e) {
								var t = [];
								return Object.keys(e).forEach(function(n) {
									e[n].forEach(function(e) {
										var r = null;
										switch (e) {
											case "bold":
												r = {
													family: n,
													weight: "bold"
												};
												break;
											case "italic":
												r = {
													family: n,
													style: "italic"
												};
												break;
											case "bolditalic":
												r = {
													family: n,
													weight: "bold",
													style: "italic"
												};
												break;
											case "":
											case "normal": r = { family: n };
										}
										r !== null && (r.ref = {
											name: n,
											style: e
										}, t.push(r));
									});
								}), t;
							}(n).concat(t)), m = r), f;
						}(this.pdf, this.fontFaces), s.map(function(e) {
							return {
								family: e,
								stretch: "normal",
								weight: r,
								style: n
							};
						}));
						this.pdf.setFont(c.ref.name, c.ref.style);
					} else {
						var l = "";
						(r === "bold" || parseInt(r, 10) >= 700 || n === "bold") && (l = "bold"), n === "italic" && (l += "italic"), l.length === 0 && (l = "normal");
						for (var u = "", d = {
							arial: "Helvetica",
							Arial: "Helvetica",
							verdana: "Helvetica",
							Verdana: "Helvetica",
							helvetica: "Helvetica",
							Helvetica: "Helvetica",
							"sans-serif": "Helvetica",
							fixed: "Courier",
							monospace: "Courier",
							terminal: "Courier",
							cursive: "Times",
							fantasy: "Times",
							serif: "Times"
						}, p = 0; p < s.length; p++) {
							if (this.pdf.internal.getFont(s[p], l, {
								noFallback: !0,
								disableWarning: !0
							}) !== void 0) {
								u = s[p];
								break;
							}
							if (l === "bolditalic" && this.pdf.internal.getFont(s[p], "bold", {
								noFallback: !0,
								disableWarning: !0
							}) !== void 0) u = s[p], l = "bold";
							else if (this.pdf.internal.getFont(s[p], "normal", {
								noFallback: !0,
								disableWarning: !0
							}) !== void 0) {
								u = s[p], l = "normal";
								break;
							}
						}
						if (u === "") {
							for (var h = 0; h < s.length; h++) if (d[s[h]]) {
								u = d[s[h]];
								break;
							}
						}
						u = u === "" ? "Times" : u, this.pdf.setFont(u, l);
					}
				}
			}
		}), Object.defineProperty(this, "globalCompositeOperation", {
			get: function() {
				return this.ctx.globalCompositeOperation;
			},
			set: function(e) {
				this.ctx.globalCompositeOperation = e;
			}
		}), Object.defineProperty(this, "globalAlpha", {
			get: function() {
				return this.ctx.globalAlpha;
			},
			set: function(e) {
				this.ctx.globalAlpha = e;
			}
		}), Object.defineProperty(this, "lineDashOffset", {
			get: function() {
				return this.ctx.lineDashOffset;
			},
			set: function(e) {
				this.ctx.lineDashOffset = e, ee.call(this);
			}
		}), Object.defineProperty(this, "lineDash", {
			get: function() {
				return this.ctx.lineDash;
			},
			set: function(e) {
				this.ctx.lineDash = e, ee.call(this);
			}
		}), Object.defineProperty(this, "ignoreClearRect", {
			get: function() {
				return this.ctx.ignoreClearRect;
			},
			set: function(e) {
				this.ctx.ignoreClearRect = !!e;
			}
		});
	};
	f.prototype.setLineDash = function(e) {
		this.lineDash = e;
	}, f.prototype.getLineDash = function() {
		return this.lineDash.length % 2 ? this.lineDash.concat(this.lineDash) : this.lineDash.slice();
	}, f.prototype.fill = function() {
		x.call(this, "fill", !1);
	}, f.prototype.stroke = function() {
		x.call(this, "stroke", !1);
	}, f.prototype.beginPath = function() {
		this.path = [{ type: "begin" }];
	}, f.prototype.moveTo = function(e, t) {
		if (isNaN(e) || isNaN(t)) throw vo.error("jsPDF.context2d.moveTo: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.moveTo");
		var n = this.ctx.transform.applyToPoint(new s(e, t));
		this.path.push({
			type: "mt",
			x: n.x,
			y: n.y
		}), this.ctx.lastPoint = new s(e, t);
	}, f.prototype.closePath = function() {
		var e = new s(0, 0), n = 0;
		for (n = this.path.length - 1; n !== -1; n--) if (this.path[n].type === "begin" && t(this.path[n + 1]) === "object" && typeof this.path[n + 1].x == "number") {
			e = new s(this.path[n + 1].x, this.path[n + 1].y);
			break;
		}
		this.path.push({ type: "close" }), this.ctx.lastPoint = new s(e.x, e.y);
	}, f.prototype.lineTo = function(e, t) {
		if (isNaN(e) || isNaN(t)) throw vo.error("jsPDF.context2d.lineTo: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.lineTo");
		var n = this.ctx.transform.applyToPoint(new s(e, t));
		this.path.push({
			type: "lt",
			x: n.x,
			y: n.y
		}), this.ctx.lastPoint = new s(n.x, n.y);
	}, f.prototype.clip = function() {
		this.ctx.clip_path = JSON.parse(JSON.stringify(this.path)), x.call(this, null, !0);
	}, f.prototype.quadraticCurveTo = function(e, t, n, r) {
		if (isNaN(n) || isNaN(r) || isNaN(e) || isNaN(t)) throw vo.error("jsPDF.context2d.quadraticCurveTo: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.quadraticCurveTo");
		var i = this.ctx.transform.applyToPoint(new s(n, r)), a = this.ctx.transform.applyToPoint(new s(e, t));
		this.path.push({
			type: "qct",
			x1: a.x,
			y1: a.y,
			x: i.x,
			y: i.y
		}), this.ctx.lastPoint = new s(i.x, i.y);
	}, f.prototype.bezierCurveTo = function(e, t, n, r, i, a) {
		if (isNaN(i) || isNaN(a) || isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r)) throw vo.error("jsPDF.context2d.bezierCurveTo: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.bezierCurveTo");
		var o = this.ctx.transform.applyToPoint(new s(i, a)), c = this.ctx.transform.applyToPoint(new s(e, t)), l = this.ctx.transform.applyToPoint(new s(n, r));
		this.path.push({
			type: "bct",
			x1: c.x,
			y1: c.y,
			x2: l.x,
			y2: l.y,
			x: o.x,
			y: o.y
		}), this.ctx.lastPoint = new s(o.x, o.y);
	}, f.prototype.arc = function(e, t, n, r, i, a) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r) || isNaN(i)) throw vo.error("jsPDF.context2d.arc: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.arc");
		if (a = !!a, !this.ctx.transform.isIdentity) {
			var o = this.ctx.transform.applyToPoint(new s(e, t));
			e = o.x, t = o.y;
			var c = this.ctx.transform.applyToPoint(new s(0, n)), l = this.ctx.transform.applyToPoint(new s(0, 0));
			n = Math.sqrt((c.x - l.x) ** 2 + (c.y - l.y) ** 2);
		}
		Math.abs(i - r) >= 2 * Math.PI && (r = 0, i = 2 * Math.PI), this.path.push({
			type: "arc",
			x: e,
			y: t,
			radius: n,
			startAngle: r,
			endAngle: i,
			counterclockwise: a
		});
	}, f.prototype.arcTo = function(e, t, n, r, i) {
		throw Error("arcTo not implemented.");
	}, f.prototype.rect = function(e, t, n, r) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r)) throw vo.error("jsPDF.context2d.rect: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.rect");
		this.moveTo(e, t), this.lineTo(e + n, t), this.lineTo(e + n, t + r), this.lineTo(e, t + r), this.lineTo(e, t), this.lineTo(e + n, t), this.lineTo(e, t);
	}, f.prototype.fillRect = function(e, t, n, r) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r)) throw vo.error("jsPDF.context2d.fillRect: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.fillRect");
		if (!m.call(this)) {
			var i = {};
			this.lineCap !== "butt" && (i.lineCap = this.lineCap, this.lineCap = "butt"), this.lineJoin !== "miter" && (i.lineJoin = this.lineJoin, this.lineJoin = "miter"), this.beginPath(), this.rect(e, t, n, r), this.fill(), i.hasOwnProperty("lineCap") && (this.lineCap = i.lineCap), i.hasOwnProperty("lineJoin") && (this.lineJoin = i.lineJoin);
		}
	}, f.prototype.strokeRect = function(e, t, n, r) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r)) throw vo.error("jsPDF.context2d.strokeRect: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.strokeRect");
		h.call(this) || (this.beginPath(), this.rect(e, t, n, r), this.stroke());
	}, f.prototype.clearRect = function(e, t, n, r) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r)) throw vo.error("jsPDF.context2d.clearRect: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.clearRect");
		this.ignoreClearRect || (this.fillStyle = "#ffffff", this.fillRect(e, t, n, r));
	}, f.prototype.save = function(e) {
		e = typeof e != "boolean" || e;
		for (var t = this.pdf.internal.getCurrentPageInfo().pageNumber, n = 0; n < this.pdf.internal.getNumberOfPages(); n++) this.pdf.setPage(n + 1), this.pdf.internal.out("q");
		if (this.pdf.setPage(t), e) {
			this.ctx.fontSize = this.pdf.internal.getFontSize();
			var r = new d(this.ctx);
			this.ctxStack.push(this.ctx), this.ctx = r;
		}
	}, f.prototype.restore = function(e) {
		e = typeof e != "boolean" || e;
		for (var t = this.pdf.internal.getCurrentPageInfo().pageNumber, n = 0; n < this.pdf.internal.getNumberOfPages(); n++) this.pdf.setPage(n + 1), this.pdf.internal.out("Q");
		this.pdf.setPage(t), e && this.ctxStack.length !== 0 && (this.ctx = this.ctxStack.pop(), this.fillStyle = this.ctx.fillStyle, this.strokeStyle = this.ctx.strokeStyle, this.font = this.ctx.font, this.lineCap = this.ctx.lineCap, this.lineWidth = this.ctx.lineWidth, this.lineJoin = this.ctx.lineJoin, this.lineDash = this.ctx.lineDash, this.lineDashOffset = this.ctx.lineDashOffset);
	}, f.prototype.toDataURL = function() {
		throw Error("toDataUrl not implemented.");
	};
	var p = function(e) {
		var t, n, r, i;
		if (!0 === e.isCanvasGradient && (e = e.getColor()), !e) return {
			r: 0,
			g: 0,
			b: 0,
			a: 0,
			style: e
		};
		if (/transparent|rgba\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*0+\s*\)/.test(e)) t = 0, n = 0, r = 0, i = 0;
		else {
			var a = /rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/.exec(e);
			if (a !== null) t = parseInt(a[1]), n = parseInt(a[2]), r = parseInt(a[3]), i = 1;
			else if ((a = /rgba\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)/.exec(e)) !== null) t = parseInt(a[1]), n = parseInt(a[2]), r = parseInt(a[3]), i = parseFloat(a[4]);
			else {
				if (i = 1, typeof e == "string" && e.charAt(0) !== "#") {
					var o = new Co(e);
					e = o.ok ? o.toHex() : "#000000";
				}
				e.length === 4 ? (t = e.substring(1, 2), t += t, n = e.substring(2, 3), n += n, r = e.substring(3, 4), r += r) : (t = e.substring(1, 3), n = e.substring(3, 5), r = e.substring(5, 7)), t = parseInt(t, 16), n = parseInt(n, 16), r = parseInt(r, 16);
			}
		}
		return {
			r: t,
			g: n,
			b: r,
			a: i,
			style: e
		};
	}, m = function() {
		return this.ctx.isFillTransparent || this.globalAlpha == 0;
	}, h = function() {
		return !!(this.ctx.isStrokeTransparent || this.globalAlpha == 0);
	};
	f.prototype.fillText = function(e, t, n, r) {
		if (isNaN(t) || isNaN(n) || typeof e != "string") throw vo.error("jsPDF.context2d.fillText: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.fillText");
		if (r = isNaN(r) ? void 0 : r, !m.call(this)) {
			var i = F(this.ctx.transform.rotation), a = this.ctx.transform.scaleX;
			k.call(this, {
				text: e,
				x: t,
				y: n,
				scale: a,
				angle: i,
				align: this.textAlign,
				maxWidth: r
			});
		}
	}, f.prototype.strokeText = function(e, t, n, r) {
		if (isNaN(t) || isNaN(n) || typeof e != "string") throw vo.error("jsPDF.context2d.strokeText: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.strokeText");
		if (!h.call(this)) {
			r = isNaN(r) ? void 0 : r;
			var i = F(this.ctx.transform.rotation), a = this.ctx.transform.scaleX;
			k.call(this, {
				text: e,
				x: t,
				y: n,
				scale: a,
				renderingMode: "stroke",
				angle: i,
				align: this.textAlign,
				maxWidth: r
			});
		}
	}, f.prototype.measureText = function(e) {
		if (typeof e != "string") throw vo.error("jsPDF.context2d.measureText: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.measureText");
		var t = this.pdf, n = this.pdf.internal.scaleFactor, r = t.internal.getFontSize(), i = t.getStringUnitWidth(e) * r / t.internal.scaleFactor;
		return new function(e) {
			var t = (e ||= {}).width || 0;
			return Object.defineProperty(this, "width", { get: function() {
				return t;
			} }), this;
		}({ width: i *= Math.round(96 * n / 72 * 1e4) / 1e4 });
	}, f.prototype.scale = function(e, t) {
		if (isNaN(e) || isNaN(t)) throw vo.error("jsPDF.context2d.scale: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.scale");
		var n = new l(e, 0, 0, t, 0, 0);
		this.ctx.transform = this.ctx.transform.multiply(n);
	}, f.prototype.rotate = function(e) {
		if (isNaN(e)) throw vo.error("jsPDF.context2d.rotate: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.rotate");
		var t = new l(Math.cos(e), Math.sin(e), -Math.sin(e), Math.cos(e), 0, 0);
		this.ctx.transform = this.ctx.transform.multiply(t);
	}, f.prototype.translate = function(e, t) {
		if (isNaN(e) || isNaN(t)) throw vo.error("jsPDF.context2d.translate: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.translate");
		var n = new l(1, 0, 0, 1, e, t);
		this.ctx.transform = this.ctx.transform.multiply(n);
	}, f.prototype.transform = function(e, t, n, r, i, a) {
		if (isNaN(e) || isNaN(t) || isNaN(n) || isNaN(r) || isNaN(i) || isNaN(a)) throw vo.error("jsPDF.context2d.transform: Invalid arguments", arguments), /* @__PURE__ */ Error("Invalid arguments passed to jsPDF.context2d.transform");
		var o = new l(e, t, n, r, i, a);
		this.ctx.transform = this.ctx.transform.multiply(o);
	}, f.prototype.setTransform = function(e, t, n, r, i, a) {
		e = isNaN(e) ? 1 : e, t = isNaN(t) ? 0 : t, n = isNaN(n) ? 0 : n, r = isNaN(r) ? 1 : r, i = isNaN(i) ? 0 : i, a = isNaN(a) ? 0 : a, this.ctx.transform = new l(e, t, n, r, i, a);
	};
	var g = function() {
		return this.margin[0] > 0 || this.margin[1] > 0 || this.margin[2] > 0 || this.margin[3] > 0;
	};
	f.prototype.drawImage = function(e, t, n, r, i, a, o, s, u) {
		var d = this.pdf.getImageProperties(e), f = 1, p = 1, m = 1, h = 1;
		r !== void 0 && s !== void 0 && (m = s / r, h = u / i, f = d.width / r * s / r, p = d.height / i * u / i), a === void 0 && (a = t, o = n, t = 0, n = 0), r !== void 0 && s === void 0 && (s = r, u = i), r === void 0 && s === void 0 && (s = d.width, u = d.height);
		var v = this.ctx.transform.decompose(), x = F(v.rotate.shx), C = new l(), w = (C = (C = (C = C.multiply(v.translate)).multiply(v.skew)).multiply(v.scale)).applyToRectangle(new c(a - t * m, o - n * h, r * f, i * p));
		if (this.autoPaging) {
			for (var T, E = _.call(this, w), D = [], O = 0; O < E.length; O += 1) D.indexOf(E[O]) === -1 && D.push(E[O]);
			b(D);
			for (var k = D[0], A = D[D.length - 1], j = k; j < A + 1; j++) {
				this.pdf.setPage(j);
				var M = this.pdf.internal.pageSize.width - this.margin[3] - this.margin[1], N = j === 1 ? this.posY + this.margin[0] : this.margin[0], P = this.pdf.internal.pageSize.height - this.posY - this.margin[0] - this.margin[2], I = this.pdf.internal.pageSize.height - this.margin[0] - this.margin[2], L = j === 1 ? 0 : P + (j - 2) * I;
				if (this.ctx.clip_path.length !== 0) {
					var ee = this.path;
					T = JSON.parse(JSON.stringify(this.ctx.clip_path)), this.path = y(T, this.posX + this.margin[3], -L + N + this.ctx.prevPageLastElemOffset), S.call(this, "fill", !0), this.path = ee;
				}
				var R = JSON.parse(JSON.stringify(w));
				R = y([R], this.posX + this.margin[3], -L + N + this.ctx.prevPageLastElemOffset)[0];
				var z = (j > k || j < A) && g.call(this);
				z && (this.pdf.saveGraphicsState(), this.pdf.rect(this.margin[3], this.margin[0], M, I, null).clip().discardPath()), this.pdf.addImage(e, "JPEG", R.x, R.y, R.w, R.h, null, null, x), z && this.pdf.restoreGraphicsState();
			}
		} else this.pdf.addImage(e, "JPEG", w.x, w.y, w.w, w.h, null, null, x);
	};
	var _ = function(e, t, n) {
		var r = [];
		t ||= this.pdf.internal.pageSize.width, n ||= this.pdf.internal.pageSize.height - this.margin[0] - this.margin[2];
		var i = this.posY + this.ctx.prevPageLastElemOffset;
		switch (e.type) {
			default:
			case "mt":
			case "lt":
				r.push(Math.floor((e.y + i) / n) + 1);
				break;
			case "arc":
				r.push(Math.floor((e.y + i - e.radius) / n) + 1), r.push(Math.floor((e.y + i + e.radius) / n) + 1);
				break;
			case "qct":
				var a = I(this.ctx.lastPoint.x, this.ctx.lastPoint.y, e.x1, e.y1, e.x, e.y);
				r.push(Math.floor((a.y + i) / n) + 1), r.push(Math.floor((a.y + a.h + i) / n) + 1);
				break;
			case "bct":
				var o = L(this.ctx.lastPoint.x, this.ctx.lastPoint.y, e.x1, e.y1, e.x2, e.y2, e.x, e.y);
				r.push(Math.floor((o.y + i) / n) + 1), r.push(Math.floor((o.y + o.h + i) / n) + 1);
				break;
			case "rect": r.push(Math.floor((e.y + i) / n) + 1), r.push(Math.floor((e.y + e.h + i) / n) + 1);
		}
		for (var s = 0; s < r.length; s += 1) for (; this.pdf.internal.getNumberOfPages() < r[s];) v.call(this);
		return r;
	}, v = function() {
		var e = this.fillStyle, t = this.strokeStyle, n = this.font, r = this.lineCap, i = this.lineWidth, a = this.lineJoin;
		this.pdf.addPage(), this.fillStyle = e, this.strokeStyle = t, this.font = n, this.lineCap = r, this.lineWidth = i, this.lineJoin = a;
	}, y = function(e, t, n) {
		for (var r = 0; r < e.length; r++) switch (e[r].type) {
			case "bct": e[r].x2 += t, e[r].y2 += n;
			case "qct": e[r].x1 += t, e[r].y1 += n;
			default: e[r].x += t, e[r].y += n;
		}
		return e;
	}, b = function(e) {
		return e.sort(function(e, t) {
			return e - t;
		});
	}, x = function(e, t) {
		var n = this.fillStyle, r = this.strokeStyle, i = this.lineCap, a = this.lineWidth, o = Math.abs(a * this.ctx.transform.scaleX), s = this.lineJoin;
		if (this.autoPaging) {
			for (var c, l, u = JSON.parse(JSON.stringify(this.path)), d = JSON.parse(JSON.stringify(this.path)), f = [], p = 0; p < d.length; p++) if (d[p].x !== void 0) for (var m = _.call(this, d[p]), h = 0; h < m.length; h += 1) f.indexOf(m[h]) === -1 && f.push(m[h]);
			for (var x = 0; x < f.length; x++) for (; this.pdf.internal.getNumberOfPages() < f[x];) v.call(this);
			b(f);
			for (var C = f[0], w = f[f.length - 1], T = C; T < w + 1; T++) {
				this.pdf.setPage(T), this.fillStyle = n, this.strokeStyle = r, this.lineCap = i, this.lineWidth = o, this.lineJoin = s;
				var E = this.pdf.internal.pageSize.width - this.margin[3] - this.margin[1], D = T === 1 ? this.posY + this.margin[0] : this.margin[0], O = this.pdf.internal.pageSize.height - this.posY - this.margin[0] - this.margin[2], k = this.pdf.internal.pageSize.height - this.margin[0] - this.margin[2], A = T === 1 ? 0 : O + (T - 2) * k;
				if (this.ctx.clip_path.length !== 0) {
					var j = this.path;
					c = JSON.parse(JSON.stringify(this.ctx.clip_path)), this.path = y(c, this.posX + this.margin[3], -A + D + this.ctx.prevPageLastElemOffset), S.call(this, e, !0), this.path = j;
				}
				if (l = JSON.parse(JSON.stringify(u)), this.path = y(l, this.posX + this.margin[3], -A + D + this.ctx.prevPageLastElemOffset), !1 === t || T === 0) {
					var M = (T > C || T < w) && g.call(this);
					M && (this.pdf.saveGraphicsState(), this.pdf.rect(this.margin[3], this.margin[0], E, k, null).clip().discardPath()), S.call(this, e, t), M && this.pdf.restoreGraphicsState();
				}
				this.lineWidth = a;
			}
			this.path = u;
		} else this.lineWidth = o, S.call(this, e, t), this.lineWidth = a;
	}, S = function(e, t) {
		if ((e !== "stroke" || t || !h.call(this)) && (e === "stroke" || t || !m.call(this))) {
			for (var n, r, i = [], a = this.path, o = 0; o < a.length; o++) {
				var s = a[o];
				switch (s.type) {
					case "begin":
						i.push({ begin: !0 });
						break;
					case "close":
						i.push({ close: !0 });
						break;
					case "mt":
						i.push({
							start: s,
							deltas: [],
							abs: []
						});
						break;
					case "lt":
						var c = i.length;
						if (a[o - 1] && !isNaN(a[o - 1].x) && (n = [s.x - a[o - 1].x, s.y - a[o - 1].y], c > 0)) {
							for (; c >= 0; c--) if (!0 !== i[c - 1].close && !0 !== i[c - 1].begin) {
								i[c - 1].deltas.push(n), i[c - 1].abs.push(s);
								break;
							}
						}
						break;
					case "bct":
						n = [
							s.x1 - a[o - 1].x,
							s.y1 - a[o - 1].y,
							s.x2 - a[o - 1].x,
							s.y2 - a[o - 1].y,
							s.x - a[o - 1].x,
							s.y - a[o - 1].y
						], i[i.length - 1].deltas.push(n);
						break;
					case "qct":
						var l = a[o - 1].x + 2 / 3 * (s.x1 - a[o - 1].x), u = a[o - 1].y + 2 / 3 * (s.y1 - a[o - 1].y), d = s.x + 2 / 3 * (s.x1 - s.x), f = s.y + 2 / 3 * (s.y1 - s.y), p = s.x, g = s.y;
						n = [
							l - a[o - 1].x,
							u - a[o - 1].y,
							d - a[o - 1].x,
							f - a[o - 1].y,
							p - a[o - 1].x,
							g - a[o - 1].y
						], i[i.length - 1].deltas.push(n);
						break;
					case "arc": i.push({
						deltas: [],
						abs: [],
						arc: !0
					}), Array.isArray(i[i.length - 1].abs) && i[i.length - 1].abs.push(s);
				}
			}
			r = t ? null : e === "stroke" ? "stroke" : "fill";
			for (var _ = !1, v = 0; v < i.length; v++) if (i[v].arc) for (var y = i[v].abs, b = 0; b < y.length; b++) {
				var x = y[b];
				x.type === "arc" ? T.call(this, x.x, x.y, x.radius, x.startAngle, x.endAngle, x.counterclockwise, void 0, t, !_) : A.call(this, x.x, x.y), _ = !0;
			}
			else if (!0 === i[v].close) this.pdf.internal.out("h"), _ = !1;
			else if (!0 !== i[v].begin) {
				var S = i[v].start.x, C = i[v].start.y;
				j.call(this, i[v].deltas, S, C), _ = !0;
			}
			r && E.call(this, r), t && D.call(this);
		}
	}, C = function(e) {
		var t = this.pdf.internal.getFontSize() / this.pdf.internal.scaleFactor, n = t * (this.pdf.internal.getLineHeightFactor() - 1);
		switch (this.ctx.textBaseline) {
			case "bottom": return e - n;
			case "top": return e + t - n;
			case "hanging": return e + t - 2 * n;
			case "middle": return e + t / 2 - n;
			default: return e;
		}
	}, w = function(e) {
		return e + this.pdf.internal.getFontSize() / this.pdf.internal.scaleFactor * (this.pdf.internal.getLineHeightFactor() - 1);
	};
	f.prototype.createLinearGradient = function() {
		var e = function() {};
		return e.colorStops = [], e.addColorStop = function(e, t) {
			this.colorStops.push([e, t]);
		}, e.getColor = function() {
			return this.colorStops.length === 0 ? "#000000" : this.colorStops[0][1];
		}, e.isCanvasGradient = !0, e;
	}, f.prototype.createPattern = function() {
		return this.createLinearGradient();
	}, f.prototype.createRadialGradient = function() {
		return this.createLinearGradient();
	};
	var T = function(e, t, n, r, i, a, o, s, c) {
		for (var l = N.call(this, n, r, i, a), u = 0; u < l.length; u++) {
			var d = l[u];
			u === 0 && (c ? O.call(this, d.x1 + e, d.y1 + t) : A.call(this, d.x1 + e, d.y1 + t)), M.call(this, e, t, d.x2, d.y2, d.x3, d.y3, d.x4, d.y4);
		}
		s ? D.call(this) : E.call(this, o);
	}, E = function(e) {
		switch (e) {
			case "stroke":
				this.pdf.internal.out("S");
				break;
			case "fill": this.pdf.internal.out("f");
		}
	}, D = function() {
		this.pdf.clip(), this.pdf.discardPath();
	}, O = function(e, t) {
		this.pdf.internal.out(r(e) + " " + i(t) + " m");
	}, k = function(e) {
		var t;
		switch (e.align) {
			case "right":
			case "end":
				t = "right";
				break;
			case "center":
				t = "center";
				break;
			default: t = "left";
		}
		var n, r, i, a = this.pdf.getTextDimensions(e.text), o = C.call(this, e.y), u = w.call(this, o) - a.h, d = this.ctx.transform.applyToPoint(new s(e.x, o));
		if (this.autoPaging) {
			var f = this.ctx.transform.decompose(), p = new l();
			p = (p = (p = p.multiply(f.translate)).multiply(f.skew)).multiply(f.scale);
			for (var m = this.ctx.transform.applyToRectangle(new c(e.x, o, a.w, a.h)), h = p.applyToRectangle(new c(e.x, u, a.w, a.h)), v = _.call(this, h), x = [], T = 0; T < v.length; T += 1) x.indexOf(v[T]) === -1 && x.push(v[T]);
			b(x);
			for (var E = x[0], D = x[x.length - 1], O = E; O < D + 1; O++) {
				this.pdf.setPage(O);
				var k = O === 1 ? this.posY + this.margin[0] : this.margin[0], A = this.pdf.internal.pageSize.height - this.posY - this.margin[0] - this.margin[2], j = this.pdf.internal.pageSize.height - this.margin[2], M = j - this.margin[0], N = this.pdf.internal.pageSize.width - this.margin[1], P = N - this.margin[3], F = O === 1 ? 0 : A + (O - 2) * M;
				if (this.ctx.clip_path.length !== 0) {
					var I = this.path;
					n = JSON.parse(JSON.stringify(this.ctx.clip_path)), this.path = y(n, this.posX + this.margin[3], -1 * F + k), S.call(this, "fill", !0), this.path = I;
				}
				var L = y([JSON.parse(JSON.stringify(h))], this.posX + this.margin[3], -F + k + this.ctx.prevPageLastElemOffset)[0];
				e.scale >= .01 && (r = this.pdf.internal.getFontSize(), this.pdf.setFontSize(r * e.scale), i = this.lineWidth, this.lineWidth = i * e.scale);
				var ee = this.autoPaging !== "text";
				if (ee || L.y + L.h <= j) {
					if (ee || L.y >= k && L.x <= N) {
						var R = ee ? e.text : this.pdf.splitTextToSize(e.text, e.maxWidth || N - L.x)[0], z = y([JSON.parse(JSON.stringify(m))], this.posX + this.margin[3], -F + k + this.ctx.prevPageLastElemOffset)[0], B = ee && (O > E || O < D) && g.call(this);
						B && (this.pdf.saveGraphicsState(), this.pdf.rect(this.margin[3], this.margin[0], P, M, null).clip().discardPath()), this.pdf.text(R, z.x, z.y, {
							angle: e.angle,
							align: t,
							renderingMode: e.renderingMode
						}), B && this.pdf.restoreGraphicsState();
					}
				} else L.y < j && (this.ctx.prevPageLastElemOffset += j - L.y);
				e.scale >= .01 && (this.pdf.setFontSize(r), this.lineWidth = i);
			}
		} else e.scale >= .01 && (r = this.pdf.internal.getFontSize(), this.pdf.setFontSize(r * e.scale), i = this.lineWidth, this.lineWidth = i * e.scale), this.pdf.text(e.text, d.x + this.posX, d.y + this.posY, {
			angle: e.angle,
			align: t,
			renderingMode: e.renderingMode,
			maxWidth: e.maxWidth
		}), e.scale >= .01 && (this.pdf.setFontSize(r), this.lineWidth = i);
	}, A = function(e, t, n, a) {
		n ||= 0, a ||= 0, this.pdf.internal.out(r(e + n) + " " + i(t + a) + " l");
	}, j = function(e, t, n) {
		return this.pdf.lines(e, t, n, null, null);
	}, M = function(e, t, r, i, s, c, l, u) {
		this.pdf.internal.out([
			n(a(r + e)),
			n(o(i + t)),
			n(a(s + e)),
			n(o(c + t)),
			n(a(l + e)),
			n(o(u + t)),
			"c"
		].join(" "));
	}, N = function(e, t, n, r) {
		for (var i = 2 * Math.PI, a = Math.PI / 2; t > n;) t -= i;
		var o = Math.abs(n - t);
		o < i && r && (o = i - o);
		for (var s = [], c = r ? -1 : 1, l = t; o > 1e-5;) {
			var u = l + c * Math.min(o, a);
			s.push(P.call(this, e, l, u)), o -= Math.abs(u - l), l = u;
		}
		return s;
	}, P = function(e, t, n) {
		var r = (n - t) / 2, i = e * Math.cos(r), a = e * Math.sin(r), o = i, s = -a, c = o * o + s * s, l = c + o * i + s * a, u = 4 / 3 * (Math.sqrt(2 * c * l) - l) / (o * a - s * i), d = o - u * s, f = s + u * o, p = d, m = -f, h = r + t, g = Math.cos(h), _ = Math.sin(h);
		return {
			x1: e * Math.cos(t),
			y1: e * Math.sin(t),
			x2: d * g - f * _,
			y2: d * _ + f * g,
			x3: p * g - m * _,
			y3: p * _ + m * g,
			x4: e * Math.cos(n),
			y4: e * Math.sin(n)
		};
	}, F = function(e) {
		return 180 * e / Math.PI;
	}, I = function(e, t, n, r, i, a) {
		var o = e + .5 * (n - e), s = t + .5 * (r - t), l = i + .5 * (n - i), u = a + .5 * (r - a), d = Math.min(e, i, o, l), f = Math.max(e, i, o, l), p = Math.min(t, a, s, u), m = Math.max(t, a, s, u);
		return new c(d, p, f - d, m - p);
	}, L = function(e, t, n, r, i, a, o, s) {
		var l, u, d, f, p, m, h, g, _, v, y, b, x, S, C = n - e, w = r - t, T = i - n, E = a - r, D = o - i, O = s - a;
		for (u = 0; u < 41; u++) _ = (h = (d = e + (l = u / 40) * C) + l * ((p = n + l * T) - d)) + l * (p + l * (i + l * D - p) - h), v = (g = (f = t + l * w) + l * ((m = r + l * E) - f)) + l * (m + l * (a + l * O - m) - g), u == 0 ? (y = _, b = v, x = _, S = v) : (y = Math.min(y, _), b = Math.min(b, v), x = Math.max(x, _), S = Math.max(S, v));
		return new c(Math.round(y), Math.round(b), Math.round(x - y), Math.round(S - b));
	}, ee = function() {
		if (this.prevLineDash || this.ctx.lineDash.length || this.ctx.lineDashOffset) {
			var e, t, n = (e = this.ctx.lineDash, t = this.ctx.lineDashOffset, JSON.stringify({
				lineDash: e,
				lineDashOffset: t
			}));
			this.prevLineDash !== n && (this.pdf.setLineDash(this.ctx.lineDash, this.ctx.lineDashOffset), this.prevLineDash = n);
		}
	};
})(Z.API), function(e) {
	var t = function(e) {
		var t, n, r, i, a, o, s, c, l, u;
		for (/[^\x00-\xFF]/.test(e), n = [], r = 0, i = (e += t = "\0\0\0\0".slice(e.length % 4 || 4)).length; i > r; r += 4) (a = (e.charCodeAt(r) << 24) + (e.charCodeAt(r + 1) << 16) + (e.charCodeAt(r + 2) << 8) + e.charCodeAt(r + 3)) === 0 ? n.push(122) : (o = (a = ((a = ((a = ((a = (a - (u = a % 85)) / 85) - (l = a % 85)) / 85) - (c = a % 85)) / 85) - (s = a % 85)) / 85) % 85, n.push(o + 33, s + 33, c + 33, l + 33, u + 33));
		return function(e, t) {
			for (var n = t; n > 0; n--) e.pop();
		}(n, t.length), String.fromCharCode.apply(String, n) + "~>";
	}, n = function(e) {
		var t, n, r, i, a, o = String, s = "length", c = 255, l = "charCodeAt", u = "slice", d = "replace";
		for (e[u](-2), e = e[u](0, -2)[d](/\s/g, "")[d]("z", "!!!!!"), r = [], i = 0, a = (e += t = "uuuuu"[u](e[s] % 5 || 5))[s]; a > i; i += 5) n = 52200625 * (e[l](i) - 33) + 614125 * (e[l](i + 1) - 33) + 7225 * (e[l](i + 2) - 33) + 85 * (e[l](i + 3) - 33) + (e[l](i + 4) - 33), r.push(c & n >> 24, c & n >> 16, c & n >> 8, c & n);
		return function(e, t) {
			for (var n = t; n > 0; n--) e.pop();
		}(r, t[s]), o.fromCharCode.apply(o, r);
	}, r = function(e) {
		return e.split("").map(function(e) {
			return ("0" + e.charCodeAt().toString(16)).slice(-2);
		}).join("") + ">";
	}, i = function(e) {
		var t = /* @__PURE__ */ new RegExp(/^([0-9A-Fa-f]{2})+$/);
		if ((e = e.replace(/\s/g, "")).indexOf(">") !== -1 && (e = e.substr(0, e.indexOf(">"))), e.length % 2 && (e += "0"), !1 === t.test(e)) return "";
		for (var n = "", r = 0; r < e.length; r += 2) n += String.fromCharCode("0x" + (e[r] + e[r + 1]));
		return n;
	}, a = function(e) {
		for (var t = new Uint8Array(e.length), n = e.length; n--;) t[n] = e.charCodeAt(n);
		return (t = we(t)).reduce(function(e, t) {
			return e + String.fromCharCode(t);
		}, "");
	};
	e.processDataByFilters = function(e, o) {
		var s = 0, c = e || "", l = [];
		for (typeof (o ||= []) == "string" && (o = [o]), s = 0; s < o.length; s += 1) switch (o[s]) {
			case "ASCII85Decode":
			case "/ASCII85Decode":
				c = n(c), l.push("/ASCII85Encode");
				break;
			case "ASCII85Encode":
			case "/ASCII85Encode":
				c = t(c), l.push("/ASCII85Decode");
				break;
			case "ASCIIHexDecode":
			case "/ASCIIHexDecode":
				c = i(c), l.push("/ASCIIHexEncode");
				break;
			case "ASCIIHexEncode":
			case "/ASCIIHexEncode":
				c = r(c), l.push("/ASCIIHexDecode");
				break;
			case "FlateEncode":
			case "/FlateEncode":
				c = a(c), l.push("/FlateDecode");
				break;
			default: throw Error("The filter: \"" + o[s] + "\" is not implemented");
		}
		return {
			data: c,
			reverseChain: l.reverse().join(" ")
		};
	};
}(Z.API), function(e) {
	e.loadFile = function(e, t, n) {
		return function(e, t, n) {
			t = !1 !== t, n = typeof n == "function" ? n : function() {};
			var r = void 0;
			try {
				r = function(e, t, n) {
					var r = new XMLHttpRequest(), i = 0, a = function(e) {
						var t = e.length, n = [], r = String.fromCharCode;
						for (i = 0; i < t; i += 1) n.push(r(255 & e.charCodeAt(i)));
						return n.join("");
					};
					if (r.open("GET", e, !t), r.overrideMimeType("text/plain; charset=x-user-defined"), !1 === t && (r.onload = function() {
						r.status === 200 ? n(a(this.responseText)) : n(void 0);
					}), r.send(null), t && r.status === 200) return a(r.responseText);
				}(e, t, n);
			} catch {}
			return r;
		}(e, t, n);
	}, e.allowFsRead = void 0, e.loadImageFile = e.loadFile;
}(Z.API), function(n) {
	function r() {
		return (X.html2canvas ? Promise.resolve(X.html2canvas) : import("./html2canvas-CiD_9f_D.js").then((t) => /* @__PURE__ */ e(t.default))).catch(function(e) {
			return Promise.reject(/* @__PURE__ */ Error("Could not load html2canvas: " + e));
		}).then(function(e) {
			return e.default ? e.default : e;
		});
	}
	function i() {
		return (X.DOMPurify ? Promise.resolve(X.DOMPurify) : import("./purify.es-KOxEkdTw.js")).catch(function(e) {
			return Promise.reject(/* @__PURE__ */ Error("Could not load dompurify: " + e));
		}).then(function(e) {
			return e.default ? e.default : e;
		});
	}
	var a = function(e) {
		var n = t(e);
		return n === "undefined" ? "undefined" : n === "string" || e instanceof String ? "string" : n === "number" || e instanceof Number ? "number" : n === "function" || e instanceof Function ? "function" : e && e.constructor === Array ? "array" : e && e.nodeType === 1 ? "element" : n === "object" ? "object" : "unknown";
	}, o = function(e, t) {
		var n = document.createElement(e);
		for (var r in t.className && (n.className = t.className), t.innerHTML && t.dompurify && (n.innerHTML = t.dompurify.sanitize(t.innerHTML)), t.style) n.style[r] = t.style[r];
		return n;
	}, s = function e(t, n) {
		for (var r = t.nodeType === 3 ? document.createTextNode(t.nodeValue) : t.cloneNode(!1), i = t.firstChild; i; i = i.nextSibling) !0 !== n && i.nodeType === 1 && i.nodeName === "SCRIPT" || r.appendChild(e(i, n));
		return t.nodeType === 1 && (t.nodeName === "CANVAS" ? (r.width = t.width, r.height = t.height, r.getContext("2d").drawImage(t, 0, 0)) : t.nodeName !== "TEXTAREA" && t.nodeName !== "SELECT" || (r.value = t.value), r.addEventListener("load", function() {
			r.scrollTop = t.scrollTop, r.scrollLeft = t.scrollLeft;
		}, !0)), r;
	}, c = function e(t) {
		var n = Object.assign(e.convert(Promise.resolve()), JSON.parse(JSON.stringify(e.template))), r = e.convert(Promise.resolve(), n);
		return (r = r.setProgress(1, e, 1, [e])).set(t);
	};
	(c.prototype = Object.create(Promise.prototype)).constructor = c, c.convert = function(e, t) {
		return e.__proto__ = t || c.prototype, e;
	}, c.template = {
		prop: {
			src: null,
			container: null,
			overlay: null,
			canvas: null,
			img: null,
			pdf: null,
			pageSize: null,
			callback: function() {}
		},
		progress: {
			val: 0,
			state: null,
			n: 0,
			stack: []
		},
		opt: {
			filename: "file.pdf",
			margin: [
				0,
				0,
				0,
				0
			],
			enableLinks: !0,
			x: 0,
			y: 0,
			html2canvas: {},
			jsPDF: {},
			backgroundColor: "transparent"
		}
	}, c.prototype.from = function(e, t) {
		return this.then(function() {
			switch (t ||= function(e) {
				switch (a(e)) {
					case "string": return "string";
					case "element": return e.nodeName.toLowerCase() === "canvas" ? "canvas" : "element";
					default: return "unknown";
				}
			}(e), t) {
				case "string": return this.then(i).then(function(t) {
					return this.set({ src: o("div", {
						innerHTML: e,
						dompurify: t
					}) });
				});
				case "element": return this.set({ src: e });
				case "canvas": return this.set({ canvas: e });
				case "img": return this.set({ img: e });
				default: return this.error("Unknown source type.");
			}
		});
	}, c.prototype.to = function(e) {
		switch (e) {
			case "container": return this.toContainer();
			case "canvas": return this.toCanvas();
			case "img": return this.toImg();
			case "pdf": return this.toPdf();
			default: return this.error("Invalid target.");
		}
	}, c.prototype.toContainer = function() {
		return this.thenList([function() {
			return this.prop.src || this.error("Cannot duplicate - no source HTML.");
		}, function() {
			return this.prop.pageSize || this.setPageSize();
		}]).then(function() {
			var e = {
				position: "relative",
				display: "inline-block",
				width: (typeof this.opt.width != "number" || isNaN(this.opt.width) || typeof this.opt.windowWidth != "number" || isNaN(this.opt.windowWidth) ? Math.max(this.prop.src.clientWidth, this.prop.src.scrollWidth, this.prop.src.offsetWidth) : this.opt.windowWidth) + "px",
				left: 0,
				right: 0,
				top: 0,
				margin: "auto",
				backgroundColor: this.opt.backgroundColor
			}, t = s(this.prop.src, this.opt.html2canvas.javascriptEnabled);
			t.tagName === "BODY" && (e.height = Math.max(document.body.scrollHeight, document.body.offsetHeight, document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight) + "px"), this.prop.overlay = o("div", {
				className: "html2pdf__overlay",
				style: {
					position: "fixed",
					overflow: "hidden",
					zIndex: 1e3,
					left: "-100000px",
					right: 0,
					bottom: 0,
					top: 0
				}
			}), this.prop.container = o("div", {
				className: "html2pdf__container",
				style: e
			}), this.prop.container.appendChild(t), this.prop.container.firstChild.appendChild(o("div", { style: {
				clear: "both",
				border: "0 none transparent",
				margin: 0,
				padding: 0,
				height: 0
			} })), this.prop.container.style.float = "none", this.prop.overlay.appendChild(this.prop.container), document.body.appendChild(this.prop.overlay), this.prop.container.firstChild.style.position = "relative", this.prop.container.height = Math.max(this.prop.container.firstChild.clientHeight, this.prop.container.firstChild.scrollHeight, this.prop.container.firstChild.offsetHeight) + "px";
		});
	}, c.prototype.toCanvas = function() {
		return this.thenList([function() {
			return document.body.contains(this.prop.container) || this.toContainer();
		}]).then(r).then(function(e) {
			var t = Object.assign({}, this.opt.html2canvas);
			return delete t.onrendered, e(this.prop.container, t);
		}).then(function(e) {
			(this.opt.html2canvas.onrendered || function() {})(e), this.prop.canvas = e, document.body.removeChild(this.prop.overlay);
		});
	}, c.prototype.toContext2d = function() {
		return this.thenList([function() {
			return document.body.contains(this.prop.container) || this.toContainer();
		}]).then(r).then(function(e) {
			var t = this.opt.jsPDF, n = this.opt.fontFaces, r = typeof this.opt.width != "number" || isNaN(this.opt.width) || typeof this.opt.windowWidth != "number" || isNaN(this.opt.windowWidth) ? 1 : this.opt.width / this.opt.windowWidth, i = Object.assign({
				async: !0,
				allowTaint: !0,
				scale: r,
				scrollX: this.opt.scrollX || 0,
				scrollY: this.opt.scrollY || 0,
				backgroundColor: "#ffffff",
				imageTimeout: 15e3,
				logging: !0,
				proxy: null,
				removeContainer: !0,
				foreignObjectRendering: !1,
				useCORS: !1
			}, this.opt.html2canvas);
			if (delete i.onrendered, t.context2d.autoPaging = this.opt.autoPaging === void 0 || this.opt.autoPaging, t.context2d.posX = this.opt.x, t.context2d.posY = this.opt.y, t.context2d.margin = this.opt.margin, t.context2d.fontFaces = n, n) for (var a = 0; a < n.length; ++a) {
				var o = n[a], s = o.src.find(function(e) {
					return e.format === "truetype";
				});
				s && t.addFont(s.url, o.ref.name, o.ref.style);
			}
			return i.windowHeight = i.windowHeight || 0, i.windowHeight = i.windowHeight == 0 ? Math.max(this.prop.container.clientHeight, this.prop.container.scrollHeight, this.prop.container.offsetHeight) : i.windowHeight, t.context2d.save(!0), e(this.prop.container, i);
		}).then(function(e) {
			this.opt.jsPDF.context2d.restore(!0), (this.opt.html2canvas.onrendered || function() {})(e), this.prop.canvas = e, document.body.removeChild(this.prop.overlay);
		});
	}, c.prototype.toImg = function() {
		return this.thenList([function() {
			return this.prop.canvas || this.toCanvas();
		}]).then(function() {
			var e = this.prop.canvas.toDataURL("image/" + this.opt.image.type, this.opt.image.quality);
			this.prop.img = document.createElement("img"), this.prop.img.src = e;
		});
	}, c.prototype.toPdf = function() {
		return this.thenList([function() {
			return this.toContext2d();
		}]).then(function() {
			this.prop.pdf = this.prop.pdf || this.opt.jsPDF;
		});
	}, c.prototype.output = function(e, t, n) {
		return (n ||= "pdf").toLowerCase() === "img" || n.toLowerCase() === "image" ? this.outputImg(e, t) : this.outputPdf(e, t);
	}, c.prototype.outputPdf = function(e, t) {
		return this.thenList([function() {
			return this.prop.pdf || this.toPdf();
		}]).then(function() {
			return this.prop.pdf.output(e, t);
		});
	}, c.prototype.outputImg = function(e) {
		return this.thenList([function() {
			return this.prop.img || this.toImg();
		}]).then(function() {
			switch (e) {
				case void 0:
				case "img": return this.prop.img;
				case "datauristring":
				case "dataurlstring": return this.prop.img.src;
				case "datauri":
				case "dataurl": return document.location.href = this.prop.img.src;
				default: throw "Image output type \"" + e + "\" is not supported.";
			}
		});
	}, c.prototype.save = function(e) {
		return this.thenList([function() {
			return this.prop.pdf || this.toPdf();
		}]).set(e ? { filename: e } : null).then(function() {
			this.prop.pdf.save(this.opt.filename);
		});
	}, c.prototype.doCallback = function() {
		return this.thenList([function() {
			return this.prop.pdf || this.toPdf();
		}]).then(function() {
			this.prop.callback(this.prop.pdf);
		});
	}, c.prototype.set = function(e) {
		if (a(e) !== "object") return this;
		var t = Object.keys(e || {}).map(function(t) {
			if (t in c.template.prop) return function() {
				this.prop[t] = e[t];
			};
			switch (t) {
				case "margin": return this.setMargin.bind(this, e.margin);
				case "jsPDF": return function() {
					return this.opt.jsPDF = e.jsPDF, this.setPageSize();
				};
				case "pageSize": return this.setPageSize.bind(this, e.pageSize);
				default: return function() {
					this.opt[t] = e[t];
				};
			}
		}, this);
		return this.then(function() {
			return this.thenList(t);
		});
	}, c.prototype.get = function(e, t) {
		return this.then(function() {
			var n = e in c.template.prop ? this.prop[e] : this.opt[e];
			return t ? t(n) : n;
		});
	}, c.prototype.setMargin = function(e) {
		return this.then(function() {
			switch (a(e)) {
				case "number": e = [
					e,
					e,
					e,
					e
				];
				case "array": if (e.length === 2 && (e = [
					e[0],
					e[1],
					e[0],
					e[1]
				]), e.length === 4) break;
				default: return this.error("Invalid margin array.");
			}
			this.opt.margin = e;
		}).then(this.setPageSize);
	}, c.prototype.setPageSize = function(e) {
		function t(e, t) {
			return Math.floor(e * t / 72 * 96);
		}
		return this.then(function() {
			(e ||= Z.getPageSize(this.opt.jsPDF)).hasOwnProperty("inner") || (e.inner = {
				width: e.width - this.opt.margin[1] - this.opt.margin[3],
				height: e.height - this.opt.margin[0] - this.opt.margin[2]
			}, e.inner.px = {
				width: t(e.inner.width, e.k),
				height: t(e.inner.height, e.k)
			}, e.inner.ratio = e.inner.height / e.inner.width), this.prop.pageSize = e;
		});
	}, c.prototype.setProgress = function(e, t, n, r) {
		return e != null && (this.progress.val = e), t != null && (this.progress.state = t), n != null && (this.progress.n = n), r != null && (this.progress.stack = r), this.progress.ratio = this.progress.val / this.progress.state, this;
	}, c.prototype.updateProgress = function(e, t, n, r) {
		return this.setProgress(e ? this.progress.val + e : null, t || null, n ? this.progress.n + n : null, r ? this.progress.stack.concat(r) : null);
	}, c.prototype.then = function(e, t) {
		var n = this;
		return this.thenCore(e, t, function(e, t) {
			return n.updateProgress(null, null, 1, [e]), Promise.prototype.then.call(this, function(t) {
				return n.updateProgress(null, e), t;
			}).then(e, t).then(function(e) {
				return n.updateProgress(1), e;
			});
		});
	}, c.prototype.thenCore = function(e, t, n) {
		n ||= Promise.prototype.then;
		var r = this;
		e &&= e.bind(r), t &&= t.bind(r);
		var i = Promise.toString().indexOf("[native code]") !== -1 && Promise.name === "Promise" ? r : c.convert(Object.assign({}, r), Promise.prototype), a = n.call(i, e, t);
		return c.convert(a, r.__proto__);
	}, c.prototype.thenExternal = function(e, t) {
		return Promise.prototype.then.call(this, e, t);
	}, c.prototype.thenList = function(e) {
		var t = this;
		return e.forEach(function(e) {
			t = t.thenCore(e);
		}), t;
	}, c.prototype.catch = function(e) {
		e &&= e.bind(this);
		var t = Promise.prototype.catch.call(this, e);
		return c.convert(t, this);
	}, c.prototype.catchExternal = function(e) {
		return Promise.prototype.catch.call(this, e);
	}, c.prototype.error = function(e) {
		return this.then(function() {
			throw Error(e);
		});
	}, c.prototype.using = c.prototype.set, c.prototype.saveAs = c.prototype.save, c.prototype.export = c.prototype.output, c.prototype.run = c.prototype.then, Z.getPageSize = function(e, n, r) {
		if (t(e) === "object") {
			var i = e;
			e = i.orientation, n = i.unit || n, r = i.format || r;
		}
		n ||= "mm", r ||= "a4", e = ("" + (e || "P")).toLowerCase();
		var a, o = ("" + r).toLowerCase(), s = {
			a0: [2383.94, 3370.39],
			a1: [1683.78, 2383.94],
			a2: [1190.55, 1683.78],
			a3: [841.89, 1190.55],
			a4: [595.28, 841.89],
			a5: [419.53, 595.28],
			a6: [297.64, 419.53],
			a7: [209.76, 297.64],
			a8: [147.4, 209.76],
			a9: [104.88, 147.4],
			a10: [73.7, 104.88],
			b0: [2834.65, 4008.19],
			b1: [2004.09, 2834.65],
			b2: [1417.32, 2004.09],
			b3: [1000.63, 1417.32],
			b4: [708.66, 1000.63],
			b5: [498.9, 708.66],
			b6: [354.33, 498.9],
			b7: [249.45, 354.33],
			b8: [175.75, 249.45],
			b9: [124.72, 175.75],
			b10: [87.87, 124.72],
			c0: [2599.37, 3676.54],
			c1: [1836.85, 2599.37],
			c2: [1298.27, 1836.85],
			c3: [918.43, 1298.27],
			c4: [649.13, 918.43],
			c5: [459.21, 649.13],
			c6: [323.15, 459.21],
			c7: [229.61, 323.15],
			c8: [161.57, 229.61],
			c9: [113.39, 161.57],
			c10: [79.37, 113.39],
			dl: [311.81, 623.62],
			letter: [612, 792],
			"government-letter": [576, 756],
			legal: [612, 1008],
			"junior-legal": [576, 360],
			ledger: [1224, 792],
			tabloid: [792, 1224],
			"credit-card": [153, 243]
		};
		switch (n) {
			case "pt":
				a = 1;
				break;
			case "mm":
				a = 72 / 25.4;
				break;
			case "cm":
				a = 72 / 2.54;
				break;
			case "in":
				a = 72;
				break;
			case "px":
				a = .75;
				break;
			case "pc":
			case "em":
				a = 12;
				break;
			case "ex":
				a = 6;
				break;
			default: throw "Invalid unit: " + n;
		}
		var c, l = 0, u = 0;
		if (s.hasOwnProperty(o)) l = s[o][1] / a, u = s[o][0] / a;
		else try {
			l = r[1], u = r[0];
		} catch {
			throw Error("Invalid format: " + r);
		}
		if (e === "p" || e === "portrait") e = "p", u > l && (c = u, u = l, l = c);
		else {
			if (e !== "l" && e !== "landscape") throw "Invalid orientation: " + e;
			e = "l", l > u && (c = u, u = l, l = c);
		}
		return {
			width: u,
			height: l,
			unit: n,
			k: a,
			orientation: e
		};
	}, n.html = function(e, t) {
		(t ||= {}).callback = t.callback || function() {}, t.html2canvas = t.html2canvas || {}, t.html2canvas.canvas = t.html2canvas.canvas || this.canvas, t.jsPDF = t.jsPDF || this, t.fontFaces = t.fontFaces ? t.fontFaces.map(Vs) : null;
		var n = new c(t);
		return t.worker ? n : n.from(e).doCallback();
	};
}(Z.API), Z.API.addJS = function(e) {
	var t, n, r = function(e) {
		for (var t = "", n = 0; n < e.length; n++) {
			var r = e[n];
			if (r === "(" || r === ")") {
				for (var i = 0, a = n - 1; a >= 0 && e[a] === "\\"; a--) i++;
				t += i % 2 == 0 ? "\\" + r : r;
			} else t += r;
		}
		return t;
	}(e);
	return this.internal.events.subscribe("postPutResources", function() {
		t = this.internal.newObject(), this.internal.out("<<"), this.internal.out("/Names [(EmbeddedJS) " + (t + 1) + " 0 R]"), this.internal.out(">>"), this.internal.out("endobj"), n = this.internal.newObject(), this.internal.out("<<"), this.internal.out("/S /JavaScript"), this.internal.out("/JS (" + r + ")"), this.internal.out(">>"), this.internal.out("endobj");
	}), this.internal.events.subscribe("putCatalog", function() {
		t !== void 0 && n !== void 0 && this.internal.out("/Names <</JavaScript " + t + " 0 R>>");
	}), this;
}, function(e) {
	var t;
	e.events.push(["postPutResources", function() {
		var e = this, n = /^(\d+) 0 obj$/;
		if (this.outline.root.children.length > 0) for (var r = e.outline.render().split(/\r\n/), i = 0; i < r.length; i++) {
			var a = r[i], o = n.exec(a);
			if (o != null) {
				var s = o[1];
				e.internal.newObjectDeferredBegin(s, !1);
			}
			e.internal.write(a);
		}
		if (this.outline.createNamedDestinations) {
			var c = this.internal.pages.length, l = [];
			for (i = 0; i < c; i++) {
				var u = e.internal.newObject();
				l.push(u);
				var d = e.internal.getPageInfo(i + 1);
				e.internal.write("<< /D[" + d.objId + " 0 R /XYZ null null null]>> endobj");
			}
			var f = e.internal.newObject();
			for (e.internal.write("<< /Names [ "), i = 0; i < l.length; i++) e.internal.write("(page_" + (i + 1) + ")" + l[i] + " 0 R");
			e.internal.write(" ] >>", "endobj"), t = e.internal.newObject(), e.internal.write("<< /Dests " + f + " 0 R"), e.internal.write(">>", "endobj");
		}
	}]), e.events.push(["putCatalog", function() {
		var e = this;
		e.outline.root.children.length > 0 && (e.internal.write("/Outlines", this.outline.makeRef(this.outline.root)), this.outline.createNamedDestinations && e.internal.write("/Names " + t + " 0 R"));
	}]), e.events.push(["initialized", function() {
		var e = this;
		e.outline = {
			createNamedDestinations: !1,
			root: { children: [] }
		}, e.outline.add = function(e, t, n) {
			var r = {
				title: t,
				options: n,
				children: []
			};
			return e ??= this.root, e.children.push(r), r;
		}, e.outline.render = function() {
			return this.ctx = {}, this.ctx.val = "", this.ctx.pdf = e, this.genIds_r(this.root), this.renderRoot(this.root), this.renderItems(this.root), this.ctx.val;
		}, e.outline.genIds_r = function(t) {
			t.id = e.internal.newObjectDeferred();
			for (var n = 0; n < t.children.length; n++) this.genIds_r(t.children[n]);
		}, e.outline.renderRoot = function(e) {
			this.objStart(e), this.line("/Type /Outlines"), e.children.length > 0 && (this.line("/First " + this.makeRef(e.children[0])), this.line("/Last " + this.makeRef(e.children[e.children.length - 1]))), this.line("/Count " + this.count_r({ count: 0 }, e)), this.objEnd();
		}, e.outline.renderItems = function(t) {
			for (var n = this.ctx.pdf.internal.getVerticalCoordinateString, r = 0; r < t.children.length; r++) {
				var i = t.children[r];
				this.objStart(i), this.line("/Title " + this.makeString(i.title)), this.line("/Parent " + this.makeRef(t)), r > 0 && this.line("/Prev " + this.makeRef(t.children[r - 1])), r < t.children.length - 1 && this.line("/Next " + this.makeRef(t.children[r + 1])), i.children.length > 0 && (this.line("/First " + this.makeRef(i.children[0])), this.line("/Last " + this.makeRef(i.children[i.children.length - 1])));
				var a = this.count = this.count_r({ count: 0 }, i);
				if (a > 0 && this.line("/Count " + a), i.options && i.options.pageNumber) {
					var o = e.internal.getPageInfo(i.options.pageNumber);
					this.line("/Dest [" + o.objId + " 0 R /XYZ 0 " + n(0) + " 0]");
				}
				this.objEnd();
			}
			for (var s = 0; s < t.children.length; s++) this.renderItems(t.children[s]);
		}, e.outline.line = function(e) {
			this.ctx.val += e + "\r\n";
		}, e.outline.makeRef = function(e) {
			return e.id + " 0 R";
		}, e.outline.makeString = function(t) {
			return "(" + e.internal.pdfEscape(t) + ")";
		}, e.outline.objStart = function(e) {
			this.ctx.val += "\r\n" + e.id + " 0 obj\r\n<<\r\n";
		}, e.outline.objEnd = function() {
			this.ctx.val += ">> \r\nendobj\r\n";
		}, e.outline.count_r = function(e, t) {
			for (var n = 0; n < t.children.length; n++) e.count++, this.count_r(e, t.children[n]);
			return e.count;
		};
	}]);
}(Z.API), function(e) {
	var t = [
		192,
		193,
		194,
		195,
		196,
		197,
		198,
		199
	];
	e.processJPEG = function(e, n, r, i, a, o) {
		var s, c = this.decode.DCT_DECODE, l = null;
		if (typeof e == "string" || this.__addimage__.isArrayBuffer(e) || this.__addimage__.isArrayBufferView(e)) {
			switch (e = a || e, e = this.__addimage__.isArrayBuffer(e) ? new Uint8Array(e) : e, s = function(e) {
				for (var n, r = 256 * e.charCodeAt(4) + e.charCodeAt(5), i = e.length, a = {
					width: 0,
					height: 0,
					numcomponents: 1
				}, o = 4; o < i; o += 2) {
					if (o += r, t.indexOf(e.charCodeAt(o + 1)) !== -1) {
						n = 256 * e.charCodeAt(o + 5) + e.charCodeAt(o + 6), a = {
							width: 256 * e.charCodeAt(o + 7) + e.charCodeAt(o + 8),
							height: n,
							numcomponents: e.charCodeAt(o + 9)
						};
						break;
					}
					r = 256 * e.charCodeAt(o + 2) + e.charCodeAt(o + 3);
				}
				return a;
			}(e = this.__addimage__.isArrayBufferView(e) ? this.__addimage__.arrayBufferToBinaryString(e) : e), s.numcomponents) {
				case 1:
					o = this.color_spaces.DEVICE_GRAY;
					break;
				case 4:
					o = this.color_spaces.DEVICE_CMYK;
					break;
				case 3: o = this.color_spaces.DEVICE_RGB;
			}
			l = {
				data: e,
				width: s.width,
				height: s.height,
				colorSpace: o,
				bitsPerComponent: 8,
				filter: c,
				index: n,
				alias: r
			};
		}
		return l;
	};
}(Z.API), Z.API.processPNG = function(e, t, n, r) {
	if (this.__addimage__.isArrayBuffer(e) && (e = new Uint8Array(e)), this.__addimage__.isArrayBufferView(e)) {
		var i, a = go(e, { checkCrc: !0 }), o = a.width, s = a.height, c = a.channels, l = a.palette, u = a.depth;
		i = l && c === 1 ? function(e) {
			for (var t = e.width, n = e.height, r = e.data, i = e.palette, a = e.depth, o = !1, s = [], c = [], l = void 0, u = !1, d = 0, f = 0; f < i.length; f++) {
				var p = je(i[f], 4), m = p[0], h = p[1], g = p[2], _ = p[3];
				s.push(m, h, g), _ != null && (_ === 0 ? (d++, c.length < 1 && c.push(f)) : _ < 255 && (u = !0));
			}
			if (u || d > 1) {
				o = !0, c = void 0;
				var v = t * n;
				l = new Uint8Array(v);
				for (var y = new DataView(r.buffer), b = 0; b < v; b++) {
					var x = je(i[lc(y, b, a)], 4)[3];
					l[b] = x;
				}
			} else d === 0 && (c = void 0);
			return {
				colorSpace: "Indexed",
				colorsPerPixel: 1,
				sMaskBitsPerComponent: o ? 8 : void 0,
				colorBytes: r,
				alphaBytes: l,
				needSMask: o,
				palette: s,
				mask: c
			};
		}(a) : c === 2 || c === 4 ? function(e) {
			for (var t = e.data, n = e.width, r = e.height, i = e.channels, a = e.depth, o = i === 2 ? "DeviceGray" : "DeviceRGB", s = i - 1, c = n * r, l = s, u = c * l, d = 1 * c, f = Math.ceil(u * a / 8), p = Math.ceil(d * a / 8), m = new Uint8Array(f), h = new Uint8Array(p), g = new DataView(t.buffer), _ = new DataView(m.buffer), v = new DataView(h.buffer), y = !1, b = 0; b < c; b++) {
				for (var x = b * i, S = 0; S < l; S++) uc(_, lc(g, x + S, a), b * l + S, a);
				var C = lc(g, x + l, a);
				C < (1 << a) - 1 && (y = !0), uc(v, C, 1 * b, a);
			}
			return {
				colorSpace: o,
				colorsPerPixel: s,
				sMaskBitsPerComponent: y ? a : void 0,
				colorBytes: m,
				alphaBytes: h,
				needSMask: y
			};
		}(a) : function(e) {
			var t = e.data, n = e.channels === 1 ? "DeviceGray" : "DeviceRGB";
			return {
				colorSpace: n,
				colorsPerPixel: n === "DeviceGray" ? 1 : 3,
				colorBytes: t instanceof Uint16Array ? function(e) {
					for (var t = e.length, n = new Uint8Array(2 * t), r = new DataView(n.buffer, n.byteOffset, n.byteLength), i = 0; i < t; i++) r.setUint16(2 * i, e[i], !1);
					return n;
				}(t) : t,
				needSMask: !1
			};
		}(a);
		var d, f, p, m = i, h = m.colorSpace, g = m.colorsPerPixel, _ = m.sMaskBitsPerComponent, v = m.colorBytes, y = m.alphaBytes, b = m.needSMask, x = m.palette, S = m.mask, C = null;
		return r !== Z.API.image_compression.NONE && typeof we == "function" ? (C = function(e) {
			var t;
			switch (e) {
				case Z.API.image_compression.FAST:
					t = 11;
					break;
				case Z.API.image_compression.MEDIUM:
					t = 13;
					break;
				case Z.API.image_compression.SLOW:
					t = 14;
					break;
				default: t = 12;
			}
			return t;
		}(r), d = this.decode.FLATE_DECODE, f = `/Predictor ${C} /Colors ${g} /BitsPerComponent ${u} /Columns ${o}`, e = tc(v, Math.ceil(o * g * u / 8), g, u, r), b && (p = tc(y, Math.ceil(o * _ / 8), 1, _, r))) : (d = void 0, f = void 0, e = v, b && (p = y)), (this.__addimage__.isArrayBuffer(e) || this.__addimage__.isArrayBufferView(e)) && (e = this.__addimage__.arrayBufferToBinaryString(e)), (p && this.__addimage__.isArrayBuffer(p) || this.__addimage__.isArrayBufferView(p)) && (p = this.__addimage__.arrayBufferToBinaryString(p)), {
			alias: n,
			data: e,
			index: t,
			filter: d,
			decodeParameters: f,
			transparency: S,
			palette: x,
			sMask: p,
			predictor: C,
			width: o,
			height: s,
			bitsPerComponent: u,
			sMaskBitsPerComponent: _,
			colorSpace: h
		};
	}
}, function(e) {
	e.processGIF89A = function(t, n, r, i) {
		var a = new fc(t), o = a.width, s = a.height, c = [];
		a.decodeAndBlitFrameRGBA(0, c);
		var l = {
			data: c,
			width: o,
			height: s
		}, u = new mc(100).encode(l, 100);
		return e.processJPEG.call(this, u, n, r, i);
	}, e.processGIF87A = e.processGIF89A;
}(Z.API), hc.prototype.parseHeader = function() {
	if (this.fileSize = this.datav.getUint32(this.pos, !0), this.pos += 4, this.reserved = this.datav.getUint32(this.pos, !0), this.pos += 4, this.offset = this.datav.getUint32(this.pos, !0), this.pos += 4, this.headerSize = this.datav.getUint32(this.pos, !0), this.pos += 4, this.width = this.datav.getUint32(this.pos, !0), this.pos += 4, this.height = this.datav.getInt32(this.pos, !0), this.pos += 4, this.planes = this.datav.getUint16(this.pos, !0), this.pos += 2, this.bitPP = this.datav.getUint16(this.pos, !0), this.pos += 2, this.compress = this.datav.getUint32(this.pos, !0), this.pos += 4, this.rawSize = this.datav.getUint32(this.pos, !0), this.pos += 4, this.hr = this.datav.getUint32(this.pos, !0), this.pos += 4, this.vr = this.datav.getUint32(this.pos, !0), this.pos += 4, this.colors = this.datav.getUint32(this.pos, !0), this.pos += 4, this.importantColors = this.datav.getUint32(this.pos, !0), this.pos += 4, this.bitPP === 16 && this.is_with_alpha && (this.bitPP = 15), this.bitPP < 15) {
		var e = this.colors === 0 ? 1 << this.bitPP : this.colors;
		this.palette = Array(e);
		for (var t = 0; t < e; t++) {
			var n = this.datav.getUint8(this.pos++, !0), r = this.datav.getUint8(this.pos++, !0), i = this.datav.getUint8(this.pos++, !0), a = this.datav.getUint8(this.pos++, !0);
			this.palette[t] = {
				red: i,
				green: r,
				blue: n,
				quad: a
			};
		}
	}
	this.height < 0 && (this.height *= -1, this.bottom_up = !1);
}, hc.prototype.parseBGR = function() {
	this.pos = this.offset;
	var e = "bit" + this.bitPP, t = this.width * this.height * 4;
	if (t > 536870912) throw Error("Image dimensions exceed 512MB, which is too large.");
	this.data = new Uint8Array(t);
	try {
		this[e]();
	} catch (e) {
		vo.log("bit decode error:" + e);
	}
}, hc.prototype.bit1 = function() {
	var e, t = Math.ceil(this.width / 8), n = t % 4;
	for (e = this.height - 1; e >= 0; e--) {
		for (var r = this.bottom_up ? e : this.height - 1 - e, i = 0; i < t; i++) for (var a = this.datav.getUint8(this.pos++, !0), o = r * this.width * 4 + 8 * i * 4, s = 0; s < 8 && 8 * i + s < this.width; s++) {
			var c = this.palette[a >> 7 - s & 1];
			this.data[o + 4 * s] = c.blue, this.data[o + 4 * s + 1] = c.green, this.data[o + 4 * s + 2] = c.red, this.data[o + 4 * s + 3] = 255;
		}
		n !== 0 && (this.pos += 4 - n);
	}
}, hc.prototype.bit4 = function() {
	for (var e = Math.ceil(this.width / 2), t = e % 4, n = this.height - 1; n >= 0; n--) {
		for (var r = this.bottom_up ? n : this.height - 1 - n, i = 0; i < e; i++) {
			var a = this.datav.getUint8(this.pos++, !0), o = r * this.width * 4 + 2 * i * 4, s = a >> 4, c = 15 & a, l = this.palette[s];
			if (this.data[o] = l.blue, this.data[o + 1] = l.green, this.data[o + 2] = l.red, this.data[o + 3] = 255, 2 * i + 1 >= this.width) break;
			l = this.palette[c], this.data[o + 4] = l.blue, this.data[o + 4 + 1] = l.green, this.data[o + 4 + 2] = l.red, this.data[o + 4 + 3] = 255;
		}
		t !== 0 && (this.pos += 4 - t);
	}
}, hc.prototype.bit8 = function() {
	for (var e = this.width % 4, t = this.height - 1; t >= 0; t--) {
		for (var n = this.bottom_up ? t : this.height - 1 - t, r = 0; r < this.width; r++) {
			var i = this.datav.getUint8(this.pos++, !0), a = n * this.width * 4 + 4 * r;
			if (i < this.palette.length) {
				var o = this.palette[i];
				this.data[a] = o.red, this.data[a + 1] = o.green, this.data[a + 2] = o.blue, this.data[a + 3] = 255;
			} else this.data[a] = 255, this.data[a + 1] = 255, this.data[a + 2] = 255, this.data[a + 3] = 255;
		}
		e !== 0 && (this.pos += 4 - e);
	}
}, hc.prototype.bit15 = function() {
	for (var e = this.width % 3, t = 31, n = this.height - 1; n >= 0; n--) {
		for (var r = this.bottom_up ? n : this.height - 1 - n, i = 0; i < this.width; i++) {
			var a = this.datav.getUint16(this.pos, !0);
			this.pos += 2;
			var o = (a & t) / t * 255 | 0, s = (a >> 5 & t) / t * 255 | 0, c = (a >> 10 & t) / t * 255 | 0, l = a >> 15 ? 255 : 0, u = r * this.width * 4 + 4 * i;
			this.data[u] = c, this.data[u + 1] = s, this.data[u + 2] = o, this.data[u + 3] = l;
		}
		this.pos += e;
	}
}, hc.prototype.bit16 = function() {
	for (var e = this.width % 3, t = 31, n = 63, r = this.height - 1; r >= 0; r--) {
		for (var i = this.bottom_up ? r : this.height - 1 - r, a = 0; a < this.width; a++) {
			var o = this.datav.getUint16(this.pos, !0);
			this.pos += 2;
			var s = (o & t) / t * 255 | 0, c = (o >> 5 & n) / n * 255 | 0, l = (o >> 11) / t * 255 | 0, u = i * this.width * 4 + 4 * a;
			this.data[u] = l, this.data[u + 1] = c, this.data[u + 2] = s, this.data[u + 3] = 255;
		}
		this.pos += e;
	}
}, hc.prototype.bit24 = function() {
	for (var e = this.height - 1; e >= 0; e--) {
		for (var t = this.bottom_up ? e : this.height - 1 - e, n = 0; n < this.width; n++) {
			var r = this.datav.getUint8(this.pos++, !0), i = this.datav.getUint8(this.pos++, !0), a = this.datav.getUint8(this.pos++, !0), o = t * this.width * 4 + 4 * n;
			this.data[o] = a, this.data[o + 1] = i, this.data[o + 2] = r, this.data[o + 3] = 255;
		}
		this.pos += this.width % 4;
	}
}, hc.prototype.bit32 = function() {
	for (var e = this.height - 1; e >= 0; e--) for (var t = this.bottom_up ? e : this.height - 1 - e, n = 0; n < this.width; n++) {
		var r = this.datav.getUint8(this.pos++, !0), i = this.datav.getUint8(this.pos++, !0), a = this.datav.getUint8(this.pos++, !0), o = this.datav.getUint8(this.pos++, !0), s = t * this.width * 4 + 4 * n;
		this.data[s] = a, this.data[s + 1] = i, this.data[s + 2] = r, this.data[s + 3] = o;
	}
}, hc.prototype.getData = function() {
	return this.data;
}, function(e) {
	e.processBMP = function(t, n, r, i) {
		var a = new hc(t, !1), o = a.width, s = a.height, c = {
			data: a.getData(),
			width: o,
			height: s
		}, l = new mc(100).encode(c, 100);
		return e.processJPEG.call(this, l, n, r, i);
	};
}(Z.API), gc.prototype.getData = function() {
	return this.data;
}, function(e) {
	e.processWEBP = function(t, n, r, i) {
		var a = new gc(t), o = a.width, s = a.height, c = {
			data: a.getData(),
			width: o,
			height: s
		}, l = new mc(100).encode(c, 100);
		return e.processJPEG.call(this, l, n, r, i);
	};
}(Z.API), Z.API.processRGBA = function(e, t, n) {
	for (var r = e.data, i = r.length, a = new Uint8Array(i / 4 * 3), o = new Uint8Array(i / 4), s = 0, c = 0, l = 0; l < i; l += 4) {
		var u = r[l], d = r[l + 1], f = r[l + 2], p = r[l + 3];
		a[s++] = u, a[s++] = d, a[s++] = f, o[c++] = p;
	}
	var m = this.__addimage__.arrayBufferToBinaryString(a);
	return {
		alpha: this.__addimage__.arrayBufferToBinaryString(o),
		data: m,
		index: t,
		alias: n,
		colorSpace: "DeviceRGB",
		bitsPerComponent: 8,
		width: e.width,
		height: e.height
	};
}, Z.API.setLanguage = function(e) {
	return this.internal.languageSettings === void 0 && (this.internal.languageSettings = {}, this.internal.languageSettings.isSubscribed = !1), {
		af: "Afrikaans",
		sq: "Albanian",
		ar: "Arabic (Standard)",
		"ar-DZ": "Arabic (Algeria)",
		"ar-BH": "Arabic (Bahrain)",
		"ar-EG": "Arabic (Egypt)",
		"ar-IQ": "Arabic (Iraq)",
		"ar-JO": "Arabic (Jordan)",
		"ar-KW": "Arabic (Kuwait)",
		"ar-LB": "Arabic (Lebanon)",
		"ar-LY": "Arabic (Libya)",
		"ar-MA": "Arabic (Morocco)",
		"ar-OM": "Arabic (Oman)",
		"ar-QA": "Arabic (Qatar)",
		"ar-SA": "Arabic (Saudi Arabia)",
		"ar-SY": "Arabic (Syria)",
		"ar-TN": "Arabic (Tunisia)",
		"ar-AE": "Arabic (U.A.E.)",
		"ar-YE": "Arabic (Yemen)",
		an: "Aragonese",
		hy: "Armenian",
		as: "Assamese",
		ast: "Asturian",
		az: "Azerbaijani",
		eu: "Basque",
		be: "Belarusian",
		bn: "Bengali",
		bs: "Bosnian",
		br: "Breton",
		bg: "Bulgarian",
		my: "Burmese",
		ca: "Catalan",
		ch: "Chamorro",
		ce: "Chechen",
		zh: "Chinese",
		"zh-HK": "Chinese (Hong Kong)",
		"zh-CN": "Chinese (PRC)",
		"zh-SG": "Chinese (Singapore)",
		"zh-TW": "Chinese (Taiwan)",
		cv: "Chuvash",
		co: "Corsican",
		cr: "Cree",
		hr: "Croatian",
		cs: "Czech",
		da: "Danish",
		nl: "Dutch (Standard)",
		"nl-BE": "Dutch (Belgian)",
		en: "English",
		"en-AU": "English (Australia)",
		"en-BZ": "English (Belize)",
		"en-CA": "English (Canada)",
		"en-IE": "English (Ireland)",
		"en-JM": "English (Jamaica)",
		"en-NZ": "English (New Zealand)",
		"en-PH": "English (Philippines)",
		"en-ZA": "English (South Africa)",
		"en-TT": "English (Trinidad & Tobago)",
		"en-GB": "English (United Kingdom)",
		"en-US": "English (United States)",
		"en-ZW": "English (Zimbabwe)",
		eo: "Esperanto",
		et: "Estonian",
		fo: "Faeroese",
		fj: "Fijian",
		fi: "Finnish",
		fr: "French (Standard)",
		"fr-BE": "French (Belgium)",
		"fr-CA": "French (Canada)",
		"fr-FR": "French (France)",
		"fr-LU": "French (Luxembourg)",
		"fr-MC": "French (Monaco)",
		"fr-CH": "French (Switzerland)",
		fy: "Frisian",
		fur: "Friulian",
		gd: "Gaelic (Scots)",
		"gd-IE": "Gaelic (Irish)",
		gl: "Galacian",
		ka: "Georgian",
		de: "German (Standard)",
		"de-AT": "German (Austria)",
		"de-DE": "German (Germany)",
		"de-LI": "German (Liechtenstein)",
		"de-LU": "German (Luxembourg)",
		"de-CH": "German (Switzerland)",
		el: "Greek",
		gu: "Gujurati",
		ht: "Haitian",
		he: "Hebrew",
		hi: "Hindi",
		hu: "Hungarian",
		is: "Icelandic",
		id: "Indonesian",
		iu: "Inuktitut",
		ga: "Irish",
		it: "Italian (Standard)",
		"it-CH": "Italian (Switzerland)",
		ja: "Japanese",
		kn: "Kannada",
		ks: "Kashmiri",
		kk: "Kazakh",
		km: "Khmer",
		ky: "Kirghiz",
		tlh: "Klingon",
		ko: "Korean",
		"ko-KP": "Korean (North Korea)",
		"ko-KR": "Korean (South Korea)",
		la: "Latin",
		lv: "Latvian",
		lt: "Lithuanian",
		lb: "Luxembourgish",
		mk: "North Macedonia",
		ms: "Malay",
		ml: "Malayalam",
		mt: "Maltese",
		mi: "Maori",
		mr: "Marathi",
		mo: "Moldavian",
		nv: "Navajo",
		ng: "Ndonga",
		ne: "Nepali",
		no: "Norwegian",
		nb: "Norwegian (Bokmal)",
		nn: "Norwegian (Nynorsk)",
		oc: "Occitan",
		or: "Oriya",
		om: "Oromo",
		fa: "Persian",
		"fa-IR": "Persian/Iran",
		pl: "Polish",
		pt: "Portuguese",
		"pt-BR": "Portuguese (Brazil)",
		pa: "Punjabi",
		"pa-IN": "Punjabi (India)",
		"pa-PK": "Punjabi (Pakistan)",
		qu: "Quechua",
		rm: "Rhaeto-Romanic",
		ro: "Romanian",
		"ro-MO": "Romanian (Moldavia)",
		ru: "Russian",
		"ru-MO": "Russian (Moldavia)",
		sz: "Sami (Lappish)",
		sg: "Sango",
		sa: "Sanskrit",
		sc: "Sardinian",
		sd: "Sindhi",
		si: "Singhalese",
		sr: "Serbian",
		sk: "Slovak",
		sl: "Slovenian",
		so: "Somani",
		sb: "Sorbian",
		es: "Spanish",
		"es-AR": "Spanish (Argentina)",
		"es-BO": "Spanish (Bolivia)",
		"es-CL": "Spanish (Chile)",
		"es-CO": "Spanish (Colombia)",
		"es-CR": "Spanish (Costa Rica)",
		"es-DO": "Spanish (Dominican Republic)",
		"es-EC": "Spanish (Ecuador)",
		"es-SV": "Spanish (El Salvador)",
		"es-GT": "Spanish (Guatemala)",
		"es-HN": "Spanish (Honduras)",
		"es-MX": "Spanish (Mexico)",
		"es-NI": "Spanish (Nicaragua)",
		"es-PA": "Spanish (Panama)",
		"es-PY": "Spanish (Paraguay)",
		"es-PE": "Spanish (Peru)",
		"es-PR": "Spanish (Puerto Rico)",
		"es-ES": "Spanish (Spain)",
		"es-UY": "Spanish (Uruguay)",
		"es-VE": "Spanish (Venezuela)",
		sx: "Sutu",
		sw: "Swahili",
		sv: "Swedish",
		"sv-FI": "Swedish (Finland)",
		"sv-SV": "Swedish (Sweden)",
		ta: "Tamil",
		tt: "Tatar",
		te: "Teluga",
		th: "Thai",
		tig: "Tigre",
		ts: "Tsonga",
		tn: "Tswana",
		tr: "Turkish",
		tk: "Turkmen",
		uk: "Ukrainian",
		hsb: "Upper Sorbian",
		ur: "Urdu",
		ve: "Venda",
		vi: "Vietnamese",
		vo: "Volapuk",
		wa: "Walloon",
		cy: "Welsh",
		xh: "Xhosa",
		ji: "Yiddish",
		zu: "Zulu"
	}[e] !== void 0 && (this.internal.languageSettings.languageCode = e, !1 === this.internal.languageSettings.isSubscribed && (this.internal.events.subscribe("putCatalog", function() {
		this.internal.write("/Lang (" + this.internal.languageSettings.languageCode + ")");
	}), this.internal.languageSettings.isSubscribed = !0)), this;
}, Ys = Z.API, Xs = Ys.getCharWidthsArray = function(e, n) {
	var r, i, a = (n ||= {}).font || this.internal.getFont(), o = n.fontSize || this.internal.getFontSize(), s = n.charSpace || this.internal.getCharSpace(), c = n.widths ? n.widths : a.metadata.Unicode.widths, l = c.fof ? c.fof : 1, u = n.kerning ? n.kerning : a.metadata.Unicode.kerning, d = u.fof ? u.fof : 1, f = !1 !== n.doKerning, p = 0, m = e.length, h = 0, g = c[0] || l, _ = [];
	for (r = 0; r < m; r++) i = e.charCodeAt(r), typeof a.metadata.widthOfString == "function" ? _.push((a.metadata.widthOfGlyph(a.metadata.characterToGlyph(i)) + 1e3 / o * s || 0) / 1e3) : (p = f && t(u[i]) === "object" && !isNaN(parseInt(u[i][h], 10)) ? u[i][h] / d : 0, _.push((c[i] || g) / l + p)), h = i;
	return _;
}, Zs = Ys.getStringUnitWidth = function(e, t) {
	var n = (t ||= {}).fontSize || this.internal.getFontSize(), r = t.font || this.internal.getFont(), i = t.charSpace || this.internal.getCharSpace();
	return Ys.processArabic && (e = Ys.processArabic(e)), typeof r.metadata.widthOfString == "function" ? r.metadata.widthOfString(e, n, i) / n : Xs.apply(this, arguments).reduce(function(e, t) {
		return e + t;
	}, 0);
}, Qs = function(e, t, n, r) {
	for (var i = [], a = 0, o = e.length, s = 0; a !== o && s + t[a] < n;) s += t[a], a++;
	i.push(e.slice(0, a));
	var c = a;
	for (s = 0; a !== o;) s + t[a] > r && (i.push(e.slice(c, a)), s = 0, c = a), s += t[a], a++;
	return c !== a && i.push(e.slice(c, a)), i;
}, $s = function(e, t, n) {
	n ||= {};
	var r, i, a, o, s, c, l, u = [], d = [u], f = n.textIndent || 0, p = 0, m = 0, h = e.split(" "), g = Xs.apply(this, [" ", n])[0];
	if (c = n.lineIndent === -1 ? h[0].length + 2 : n.lineIndent || 0) {
		var _ = Array(c).join(" "), v = [];
		h.map(function(e) {
			(e = e.split(/\s*\n/)).length > 1 ? v = v.concat(e.map(function(e, t) {
				return (t && e.length ? "\n" : "") + e;
			})) : v.push(e[0]);
		}), h = v, c = Zs.apply(this, [_, n]);
	}
	for (a = 0, o = h.length; a < o; a++) {
		var y = 0;
		if (r = h[a], c && r[0] == "\n" && (r = r.substr(1), y = 1), f + p + (m = (i = Xs.apply(this, [r, n])).reduce(function(e, t) {
			return e + t;
		}, 0)) > t || y) {
			if (m > t) {
				for (s = Qs.apply(this, [
					r,
					i,
					t - (f + p),
					t
				]), u.push(s.shift()), u = [s.pop()]; s.length;) d.push([s.shift()]);
				m = i.slice(r.length - (u[0] ? u[0].length : 0)).reduce(function(e, t) {
					return e + t;
				}, 0);
			} else u = [r];
			d.push(u), f = m + c, p = g;
		} else u.push(r), f += p + m, p = g;
	}
	return l = c ? function(e, t) {
		return (t ? _ : "") + e.join(" ");
	} : function(e) {
		return e.join(" ");
	}, d.map(l);
}, Ys.splitTextToSize = function(e, t, n) {
	var r, i = (n ||= {}).fontSize || this.internal.getFontSize(), a = function(e) {
		if (e.widths && e.kerning) return {
			widths: e.widths,
			kerning: e.kerning
		};
		var t = this.internal.getFont(e.fontName, e.fontStyle), n = "Unicode";
		return t.metadata[n] ? {
			widths: t.metadata[n].widths || { 0: 1 },
			kerning: t.metadata[n].kerning || {}
		} : {
			font: t.metadata,
			fontSize: this.internal.getFontSize(),
			charSpace: this.internal.getCharSpace()
		};
	}.call(this, n);
	r = Array.isArray(e) ? e : String(e).split(/\r?\n/);
	var o = 1 * this.internal.scaleFactor * t / i;
	a.textIndent = n.textIndent ? 1 * n.textIndent * this.internal.scaleFactor / i : 0, a.lineIndent = n.lineIndent;
	var s, c, l = [];
	for (s = 0, c = r.length; s < c; s++) l = l.concat($s.apply(this, [
		r[s],
		o,
		a
	]));
	return l;
}, function(e) {
	e.__fontmetrics__ = e.__fontmetrics__ || {};
	for (var n = "0123456789abcdef", r = "klmnopqrstuvwxyz", i = {}, a = {}, o = 0; o < 16; o++) i[r[o]] = n[o], a[n[o]] = r[o];
	var s = function(e) {
		return "0x" + parseInt(e, 10).toString(16);
	}, c = e.__fontmetrics__.compress = function(e) {
		var n, r, i, o, l = ["{"];
		for (var u in e) {
			if (n = e[u], isNaN(parseInt(u, 10)) ? r = "'" + u + "'" : (u = parseInt(u, 10), r = (r = s(u).slice(2)).slice(0, -1) + a[r.slice(-1)]), typeof n == "number") n < 0 ? (i = s(n).slice(3), o = "-") : (i = s(n).slice(2), o = ""), i = o + i.slice(0, -1) + a[i.slice(-1)];
			else {
				if (t(n) !== "object") throw Error("Don't know what to do with value type " + t(n) + ".");
				i = c(n);
			}
			l.push(r + i);
		}
		return l.push("}"), l.join("");
	}, l = e.__fontmetrics__.uncompress = function(e) {
		if (typeof e != "string") throw Error("Invalid argument passed to uncompress.");
		for (var t, n, r, a, o = {}, s = 1, c = o, l = [], u = "", d = "", f = e.length - 1, p = 1; p < f; p += 1) (a = e[p]) == "'" ? t ? (r = t.join(""), t = void 0) : t = [] : t ? t.push(a) : a == "{" ? (l.push([c, r]), c = {}, r = void 0) : a == "}" ? ((n = l.pop())[0][n[1]] = c, r = void 0, c = n[0]) : a == "-" ? s = -1 : r === void 0 ? i.hasOwnProperty(a) ? (u += i[a], r = parseInt(u, 16) * s, s = 1, u = "") : u += a : i.hasOwnProperty(a) ? (d += i[a], c[r] = parseInt(d, 16) * s, s = 1, r = void 0, d = "") : d += a;
		return o;
	}, u = {
		codePages: ["WinAnsiEncoding"],
		WinAnsiEncoding: l("{19m8n201n9q201o9r201s9l201t9m201u8m201w9n201x9o201y8o202k8q202l8r202m9p202q8p20aw8k203k8t203t8v203u9v2cq8s212m9t15m8w15n9w2dw9s16k8u16l9u17s9z17x8y17y9y}")
	}, d = { Unicode: {
		Courier: u,
		"Courier-Bold": u,
		"Courier-BoldOblique": u,
		"Courier-Oblique": u,
		Helvetica: u,
		"Helvetica-Bold": u,
		"Helvetica-BoldOblique": u,
		"Helvetica-Oblique": u,
		"Times-Roman": u,
		"Times-Bold": u,
		"Times-BoldItalic": u,
		"Times-Italic": u
	} }, f = { Unicode: {
		"Courier-Oblique": l("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"),
		"Times-BoldItalic": l("{'widths'{k3o2q4ycx2r201n3m201o6o201s2l201t2l201u2l201w3m201x3m201y3m2k1t2l2r202m2n2n3m2o3m2p5n202q6o2r1w2s2l2t2l2u3m2v3t2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w3t3x3t3y3t3z3m4k5n4l4m4m4m4n4m4o4s4p4m4q4m4r4s4s4y4t2r4u3m4v4m4w3x4x5t4y4s4z4s5k3x5l4s5m4m5n3r5o3x5p4s5q4m5r5t5s4m5t3x5u3x5v2l5w1w5x2l5y3t5z3m6k2l6l3m6m3m6n2w6o3m6p2w6q2l6r3m6s3r6t1w6u1w6v3m6w1w6x4y6y3r6z3m7k3m7l3m7m2r7n2r7o1w7p3r7q2w7r4m7s3m7t2w7u2r7v2n7w1q7x2n7y3t202l3mcl4mal2ram3man3mao3map3mar3mas2lat4uau1uav3maw3way4uaz2lbk2sbl3t'fof'6obo2lbp3tbq3mbr1tbs2lbu1ybv3mbz3mck4m202k3mcm4mcn4mco4mcp4mcq5ycr4mcs4mct4mcu4mcv4mcw2r2m3rcy2rcz2rdl4sdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek3mel3mem3men3meo3mep3meq4ser2wes2wet2weu2wev2wew1wex1wey1wez1wfl3rfm3mfn3mfo3mfp3mfq3mfr3tfs3mft3rfu3rfv3rfw3rfz2w203k6o212m6o2dw2l2cq2l3t3m3u2l17s3x19m3m}'kerning'{cl{4qu5kt5qt5rs17ss5ts}201s{201ss}201t{cks4lscmscnscoscpscls2wu2yu201ts}201x{2wu2yu}2k{201ts}2w{4qx5kx5ou5qx5rs17su5tu}2x{17su5tu5ou}2y{4qx5kx5ou5qx5rs17ss5ts}'fof'-6ofn{17sw5tw5ou5qw5rs}7t{cksclscmscnscoscps4ls}3u{17su5tu5os5qs}3v{17su5tu5os5qs}7p{17su5tu}ck{4qu5kt5qt5rs17ss5ts}4l{4qu5kt5qt5rs17ss5ts}cm{4qu5kt5qt5rs17ss5ts}cn{4qu5kt5qt5rs17ss5ts}co{4qu5kt5qt5rs17ss5ts}cp{4qu5kt5qt5rs17ss5ts}6l{4qu5ou5qw5rt17su5tu}5q{ckuclucmucnucoucpu4lu}5r{ckuclucmucnucoucpu4lu}7q{cksclscmscnscoscps4ls}6p{4qu5ou5qw5rt17sw5tw}ek{4qu5ou5qw5rt17su5tu}el{4qu5ou5qw5rt17su5tu}em{4qu5ou5qw5rt17su5tu}en{4qu5ou5qw5rt17su5tu}eo{4qu5ou5qw5rt17su5tu}ep{4qu5ou5qw5rt17su5tu}es{17ss5ts5qs4qu}et{4qu5ou5qw5rt17sw5tw}eu{4qu5ou5qw5rt17ss5ts}ev{17ss5ts5qs4qu}6z{17sw5tw5ou5qw5rs}fm{17sw5tw5ou5qw5rs}7n{201ts}fo{17sw5tw5ou5qw5rs}fp{17sw5tw5ou5qw5rs}fq{17sw5tw5ou5qw5rs}7r{cksclscmscnscoscps4ls}fs{17sw5tw5ou5qw5rs}ft{17su5tu}fu{17su5tu}fv{17su5tu}fw{17su5tu}fz{cksclscmscnscoscps4ls}}}"),
		"Helvetica-Bold": l("{'widths'{k3s2q4scx1w201n3r201o6o201s1w201t1w201u1w201w3m201x3m201y3m2k1w2l2l202m2n2n3r2o3r2p5t202q6o2r1s2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v2l3w3u3x3u3y3u3z3x4k6l4l4s4m4s4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3r4v4s4w3x4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v2l5w1w5x2l5y3u5z3r6k2l6l3r6m3x6n3r6o3x6p3r6q2l6r3x6s3x6t1w6u1w6v3r6w1w6x5t6y3x6z3x7k3x7l3x7m2r7n3r7o2l7p3x7q3r7r4y7s3r7t3r7u3m7v2r7w1w7x2r7y3u202l3rcl4sal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3xbq3rbr1wbs2lbu2obv3rbz3xck4s202k3rcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw1w2m2zcy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3res3ret3reu3rev3rew1wex1wey1wez1wfl3xfm3xfn3xfo3xfp3xfq3xfr3ufs3xft3xfu3xfv3xfw3xfz3r203k6o212m6o2dw2l2cq2l3t3r3u2l17s4m19m3r}'kerning'{cl{4qs5ku5ot5qs17sv5tv}201t{2ww4wy2yw}201w{2ks}201x{2ww4wy2yw}2k{201ts201xs}2w{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}2x{5ow5qs}2y{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}'fof'-6o7p{17su5tu5ot}ck{4qs5ku5ot5qs17sv5tv}4l{4qs5ku5ot5qs17sv5tv}cm{4qs5ku5ot5qs17sv5tv}cn{4qs5ku5ot5qs17sv5tv}co{4qs5ku5ot5qs17sv5tv}cp{4qs5ku5ot5qs17sv5tv}6l{17st5tt5os}17s{2kwclvcmvcnvcovcpv4lv4wwckv}5o{2kucltcmtcntcotcpt4lt4wtckt}5q{2ksclscmscnscoscps4ls4wvcks}5r{2ks4ws}5t{2kwclvcmvcnvcovcpv4lv4wwckv}eo{17st5tt5os}fu{17su5tu5ot}6p{17ss5ts}ek{17st5tt5os}el{17st5tt5os}em{17st5tt5os}en{17st5tt5os}6o{201ts}ep{17st5tt5os}es{17ss5ts}et{17ss5ts}eu{17ss5ts}ev{17ss5ts}6z{17su5tu5os5qt}fm{17su5tu5os5qt}fn{17su5tu5os5qt}fo{17su5tu5os5qt}fp{17su5tu5os5qt}fq{17su5tu5os5qt}fs{17su5tu5os5qt}ft{17su5tu5ot}7m{5os}fv{17su5tu5ot}fw{17su5tu5ot}}}"),
		Courier: l("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"),
		"Courier-BoldOblique": l("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"),
		"Times-Bold": l("{'widths'{k3q2q5ncx2r201n3m201o6o201s2l201t2l201u2l201w3m201x3m201y3m2k1t2l2l202m2n2n3m2o3m2p6o202q6o2r1w2s2l2t2l2u3m2v3t2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w3t3x3t3y3t3z3m4k5x4l4s4m4m4n4s4o4s4p4m4q3x4r4y4s4y4t2r4u3m4v4y4w4m4x5y4y4s4z4y5k3x5l4y5m4s5n3r5o4m5p4s5q4s5r6o5s4s5t4s5u4m5v2l5w1w5x2l5y3u5z3m6k2l6l3m6m3r6n2w6o3r6p2w6q2l6r3m6s3r6t1w6u2l6v3r6w1w6x5n6y3r6z3m7k3r7l3r7m2w7n2r7o2l7p3r7q3m7r4s7s3m7t3m7u2w7v2r7w1q7x2r7y3o202l3mcl4sal2lam3man3mao3map3mar3mas2lat4uau1yav3maw3tay4uaz2lbk2sbl3t'fof'6obo2lbp3rbr1tbs2lbu2lbv3mbz3mck4s202k3mcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw2r2m3rcy2rcz2rdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3rek3mel3mem3men3meo3mep3meq4ser2wes2wet2weu2wev2wew1wex1wey1wez1wfl3rfm3mfn3mfo3mfp3mfq3mfr3tfs3mft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3m3u2l17s4s19m3m}'kerning'{cl{4qt5ks5ot5qy5rw17sv5tv}201t{cks4lscmscnscoscpscls4wv}2k{201ts}2w{4qu5ku7mu5os5qx5ru17su5tu}2x{17su5tu5ou5qs}2y{4qv5kv7mu5ot5qz5ru17su5tu}'fof'-6o7t{cksclscmscnscoscps4ls}3u{17su5tu5os5qu}3v{17su5tu5os5qu}fu{17su5tu5ou5qu}7p{17su5tu5ou5qu}ck{4qt5ks5ot5qy5rw17sv5tv}4l{4qt5ks5ot5qy5rw17sv5tv}cm{4qt5ks5ot5qy5rw17sv5tv}cn{4qt5ks5ot5qy5rw17sv5tv}co{4qt5ks5ot5qy5rw17sv5tv}cp{4qt5ks5ot5qy5rw17sv5tv}6l{17st5tt5ou5qu}17s{ckuclucmucnucoucpu4lu4wu}5o{ckuclucmucnucoucpu4lu4wu}5q{ckzclzcmzcnzcozcpz4lz4wu}5r{ckxclxcmxcnxcoxcpx4lx4wu}5t{ckuclucmucnucoucpu4lu4wu}7q{ckuclucmucnucoucpu4lu}6p{17sw5tw5ou5qu}ek{17st5tt5qu}el{17st5tt5ou5qu}em{17st5tt5qu}en{17st5tt5qu}eo{17st5tt5qu}ep{17st5tt5ou5qu}es{17ss5ts5qu}et{17sw5tw5ou5qu}eu{17sw5tw5ou5qu}ev{17ss5ts5qu}6z{17sw5tw5ou5qu5rs}fm{17sw5tw5ou5qu5rs}fn{17sw5tw5ou5qu5rs}fo{17sw5tw5ou5qu5rs}fp{17sw5tw5ou5qu5rs}fq{17sw5tw5ou5qu5rs}7r{cktcltcmtcntcotcpt4lt5os}fs{17sw5tw5ou5qu5rs}ft{17su5tu5ou5qu}7m{5os}fv{17su5tu5ou5qu}fw{17su5tu5ou5qu}fz{cksclscmscnscoscps4ls}}}"),
		Symbol: l("{'widths'{k3uaw4r19m3m2k1t2l2l202m2y2n3m2p5n202q6o3k3m2s2l2t2l2v3r2w1t3m3m2y1t2z1wbk2sbl3r'fof'6o3n3m3o3m3p3m3q3m3r3m3s3m3t3m3u1w3v1w3w3r3x3r3y3r3z2wbp3t3l3m5v2l5x2l5z3m2q4yfr3r7v3k7w1o7x3k}'kerning'{'fof'-6o}}"),
		Helvetica: l("{'widths'{k3p2q4mcx1w201n3r201o6o201s1q201t1q201u1q201w2l201x2l201y2l2k1w2l1w202m2n2n3r2o3r2p5t202q6o2r1n2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v1w3w3u3x3u3y3u3z3r4k6p4l4m4m4m4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3m4v4m4w3r4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v1w5w1w5x1w5y2z5z3r6k2l6l3r6m3r6n3m6o3r6p3r6q1w6r3r6s3r6t1q6u1q6v3m6w1q6x5n6y3r6z3r7k3r7l3r7m2l7n3m7o1w7p3r7q3m7r4s7s3m7t3m7u3m7v2l7w1u7x2l7y3u202l3rcl4mal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3rbr1wbs2lbu2obv3rbz3xck4m202k3rcm4mcn4mco4mcp4mcq6ocr4scs4mct4mcu4mcv4mcw1w2m2ncy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3mes3ret3reu3rev3rew1wex1wey1wez1wfl3rfm3rfn3rfo3rfp3rfq3rfr3ufs3xft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3r3u1w17s4m19m3r}'kerning'{5q{4wv}cl{4qs5kw5ow5qs17sv5tv}201t{2wu4w1k2yu}201x{2wu4wy2yu}17s{2ktclucmucnu4otcpu4lu4wycoucku}2w{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}2x{17sy5ty5oy5qs}2y{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}'fof'-6o7p{17sv5tv5ow}ck{4qs5kw5ow5qs17sv5tv}4l{4qs5kw5ow5qs17sv5tv}cm{4qs5kw5ow5qs17sv5tv}cn{4qs5kw5ow5qs17sv5tv}co{4qs5kw5ow5qs17sv5tv}cp{4qs5kw5ow5qs17sv5tv}6l{17sy5ty5ow}do{17st5tt}4z{17st5tt}7s{fst}dm{17st5tt}dn{17st5tt}5o{ckwclwcmwcnwcowcpw4lw4wv}dp{17st5tt}dq{17st5tt}7t{5ow}ds{17st5tt}5t{2ktclucmucnu4otcpu4lu4wycoucku}fu{17sv5tv5ow}6p{17sy5ty5ow5qs}ek{17sy5ty5ow}el{17sy5ty5ow}em{17sy5ty5ow}en{5ty}eo{17sy5ty5ow}ep{17sy5ty5ow}es{17sy5ty5qs}et{17sy5ty5ow5qs}eu{17sy5ty5ow5qs}ev{17sy5ty5ow5qs}6z{17sy5ty5ow5qs}fm{17sy5ty5ow5qs}fn{17sy5ty5ow5qs}fo{17sy5ty5ow5qs}fp{17sy5ty5qs}fq{17sy5ty5ow5qs}7r{5ow}fs{17sy5ty5ow5qs}ft{17sv5tv5ow}7m{5ow}fv{17sv5tv5ow}fw{17sv5tv5ow}}}"),
		"Helvetica-BoldOblique": l("{'widths'{k3s2q4scx1w201n3r201o6o201s1w201t1w201u1w201w3m201x3m201y3m2k1w2l2l202m2n2n3r2o3r2p5t202q6o2r1s2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v2l3w3u3x3u3y3u3z3x4k6l4l4s4m4s4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3r4v4s4w3x4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v2l5w1w5x2l5y3u5z3r6k2l6l3r6m3x6n3r6o3x6p3r6q2l6r3x6s3x6t1w6u1w6v3r6w1w6x5t6y3x6z3x7k3x7l3x7m2r7n3r7o2l7p3x7q3r7r4y7s3r7t3r7u3m7v2r7w1w7x2r7y3u202l3rcl4sal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3xbq3rbr1wbs2lbu2obv3rbz3xck4s202k3rcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw1w2m2zcy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3res3ret3reu3rev3rew1wex1wey1wez1wfl3xfm3xfn3xfo3xfp3xfq3xfr3ufs3xft3xfu3xfv3xfw3xfz3r203k6o212m6o2dw2l2cq2l3t3r3u2l17s4m19m3r}'kerning'{cl{4qs5ku5ot5qs17sv5tv}201t{2ww4wy2yw}201w{2ks}201x{2ww4wy2yw}2k{201ts201xs}2w{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}2x{5ow5qs}2y{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}'fof'-6o7p{17su5tu5ot}ck{4qs5ku5ot5qs17sv5tv}4l{4qs5ku5ot5qs17sv5tv}cm{4qs5ku5ot5qs17sv5tv}cn{4qs5ku5ot5qs17sv5tv}co{4qs5ku5ot5qs17sv5tv}cp{4qs5ku5ot5qs17sv5tv}6l{17st5tt5os}17s{2kwclvcmvcnvcovcpv4lv4wwckv}5o{2kucltcmtcntcotcpt4lt4wtckt}5q{2ksclscmscnscoscps4ls4wvcks}5r{2ks4ws}5t{2kwclvcmvcnvcovcpv4lv4wwckv}eo{17st5tt5os}fu{17su5tu5ot}6p{17ss5ts}ek{17st5tt5os}el{17st5tt5os}em{17st5tt5os}en{17st5tt5os}6o{201ts}ep{17st5tt5os}es{17ss5ts}et{17ss5ts}eu{17ss5ts}ev{17ss5ts}6z{17su5tu5os5qt}fm{17su5tu5os5qt}fn{17su5tu5os5qt}fo{17su5tu5os5qt}fp{17su5tu5os5qt}fq{17su5tu5os5qt}fs{17su5tu5os5qt}ft{17su5tu5ot}7m{5os}fv{17su5tu5ot}fw{17su5tu5ot}}}"),
		ZapfDingbats: l("{'widths'{k4u2k1w'fof'6o}'kerning'{'fof'-6o}}"),
		"Courier-Bold": l("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"),
		"Times-Italic": l("{'widths'{k3n2q4ycx2l201n3m201o5t201s2l201t2l201u2l201w3r201x3r201y3r2k1t2l2l202m2n2n3m2o3m2p5n202q5t2r1p2s2l2t2l2u3m2v4n2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w4n3x4n3y4n3z3m4k5w4l3x4m3x4n4m4o4s4p3x4q3x4r4s4s4s4t2l4u2w4v4m4w3r4x5n4y4m4z4s5k3x5l4s5m3x5n3m5o3r5p4s5q3x5r5n5s3x5t3r5u3r5v2r5w1w5x2r5y2u5z3m6k2l6l3m6m3m6n2w6o3m6p2w6q1w6r3m6s3m6t1w6u1w6v2w6w1w6x4s6y3m6z3m7k3m7l3m7m2r7n2r7o1w7p3m7q2w7r4m7s2w7t2w7u2r7v2s7w1v7x2s7y3q202l3mcl3xal2ram3man3mao3map3mar3mas2lat4wau1vav3maw4nay4waz2lbk2sbl4n'fof'6obo2lbp3mbq3obr1tbs2lbu1zbv3mbz3mck3x202k3mcm3xcn3xco3xcp3xcq5tcr4mcs3xct3xcu3xcv3xcw2l2m2ucy2lcz2ldl4mdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek3mel3mem3men3meo3mep3meq4mer2wes2wet2weu2wev2wew1wex1wey1wez1wfl3mfm3mfn3mfo3mfp3mfq3mfr4nfs3mft3mfu3mfv3mfw3mfz2w203k6o212m6m2dw2l2cq2l3t3m3u2l17s3r19m3m}'kerning'{cl{5kt4qw}201s{201sw}201t{201tw2wy2yy6q-t}201x{2wy2yy}2k{201tw}2w{7qs4qy7rs5ky7mw5os5qx5ru17su5tu}2x{17ss5ts5os}2y{7qs4qy7rs5ky7mw5os5qx5ru17su5tu}'fof'-6o6t{17ss5ts5qs}7t{5os}3v{5qs}7p{17su5tu5qs}ck{5kt4qw}4l{5kt4qw}cm{5kt4qw}cn{5kt4qw}co{5kt4qw}cp{5kt4qw}6l{4qs5ks5ou5qw5ru17su5tu}17s{2ks}5q{ckvclvcmvcnvcovcpv4lv}5r{ckuclucmucnucoucpu4lu}5t{2ks}6p{4qs5ks5ou5qw5ru17su5tu}ek{4qs5ks5ou5qw5ru17su5tu}el{4qs5ks5ou5qw5ru17su5tu}em{4qs5ks5ou5qw5ru17su5tu}en{4qs5ks5ou5qw5ru17su5tu}eo{4qs5ks5ou5qw5ru17su5tu}ep{4qs5ks5ou5qw5ru17su5tu}es{5ks5qs4qs}et{4qs5ks5ou5qw5ru17su5tu}eu{4qs5ks5qw5ru17su5tu}ev{5ks5qs4qs}ex{17ss5ts5qs}6z{4qv5ks5ou5qw5ru17su5tu}fm{4qv5ks5ou5qw5ru17su5tu}fn{4qv5ks5ou5qw5ru17su5tu}fo{4qv5ks5ou5qw5ru17su5tu}fp{4qv5ks5ou5qw5ru17su5tu}fq{4qv5ks5ou5qw5ru17su5tu}7r{5os}fs{4qv5ks5ou5qw5ru17su5tu}ft{17su5tu5qs}fu{17su5tu5qs}fv{17su5tu5qs}fw{17su5tu5qs}}}"),
		"Times-Roman": l("{'widths'{k3n2q4ycx2l201n3m201o6o201s2l201t2l201u2l201w2w201x2w201y2w2k1t2l2l202m2n2n3m2o3m2p5n202q6o2r1m2s2l2t2l2u3m2v3s2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v1w3w3s3x3s3y3s3z2w4k5w4l4s4m4m4n4m4o4s4p3x4q3r4r4s4s4s4t2l4u2r4v4s4w3x4x5t4y4s4z4s5k3r5l4s5m4m5n3r5o3x5p4s5q4s5r5y5s4s5t4s5u3x5v2l5w1w5x2l5y2z5z3m6k2l6l2w6m3m6n2w6o3m6p2w6q2l6r3m6s3m6t1w6u1w6v3m6w1w6x4y6y3m6z3m7k3m7l3m7m2l7n2r7o1w7p3m7q3m7r4s7s3m7t3m7u2w7v3k7w1o7x3k7y3q202l3mcl4sal2lam3man3mao3map3mar3mas2lat4wau1vav3maw3say4waz2lbk2sbl3s'fof'6obo2lbp3mbq2xbr1tbs2lbu1zbv3mbz2wck4s202k3mcm4scn4sco4scp4scq5tcr4mcs3xct3xcu3xcv3xcw2l2m2tcy2lcz2ldl4sdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek2wel2wem2wen2weo2wep2weq4mer2wes2wet2weu2wev2wew1wex1wey1wez1wfl3mfm3mfn3mfo3mfp3mfq3mfr3sfs3mft3mfu3mfv3mfw3mfz3m203k6o212m6m2dw2l2cq2l3t3m3u1w17s4s19m3m}'kerning'{cl{4qs5ku17sw5ou5qy5rw201ss5tw201ws}201s{201ss}201t{ckw4lwcmwcnwcowcpwclw4wu201ts}2k{201ts}2w{4qs5kw5os5qx5ru17sx5tx}2x{17sw5tw5ou5qu}2y{4qs5kw5os5qx5ru17sx5tx}'fof'-6o7t{ckuclucmucnucoucpu4lu5os5rs}3u{17su5tu5qs}3v{17su5tu5qs}7p{17sw5tw5qs}ck{4qs5ku17sw5ou5qy5rw201ss5tw201ws}4l{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cm{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cn{4qs5ku17sw5ou5qy5rw201ss5tw201ws}co{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cp{4qs5ku17sw5ou5qy5rw201ss5tw201ws}6l{17su5tu5os5qw5rs}17s{2ktclvcmvcnvcovcpv4lv4wuckv}5o{ckwclwcmwcnwcowcpw4lw4wu}5q{ckyclycmycnycoycpy4ly4wu5ms}5r{cktcltcmtcntcotcpt4lt4ws}5t{2ktclvcmvcnvcovcpv4lv4wuckv}7q{cksclscmscnscoscps4ls}6p{17su5tu5qw5rs}ek{5qs5rs}el{17su5tu5os5qw5rs}em{17su5tu5os5qs5rs}en{17su5qs5rs}eo{5qs5rs}ep{17su5tu5os5qw5rs}es{5qs}et{17su5tu5qw5rs}eu{17su5tu5qs5rs}ev{5qs}6z{17sv5tv5os5qx5rs}fm{5os5qt5rs}fn{17sv5tv5os5qx5rs}fo{17sv5tv5os5qx5rs}fp{5os5qt5rs}fq{5os5qt5rs}7r{ckuclucmucnucoucpu4lu5os}fs{17sv5tv5os5qx5rs}ft{17ss5ts5qs}fu{17sw5tw5qs}fv{17sw5tw5qs}fw{17ss5ts5qs}fz{ckuclucmucnucoucpu4lu5os5rs}}}"),
		"Helvetica-Oblique": l("{'widths'{k3p2q4mcx1w201n3r201o6o201s1q201t1q201u1q201w2l201x2l201y2l2k1w2l1w202m2n2n3r2o3r2p5t202q6o2r1n2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v1w3w3u3x3u3y3u3z3r4k6p4l4m4m4m4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3m4v4m4w3r4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v1w5w1w5x1w5y2z5z3r6k2l6l3r6m3r6n3m6o3r6p3r6q1w6r3r6s3r6t1q6u1q6v3m6w1q6x5n6y3r6z3r7k3r7l3r7m2l7n3m7o1w7p3r7q3m7r4s7s3m7t3m7u3m7v2l7w1u7x2l7y3u202l3rcl4mal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3rbr1wbs2lbu2obv3rbz3xck4m202k3rcm4mcn4mco4mcp4mcq6ocr4scs4mct4mcu4mcv4mcw1w2m2ncy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3mes3ret3reu3rev3rew1wex1wey1wez1wfl3rfm3rfn3rfo3rfp3rfq3rfr3ufs3xft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3r3u1w17s4m19m3r}'kerning'{5q{4wv}cl{4qs5kw5ow5qs17sv5tv}201t{2wu4w1k2yu}201x{2wu4wy2yu}17s{2ktclucmucnu4otcpu4lu4wycoucku}2w{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}2x{17sy5ty5oy5qs}2y{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}'fof'-6o7p{17sv5tv5ow}ck{4qs5kw5ow5qs17sv5tv}4l{4qs5kw5ow5qs17sv5tv}cm{4qs5kw5ow5qs17sv5tv}cn{4qs5kw5ow5qs17sv5tv}co{4qs5kw5ow5qs17sv5tv}cp{4qs5kw5ow5qs17sv5tv}6l{17sy5ty5ow}do{17st5tt}4z{17st5tt}7s{fst}dm{17st5tt}dn{17st5tt}5o{ckwclwcmwcnwcowcpw4lw4wv}dp{17st5tt}dq{17st5tt}7t{5ow}ds{17st5tt}5t{2ktclucmucnu4otcpu4lu4wycoucku}fu{17sv5tv5ow}6p{17sy5ty5ow5qs}ek{17sy5ty5ow}el{17sy5ty5ow}em{17sy5ty5ow}en{5ty}eo{17sy5ty5ow}ep{17sy5ty5ow}es{17sy5ty5qs}et{17sy5ty5ow5qs}eu{17sy5ty5ow5qs}ev{17sy5ty5ow5qs}6z{17sy5ty5ow5qs}fm{17sy5ty5ow5qs}fn{17sy5ty5ow5qs}fo{17sy5ty5ow5qs}fp{17sy5ty5qs}fq{17sy5ty5ow5qs}7r{5ow}fs{17sy5ty5ow5qs}ft{17sv5tv5ow}7m{5ow}fv{17sv5tv5ow}fw{17sv5tv5ow}}}")
	} };
	e.events.push(["addFont", function(e) {
		var t = e.font, n = f.Unicode[t.postScriptName];
		n && (t.metadata.Unicode = {}, t.metadata.Unicode.widths = n.widths, t.metadata.Unicode.kerning = n.kerning);
		var r = d.Unicode[t.postScriptName];
		r && (t.metadata.Unicode.encoding = r, t.encoding = r.codePages[0]);
	}]);
}(Z.API), function(e) {
	var t = function(e) {
		for (var t = e.length, n = new Uint8Array(t), r = 0; r < t; r++) n[r] = e.charCodeAt(r);
		return n;
	};
	e.API.events.push(["addFont", function(n) {
		var r = void 0, i = n.font, a = n.instance;
		if (!i.isStandardFont) {
			if (a === void 0) throw Error("Font does not exist in vFS, import fonts or remove declaration doc.addFont('" + i.postScriptName + "').");
			if (typeof (r = !1 === a.existsFileInVFS(i.postScriptName) ? a.loadFile(i.postScriptName) : a.getFileFromVFS(i.postScriptName)) != "string") throw Error("Font is not stored as string-data in vFS, import fonts or remove declaration doc.addFont('" + i.postScriptName + "').");
			(function(n, r) {
				r = /^\x00\x01\x00\x00/.test(r) ? t(r) : t(wo(r)), n.metadata = e.API.TTFFont.open(r), n.metadata.Unicode = n.metadata.Unicode || {
					encoding: {},
					kerning: {},
					widths: []
				}, n.metadata.glyIdsUsed = [0];
			})(i, r);
		}
	}]);
}(Z), Z.API.addSvgAsImage = function(e, t, n, r, i, a, o, s) {
	if (isNaN(t) || isNaN(n)) throw vo.error("jsPDF.addSvgAsImage: Invalid coordinates", arguments), /* @__PURE__ */ Error("Invalid coordinates passed to jsPDF.addSvgAsImage");
	if (isNaN(r) || isNaN(i)) throw vo.error("jsPDF.addSvgAsImage: Invalid measurements", arguments), /* @__PURE__ */ Error("Invalid measurements (width and/or height) passed to jsPDF.addSvgAsImage");
	var c = document.createElement("canvas");
	c.width = r, c.height = i;
	var l = c.getContext("2d");
	l.fillStyle = "#fff", l.fillRect(0, 0, c.width, c.height);
	var u = {
		ignoreMouse: !0,
		ignoreAnimation: !0,
		ignoreDimensions: !0
	}, d = this;
	return (X.canvg ? Promise.resolve(X.canvg) : import("./index.es-BJKqVIrT.js")).catch(function(e) {
		return Promise.reject(/* @__PURE__ */ Error("Could not load canvg: " + e));
	}).then(function(e) {
		return e.default ? e.default : e;
	}).then(function(t) {
		return t.fromString(l, e, u);
	}, function() {
		return Promise.reject(/* @__PURE__ */ Error("Could not load canvg."));
	}).then(function(e) {
		return e.render(u);
	}).then(function() {
		d.addImage(c.toDataURL("image/jpeg", 1), t, n, r, i, o, s);
	});
}, Z.API.putTotalPages = function(e) {
	var t, n = 0;
	parseInt(this.internal.getFont().id.substr(1), 10) < 15 ? (t = new RegExp(e, "g"), n = this.internal.getNumberOfPages()) : (t = new RegExp(this.pdfEscape16(e, this.internal.getFont()), "g"), n = this.pdfEscape16(this.internal.getNumberOfPages() + "", this.internal.getFont()));
	for (var r = 1; r <= this.internal.getNumberOfPages(); r++) for (var i = 0; i < this.internal.pages[r].length; i++) this.internal.pages[r][i] = this.internal.pages[r][i].replace(t, n);
	return this;
}, Z.API.viewerPreferences = function(e, n) {
	var r;
	e ||= {}, n ||= !1;
	var i, a, o, s = {
		HideToolbar: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.3
		},
		HideMenubar: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.3
		},
		HideWindowUI: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.3
		},
		FitWindow: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.3
		},
		CenterWindow: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.3
		},
		DisplayDocTitle: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.4
		},
		NonFullScreenPageMode: {
			defaultValue: "UseNone",
			value: "UseNone",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"UseNone",
				"UseOutlines",
				"UseThumbs",
				"UseOC"
			],
			pdfVersion: 1.3
		},
		Direction: {
			defaultValue: "L2R",
			value: "L2R",
			type: "name",
			explicitSet: !1,
			valueSet: ["L2R", "R2L"],
			pdfVersion: 1.3
		},
		ViewArea: {
			defaultValue: "CropBox",
			value: "CropBox",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"MediaBox",
				"CropBox",
				"TrimBox",
				"BleedBox",
				"ArtBox"
			],
			pdfVersion: 1.4
		},
		ViewClip: {
			defaultValue: "CropBox",
			value: "CropBox",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"MediaBox",
				"CropBox",
				"TrimBox",
				"BleedBox",
				"ArtBox"
			],
			pdfVersion: 1.4
		},
		PrintArea: {
			defaultValue: "CropBox",
			value: "CropBox",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"MediaBox",
				"CropBox",
				"TrimBox",
				"BleedBox",
				"ArtBox"
			],
			pdfVersion: 1.4
		},
		PrintClip: {
			defaultValue: "CropBox",
			value: "CropBox",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"MediaBox",
				"CropBox",
				"TrimBox",
				"BleedBox",
				"ArtBox"
			],
			pdfVersion: 1.4
		},
		PrintScaling: {
			defaultValue: "AppDefault",
			value: "AppDefault",
			type: "name",
			explicitSet: !1,
			valueSet: ["AppDefault", "None"],
			pdfVersion: 1.6
		},
		Duplex: {
			defaultValue: "",
			value: "none",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"Simplex",
				"DuplexFlipShortEdge",
				"DuplexFlipLongEdge",
				"none"
			],
			pdfVersion: 1.7
		},
		PickTrayByPDFSize: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.7
		},
		PrintPageRange: {
			defaultValue: "",
			value: "",
			type: "array",
			explicitSet: !1,
			valueSet: null,
			pdfVersion: 1.7
		},
		NumCopies: {
			defaultValue: 1,
			value: 1,
			type: "integer",
			explicitSet: !1,
			valueSet: null,
			pdfVersion: 1.7
		}
	}, c = Object.keys(s), l = [], u = 0, d = 0, f = 0;
	function p(e, t) {
		var n, r = !1;
		for (n = 0; n < e.length; n += 1) e[n] === t && (r = !0);
		return r;
	}
	if (this.internal.viewerpreferences === void 0 && (this.internal.viewerpreferences = {}, this.internal.viewerpreferences.configuration = JSON.parse(JSON.stringify(s)), this.internal.viewerpreferences.isSubscribed = !1), r = this.internal.viewerpreferences.configuration, e === "reset" || !0 === n) {
		var m = c.length;
		for (f = 0; f < m; f += 1) r[c[f]].value = r[c[f]].defaultValue, r[c[f]].explicitSet = !1;
	}
	if (t(e) === "object") {
		for (a in e) if (o = e[a], p(c, a) && o !== void 0) {
			if (r[a].type === "boolean" && typeof o == "boolean") r[a].value = o;
			else if (r[a].type === "name" && p(r[a].valueSet, o)) r[a].value = o;
			else if (r[a].type === "integer" && Number.isInteger(o)) r[a].value = o;
			else if (r[a].type === "array") {
				for (u = 0; u < o.length; u += 1) if (i = !0, o[u].length === 1 && typeof o[u][0] == "number") l.push(String(o[u] - 1));
				else if (o[u].length > 1) {
					for (d = 0; d < o[u].length; d += 1) typeof o[u][d] != "number" && (i = !1);
					!0 === i && l.push([o[u][0] - 1, o[u][1] - 1].join(" "));
				}
				r[a].value = "[" + l.join(" ") + "]";
			} else r[a].value = r[a].defaultValue;
			r[a].explicitSet = !0;
		}
	}
	return !1 === this.internal.viewerpreferences.isSubscribed && (this.internal.events.subscribe("putCatalog", function() {
		var e, t = [];
		for (e in r) !0 === r[e].explicitSet && (r[e].type === "name" ? t.push("/" + e + " /" + r[e].value) : t.push("/" + e + " " + r[e].value));
		t.length !== 0 && this.internal.write("/ViewerPreferences\n<<\n" + t.join("\n") + "\n>>");
	}), this.internal.viewerpreferences.isSubscribed = !0), this.internal.viewerpreferences.configuration = r, this;
}, Z.API.addMetadata = function(e, t) {
	return this.internal.__metadata__ === void 0 && (this.internal.__metadata__ = {
		metadata: e,
		namespaceUri: t ?? "http://jspdf.default.namespaceuri/",
		rawXml: typeof t == "boolean" && t
	}, this.internal.events.subscribe("putCatalog", vc), this.internal.events.subscribe("postPutResources", _c)), this;
}, function(e) {
	var t = e.API, n = t.pdfEscape16 = function(e, t) {
		for (var n, r = t.metadata.Unicode.widths, i = [
			"",
			"0",
			"00",
			"000",
			"0000"
		], a = [""], o = 0, s = e.length; o < s; ++o) {
			if (n = t.metadata.characterToGlyph(e.charCodeAt(o)), t.metadata.glyIdsUsed.push(n), t.metadata.toUnicode[n] = e.charCodeAt(o), r.indexOf(n) == -1 && (r.push(n), r.push([parseInt(t.metadata.widthOfGlyph(n), 10)])), n == "0") return a.join("");
			n = n.toString(16), a.push(i[4 - n.length], n);
		}
		return a.join("");
	}, r = function(e) {
		var t, n, r, i, a = "/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo <<\n  /Registry (Adobe)\n  /Ordering (UCS)\n  /Supplement 0\n>> def\n/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n1 begincodespacerange\n<0000><ffff>\nendcodespacerange", o, s;
		for (r = [], o = 0, s = (n = Object.keys(e).sort(function(e, t) {
			return e - t;
		})).length; o < s; o++) t = n[o], r.length >= 100 && (a += "\n" + r.length + " beginbfchar\n" + r.join("\n") + "\nendbfchar", r = []), e[t] !== void 0 && e[t] !== null && typeof e[t].toString == "function" && (i = ("0000" + e[t].toString(16)).slice(-4), t = ("0000" + (+t).toString(16)).slice(-4), r.push("<" + t + "><" + i + ">"));
		return r.length && (a += "\n" + r.length + " beginbfchar\n" + r.join("\n") + "\nendbfchar\n"), a + "endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend";
	};
	t.events.push(["putFont", function(t) {
		(function(t) {
			var n = t.font, i = t.out, a = t.newObject, o = t.putStream;
			if (n.metadata instanceof e.API.TTFFont && n.encoding === "Identity-H") {
				for (var s = n.metadata.Unicode.widths, c = n.metadata.subset.encode(n.metadata.glyIdsUsed, 1), l = "", u = 0; u < c.length; u++) l += String.fromCharCode(c[u]);
				var d = a();
				o({
					data: l,
					addLength1: !0,
					objectId: d
				}), i("endobj");
				var f = a();
				o({
					data: r(n.metadata.toUnicode),
					addLength1: !0,
					objectId: f
				}), i("endobj");
				var p = a();
				i("<<"), i("/Type /FontDescriptor"), i("/FontName /" + Uo(n.fontName)), i("/FontFile2 " + d + " 0 R"), i("/FontBBox " + e.API.PDFObject.convert(n.metadata.bbox)), i("/Flags " + n.metadata.flags), i("/StemV " + n.metadata.stemV), i("/ItalicAngle " + n.metadata.italicAngle), i("/Ascent " + n.metadata.ascender), i("/Descent " + n.metadata.decender), i("/CapHeight " + n.metadata.capHeight), i(">>"), i("endobj");
				var m = a();
				i("<<"), i("/Type /Font"), i("/BaseFont /" + Uo(n.fontName)), i("/FontDescriptor " + p + " 0 R"), i("/W " + e.API.PDFObject.convert(s)), i("/CIDToGIDMap /Identity"), i("/DW 1000"), i("/Subtype /CIDFontType2"), i("/CIDSystemInfo"), i("<<"), i("/Supplement 0"), i("/Registry (Adobe)"), i("/Ordering (" + n.encoding + ")"), i(">>"), i(">>"), i("endobj"), n.objectNumber = a(), i("<<"), i("/Type /Font"), i("/Subtype /Type0"), i("/ToUnicode " + f + " 0 R"), i("/BaseFont /" + Uo(n.fontName)), i("/Encoding /" + n.encoding), i("/DescendantFonts [" + m + " 0 R]"), i(">>"), i("endobj"), n.isAlreadyPutted = !0;
			}
		})(t);
	}]), t.events.push(["putFont", function(t) {
		(function(t) {
			var n = t.font, i = t.out, a = t.newObject, o = t.putStream;
			if (n.metadata instanceof e.API.TTFFont && n.encoding === "WinAnsiEncoding") {
				for (var s = n.metadata.rawData, c = "", l = 0; l < s.length; l++) c += String.fromCharCode(s[l]);
				var u = a();
				o({
					data: c,
					addLength1: !0,
					objectId: u
				}), i("endobj");
				var d = a();
				o({
					data: r(n.metadata.toUnicode),
					addLength1: !0,
					objectId: d
				}), i("endobj");
				var f = a();
				i("<<"), i("/Descent " + n.metadata.decender), i("/CapHeight " + n.metadata.capHeight), i("/StemV " + n.metadata.stemV), i("/Type /FontDescriptor"), i("/FontFile2 " + u + " 0 R"), i("/Flags 96"), i("/FontBBox " + e.API.PDFObject.convert(n.metadata.bbox)), i("/FontName /" + Uo(n.fontName)), i("/ItalicAngle " + n.metadata.italicAngle), i("/Ascent " + n.metadata.ascender), i(">>"), i("endobj"), n.objectNumber = a();
				for (var p = 0; p < n.metadata.hmtx.widths.length; p++) n.metadata.hmtx.widths[p] = parseInt(n.metadata.hmtx.widths[p] * (1e3 / n.metadata.head.unitsPerEm));
				i("<</Subtype/TrueType/Type/Font/ToUnicode " + d + " 0 R/BaseFont/" + Uo(n.fontName) + "/FontDescriptor " + f + " 0 R/Encoding/" + n.encoding + " /FirstChar 29 /LastChar 255 /Widths " + e.API.PDFObject.convert(n.metadata.hmtx.widths) + ">>"), i("endobj"), n.isAlreadyPutted = !0;
			}
		})(t);
	}]);
	var i = function(e) {
		var t, r = e.text || "", i = e.x, a = e.y, o = e.options || {}, s = e.mutex || {}, c = s.pdfEscape, l = s.activeFontKey, u = s.fonts, d = l, f = "", p = 0, m = "", h = u[d].encoding;
		if (u[d].encoding !== "Identity-H") return {
			text: r,
			x: i,
			y: a,
			options: o,
			mutex: s
		};
		for (m = r, d = l, Array.isArray(r) && (m = r[0]), p = 0; p < m.length; p += 1) u[d].metadata.hasOwnProperty("cmap") && (t = u[d].metadata.cmap.unicode.codeMap[m[p].charCodeAt(0)]), t || m[p].charCodeAt(0) < 256 && u[d].metadata.hasOwnProperty("Unicode") ? f += m[p] : f += "";
		var g = "";
		return parseInt(d.slice(1)) < 14 || h === "WinAnsiEncoding" ? g = c(f, d).split("").map(function(e) {
			return e.charCodeAt(0).toString(16);
		}).join("") : h === "Identity-H" && (g = n(f, u[d])), s.isHex = !0, {
			text: g,
			x: i,
			y: a,
			options: o,
			mutex: s
		};
	};
	t.events.push(["postProcessText", function(e) {
		var t = e.text || "", n = [], r = {
			text: t,
			x: e.x,
			y: e.y,
			options: e.options,
			mutex: e.mutex
		};
		if (Array.isArray(t)) {
			var a = 0;
			for (a = 0; a < t.length; a += 1) Array.isArray(t[a]) && t[a].length === 3 ? n.push([
				i(Object.assign({}, r, { text: t[a][0] })).text,
				t[a][1],
				t[a][2]
			]) : n.push(i(Object.assign({}, r, { text: t[a] })).text);
			e.text = n;
		} else e.text = i(Object.assign({}, r, { text: t })).text;
	}]);
}(Z), function(e) {
	var t = function() {
		return this.internal.vFS === void 0 && (this.internal.vFS = {}), !0;
	};
	e.existsFileInVFS = function(e) {
		return t.call(this), this.internal.vFS[e] !== void 0;
	}, e.addFileToVFS = function(e, n) {
		return t.call(this), this.internal.vFS[e] = n, this;
	}, e.getFileFromVFS = function(e) {
		return t.call(this), this.internal.vFS[e] === void 0 ? null : this.internal.vFS[e];
	};
}(Z.API), function(e) {
	e.__bidiEngine__ = e.prototype.__bidiEngine__ = function(e) {
		var n, r, i, a, o, s, c, l = t, u = [
			[
				0,
				3,
				0,
				1,
				0,
				0,
				0
			],
			[
				0,
				3,
				0,
				1,
				2,
				2,
				0
			],
			[
				0,
				3,
				0,
				17,
				2,
				0,
				1
			],
			[
				0,
				3,
				5,
				5,
				4,
				1,
				0
			],
			[
				0,
				3,
				21,
				21,
				4,
				0,
				1
			],
			[
				0,
				3,
				5,
				5,
				4,
				2,
				0
			]
		], d = [
			[
				2,
				0,
				1,
				1,
				0,
				1,
				0
			],
			[
				2,
				0,
				1,
				1,
				0,
				2,
				0
			],
			[
				2,
				0,
				2,
				1,
				3,
				2,
				0
			],
			[
				2,
				0,
				2,
				33,
				3,
				1,
				1
			]
		], f = {
			L: 0,
			R: 1,
			EN: 2,
			AN: 3,
			N: 4,
			B: 5,
			S: 6
		}, p = {
			0: 0,
			5: 1,
			6: 2,
			7: 3,
			32: 4,
			251: 5,
			254: 6,
			255: 7
		}, m = /* @__PURE__ */ "(.).(.<.>.<.[.].[.{.}.{.«.».«.‹.›.‹.⁅.⁆.⁅.⁽.⁾.⁽.₍.₎.₍.≤.≥.≤.〈.〉.〈.﹙.﹚.﹙.﹛.﹜.﹛.﹝.﹞.﹝.﹤.﹥.﹤".split("."), h = /* @__PURE__ */ new RegExp(/^([1-4|9]|1[0-9]|2[0-9]|3[0168]|4[04589]|5[012]|7[78]|159|16[0-9]|17[0-2]|21[569]|22[03489]|250)$/), g = !1, _ = 0;
		this.__bidiEngine__ = {};
		var v = function(e) {
			var t = e.charCodeAt(), n = t >> 8, r = p[n];
			return r === void 0 ? n === 252 || n === 253 ? "AL" : h.test(n) ? "L" : n === 8 ? "R" : "N" : l[256 * r + (255 & t)];
		}, y = function(e) {
			for (var t, n = 0; n < e.length; n++) {
				if ((t = v(e.charAt(n))) === "L") return !1;
				if (t === "R") return !0;
			}
			return !1;
		}, b = function(e, t, o, s) {
			var c, l, u, d, f = t[s];
			switch (f) {
				case "L":
				case "R":
				case "LRE":
				case "RLE":
				case "LRO":
				case "RLO":
				case "PDF":
					g = !1;
					break;
				case "N":
				case "AN": break;
				case "EN":
					g && (f = "AN");
					break;
				case "AL":
					g = !0, f = "R";
					break;
				case "WS":
				case "BN":
					f = "N";
					break;
				case "CS":
					s < 1 || s + 1 >= t.length || (c = o[s - 1]) !== "EN" && c !== "AN" || (l = t[s + 1]) !== "EN" && l !== "AN" ? f = "N" : g && (l = "AN"), f = l === c ? l : "N";
					break;
				case "ES":
					f = (c = s > 0 ? o[s - 1] : "B") === "EN" && s + 1 < t.length && t[s + 1] === "EN" ? "EN" : "N";
					break;
				case "ET":
					if (s > 0 && o[s - 1] === "EN") {
						f = "EN";
						break;
					}
					if (g) {
						f = "N";
						break;
					}
					for (u = s + 1, d = t.length; u < d && t[u] === "ET";) u++;
					f = u < d && t[u] === "EN" ? "EN" : "N";
					break;
				case "NSM":
					if (i && !a) {
						for (d = t.length, u = s + 1; u < d && t[u] === "NSM";) u++;
						if (u < d) {
							var p = e[s], m = p >= 1425 && p <= 2303 || p === 64286;
							if (c = t[u], m && (c === "R" || c === "AL")) {
								f = "R";
								break;
							}
						}
					}
					f = s < 1 || (c = t[s - 1]) === "B" ? "N" : o[s - 1];
					break;
				case "B":
					g = !1, n = !0, f = _;
					break;
				case "S": r = !0, f = "N";
			}
			return f;
		}, x = function(e, t, n) {
			var r = e.split("");
			return n && S(r, n, { hiLevel: _ }), r.reverse(), t && t.reverse(), r.join("");
		}, S = function(e, t, i) {
			var a, o, s, c, l, p = -1, m = e.length, h = 0, y = [], x = _ ? d : u, S = [];
			for (g = !1, n = !1, r = !1, o = 0; o < m; o++) S[o] = v(e[o]);
			for (s = 0; s < m; s++) {
				if (l = h, y[s] = b(e, S, y, s), a = 240 & (h = x[l][f[y[s]]]), h &= 15, t[s] = c = x[h][5], a > 0) {
					if (a === 16) {
						for (o = p; o < s; o++) t[o] = 1;
						p = -1;
					} else p = -1;
				}
				if (x[h][6]) p === -1 && (p = s);
				else if (p > -1) {
					for (o = p; o < s; o++) t[o] = c;
					p = -1;
				}
				S[s] === "B" && (t[s] = 0), i.hiLevel |= c;
			}
			r && function(e, t, n) {
				for (var r = 0; r < n; r++) if (e[r] === "S") {
					t[r] = _;
					for (var i = r - 1; i >= 0 && e[i] === "WS"; i--) t[i] = _;
				}
			}(S, t, m);
		}, C = function(e, t, r, i, a) {
			if (!(a.hiLevel < e)) {
				if (e === 1 && _ === 1 && !n) return t.reverse(), void (r && r.reverse());
				for (var o, s, c, l, u = t.length, d = 0; d < u;) {
					if (i[d] >= e) {
						for (c = d + 1; c < u && i[c] >= e;) c++;
						for (l = d, s = c - 1; l < s; l++, s--) o = t[l], t[l] = t[s], t[s] = o, r && (o = r[l], r[l] = r[s], r[s] = o);
						d = c;
					}
					d++;
				}
			}
		}, w = function(e, t, n) {
			var r = e.split(""), i = { hiLevel: _ };
			return n ||= [], S(r, n, i), function(e, t, n) {
				if (n.hiLevel !== 0 && c) for (var r, i = 0; i < e.length; i++) t[i] === 1 && (r = m.indexOf(e[i])) >= 0 && (e[i] = m[r + 1]);
			}(r, n, i), C(2, r, t, n, i), C(1, r, t, n, i), r.join("");
		};
		return this.__bidiEngine__.doBidiReorder = function(e, t, n) {
			if (function(e, t) {
				if (t) for (var n = 0; n < e.length; n++) t[n] = n;
				a === void 0 && (a = y(e)), s === void 0 && (s = y(e));
			}(e, t), i || !o || s) {
				if (i && o && a ^ s) _ = +!!a, e = x(e, t, n);
				else if (!i && o && s) _ = +!!a, e = w(e, t, n), e = x(e, t);
				else if (!i || a || o || s) {
					if (i && !o && a ^ s) e = x(e, t), a ? (_ = 0, e = w(e, t, n)) : (_ = 1, e = w(e, t, n), e = x(e, t));
					else if (i && a && !o && s) _ = 1, e = w(e, t, n), e = x(e, t);
					else if (!i && !o && a ^ s) {
						var r = c;
						a ? (_ = 1, e = w(e, t, n), _ = 0, c = !1, e = w(e, t, n), c = r) : (_ = 0, e = w(e, t, n), e = x(e, t), _ = 1, c = !1, e = w(e, t, n), c = r, e = x(e, t));
					}
				} else _ = 0, e = w(e, t, n);
			} else _ = +!!a, e = w(e, t, n);
			return e;
		}, this.__bidiEngine__.setOptions = function(e) {
			e && (i = e.isInputVisual, o = e.isOutputVisual, a = e.isInputRtl, s = e.isOutputRtl, c = e.isSymmetricSwapping);
		}, this.__bidiEngine__.setOptions(e), this.__bidiEngine__;
	};
	var t = /* @__PURE__ */ "BN.BN.BN.BN.BN.BN.BN.BN.BN.S.B.S.WS.B.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.B.B.B.S.WS.N.N.ET.ET.ET.N.N.N.N.N.ES.CS.ES.CS.CS.EN.EN.EN.EN.EN.EN.EN.EN.EN.EN.CS.N.N.N.N.N.N.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.N.N.N.N.N.N.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.N.N.N.N.BN.BN.BN.BN.BN.BN.B.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.BN.CS.N.ET.ET.ET.ET.N.N.N.N.L.N.N.BN.N.N.ET.ET.EN.EN.N.L.N.N.N.EN.L.N.N.N.N.N.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.N.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.N.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.N.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.N.N.L.L.L.L.L.L.L.N.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.N.L.N.N.N.N.N.ET.N.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.R.NSM.R.NSM.NSM.R.NSM.NSM.R.NSM.N.N.N.N.N.N.N.N.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.N.N.N.N.N.R.R.R.R.R.N.N.N.N.N.N.N.N.N.N.N.AN.AN.AN.AN.AN.AN.N.N.AL.ET.ET.AL.CS.AL.N.N.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.AL.AL.N.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.AN.AN.AN.AN.AN.AN.AN.AN.AN.AN.ET.AN.AN.AL.AL.AL.NSM.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.NSM.NSM.NSM.NSM.NSM.NSM.NSM.AN.N.NSM.NSM.NSM.NSM.NSM.NSM.AL.AL.NSM.NSM.N.NSM.NSM.NSM.NSM.AL.AL.EN.EN.EN.EN.EN.EN.EN.EN.EN.EN.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.N.AL.AL.NSM.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.N.N.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.AL.N.N.N.N.N.N.N.N.N.N.N.N.N.N.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.R.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.R.R.N.N.N.N.R.N.N.N.N.N.WS.WS.WS.WS.WS.WS.WS.WS.WS.WS.WS.BN.BN.BN.L.R.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.WS.B.LRE.RLE.PDF.LRO.RLO.CS.ET.ET.ET.ET.ET.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.CS.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.WS.BN.BN.BN.BN.BN.N.LRI.RLI.FSI.PDI.BN.BN.BN.BN.BN.BN.EN.L.N.N.EN.EN.EN.EN.EN.EN.ES.ES.N.N.N.L.EN.EN.EN.EN.EN.EN.EN.EN.EN.EN.ES.ES.N.N.N.N.L.L.L.L.L.L.L.L.L.L.L.L.L.N.N.N.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.ET.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.L.L.L.L.L.L.L.N.N.N.N.N.N.N.N.N.N.N.N.L.L.L.L.L.N.N.N.N.N.R.NSM.R.R.R.R.R.R.R.R.R.R.ES.R.R.R.R.R.R.R.R.R.R.R.R.R.N.R.R.R.R.R.N.R.N.R.R.N.R.R.N.R.R.R.R.R.R.R.R.R.R.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.NSM.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.CS.N.CS.N.N.CS.N.N.N.N.N.N.N.N.N.ET.N.N.ES.ES.N.N.N.N.N.ET.ET.N.N.N.N.N.AL.AL.AL.AL.AL.N.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.AL.N.N.BN.N.N.N.ET.ET.ET.N.N.N.N.N.ES.CS.ES.CS.CS.EN.EN.EN.EN.EN.EN.EN.EN.EN.EN.CS.N.N.N.N.N.N.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.N.N.N.N.N.N.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.N.N.N.N.N.N.N.N.N.N.N.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.L.N.N.N.L.L.L.L.L.L.N.N.L.L.L.L.L.L.N.N.L.L.L.L.L.L.N.N.L.L.L.N.N.N.ET.ET.N.N.N.ET.ET.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N.N".split("."), n = new e.__bidiEngine__({ isInputVisual: !0 });
	e.API.events.push(["postProcessText", function(e) {
		var t = e.text;
		e.x, e.y;
		var r = e.options || {};
		e.mutex, r.lang;
		var i = [];
		if (r.isInputVisual = typeof r.isInputVisual != "boolean" || r.isInputVisual, n.setOptions(r), Object.prototype.toString.call(t) === "[object Array]") {
			var a = 0;
			for (i = [], a = 0; a < t.length; a += 1) Object.prototype.toString.call(t[a]) === "[object Array]" ? i.push([
				n.doBidiReorder(t[a][0]),
				t[a][1],
				t[a][2]
			]) : i.push([n.doBidiReorder(t[a])]);
			e.text = i;
		} else e.text = n.doBidiReorder(t);
		n.setOptions({ isInputVisual: !0 });
	}]);
}(Z), Z.API.TTFFont = function() {
	function e(e) {
		var t;
		if (this.rawData = e, t = this.contents = new bc(e), this.contents.pos = 4, t.readString(4) === "ttcf") throw Error("TTCF not supported.");
		t.pos = 0, this.parse(), this.subset = new zc(this), this.registerTTF();
	}
	return e.open = function(t) {
		return new e(t);
	}, e.prototype.parse = function() {
		return this.directory = new xc(this.contents), this.head = new wc(this), this.name = new jc(this), this.cmap = new Ec(this), this.toUnicode = {}, this.hhea = new Dc(this), this.maxp = new Mc(this), this.hmtx = new Nc(this), this.post = new kc(this), this.os2 = new Oc(this), this.loca = new Rc(this), this.glyf = new Fc(this), this.ascender = this.os2.exists && this.os2.ascender || this.hhea.ascender, this.decender = this.os2.exists && this.os2.decender || this.hhea.decender, this.lineGap = this.os2.exists && this.os2.lineGap || this.hhea.lineGap, this.bbox = [
			this.head.xMin,
			this.head.yMin,
			this.head.xMax,
			this.head.yMax
		];
	}, e.prototype.registerTTF = function() {
		var e, t, n, r, i;
		if (this.scaleFactor = 1e3 / this.head.unitsPerEm, this.bbox = function() {
			var t, n, r, i = [];
			for (t = 0, n = (r = this.bbox).length; t < n; t++) e = r[t], i.push(Math.round(e * this.scaleFactor));
			return i;
		}.call(this), this.stemV = 0, this.post.exists ? (n = 255 & (r = this.post.italic_angle), 32768 & (t = r >> 16) && (t = -(1 + (65535 ^ t))), this.italicAngle = +(t + "." + n)) : this.italicAngle = 0, this.ascender = Math.round(this.ascender * this.scaleFactor), this.decender = Math.round(this.decender * this.scaleFactor), this.lineGap = Math.round(this.lineGap * this.scaleFactor), this.capHeight = this.os2.exists && this.os2.capHeight || this.ascender, this.xHeight = this.os2.exists && this.os2.xHeight || 0, this.familyClass = (this.os2.exists && this.os2.familyClass || 0) >> 8, this.isSerif = (i = this.familyClass) === 1 || i === 2 || i === 3 || i === 4 || i === 5 || i === 7, this.isScript = this.familyClass === 10, this.flags = 0, this.post.isFixedPitch && (this.flags |= 1), this.isSerif && (this.flags |= 2), this.isScript && (this.flags |= 8), this.italicAngle !== 0 && (this.flags |= 64), this.flags |= 32, !this.cmap.unicode) throw Error("No unicode cmap for font");
	}, e.prototype.characterToGlyph = function(e) {
		return this.cmap.unicode?.codeMap[e] || 0;
	}, e.prototype.widthOfGlyph = function(e) {
		var t = 1e3 / this.head.unitsPerEm;
		return this.hmtx.forGlyph(e).advance * t;
	}, e.prototype.widthOfString = function(e, t, n) {
		var r, i, a = 0, o;
		for (i = 0, o = (e = "" + e).length; 0 <= o ? i < o : i > o; i = 0 <= o ? ++i : --i) r = e.charCodeAt(i), a += this.widthOfGlyph(this.characterToGlyph(r)) + 1e3 / t * n || 0;
		return t / 1e3 * a;
	}, e.prototype.lineHeight = function(e, t) {
		var n;
		return t ??= !1, n = t ? this.lineGap : 0, (this.ascender + n - this.decender) / 1e3 * e;
	}, e;
}();
var yc, bc = function() {
	function e(e) {
		this.data = e ?? [], this.pos = 0, this.length = this.data.length;
	}
	return e.prototype.readByte = function() {
		return this.data[this.pos++];
	}, e.prototype.writeByte = function(e) {
		return this.data[this.pos++] = e;
	}, e.prototype.readUInt32 = function() {
		return 16777216 * this.readByte() + (this.readByte() << 16) + (this.readByte() << 8) + this.readByte();
	}, e.prototype.writeUInt32 = function(e) {
		return this.writeByte(e >>> 24 & 255), this.writeByte(e >> 16 & 255), this.writeByte(e >> 8 & 255), this.writeByte(255 & e);
	}, e.prototype.readInt32 = function() {
		var e;
		return (e = this.readUInt32()) >= 2147483648 ? e - 4294967296 : e;
	}, e.prototype.writeInt32 = function(e) {
		return e < 0 && (e += 4294967296), this.writeUInt32(e);
	}, e.prototype.readUInt16 = function() {
		return this.readByte() << 8 | this.readByte();
	}, e.prototype.writeUInt16 = function(e) {
		return this.writeByte(e >> 8 & 255), this.writeByte(255 & e);
	}, e.prototype.readInt16 = function() {
		var e;
		return (e = this.readUInt16()) >= 32768 ? e - 65536 : e;
	}, e.prototype.writeInt16 = function(e) {
		return e < 0 && (e += 65536), this.writeUInt16(e);
	}, e.prototype.readString = function(e) {
		var t, n = [];
		for (t = 0; 0 <= e ? t < e : t > e; t = 0 <= e ? ++t : --t) n[t] = String.fromCharCode(this.readByte());
		return n.join("");
	}, e.prototype.writeString = function(e) {
		var t, n, r = [];
		for (t = 0, n = e.length; 0 <= n ? t < n : t > n; t = 0 <= n ? ++t : --t) r.push(this.writeByte(e.charCodeAt(t)));
		return r;
	}, e.prototype.readShort = function() {
		return this.readInt16();
	}, e.prototype.writeShort = function(e) {
		return this.writeInt16(e);
	}, e.prototype.readLongLong = function() {
		var e = this.readByte(), t = this.readByte(), n = this.readByte(), r = this.readByte(), i = this.readByte(), a = this.readByte(), o = this.readByte(), s = this.readByte();
		return 128 & e ? -1 * (72057594037927940 * (255 ^ e) + 281474976710656 * (255 ^ t) + 1099511627776 * (255 ^ n) + 4294967296 * (255 ^ r) + 16777216 * (255 ^ i) + 65536 * (255 ^ a) + 256 * (255 ^ o) + (255 ^ s) + 1) : 72057594037927940 * e + 281474976710656 * t + 1099511627776 * n + 4294967296 * r + 16777216 * i + 65536 * a + 256 * o + s;
	}, e.prototype.writeLongLong = function(e) {
		var t = Math.floor(e / 4294967296), n = 0 | e;
		return this.writeByte(t >> 24 & 255), this.writeByte(t >> 16 & 255), this.writeByte(t >> 8 & 255), this.writeByte(255 & t), this.writeByte(n >> 24 & 255), this.writeByte(n >> 16 & 255), this.writeByte(n >> 8 & 255), this.writeByte(255 & n);
	}, e.prototype.readInt = function() {
		return this.readInt32();
	}, e.prototype.writeInt = function(e) {
		return this.writeInt32(e);
	}, e.prototype.read = function(e) {
		for (var t = [], n = 0; 0 <= e ? n < e : n > e; n = 0 <= e ? ++n : --n) t.push(this.readByte());
		return t;
	}, e.prototype.write = function(e) {
		var t, n, r, i = [];
		for (n = 0, r = e.length; n < r; n++) t = e[n], i.push(this.writeByte(t));
		return i;
	}, e;
}(), xc = function() {
	var e;
	function t(e) {
		var t, n, r;
		for (this.scalarType = e.readInt(), this.tableCount = e.readShort(), this.searchRange = e.readShort(), this.entrySelector = e.readShort(), this.rangeShift = e.readShort(), this.tables = {}, n = 0, r = this.tableCount; 0 <= r ? n < r : n > r; n = 0 <= r ? ++n : --n) t = {
			tag: e.readString(4),
			checksum: e.readInt(),
			offset: e.readInt(),
			length: e.readInt()
		}, this.tables[t.tag] = t;
	}
	return t.prototype.encode = function(t) {
		var n, r, i, a, o, s, c, l, u, d, f = Object.keys(t).length, p, m;
		for (m in s = Math.log(2), u = 16 * Math.floor(Math.log(f) / s), a = Math.floor(u / s), l = 16 * f - u, (r = new bc()).writeInt(this.scalarType), r.writeShort(f), r.writeShort(u), r.writeShort(a), r.writeShort(l), i = 16 * f, c = r.pos + i, o = null, p = [], t) for (d = t[m], r.writeString(m), r.writeInt(e(d)), r.writeInt(c), r.writeInt(d.length), p = p.concat(d), m === "head" && (o = c), c += d.length; c % 4;) p.push(0), c++;
		return r.write(p), n = 2981146554 - e(r.data), r.pos = o + 8, r.writeUInt32(n), r.data;
	}, e = function(e) {
		var t, n, r, i;
		for (e = Pc.call(e); e.length % 4;) e.push(0);
		for (r = new bc(e), n = 0, t = 0, i = e.length; t < i; t = t += 4) n += r.readUInt32();
		return 0 | n;
	}, t;
}(), Sc = {}.hasOwnProperty, Cc = function(e, t) {
	for (var n in t) Sc.call(t, n) && (e[n] = t[n]);
	function r() {
		this.constructor = e;
	}
	return r.prototype = t.prototype, e.prototype = new r(), e.__super__ = t.prototype, e;
};
yc = function() {
	function e(e) {
		var t;
		this.file = e, t = this.file.directory.tables[this.tag], this.exists = !!t, t && (this.offset = t.offset, this.length = t.length, this.parse(this.file.contents));
	}
	return e.prototype.parse = function() {}, e.prototype.encode = function() {}, e.prototype.raw = function() {
		return this.exists ? (this.file.contents.pos = this.offset, this.file.contents.read(this.length)) : null;
	}, e;
}();
var wc = function() {
	function e() {
		return e.__super__.constructor.apply(this, arguments);
	}
	return Cc(e, yc), e.prototype.tag = "head", e.prototype.parse = function(e) {
		return e.pos = this.offset, this.version = e.readInt(), this.revision = e.readInt(), this.checkSumAdjustment = e.readInt(), this.magicNumber = e.readInt(), this.flags = e.readShort(), this.unitsPerEm = e.readShort(), this.created = e.readLongLong(), this.modified = e.readLongLong(), this.xMin = e.readShort(), this.yMin = e.readShort(), this.xMax = e.readShort(), this.yMax = e.readShort(), this.macStyle = e.readShort(), this.lowestRecPPEM = e.readShort(), this.fontDirectionHint = e.readShort(), this.indexToLocFormat = e.readShort(), this.glyphDataFormat = e.readShort();
	}, e.prototype.encode = function(e) {
		var t;
		return (t = new bc()).writeInt(this.version), t.writeInt(this.revision), t.writeInt(this.checkSumAdjustment), t.writeInt(this.magicNumber), t.writeShort(this.flags), t.writeShort(this.unitsPerEm), t.writeLongLong(this.created), t.writeLongLong(this.modified), t.writeShort(this.xMin), t.writeShort(this.yMin), t.writeShort(this.xMax), t.writeShort(this.yMax), t.writeShort(this.macStyle), t.writeShort(this.lowestRecPPEM), t.writeShort(this.fontDirectionHint), t.writeShort(e), t.writeShort(this.glyphDataFormat), t.data;
	}, e;
}(), Tc = function() {
	function e(e, t) {
		var n, r, i, a, o, s, c, l, u, d, f, p, m, h, g, _, v;
		switch (this.platformID = e.readUInt16(), this.encodingID = e.readShort(), this.offset = t + e.readInt(), u = e.pos, e.pos = this.offset, this.format = e.readUInt16(), this.length = e.readUInt16(), this.language = e.readUInt16(), this.isUnicode = this.platformID === 3 && this.encodingID === 1 && this.format === 4 || this.platformID === 0 && this.format === 4, this.codeMap = {}, this.format) {
			case 0:
				for (s = 0; s < 256; ++s) this.codeMap[s] = e.readByte();
				break;
			case 4: for (f = e.readUInt16(), d = f / 2, e.pos += 6, i = function() {
				var t, n = [];
				for (s = t = 0; 0 <= d ? t < d : t > d; s = 0 <= d ? ++t : --t) n.push(e.readUInt16());
				return n;
			}(), e.pos += 2, m = function() {
				var t, n = [];
				for (s = t = 0; 0 <= d ? t < d : t > d; s = 0 <= d ? ++t : --t) n.push(e.readUInt16());
				return n;
			}(), c = function() {
				var t, n = [];
				for (s = t = 0; 0 <= d ? t < d : t > d; s = 0 <= d ? ++t : --t) n.push(e.readUInt16());
				return n;
			}(), l = function() {
				var t, n = [];
				for (s = t = 0; 0 <= d ? t < d : t > d; s = 0 <= d ? ++t : --t) n.push(e.readUInt16());
				return n;
			}(), r = (this.length - e.pos + this.offset) / 2, o = function() {
				var t, n = [];
				for (s = t = 0; 0 <= r ? t < r : t > r; s = 0 <= r ? ++t : --t) n.push(e.readUInt16());
				return n;
			}(), s = g = 0, v = i.length; g < v; s = ++g) for (h = i[s], n = _ = p = m[s]; p <= h ? _ <= h : _ >= h; n = p <= h ? ++_ : --_) l[s] === 0 ? a = n + c[s] : (a = o[l[s] / 2 + (n - p) - (d - s)] || 0) !== 0 && (a += c[s]), this.codeMap[n] = 65535 & a;
		}
		e.pos = u;
	}
	return e.encode = function(e, t) {
		var n, r, i, a, o, s, c, l, u, d, f, p, m, h, g, _, v, y, b, x, S, C, w, T, E, D, O, k = new bc(), A, j, M, N, P, F, I, L, ee, R, z, B, te, V, H, U, ne, W;
		switch (a = Object.keys(e).sort(function(e, t) {
			return e - t;
		}), t) {
			case "macroman":
				for (m = 0, h = function() {
					var e = [];
					for (p = 0; p < 256; ++p) e.push(0);
					return e;
				}(), _ = { 0: 0 }, i = {}, A = 0, P = a.length; A < P; A++) _[H = e[r = a[A]]] ?? (_[H] = ++m), i[r] = {
					old: e[r],
					new: _[e[r]]
				}, h[r] = _[e[r]];
				return k.writeUInt16(1), k.writeUInt16(0), k.writeUInt32(12), k.writeUInt16(0), k.writeUInt16(262), k.writeUInt16(0), k.write(h), {
					charMap: i,
					subtable: k.data,
					maxGlyphID: m + 1
				};
			case "unicode":
				for (D = [], u = [], v = 0, _ = {}, n = {}, g = c = null, j = 0, F = a.length; j < F; j++) _[b = e[r = a[j]]] ?? (_[b] = ++v), n[r] = {
					old: b,
					new: _[b]
				}, o = _[b] - r, g != null && o === c || (g && u.push(g), D.push(r), c = o), g = r;
				for (g && u.push(g), u.push(65535), D.push(65535), T = 2 * (w = D.length), C = 2 * (Math.log(w) / Math.LN2) ** 2, d = Math.log(C / 2) / Math.LN2, S = 2 * w - C, s = [], x = [], f = [], p = M = 0, I = D.length; M < I; p = ++M) {
					if (E = D[p], l = u[p], E === 65535) {
						s.push(0), x.push(0);
						break;
					}
					if (E - (O = n[E].new) >= 32768) for (s.push(0), x.push(2 * (f.length + w - p)), r = N = E; E <= l ? N <= l : N >= l; r = E <= l ? ++N : --N) f.push(n[r].new);
					else s.push(O - E), x.push(0);
				}
				for (k.writeUInt16(3), k.writeUInt16(1), k.writeUInt32(12), k.writeUInt16(4), k.writeUInt16(16 + 8 * w + 2 * f.length), k.writeUInt16(0), k.writeUInt16(T), k.writeUInt16(C), k.writeUInt16(d), k.writeUInt16(S), te = 0, L = u.length; te < L; te++) r = u[te], k.writeUInt16(r);
				for (k.writeUInt16(0), V = 0, ee = D.length; V < ee; V++) r = D[V], k.writeUInt16(r);
				for (U = 0, R = s.length; U < R; U++) o = s[U], k.writeUInt16(o);
				for (ne = 0, z = x.length; ne < z; ne++) y = x[ne], k.writeUInt16(y);
				for (W = 0, B = f.length; W < B; W++) m = f[W], k.writeUInt16(m);
				return {
					charMap: n,
					subtable: k.data,
					maxGlyphID: v + 1
				};
		}
	}, e;
}(), Ec = function() {
	function e() {
		return e.__super__.constructor.apply(this, arguments);
	}
	return Cc(e, yc), e.prototype.tag = "cmap", e.prototype.parse = function(e) {
		var t, n, r;
		for (e.pos = this.offset, this.version = e.readUInt16(), r = e.readUInt16(), this.tables = [], this.unicode = null, n = 0; 0 <= r ? n < r : n > r; n = 0 <= r ? ++n : --n) t = new Tc(e, this.offset), this.tables.push(t), t.isUnicode && this.unicode == null && (this.unicode = t);
		return !0;
	}, e.encode = function(e, t) {
		var n, r;
		return t ??= "macroman", n = Tc.encode(e, t), (r = new bc()).writeUInt16(0), r.writeUInt16(1), n.table = r.data.concat(n.subtable), n;
	}, e;
}(), Dc = function() {
	function e() {
		return e.__super__.constructor.apply(this, arguments);
	}
	return Cc(e, yc), e.prototype.tag = "hhea", e.prototype.parse = function(e) {
		return e.pos = this.offset, this.version = e.readInt(), this.ascender = e.readShort(), this.decender = e.readShort(), this.lineGap = e.readShort(), this.advanceWidthMax = e.readShort(), this.minLeftSideBearing = e.readShort(), this.minRightSideBearing = e.readShort(), this.xMaxExtent = e.readShort(), this.caretSlopeRise = e.readShort(), this.caretSlopeRun = e.readShort(), this.caretOffset = e.readShort(), e.pos += 8, this.metricDataFormat = e.readShort(), this.numberOfMetrics = e.readUInt16();
	}, e;
}(), Oc = function() {
	function e() {
		return e.__super__.constructor.apply(this, arguments);
	}
	return Cc(e, yc), e.prototype.tag = "OS/2", e.prototype.parse = function(e) {
		if (e.pos = this.offset, this.version = e.readUInt16(), this.averageCharWidth = e.readShort(), this.weightClass = e.readUInt16(), this.widthClass = e.readUInt16(), this.type = e.readShort(), this.ySubscriptXSize = e.readShort(), this.ySubscriptYSize = e.readShort(), this.ySubscriptXOffset = e.readShort(), this.ySubscriptYOffset = e.readShort(), this.ySuperscriptXSize = e.readShort(), this.ySuperscriptYSize = e.readShort(), this.ySuperscriptXOffset = e.readShort(), this.ySuperscriptYOffset = e.readShort(), this.yStrikeoutSize = e.readShort(), this.yStrikeoutPosition = e.readShort(), this.familyClass = e.readShort(), this.panose = function() {
			var t, n = [];
			for (t = 0; t < 10; ++t) n.push(e.readByte());
			return n;
		}(), this.charRange = function() {
			var t, n = [];
			for (t = 0; t < 4; ++t) n.push(e.readInt());
			return n;
		}(), this.vendorID = e.readString(4), this.selection = e.readShort(), this.firstCharIndex = e.readShort(), this.lastCharIndex = e.readShort(), this.version > 0 && (this.ascent = e.readShort(), this.descent = e.readShort(), this.lineGap = e.readShort(), this.winAscent = e.readShort(), this.winDescent = e.readShort(), this.codePageRange = function() {
			var t, n = [];
			for (t = 0; t < 2; t = ++t) n.push(e.readInt());
			return n;
		}(), this.version > 1)) return this.xHeight = e.readShort(), this.capHeight = e.readShort(), this.defaultChar = e.readShort(), this.breakChar = e.readShort(), this.maxContext = e.readShort();
	}, e;
}(), kc = function() {
	function e() {
		return e.__super__.constructor.apply(this, arguments);
	}
	return Cc(e, yc), e.prototype.tag = "post", e.prototype.parse = function(e) {
		var t, n, r;
		switch (e.pos = this.offset, this.format = e.readInt(), this.italicAngle = e.readInt(), this.underlinePosition = e.readShort(), this.underlineThickness = e.readShort(), this.isFixedPitch = e.readInt(), this.minMemType42 = e.readInt(), this.maxMemType42 = e.readInt(), this.minMemType1 = e.readInt(), this.maxMemType1 = e.readInt(), this.format) {
			case 65536:
			case 196608: break;
			case 131072:
				var i;
				for (n = e.readUInt16(), this.glyphNameIndex = [], i = 0; 0 <= n ? i < n : i > n; i = 0 <= n ? ++i : --i) this.glyphNameIndex.push(e.readUInt16());
				for (this.names = [], r = []; e.pos < this.offset + this.length;) t = e.readByte(), r.push(this.names.push(e.readString(t)));
				return r;
			case 151552: return n = e.readUInt16(), this.offsets = e.read(n);
			case 262144: return this.map = function() {
				var t, n, r = [];
				for (i = t = 0, n = this.file.maxp.numGlyphs; 0 <= n ? t < n : t > n; i = 0 <= n ? ++t : --t) r.push(e.readUInt32());
				return r;
			}.call(this);
		}
	}, e;
}(), Ac = function(e, t) {
	this.raw = e, this.length = e.length, this.platformID = t.platformID, this.encodingID = t.encodingID, this.languageID = t.languageID;
}, jc = function() {
	function e() {
		return e.__super__.constructor.apply(this, arguments);
	}
	return Cc(e, yc), e.prototype.tag = "name", e.prototype.parse = function(e) {
		var t, n, r, i, a, o, s, c, l, u, d;
		for (e.pos = this.offset, e.readShort(), t = e.readShort(), o = e.readShort(), n = [], i = 0; 0 <= t ? i < t : i > t; i = 0 <= t ? ++i : --i) n.push({
			platformID: e.readShort(),
			encodingID: e.readShort(),
			languageID: e.readShort(),
			nameID: e.readShort(),
			length: e.readShort(),
			offset: this.offset + o + e.readShort()
		});
		for (s = {}, i = l = 0, u = n.length; l < u; i = ++l) r = n[i], e.pos = r.offset, c = e.readString(r.length), a = new Ac(c, r), s[d = r.nameID] ?? (s[d] = []), s[r.nameID].push(a);
		this.strings = s, this.copyright = s[0], this.fontFamily = s[1], this.fontSubfamily = s[2], this.uniqueSubfamily = s[3], this.fontName = s[4], this.version = s[5];
		try {
			this.postscriptName = s[6][0].raw.replace(/[\x00-\x19\x80-\xff]/g, "");
		} catch {
			this.postscriptName = s[4][0].raw.replace(/[\x00-\x19\x80-\xff]/g, "");
		}
		return this.trademark = s[7], this.manufacturer = s[8], this.designer = s[9], this.description = s[10], this.vendorUrl = s[11], this.designerUrl = s[12], this.license = s[13], this.licenseUrl = s[14], this.preferredFamily = s[15], this.preferredSubfamily = s[17], this.compatibleFull = s[18], this.sampleText = s[19];
	}, e;
}(), Mc = function() {
	function e() {
		return e.__super__.constructor.apply(this, arguments);
	}
	return Cc(e, yc), e.prototype.tag = "maxp", e.prototype.parse = function(e) {
		return e.pos = this.offset, this.version = e.readInt(), this.numGlyphs = e.readUInt16(), this.maxPoints = e.readUInt16(), this.maxContours = e.readUInt16(), this.maxCompositePoints = e.readUInt16(), this.maxComponentContours = e.readUInt16(), this.maxZones = e.readUInt16(), this.maxTwilightPoints = e.readUInt16(), this.maxStorage = e.readUInt16(), this.maxFunctionDefs = e.readUInt16(), this.maxInstructionDefs = e.readUInt16(), this.maxStackElements = e.readUInt16(), this.maxSizeOfInstructions = e.readUInt16(), this.maxComponentElements = e.readUInt16(), this.maxComponentDepth = e.readUInt16();
	}, e;
}(), Nc = function() {
	function e() {
		return e.__super__.constructor.apply(this, arguments);
	}
	return Cc(e, yc), e.prototype.tag = "hmtx", e.prototype.parse = function(e) {
		var t, n, r, i, a, o, s;
		for (e.pos = this.offset, this.metrics = [], t = 0, o = this.file.hhea.numberOfMetrics; 0 <= o ? t < o : t > o; t = 0 <= o ? ++t : --t) this.metrics.push({
			advance: e.readUInt16(),
			lsb: e.readInt16()
		});
		for (r = this.file.maxp.numGlyphs - this.file.hhea.numberOfMetrics, this.leftSideBearings = function() {
			var n, i = [];
			for (t = n = 0; 0 <= r ? n < r : n > r; t = 0 <= r ? ++n : --n) i.push(e.readInt16());
			return i;
		}(), this.widths = function() {
			var e, t, n, r = [];
			for (e = 0, t = (n = this.metrics).length; e < t; e++) i = n[e], r.push(i.advance);
			return r;
		}.call(this), n = this.widths[this.widths.length - 1], s = [], t = a = 0; 0 <= r ? a < r : a > r; t = 0 <= r ? ++a : --a) s.push(this.widths.push(n));
		return s;
	}, e.prototype.forGlyph = function(e) {
		return e in this.metrics ? this.metrics[e] : {
			advance: this.metrics[this.metrics.length - 1].advance,
			lsb: this.leftSideBearings[e - this.metrics.length]
		};
	}, e;
}(), Pc = [].slice, Fc = function() {
	function e() {
		return e.__super__.constructor.apply(this, arguments);
	}
	return Cc(e, yc), e.prototype.tag = "glyf", e.prototype.parse = function() {
		return this.cache = {};
	}, e.prototype.glyphFor = function(e) {
		var t, n, r, i, a, o, s, c, l, u;
		return e in this.cache ? this.cache[e] : (i = this.file.loca, t = this.file.contents, n = i.indexOf(e), (r = i.lengthOf(e)) === 0 ? this.cache[e] = null : (t.pos = this.offset + n, a = (o = new bc(t.read(r))).readShort(), c = o.readShort(), u = o.readShort(), s = o.readShort(), l = o.readShort(), this.cache[e] = a === -1 ? new Lc(o, c, u, s, l) : new Ic(o, a, c, u, s, l), this.cache[e]));
	}, e.prototype.encode = function(e, t, n) {
		var r, i, a = [], o, s;
		for (i = [], o = 0, s = t.length; o < s; o++) r = e[t[o]], i.push(a.length), r && (a = a.concat(r.encode(n)));
		return i.push(a.length), {
			table: a,
			offsets: i
		};
	}, e;
}(), Ic = function() {
	function e(e, t, n, r, i, a) {
		this.raw = e, this.numberOfContours = t, this.xMin = n, this.yMin = r, this.xMax = i, this.yMax = a, this.compound = !1;
	}
	return e.prototype.encode = function() {
		return this.raw.data;
	}, e;
}(), Lc = function() {
	function e(e, t, n, r, i) {
		var a, o;
		for (this.raw = e, this.xMin = t, this.yMin = n, this.xMax = r, this.yMax = i, this.compound = !0, this.glyphIDs = [], this.glyphOffsets = [], a = this.raw; o = a.readShort(), this.glyphOffsets.push(a.pos), this.glyphIDs.push(a.readUInt16()), 32 & o;) a.pos += 1 & o ? 4 : 2, 128 & o ? a.pos += 8 : 64 & o ? a.pos += 4 : 8 & o && (a.pos += 2);
	}
	return e.prototype.encode = function() {
		var e, t = new bc(Pc.call(this.raw.data)), n;
		for (e = 0, n = this.glyphIDs.length; e < n; ++e) t.pos = this.glyphOffsets[e];
		return t.data;
	}, e;
}(), Rc = function() {
	function e() {
		return e.__super__.constructor.apply(this, arguments);
	}
	return Cc(e, yc), e.prototype.tag = "loca", e.prototype.parse = function(e) {
		var t, n;
		return e.pos = this.offset, t = this.file.head.indexToLocFormat, this.offsets = t === 0 ? function() {
			var t, r = [];
			for (n = 0, t = this.length; n < t; n += 2) r.push(2 * e.readUInt16());
			return r;
		}.call(this) : function() {
			var t, r = [];
			for (n = 0, t = this.length; n < t; n += 4) r.push(e.readUInt32());
			return r;
		}.call(this);
	}, e.prototype.indexOf = function(e) {
		return this.offsets[e];
	}, e.prototype.lengthOf = function(e) {
		return this.offsets[e + 1] - this.offsets[e];
	}, e.prototype.encode = function(e, t) {
		for (var n = new Uint32Array(this.offsets.length), r = 0, i = 0, a = 0; a < n.length; ++a) if (n[a] = r, i < t.length && t[i] == a) {
			++i, n[a] = r;
			var o = this.offsets[a], s = this.offsets[a + 1] - o;
			s > 0 && (r += s);
		}
		for (var c = Array(4 * n.length), l = 0; l < n.length; ++l) c[4 * l + 3] = 255 & n[l], c[4 * l + 2] = (65280 & n[l]) >> 8, c[4 * l + 1] = (16711680 & n[l]) >> 16, c[4 * l] = (4278190080 & n[l]) >> 24;
		return c;
	}, e;
}(), zc = function() {
	function e(e) {
		this.font = e, this.subset = {}, this.unicodes = {}, this.next = 33;
	}
	return e.prototype.generateCmap = function() {
		var e, t, n, r = this.font.cmap.tables[0].codeMap, i;
		for (t in e = {}, i = this.subset) n = i[t], e[t] = r[n];
		return e;
	}, e.prototype.glyphsFor = function(e) {
		for (var t, n, r = {}, i, a = 0, o = e.length, s; a < o; a++) r[i = e[a]] = this.font.glyf.glyphFor(i);
		for (i in t = [], r) (n = r[i]) != null && n.compound && t.push.apply(t, n.glyphIDs);
		if (t.length > 0) for (i in s = this.glyphsFor(t)) n = s[i], r[i] = n;
		return r;
	}, e.prototype.encode = function(e, t) {
		var n = Ec.encode(this.generateCmap(), "unicode"), r, i, a = this.glyphsFor(e), o, s, c, l, u, d, f = { 0: 0 }, p, m, h, g;
		for (r in g = n.charMap) f[(s = g[r]).old] = s.new;
		for (p in d = n.maxGlyphID, a) p in f || (f[p] = d++);
		return l = function(e) {
			var t, n = {};
			for (t in e) n[e[t]] = t;
			return n;
		}(f), u = Object.keys(l).sort(function(e, t) {
			return e - t;
		}), m = function() {
			var e, t, n = [];
			for (e = 0, t = u.length; e < t; e++) o = u[e], n.push(l[o]);
			return n;
		}(), i = this.font.glyf.encode(a, m, f), c = this.font.loca.encode(i.offsets, m), h = {
			cmap: this.font.cmap.raw(),
			glyf: i.table,
			loca: c,
			hmtx: this.font.hmtx.raw(),
			hhea: this.font.hhea.raw(),
			maxp: this.font.maxp.raw(),
			post: this.font.post.raw(),
			name: this.font.name.raw(),
			head: this.font.head.encode(t)
		}, this.font.os2.exists && (h["OS/2"] = this.font.os2.raw()), this.font.directory.encode(h);
	}, e;
}();
Z.API.PDFObject = function() {
	var e;
	function t() {}
	return e = function(e, t) {
		return (Array(t + 1).join("0") + e).slice(-t);
	}, t.convert = function(n) {
		var r, i, a, o;
		if (Array.isArray(n)) return "[" + function() {
			var e, i, a = [];
			for (e = 0, i = n.length; e < i; e++) r = n[e], a.push(t.convert(r));
			return a;
		}().join(" ") + "]";
		if (typeof n == "string") return "/" + n;
		if (n?.isString) return "(" + n + ")";
		if (n instanceof Date) return "(D:" + e(n.getUTCFullYear(), 4) + e(n.getUTCMonth(), 2) + e(n.getUTCDate(), 2) + e(n.getUTCHours(), 2) + e(n.getUTCMinutes(), 2) + e(n.getUTCSeconds(), 2) + "Z)";
		if ({}.toString.call(n) === "[object Object]") {
			for (i in a = ["<<"], n) o = n[i], a.push("/" + i + " " + t.convert(o));
			return a.push(">>"), a.join("\n");
		}
		return "" + n;
	}, t;
}();
// src/types/cv.ts
var Bc = {
	shape: "rounded",
	position: "left",
	size: "md",
	fit: "cover"
}, Vc = {
	summary: "Summary",
	objective: "Objective",
	skills: "Skills",
	experience: "Experience",
	projects: "Projects",
	education: "Education",
	certificates: "Certificates",
	"page-break": "Page break"
}, Hc = {
	English: {
		summary: "Summary",
		objective: "Objective",
		skills: "Skills",
		experience: "Experience",
		projects: "Projects",
		education: "Education",
		certificates: "Certificates",
		"page-break": "Page break"
	},
	Vietnamese: {
		summary: "Tóm tắt",
		objective: "Mục tiêu",
		skills: "Kỹ năng",
		experience: "Kinh nghiệm",
		projects: "Dự án",
		education: "Học vấn",
		certificates: "Chứng chỉ",
		"page-break": "Ngắt trang"
	},
	Japanese: {
		summary: "要約",
		objective: "志望動機",
		skills: "スキル",
		experience: "職歴",
		projects: "プロジェクト",
		education: "学歴",
		certificates: "資格",
		"page-break": "改ページ"
	},
	Korean: {
		summary: "요약",
		objective: "목표",
		skills: "스킬",
		experience: "경력",
		projects: "프로젝트",
		education: "학력",
		certificates: "자격증",
		"page-break": "페이지 나누기"
	},
	Chinese: {
		summary: "个人总结",
		objective: "求职意向",
		skills: "专业技能",
		experience: "工作经历",
		projects: "项目经验",
		education: "教育背景",
		certificates: "荣誉证书",
		"page-break": "分页符"
	}
}, Uc = {
	sm: 56,
	md: 72,
	lg: 90
};
// src/utils/richText.ts
function Wc(e) {
	return e ? !e.startsWith("http://") && !e.startsWith("https://") ? "https://" + e : e : "";
}
function Gc(e) {
	let t = [], n = "", r = !1, i = !1, a = !1, o = 0;
	for (; o < e.length;) e.startsWith("***", o) ? (n &&= (t.push({
		text: n,
		bold: r,
		italic: i,
		underline: a
	}), ""), r = !r, i = !i, o += 3) : e.startsWith("**", o) ? (n &&= (t.push({
		text: n,
		bold: r,
		italic: i,
		underline: a
	}), ""), r = !r, o += 2) : e.startsWith("<u>", o) ? (n &&= (t.push({
		text: n,
		bold: r,
		italic: i,
		underline: a
	}), ""), a = !0, o += 3) : e.startsWith("</u>", o) ? (n &&= (t.push({
		text: n,
		bold: r,
		italic: i,
		underline: a
	}), ""), a = !1, o += 4) : e.startsWith("*", o) || e.startsWith("_", o) ? (n &&= (t.push({
		text: n,
		bold: r,
		italic: i,
		underline: a
	}), ""), i = !i, o += 1) : (n += e[o], o += 1);
	return n && t.push({
		text: n,
		bold: r,
		italic: i,
		underline: a
	}), t;
}
// src/utils/fonts.ts
var Kc = {
	latin: {
		files: ["Calibri-Regular-normal.js", "Calibri-Bold-normal.js"],
		vars: ["CalibriRegular", "CalibriBold"]
	},
	garamond: {
		files: ["EBGaramond-Regular-normal.js", "EBGaramond-Bold-normal.js"],
		vars: ["font", "fontBold"]
	},
	ja: {
		files: ["NotoSansJP-Regular-normal.js", "NotoSansJP-Bold-normal.js"],
		vars: ["RegJap", "Boldjap"]
	},
	ko: {
		files: ["NotoSansKR-Regular-normal.js", "NotoSansKR-Bold-normal.js"],
		vars: ["KrRegular", "KrBold"]
	},
	zh: {
		files: ["NotoSansSC-Regular-normal.js", "NotoSansSC-Bold-normal.js"],
		vars: ["RegCN", "BoldCN"]
	}
};
function qc(e) {
	return e === "Japanese" || e === "ja" ? "ja" : e === "Korean" || e === "ko" ? "ko" : e === "Chinese" || e === "zh" ? "zh" : "latin";
}
function Jc(e) {
	let t = window, [n, r] = Kc[e].vars, i = t[n], a = t[r];
	return i && a ? {
		normal: i,
		bold: a
	} : null;
}
function Yc(e) {
	return !/[^\x00-\xFF•–—‘’“”…€ŒœŠšŸŽžƒˆ˜†‡‰‹›™]/.test(e);
}
function Xc(e) {
	return [
		"notosans",
		"times",
		"garamond",
		"arial",
		"custom"
	].includes(e) ? e : "notosans";
}
function Zc(e, t, n, r) {
	let i = qc(n);
	if (i !== "latin") return {
		family: "NotoSans",
		embed: i,
		fellBack: !1
	};
	let a = Xc(e);
	if (a === "notosans") return {
		family: "NotoSans",
		embed: "latin",
		fellBack: !1
	};
	if (a === "garamond") return {
		family: "EBGaramond",
		embed: "garamond",
		fellBack: !1
	};
	let o = a === "arial" ? "helvetica" : "times";
	if (a === "custom") {
		let e = t.trim().toLowerCase();
		o = /arial|sans|helvetica|inter|roboto|system/.test(e) ? "helvetica" : /courier|mono/.test(e) ? "courier" : "times";
	}
	return Yc(r) ? {
		family: o,
		embed: null,
		fellBack: !1
	} : {
		family: "NotoSans",
		embed: "latin",
		fellBack: !0
	};
}
// src/utils/pdf/renderCv.ts
function Qc(e, t) {
	let n = Math.min(1.6, Math.max(.8, t));
	if (e === "harvard") {
		let e = Math.round(10.5 * n * 2) / 2;
		return {
			marginX: 46,
			top: 44,
			bottom: 40,
			body: e,
			lineH: Math.round(e * 1.24 * 10) / 10,
			bulletLineH: Math.round(e * 1.22 * 10) / 10,
			nameSize: Math.round(e * 1.65),
			headingSize: e + .5,
			headingCentered: !1,
			headingUpper: !1,
			sectionGapBefore: Math.round(7 * n),
			sectionGapAfter: Math.round(e * 1.35),
			entryGap: Math.round(4 * n),
			justify: !1,
			muted: "#000000",
			linkColor: "#000000",
			bulletIndent: 6,
			bulletTextGap: 10,
			uppercaseOrg: !1
		};
	}
	return {
		marginX: 40,
		top: 40,
		bottom: 30,
		body: Math.max(10, Math.round(10 * n)),
		lineH: Math.max(15, Math.round(16 * n)),
		bulletLineH: Math.max(10, Math.round(14 * n)),
		nameSize: Math.round(14 * n) + 2,
		headingSize: Math.round(14 * n),
		headingCentered: !1,
		headingUpper: !1,
		sectionGapBefore: Math.max(3, Math.round(5 * n)),
		sectionGapAfter: Math.max(15, Math.round(21 * n)),
		entryGap: Math.max(2, Math.round(3 * n)),
		justify: !1,
		muted: "#333333",
		linkColor: "#115bca",
		bulletIndent: 0,
		bulletTextGap: 14,
		uppercaseOrg: !0
	};
}
function $c(e, t) {
	return e && t ? "bolditalic" : e ? "bold" : t ? "italic" : "normal";
}
function el(e, t = "normal") {
	let n = [];
	for (let r of Gc(e)) {
		let e = $c(r.bold || t === "bold" || t === "bolditalic", r.italic || t === "italic" || t === "bolditalic");
		(r.text.match(/\s*\S+\s*/g) || (r.text ? [r.text] : [])).forEach((t) => n.push({
			text: t,
			style: e,
			underline: r.underline
		}));
	}
	return n;
}
function tl(e) {
	return e.replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/$/, "");
}
function nl(e) {
	let t = [
		e.name,
		e.title || "",
		e.location,
		e.email,
		e.phone,
		e.summary,
		e.objective
	];
	return e.experiences.forEach((e) => t.push(e.position, e.company, e.location, e.dates, ...e.bullets.map((e) => e.text))), t.push(e.projectIntro || ""), e.projects.forEach((e) => t.push(e.projectName, e.overview || "", e.dates || "", e.technologies || "", ...e.bullets.map((e) => e.text))), e.customSections?.forEach((e) => {
		t.push(e.title), e.entries.forEach((e) => t.push(e.position, e.company, e.location, e.dates, ...e.bullets.map((e) => e.text)));
	}), e.skills.forEach((e) => t.push(e.skill, e.description)), e.educations.forEach((e) => t.push(e.university, e.degree, e.gpa, e.graduationDate)), e.certificates.forEach((e) => t.push(e.certName, e["issuer/description"], e.certDate)), t.filter(Boolean).join("\n");
}
function rl(e) {
	let { cv: t } = e, n = Object.values(e.sectionLabels).join(" "), r = Zc(e.selectedFont, e.customFontName, e.language, `${nl(t)} ${n}`), i = r.embed ? Jc(r.embed) : null;
	if (r.embed && !i) return {
		ok: !1,
		needsFonts: r.embed
	};
	let a = Qc(e.template, e.sizeMultiplier), o = new Z({
		orientation: "p",
		unit: "pt",
		format: "a4",
		putOnlyUsedFonts: !0,
		compress: !0
	});
	i && (o.addFileToVFS("CvFont-normal.ttf", i.normal), o.addFileToVFS("CvFont-bold.ttf", i.bold), o.addFont("CvFont-normal.ttf", r.family, "normal"), o.addFont("CvFont-bold.ttf", r.family, "bold"), o.addFont("CvFont-normal.ttf", r.family, "italic"), o.addFont("CvFont-bold.ttf", r.family, "bolditalic")), o.setProperties({
		title: `${t.name || "CV"} - CV`,
		author: t.name || "",
		creator: "CV Editor"
	});
	let s = o.internal.pageSize.getWidth(), c = o.internal.pageSize.getHeight(), l = a.marginX, u = s - a.marginX, d = u - l, f = c - a.bottom, p = a.top, m = "normal", h = a.body, g = !1, _ = !1, v = (e, t = a.body) => {
		m = e, h = t, o.setFont(r.family, e), o.setFontSize(t);
	}, y = /* @__PURE__ */ new Map(), b = (e) => {
		let t = 0;
		for (let n of e) {
			let e = `${m}|${h}|${n}`, r = y.get(e);
			r === void 0 && (r = o.getTextWidth(n), y.set(e, r)), t += r;
		}
		return t;
	}, x = (e, t, n) => o.text(e, t - b(e), n), S = (e, t, n) => o.text(e, t - b(e) / 2, n), C = (e) => o.setTextColor(e), w = (e) => {
		p + e > f && (o.addPage("a4", "p"), p = a.top + a.body);
	}, T = (e, t) => (v(e.style, t), b(e.text));
	function E(e, t, n) {
		let r = 0, i = [], a = 0;
		for (let o of e) {
			let e = T(o, n), s = T({
				...o,
				text: o.text.trimEnd()
			}, n);
			if (i.length && a + s > t) {
				r++;
				let e = {
					...o,
					text: o.text.trimStart()
				};
				i = [e], a = T(e, n);
			} else i.push(o), a += e;
		}
		return r + +!!i.length;
	}
	function D(e) {
		v("normal", a.body);
		let t = e.projectLink?.trim(), n = t ? tl(t) : "", r = 0, i = e.dates?.trim() ? d - (b(e.dates.trim()) + 12) : n && b(n) < d * .45 ? d - b(n) - 12 : d;
		r += E(el(`**${G(e.projectName.trim())}**`), i, a.body) * a.lineH, e.dates?.trim() && n && (r += a.lineH), e.overview?.trim() && (r += E(el(e.overview.trim()), d, a.body) * a.lineH), e.technologies?.trim() && (r += 2 + E(el(`**Technologies:** ${e.technologies.trim()}`), d - a.bulletIndent - a.bulletTextGap, a.body) * a.bulletLineH);
		let o = e.bullets.filter((e) => e.text.trim());
		o.length && (r += 2);
		for (let e of o) {
			let t = e.type === "header", n = t ? d : d - a.bulletIndent - a.bulletTextGap;
			r += E(el(e.text.trim()), n, a.body) * (t ? a.lineH : a.bulletLineH);
		}
		return r + 4;
	}
	function O(e, t, n, r, i = a.body, s = a.justify) {
		let c = [], l = [], u = 0;
		for (let t of e) {
			let e = T(t, i);
			l.length && u + T({
				...t,
				text: t.text.trimEnd()
			}, i) > n ? (c.push(l), l = [{
				...t,
				text: t.text.trimStart()
			}], u = T(l[0], i)) : (l.push(t), u += e);
		}
		l.length && c.push(l), c.forEach((e, a) => {
			w(r * .3);
			let l = a === c.length - 1, u = e.map((t, n) => n === e.length - 1 ? {
				...t,
				text: t.text.trimEnd()
			} : t), d = u.reduce((e, t) => e + T(t, i), 0), f = u.length - 1, m = s && !l && f > 0 ? (n - d) / f : 0, h = t;
			u.forEach((e) => {
				v(e.style, i), o.text(e.text, h, p);
				let t = b(e.text);
				e.underline && (o.setLineWidth(.4), o.line(h, p + 1, h + b(e.text.trimEnd()), p + 1)), h += t + m;
			}), p += r;
		});
	}
	function k(e, t, n, r = "normal") {
		w(a.lineH), v(r);
		let i = n ? b(n) + 12 : 0;
		n && (C(a.muted), x(n, u, p), C("#000000")), O(el(e, t), l, d - i, a.lineH, a.body, !1);
	}
	let A = [];
	[
		t.location,
		t.email,
		t.phone
	].forEach((e) => e?.trim() && A.push({ text: e.trim() })), t.email?.trim() && (A[A.findIndex((e) => e.text === t.email.trim())].url = `mailto:${t.email.trim()}`), [
		[t.github, t.github_placeholder],
		[t.website, t.website_placeholder],
		[t.linkedin, t.linkedin_placeholder]
	].forEach(([e, t]) => {
		(e?.trim() || t?.trim()) && A.push({
			text: (t || tl(e || "")).trim(),
			url: e ? Wc(e.trim()) : void 0
		});
	});
	let j = e.template === "harvard" ? a.body - .5 : Math.max(9, Math.round(a.body * .9)), M = e.avatarStyle ?? Bc, N = !!t.profileImage, P = Uc[M.size] ?? Uc.md, F = p - 6, I = l, L = d, ee = !0;
	N && M.position === "left" ? (I = l + P + 14, L = u - I, ee = !1) : N && M.position === "right" && (L = d - P - 14, ee = !1);
	function R(e, n) {
		try {
			let r = t.profileImage, i = o.getImageProperties(r);
			o.saveGraphicsState(), M.shape === "circle" ? o.circle(e + P / 2, n + P / 2, P / 2, null) : M.shape === "rounded" ? o.roundedRect(e, n, P, P, P * .16, P * .16, null) : o.rect(e, n, P, P, null), o.clip(), o.discardPath();
			let a = M.fit === "contain" ? Math.min(P / i.width, P / i.height) : Math.max(P / i.width, P / i.height), s = i.width * a, c = i.height * a;
			o.addImage(r, i.fileType || "JPEG", e + (P - s) / 2, n + (P - c) / 2, s, c, "avatar", "MEDIUM"), o.restoreGraphicsState();
		} catch (e) {
			console.error("Profile image failed to render:", e);
		}
	}
	N && (M.position === "center" ? (R(s / 2 - P / 2, F), p = F + P + 6) : R(M.position === "right" ? u - P : l, F)), p += a.nameSize * .55, v("bold", a.nameSize);
	let z = t.name || "Your Name", B = e.template === "harvard" ? z.toUpperCase() : z;
	ee ? S(B, s / 2, p) : o.text(B, I, p), p += a.nameSize * .5 + j * .9, t.title?.trim() && (v("normal", a.body + .5), ee ? S(t.title.trim(), s / 2, p) : o.text(t.title.trim(), I, p), p += a.lineH), v("normal", j);
	let te = b(" | "), V = [[]], H = 0;
	A.forEach((e) => {
		let t = b(e.text), n = V[V.length - 1];
		n.length && H + te + t > L ? (V.push([{
			...e,
			w: t
		}]), H = t) : (H += (n.length ? te : 0) + t, n.push({
			...e,
			w: t
		}));
	}), V.forEach((t) => {
		if (!t.length) return;
		let n = t.reduce((e, t) => e + t.w, 0) + te * (t.length - 1), r = ee ? s / 2 - n / 2 : I;
		t.forEach((t, n) => {
			n > 0 && (C(a.muted), o.text(" | ", r, p), r += te);
			let i = t.url && !t.url.startsWith("mailto:");
			C(i ? a.linkColor : a.muted), o.text(t.text, r, p), t.url && (o.link(r, p - j * .8, t.w, j, { url: t.url }), i && e.template === "modern" && (o.setDrawColor(a.linkColor), o.setLineWidth(.4), o.line(r, p + 1, r + t.w, p + 1), o.setDrawColor("#000000"))), r += t.w;
		}), C("#000000"), p += j * 1.3;
	}), N && M.position !== "center" && (p = Math.max(p, F + P + 8)), p += 2;
	function U(n) {
		g && _ && (o.addPage("a4", "p"), p = a.top), g = !1, p += a.sectionGapBefore, w(a.sectionGapAfter + a.lineH * 2), v("bold", a.headingSize);
		let r = e.sectionLabels[n] || t.customSections?.find((e) => `custom:${e.id}` === n)?.title || n, i = a.headingUpper ? r.toUpperCase() : r;
		a.headingCentered ? S(i, s / 2, p) : o.text(i, l, p), o.setDrawColor("#000000"), o.setLineWidth(e.template === "harvard" ? .6 : .2), o.line(l, p + 4, u, p + 4), p += a.sectionGapAfter, _ = !0;
	}
	function ne(t) {
		t.some((e) => e.text.trim()) && (p += 2), t.forEach((t) => {
			let n = t.text.trim();
			if (!n) return;
			if (t.type === "header") {
				O(el(n), l, d, a.lineH, a.body, !1);
				return;
			}
			let i = t.type === "l3" ? 3 : t.type === "l2" ? 2 : 1, s = (i === 1 ? e.bulletChars.l1 : i === 2 ? e.bulletChars.l2 : e.bulletChars.l3) || "•";
			!r.embed && !Yc(s) && (s = [
				"•",
				"–",
				"·"
			][i - 1]);
			let c = l + a.bulletIndent + (i - 1) * 12;
			w(a.bulletLineH), v("normal"), o.text(s, c, p);
			let f = c + a.bulletTextGap;
			O(el(n), f, u - f, a.bulletLineH);
		});
	}
	let W = (t) => !e.disabledSections.includes(t), G = (e) => a.uppercaseOrg ? e.toUpperCase() : e;
	function re(t) {
		t.forEach((n, r) => {
			let i = n.company.trim(), o = n.position.trim(), s = n.location.trim(), c = n.dates.trim(), l = r > 0 && !!i && t[r - 1].company.trim().toLowerCase() === i.toLowerCase();
			if (r > 0 && (p += l ? 3 : a.entryGap), w(a.lineH * 3), e.experienceHeaderStyle === "one-line") k(l ? o && `*${o}*` : [i && `**${G(i)}**`, o && `*${o}*`].filter(Boolean).join("  |  "), "normal", c);
			else if (e.experienceHeaderStyle === "role-company") k([o && `**${o}**`, i].filter(Boolean).join(", ") + (s ? `, ${s}` : ""), "normal", c);
			else if (l) {
				let t = e.template === "harvard" ? `*${o}*` : `**${o}**`;
				k(o ? t : "", "normal", c);
			} else e.template === "harvard" ? (k(i ? `**${G(i)}**` : "", "normal", s || c), (o || s) && k(o ? `*${o}*` : "", "normal", s ? c : "")) : (k(`**${G(i)}**${s ? `*, ${s}*` : ""}`, "normal", c), o && k(`**${o}**`, "normal", ""));
			ne(n.bullets);
		});
	}
	let ie = {
		summary() {
			t.summary?.trim() && (U("summary"), O(el(t.summary.trim()), l, d, a.lineH));
		},
		objective() {
			t.objective?.trim() && (U("objective"), O(el(t.objective.trim()), l, d, a.lineH));
		},
		skills() {
			let e = t.skills.filter((e) => e.skill?.trim() || e.description?.trim());
			e.length && (U("skills"), e.forEach((e) => {
				let t = e.skill.trim();
				O(el(t ? `**${t}:** ${e.description.trim()}` : e.description.trim()), l, d, a.lineH, a.body, !1);
			}));
		},
		experience() {
			let e = t.experiences.filter((e) => e.company?.trim() || e.position?.trim() || e.bullets.length);
			e.length && (U("experience"), re(e));
		},
		projects() {
			let e = t.projects.filter((e) => e.projectName?.trim() || e.bullets.length);
			e.length && (w(a.sectionGapBefore + a.sectionGapAfter + a.lineH + D(e[0])), U("projects"), t.projectIntro?.trim() && O(el(`**${t.projectIntro.trim()}**`), l, d, a.lineH, a.body, !1), e.forEach((e, t) => {
				t > 0 && (p += a.entryGap);
				let n = o.getNumberOfPages();
				w(D(e)), o.getNumberOfPages() > n && U("projects");
				let r = e.projectLink?.trim(), i = r ? tl(r) : "";
				v("normal", a.body - .5);
				let s = i ? b(i) : 0;
				if (e.dates?.trim()) {
					if (k(`**${G(e.projectName.trim())}**`, "normal", e.dates.trim()), i) {
						let e = p;
						O(el(i), l, d, a.lineH, a.body, !1), o.link(l, e - a.body * .8, Math.min(d, b(i)), a.body, { url: Wc(r) });
					}
				} else i && s < d * .45 ? (C(a.linkColor), x(i, u, p), o.link(u - s, p - a.body * .8, s, a.body, { url: Wc(r) }), C("#000000"), O(el(`**${G(e.projectName.trim())}**`), l, d - s - 12, a.lineH, a.body, !1)) : O(el(`**${G(e.projectName.trim())}**`), l, d, a.lineH, a.body, !1);
				e.overview?.trim() && O(el(e.overview.trim()), l, d, a.lineH, a.body, !1), e.technologies?.trim() && ne([{
					id: "project-technologies",
					type: "l1",
					text: `**Technologies:** ${e.technologies.trim()}`
				}]), ne(e.bullets);
			}));
		},
		education() {
			let n = t.educations.filter((e) => e.university?.trim() || e.degree?.trim());
			n.length && (U("education"), n.forEach((t, n) => {
				n > 0 && (p += a.entryGap), k(`**${e.template === "harvard" ? G(t.university.trim()) : t.university.trim()}**`, "normal", t.graduationDate.trim());
				let r = [t.degree.trim(), t.gpa.trim() && `GPA: ${t.gpa.trim().replace(/^GPA:?\s*/i, "")}`].filter(Boolean).join(". ");
				r && O(el(e.template === "harvard" ? `*${r}*` : r), l, d, a.lineH, a.body, !1);
			}));
		},
		certificates() {
			let e = t.certificates.filter((e) => e.certName?.trim());
			e.length && (U("certificates"), e.forEach((e) => {
				let t = e["issuer/description"]?.trim();
				k(`**${e.certName.trim()}**${t ? `, ${t}` : ""}`, "normal", e.certDate?.trim() || "");
			}));
		}
	};
	return e.sectionsOrder.forEach((e) => {
		if (e === "page-break") g = !0;
		else if (W(e)) {
			if (e.startsWith("custom:")) {
				let n = t.customSections?.find((t) => `custom:${t.id}` === e);
				n?.entries.length && (U(e), re(n.entries));
			} else ie[e]?.();
		}
	}), {
		ok: !0,
		doc: o,
		pages: o.getNumberOfPages(),
		fontFellBack: r.fellBack
	};
}
// src/cli/format.ts
var il = {
	template: "modern",
	language: "English",
	sizeMultiplier: 1,
	selectedFont: "garamond",
	customFontName: "",
	experienceHeaderStyle: "classic",
	bulletChars: {
		l1: "•",
		l2: "◦",
		l3: "▪"
	},
	avatarStyle: { ...Bc }
};
function al(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) return ["config must be an object"];
	let t = e, n = [], r = new Set(Object.keys(il));
	for (let e of Object.keys(t)) r.has(e) || n.push(`config.${e} is not a formatting option`);
	for (let e of r) e in t || n.push(`config.${e} is required`);
	t.template !== "harvard" && t.template !== "modern" && n.push("config.template must be harvard or modern"), typeof t.language == "string" && t.language.trim() || n.push("config.language must be a non-empty string"), (typeof t.sizeMultiplier != "number" || !Number.isFinite(t.sizeMultiplier) || t.sizeMultiplier < .8 || t.sizeMultiplier > 1.6) && n.push("config.sizeMultiplier must be between 0.8 and 1.6"), [
		"notosans",
		"times",
		"garamond",
		"arial",
		"custom"
	].includes(String(t.selectedFont)) || n.push("config.selectedFont is unsupported"), typeof t.customFontName != "string" && n.push("config.customFontName must be a string"), [
		"classic",
		"role-company",
		"one-line"
	].includes(String(t.experienceHeaderStyle)) || n.push("config.experienceHeaderStyle is unsupported");
	let i = t.bulletChars;
	i && typeof i == "object" && [
		"l1",
		"l2",
		"l3"
	].every((e) => typeof i[e] == "string") && !Object.keys(i).some((e) => ![
		"l1",
		"l2",
		"l3"
	].includes(e)) || n.push("config.bulletChars must contain only l1, l2 and l3 strings");
	let a = t.avatarStyle;
	return a && typeof a == "object" && [
		"square",
		"rounded",
		"circle"
	].includes(String(a.shape)) && [
		"left",
		"right",
		"center"
	].includes(String(a.position)) && [
		"sm",
		"md",
		"lg"
	].includes(String(a.size)) && ["cover", "contain"].includes(String(a.fit)) && !Object.keys(a).some((e) => ![
		"shape",
		"position",
		"size",
		"fit"
	].includes(e)) || n.push("config.avatarStyle must contain valid shape, position, size and fit"), n;
}
// src/cli/payload.ts
var ol = [
	"summary",
	"objective",
	"skills",
	"experience",
	"projects",
	"education",
	"certificates",
	"page-break"
], sl = /* @__PURE__ */ new Set([
	"header",
	"l1",
	"l2",
	"l3"
]);
function cl(e) {
	return !!e && typeof e == "object" && !Array.isArray(e);
}
function ll(e, t, n, r) {
	typeof e[t] == "string" && e[t].trim() || r.push(`${n}.${t} must be a non-empty string`);
}
function ul(e, t, n) {
	Array.isArray(e) ? e.forEach((e, r) => {
		cl(e) ? (typeof e.text == "string" && e.text.trim() || n.push(`${t}[${r}].text must be a non-empty string`), typeof e.type == "string" && sl.has(e.type) || n.push(`${t}[${r}].type must be header, l1, l2, or l3`)) : n.push(`${t}[${r}] must be an object`);
	}) : n.push(`${t} must be an array`);
}
function dl(e) {
	let t = [];
	if (!cl(e)) return ["payload must be a JSON object"];
	let n = cl(e.content) ? e.content : e, r = n.cv;
	if (!cl(r)) return ["payload.cv must be an object"];
	for (let e of [
		"name",
		"email",
		"phone"
	]) ll(r, e, "cv", t);
	for (let e of [
		"experiences",
		"projects",
		"skills",
		"educations",
		"certificates"
	]) Array.isArray(r[e]) || t.push(`cv.${e} must be an array`);
	Array.isArray(r.experiences) && r.experiences.forEach((e, n) => {
		if (!cl(e)) t.push(`cv.experiences[${n}] must be an object`);
		else {
			for (let r of [
				"position",
				"company",
				"dates"
			]) ll(e, r, `cv.experiences[${n}]`, t);
			ul(e.bullets, `cv.experiences[${n}].bullets`, t);
		}
	}), Array.isArray(r.projects) && r.projects.forEach((e, n) => {
		cl(e) ? (ll(e, "projectName", `cv.projects[${n}]`, t), ul(e.bullets, `cv.projects[${n}].bullets`, t)) : t.push(`cv.projects[${n}] must be an object`);
	});
	let i = cl(n.layout) ? n.layout : n, a = (e) => ol.includes(e) || typeof e == "string" && /^custom:[a-zA-Z0-9_-]+$/.test(e) && Array.isArray(r.customSections) && r.customSections.some((t) => cl(t) && `custom:${t.id}` === e);
	return i.sectionsOrder !== void 0 && (!Array.isArray(i.sectionsOrder) || i.sectionsOrder.some((e) => !a(e))) && t.push("sectionsOrder contains an unsupported section"), Array.isArray(i.sectionsOrder) && i.sectionsOrder.filter((e) => e === "page-break").length > 1 && t.push("sectionsOrder may contain page-break only once"), i.disabledSections !== void 0 && (!Array.isArray(i.disabledSections) || i.disabledSections.some((e) => !a(e))) && t.push("disabledSections contains an unsupported section"), r.customSections !== void 0 && !Array.isArray(r.customSections) && t.push("cv.customSections must be an array"), Array.isArray(r.customSections) && r.customSections.forEach((e, n) => {
		!cl(e) || typeof e.id != "string" || typeof e.title != "string" || !Array.isArray(e.entries) ? t.push(`cv.customSections[${n}] needs id, title and entries`) : e.entries.forEach((e, r) => {
			cl(e) ? ul(e.bullets, `cv.customSections[${n}].entries[${r}].bullets`, t) : t.push(`cv.customSections[${n}].entries[${r}] must be an object`);
		});
	}), t;
}
function fl(e, t) {
	let n = dl(e);
	if (n.length) throw Error(n.join("\n"));
	let r = e, i = cl(r.content) ? r.content : r, a = cl(i.layout) ? i.layout : i, o = t ?? (cl(r.config) && al(r.config).length === 0 ? r.config : cl(r.content) ? il : r), s = typeof o.language == "string" ? o.language : il.language, c = Hc[s] ?? Vc, l = cl(a.sectionLabels) ? a.sectionLabels : cl(a.customSectionLabels) ? a.customSectionLabels : {}, u = cl(o.bulletChars) ? o.bulletChars : {}, d = cl(o.avatarStyle) ? o.avatarStyle : {};
	return {
		cv: i.cv,
		coverLetter: cl(i.coverLetter) ? i.coverLetter : void 0,
		template: o.template === "modern" ? "modern" : "harvard",
		language: s,
		sizeMultiplier: typeof o.sizeMultiplier == "number" ? o.sizeMultiplier : il.sizeMultiplier,
		selectedFont: typeof o.selectedFont == "string" ? o.selectedFont : il.selectedFont,
		customFontName: typeof o.customFontName == "string" ? o.customFontName : "",
		sectionsOrder: Array.isArray(a.sectionsOrder) ? a.sectionsOrder : [
			"summary",
			"experience",
			"skills",
			"education",
			"projects",
			"certificates",
			"objective"
		],
		disabledSections: Array.isArray(a.disabledSections) ? a.disabledSections : ["objective"],
		experienceHeaderStyle: o.experienceHeaderStyle === "role-company" || o.experienceHeaderStyle === "one-line" ? o.experienceHeaderStyle : "classic",
		bulletChars: {
			l1: typeof u.l1 == "string" ? u.l1 : "•",
			l2: typeof u.l2 == "string" ? u.l2 : "◦",
			l3: typeof u.l3 == "string" ? u.l3 : "▪"
		},
		customSectionLabels: Object.fromEntries(ol.map((e) => [e, typeof l[e] == "string" && l[e] ? l[e] : c[e]])),
		avatarStyle: {
			shape: d.shape === "square" || d.shape === "circle" ? d.shape : Bc.shape,
			position: d.position === "right" || d.position === "center" ? d.position : Bc.position,
			size: d.size === "sm" || d.size === "lg" ? d.size : Bc.size,
			fit: d.fit === "contain" ? "contain" : Bc.fit
		}
	};
}
// src/cli/main.ts
var pl = "Fynx CV CLI\n\nUsage:\n  fynx-cv validate <content.json> [--config <config.json>] [--json]\n  fynx-cv audit <content.json> [--config <config.json>] [--jd <job-description.txt>] [--json]\n  fynx-cv link <content.json> [--config <config.json>] [--base <url>]\n  fynx-cv create <content.json> [--config <config.json>] --output <cv.pdf>\n\nThe CLI validates structure and CV quality. Truth still comes from the fact bank used by the agent skill.";
function ml(e) {
	let t = process.argv.indexOf(e);
	return t >= 0 ? process.argv[t + 1] : void 0;
}
function hl(e) {
	process.stdout.write(`${JSON.stringify(e, null, 2)}\n`);
}
async function gl(e) {
	return JSON.parse(await n(a(e), "utf8"));
}
function _l(e, t) {
	let n = s(Buffer.from(JSON.stringify(e))), r = new URL(t);
	return r.searchParams.set("view", "preview"), `${r.toString()}#cv=z:${n.toString("base64url")}`;
}
async function vl(e) {
	let t = a(i(o(import.meta.url)), "fonts"), r = e === "latin" ? ["Calibri-Regular-normal.js", "Calibri-Bold-normal.js"] : ["EBGaramond-Regular-normal.js", "EBGaramond-Bold-normal.js"], s = e === "latin" ? ["CalibriRegular", "CalibriBold"] : ["font", "fontBold"], [c, l] = await Promise.all(r.map(async (e) => {
		let r = (await n(a(t, e), "utf8")).match(/var \w+ = '([A-Za-z0-9+/=]+)'/);
		if (!r) throw Error(`Invalid embedded font data: ${e}`);
		return r[1];
	})), u = globalThis.window ?? {};
	Object.assign(globalThis, { window: {
		...u,
		[s[0]]: c,
		[s[1]]: l
	} });
}
async function yl() {
	let [e, t] = process.argv.slice(2);
	if (!e || e === "--help" || e === "-h") {
		process.stdout.write(`${pl}\n`);
		return;
	}
	if (!t) throw Error(`Missing input JSON file.\n\n${pl}`);
	let i = await gl(t), o = ml("--config"), s = o ? await gl(o) : i.config, c = [...dl(i), ...s === void 0 ? [] : al(s)];
	if (e === "validate") {
		process.argv.includes("--json") ? hl({
			ok: c.length === 0,
			errors: c
		}) : process.stdout.write(c.length ? `${c.join("\n")}\n` : "VALID\n"), c.length && (process.exitCode = 2);
		return;
	}
	if (c.length) throw Error(c.join("\n"));
	let l = fl(i, s);
	if (e === "link") {
		let e = i, t = e.content ?? {
			cv: e.cv,
			coverLetter: e.coverLetter,
			layout: {
				sectionsOrder: l.sectionsOrder,
				disabledSections: l.disabledSections,
				sectionLabels: l.customSectionLabels
			}
		}, n = s ?? (e.content ? il : {
			template: l.template,
			language: l.language,
			sizeMultiplier: l.sizeMultiplier,
			selectedFont: l.selectedFont,
			customFontName: l.customFontName,
			experienceHeaderStyle: l.experienceHeaderStyle,
			bulletChars: l.bulletChars,
			avatarStyle: l.avatarStyle
		});
		process.stdout.write(`${_l({
			content: t,
			config: n
		}, ml("--base") ?? "https://cv-editor.fynx.io.vn")}\n`);
		return;
	}
	let u = {
		cv: l.cv,
		template: l.template,
		language: l.language,
		sizeMultiplier: l.sizeMultiplier,
		selectedFont: l.selectedFont,
		customFontName: l.customFontName,
		sectionsOrder: l.sectionsOrder,
		disabledSections: l.disabledSections,
		bulletChars: l.bulletChars,
		experienceHeaderStyle: l.experienceHeaderStyle,
		avatarStyle: l.avatarStyle,
		sectionLabels: l.customSectionLabels
	};
	Object.assign(globalThis, { window: {} });
	let d = rl(u);
	if (d.ok || d.needsFonts !== "latin" && d.needsFonts !== "garamond" || (await vl(d.needsFonts), d = rl(u)), !d.ok) throw Error(`CLI PDF output cannot load embedded ${d.needsFonts} fonts. Render this language in the web app.`);
	if (e === "audit") {
		let e = ml("--jd"), t = N({
			cv: l.cv,
			disabledSections: l.disabledSections,
			pageCount: d.pages,
			bulletChars: l.bulletChars,
			customSectionLabels: l.customSectionLabels,
			jobDescription: e ? await n(a(e), "utf8") : "",
			coverLetter: l.coverLetter
		});
		process.argv.includes("--json") ? hl(t) : (process.stdout.write(`Score: ${t.score}/100\nPages: ${d.pages}\n`), t.findings.forEach((e) => process.stdout.write(`[${e.severity}] ${e.title.English}: ${e.detail.English}\n`))), t.findings.some((e) => e.severity === "blocker") && (process.exitCode = 1);
	} else if (e === "create") {
		let e = ml("--output");
		if (!e) throw Error("create requires --output <cv.pdf>");
		await r(a(e), Buffer.from(d.doc.output("arraybuffer"))), hl({
			ok: !0,
			output: a(e),
			pages: d.pages,
			fontFellBack: d.fontFellBack
		});
	} else throw Error(`Unknown command: ${e}\n\n${pl}`);
}
yl().catch((e) => {
	process.stderr.write(`fynx-cv: ${e instanceof Error ? e.message : String(e)}\n`), process.exitCode = 2;
});
