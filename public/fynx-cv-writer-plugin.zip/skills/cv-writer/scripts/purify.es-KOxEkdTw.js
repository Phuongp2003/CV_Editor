#!/usr/bin/env node
// node_modules/dompurify/dist/purify.es.mjs
function e(e, t) {
	this.v = e, this.k = t;
}
function t(e, t) {
	(t == null || t > e.length) && (t = e.length);
	for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
	return r;
}
function n(e) {
	if (Array.isArray(e)) return e;
}
function r(e, t) {
	var n = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
	if (n != null) {
		var r, i, a, o, s = [], c = !0, l = !1;
		try {
			if (a = (n = n.call(e)).next, t === 0) {
				if (Object(n) !== n) return;
				c = !1;
			} else for (; !(c = (r = a.call(n)).done) && (s.push(r.value), s.length !== t); c = !0);
		} catch (e) {
			l = !0, i = e;
		} finally {
			try {
				if (!c && n.return != null && (o = n.return(), Object(o) !== o)) return;
			} finally {
				if (l) throw i;
			}
		}
		return s;
	}
}
function i() {
	throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function a(e, t) {
	return n(e) || r(e, t) || o(e, t) || i();
}
function o(e, n) {
	if (e) {
		if (typeof e == "string") return t(e, n);
		var r = {}.toString.call(e).slice(8, -1);
		return r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set" ? Array.from(e) : r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? t(e, n) : void 0;
	}
}
function s(t) {
	var n, r;
	function i(n, r) {
		try {
			var o = t[n](r), s = o.value, c = s instanceof e;
			Promise.resolve(c ? s.v : s).then(function(e) {
				if (c) {
					var r = n === "return" && s.k ? n : "next";
					if (!s.k || e.done) return i(r, e);
					e = t[r](e).value;
				}
				a(!!o.done, e);
			}, function(e) {
				i("throw", e);
			});
		} catch (e) {
			a(2, e);
		}
	}
	function a(e, t) {
		e === 2 ? n.reject(t) : n.resolve({
			value: t,
			done: e
		}), (n = n.next) ? i(n.key, n.arg) : r = null;
	}
	this._invoke = function(e, t) {
		return new Promise(function(a, o) {
			var s = {
				key: e,
				arg: t,
				resolve: a,
				reject: o,
				next: null
			};
			r ? r = r.next = s : (n = r = s, i(e, t));
		});
	}, typeof t.return != "function" && (this.return = void 0);
}
s.prototype[typeof Symbol == "function" && Symbol.asyncIterator || "@@asyncIterator"] = function() {
	return this;
}, s.prototype.next = function(e) {
	return this._invoke("next", e);
}, s.prototype.throw = function(e) {
	return this._invoke("throw", e);
}, s.prototype.return = function(e) {
	return this._invoke("return", e);
};
var c = Object.entries, l = Object.keys, u = Object.setPrototypeOf, d = Object.isFrozen, f = Object.getPrototypeOf, p = Object.getOwnPropertyDescriptor, m = Object.freeze, h = Object.seal, g = Object.create, ee = typeof Reflect < "u" && Reflect, te = ee.apply, ne = ee.construct;
m ||= function(e) {
	return e;
}, h ||= function(e) {
	return e;
}, te ||= function(e, t) {
	var n = [...arguments].slice(2);
	return e.apply(t, n);
}, ne ||= function(e) {
	return new e(...[...arguments].slice(1));
};
var _ = D(Array.prototype.forEach), re = D(Array.prototype.lastIndexOf), ie = D(Array.prototype.pop), ae = D(Array.prototype.push), oe = D(Array.prototype.slice), se = D(Array.prototype.splice), v = Array.isArray, ce = Se(Set), le = D(Set.prototype.add), ue = D(Set.prototype.has), de = D(Set.prototype.delete), fe = Se(Map), pe = D(Map.prototype.get), me = D(Map.prototype.set), y = D(String.prototype.toLowerCase), he = D(String.prototype.toString), ge = D(String.prototype.match), _e = D(String.prototype.replace), ve = D(String.prototype.indexOf), ye = D(String.prototype.trim), be = D(Number.prototype.toString), b = D(Boolean.prototype.toString), x = typeof BigInt > "u" ? null : D(BigInt.prototype.toString), xe = typeof Symbol > "u" ? null : D(Symbol.prototype.toString), S = D(Object.prototype.hasOwnProperty), C = D(Object.prototype.toString), w = RegExp.prototype.test, T = function(e, t) {
	return e instanceof RegExp && (e.lastIndex = 0), te(w, e, [t]);
}, E = Se(TypeError);
function D(e) {
	return function(t) {
		var n = [...arguments].slice(1);
		return te(e, t, n);
	};
}
function Se(e) {
	return function() {
		return ne(e, [...arguments]);
	};
}
function O(e, t) {
	let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : y;
	if (u && u(e, null), !v(t)) return e;
	let r = t.length;
	for (; r--;) {
		let i = t[r];
		if (typeof i == "string") {
			let e = n(i);
			e !== i && (d(t) || (t[r] = e), i = e);
		}
		e[i] = !0;
	}
	return e;
}
function k(e) {
	for (let t = 0; t < e.length; t++) S(e, t) || (e[t] = null);
	return e;
}
function Ce(e) {
	let t = g(null);
	for (let r of c(e)) {
		var n = a(r, 2);
		let i = n[0], o = n[1];
		S(e, i) && (t[i] = v(o) ? k(o) : o && typeof o == "object" && o.constructor === Object ? Ce(o) : o);
	}
	return t;
}
function we(e) {
	let t = g(null), n = l(e), r = n.length;
	for (; r--;) t[n[r]] = e[n[r]];
	return t;
}
function Te(e) {
	switch (typeof e) {
		case "string": return e;
		case "number": return be(e);
		case "boolean": return b(e);
		case "bigint": return x ? x(e) : "0";
		case "symbol": return xe ? xe(e) : "Symbol()";
		case "undefined": return C(e);
		case "function":
		case "object": {
			if (e === null) return C(e);
			let t = e, n = A(t, "toString");
			if (typeof n == "function") {
				let e = n(t);
				return typeof e == "string" ? e : C(e);
			}
			return C(e);
		}
		default: return C(e);
	}
}
function A(e, t) {
	for (; e !== null;) {
		let n = p(e, t);
		if (n) {
			if (n.get) return D(n.get);
			if (typeof n.value == "function") return D(n.value);
		}
		e = f(e);
	}
	function n() {
		return null;
	}
	return n;
}
function Ee(e, t) {
	for (; e !== null;) {
		let n = p(e, t);
		if (n) return n.get ? D(n.get) : null;
		e = f(e);
	}
	return null;
}
function De(e) {
	if (!e) return !1;
	try {
		return T(e, ""), !0;
	} catch {
		return !1;
	}
}
var Oe = m(/* @__PURE__ */ "a.abbr.acronym.address.area.article.aside.audio.b.bdi.bdo.big.blink.blockquote.body.br.button.canvas.caption.center.cite.code.col.colgroup.content.data.datalist.dd.decorator.del.details.dfn.dialog.dir.div.dl.dt.element.em.fieldset.figcaption.figure.font.footer.form.h1.h2.h3.h4.h5.h6.head.header.hgroup.hr.html.i.img.input.ins.kbd.label.legend.li.main.map.mark.marquee.menu.menuitem.meter.nav.nobr.ol.optgroup.option.output.p.picture.pre.progress.q.rp.rt.ruby.s.samp.search.section.select.shadow.slot.small.source.spacer.span.strike.strong.style.sub.summary.sup.table.tbody.td.template.textarea.tfoot.th.thead.time.tr.track.tt.u.ul.var.video.wbr".split(".")), ke = m(/* @__PURE__ */ "svg.a.altglyph.altglyphdef.altglyphitem.animatecolor.animatemotion.animatetransform.circle.clippath.defs.desc.ellipse.filter.font.g.glyph.glyphref.hkern.image.line.lineargradient.marker.mask.metadata.mpath.path.pattern.polygon.polyline.radialgradient.rect.stop.style.switch.symbol.text.textpath.title.tref.tspan.view.vkern".split(".")), Ae = m([
	"feBlend",
	"feColorMatrix",
	"feComponentTransfer",
	"feComposite",
	"feConvolveMatrix",
	"feDiffuseLighting",
	"feDisplacementMap",
	"feDistantLight",
	"feDropShadow",
	"feFlood",
	"feFuncA",
	"feFuncB",
	"feFuncG",
	"feFuncR",
	"feGaussianBlur",
	"feImage",
	"feMerge",
	"feMergeNode",
	"feMorphology",
	"feOffset",
	"fePointLight",
	"feSpecularLighting",
	"feSpotLight",
	"feTile",
	"feTurbulence"
]), je = m([
	"animate",
	"color-profile",
	"cursor",
	"discard",
	"font-face",
	"font-face-format",
	"font-face-name",
	"font-face-src",
	"font-face-uri",
	"foreignobject",
	"hatch",
	"hatchpath",
	"mesh",
	"meshgradient",
	"meshpatch",
	"meshrow",
	"missing-glyph",
	"script",
	"set",
	"solidcolor",
	"unknown",
	"use"
]), Me = m(/* @__PURE__ */ "math.menclose.merror.mfenced.mfrac.mglyph.mi.mlabeledtr.mmultiscripts.mn.mo.mover.mpadded.mphantom.mroot.mrow.ms.mspace.msqrt.mstyle.msub.msup.msubsup.mtable.mtd.mtext.mtr.munder.munderover.mprescripts".split(".")), Ne = m([
	"maction",
	"maligngroup",
	"malignmark",
	"mlongdiv",
	"mscarries",
	"mscarry",
	"msgroup",
	"mstack",
	"msline",
	"msrow",
	"semantics",
	"annotation",
	"annotation-xml",
	"mprescripts",
	"none"
]), Pe = m(["#text"]), Fe = m(/* @__PURE__ */ "accept.action.align.alt.autocapitalize.autocomplete.autopictureinpicture.autoplay.background.bgcolor.border.capture.cellpadding.cellspacing.checked.cite.class.clear.color.cols.colspan.command.commandfor.controls.controlslist.coords.crossorigin.datetime.decoding.default.dir.disabled.disablepictureinpicture.disableremoteplayback.download.draggable.enctype.enterkeyhint.exportparts.face.for.headers.height.hidden.high.href.hreflang.id.inert.inputmode.integrity.ismap.kind.label.lang.list.loading.loop.low.max.maxlength.media.method.min.minlength.multiple.muted.name.nonce.noshade.novalidate.nowrap.open.optimum.part.pattern.placeholder.playsinline.popover.popovertarget.popovertargetaction.poster.preload.pubdate.radiogroup.readonly.rel.required.rev.reversed.role.rows.rowspan.spellcheck.scope.selected.shape.size.sizes.slot.span.srclang.start.src.srcset.step.style.summary.tabindex.title.translate.type.usemap.valign.value.width.wrap.xmlns".split(".")), Ie = m(/* @__PURE__ */ "accent-height.accumulate.additive.alignment-baseline.amplitude.ascent.attributename.attributetype.azimuth.basefrequency.baseline-shift.begin.bias.by.class.clip.clippathunits.clip-path.clip-rule.color.color-interpolation.color-interpolation-filters.color-profile.color-rendering.cx.cy.d.dx.dy.diffuseconstant.direction.display.divisor.dominant-baseline.dur.edgemode.elevation.end.exponent.fill.fill-opacity.fill-rule.filter.filterunits.flood-color.flood-opacity.font-family.font-size.font-size-adjust.font-stretch.font-style.font-variant.font-weight.fx.fy.g1.g2.glyph-name.glyphref.gradientunits.gradienttransform.height.href.id.image-rendering.in.in2.intercept.k.k1.k2.k3.k4.kerning.keypoints.keysplines.keytimes.lang.lengthadjust.letter-spacing.kernelmatrix.kernelunitlength.lighting-color.local.marker-end.marker-mid.marker-start.markerheight.markerunits.markerwidth.maskcontentunits.maskunits.max.mask.mask-type.media.method.mode.min.name.numoctaves.offset.operator.opacity.order.orient.orientation.origin.overflow.paint-order.path.pathlength.patterncontentunits.patterntransform.patternunits.pointer-events.points.preservealpha.preserveaspectratio.primitiveunits.r.rx.ry.radius.refx.refy.repeatcount.repeatdur.restart.result.rotate.scale.seed.shape-rendering.slope.specularconstant.specularexponent.spreadmethod.startoffset.stddeviation.stitchtiles.stop-color.stop-opacity.stroke-dasharray.stroke-dashoffset.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-opacity.stroke.stroke-width.style.surfacescale.systemlanguage.tabindex.tablevalues.targetx.targety.transform.transform-origin.text-anchor.text-decoration.text-orientation.text-rendering.textlength.type.u1.u2.unicode.values.vector-effect.viewbox.visibility.version.vert-adv-y.vert-origin-x.vert-origin-y.width.word-spacing.wrap.writing-mode.xchannelselector.ychannelselector.x.x1.x2.xmlns.y.y1.y2.z.zoomandpan".split(".")), Le = m(/* @__PURE__ */ "accent.accentunder.align.bevelled.close.columnalign.columnlines.columnspacing.columnspan.denomalign.depth.dir.display.displaystyle.encoding.fence.frame.height.href.id.largeop.length.linethickness.lquote.lspace.mathbackground.mathcolor.mathsize.mathvariant.maxsize.minsize.movablelimits.notation.numalign.open.rowalign.rowlines.rowspacing.rowspan.rspace.rquote.scriptlevel.scriptminsize.scriptsizemultiplier.selection.separator.separators.stretchy.subscriptshift.supscriptshift.symmetric.voffset.width.xmlns".split(".")), Re = m([
	"xlink:href",
	"xml:id",
	"xlink:title",
	"xml:space",
	"xmlns:xlink"
]), ze = h(/{{[\w\W]*|^[\w\W]*}}/g), Be = h(/<%[\w\W]*|^[\w\W]*%>/g), Ve = h(/\${[\w\W]*/g), He = h(/{{|}}|\${|<%|%>/), Ue = h(/[^\t\n\f\r ]/), We = h(/\u0000/g), Ge = h(/^data-[\-\w.\u00B7-\uFFFF]+$/), Ke = h(/^aria-[\-\w]+$/), qe = h(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i), Je = h(/^(?:\w+script|data):/i), Ye = h(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g), Xe = h(/^html$/i), Ze = h(/^[a-z][.\w]*(-[.\w]+)+$/i), Qe = h(/<[/\w!]/g), $e = h(/<[/\w]/g), et = h(/<[/\w]|^-?>|--!?>|<!-$/g), tt = h(/<\/no(script|embed|frames)/i), nt = h(/\/>/i), rt = h(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i), it = h(/^[\r\n\t ]+/), j = {
	element: 1,
	text: 3,
	processingInstruction: 7,
	comment: 8,
	document: 9,
	documentFragment: 11
}, at = m(O({}, [
	"style",
	"script",
	"xmp",
	"iframe",
	"noembed",
	"noframes",
	"plaintext",
	"noscript"
])), ot = m(O({}, ["textarea", "title"])), st = m(O({}, [
	"area",
	"base",
	"basefont",
	"bgsound",
	"br",
	"col",
	"embed",
	"frame",
	"hr",
	"img",
	"input",
	"keygen",
	"link",
	"meta",
	"param",
	"source",
	"track",
	"wbr"
])), ct = function() {
	return typeof window > "u" ? null : window;
}, lt = function(e, t) {
	if (typeof e != "object" || typeof e.createPolicy != "function") return null;
	let n = null, r = "data-tt-policy-suffix";
	t && t.hasAttribute(r) && (n = t.getAttribute(r));
	let i = "dompurify" + (n ? "#" + n : "");
	try {
		return e.createPolicy(i, {
			createHTML(e) {
				return e;
			},
			createScriptURL(e) {
				return e;
			}
		});
	} catch {
		return console.warn("TrustedTypes policy " + i + " could not be created."), null;
	}
}, ut = function() {
	return {
		afterSanitizeAttributes: [],
		afterSanitizeElements: [],
		afterSanitizeShadowDOM: [],
		beforeSanitizeAttributes: [],
		beforeSanitizeElements: [],
		beforeSanitizeShadowDOM: [],
		uponSanitizeAttribute: [],
		uponSanitizeElement: [],
		uponSanitizeShadowNode: []
	};
}, M = function(e, t, n, r) {
	return S(e, t) && v(e[t]) ? O(r.base ? we(r.base) : {}, e[t], r.transform) : n;
}, dt = function(e, t, n) {
	let r = S(e, t) ? e[t] : void 0;
	return r && typeof r == "object" ? Ce(r) : n;
};
function ft() {
	let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : ct(), t = (e) => ft(e);
	if (t.version = "3.5.0", t.removed = [], !e || !e.document || e.document.nodeType !== j.document || !e.Element) return t.isSupported = !1, t;
	let n = e.document, r = n, i = r.currentScript, a = e.HTMLTemplateElement, o = e.Node, s = e.Element, l = e.NodeFilter, u = e.DOMParser, d = e.trustedTypes, f = s.prototype, p = A(f, "cloneNode"), ee = A(f, "remove"), te = A(f, "removeChild"), ne = A(f, "removeAttributeNode"), be = A(f, "nextSibling"), b = A(f, "childNodes"), x = A(f, "parentNode"), xe = A(f, "shadowRoot"), C = A(f, "attributes"), w = o && o.prototype ? A(o.prototype, "nodeType") : null, D = o && o.prototype ? A(o.prototype, "nodeName") : null, Se = o && o.prototype ? A(o.prototype, "ownerDocument") : null, k = function(e) {
		return w ? w(e) : e.nodeType;
	}, N = function(e) {
		return D ? D(e) : e.nodeName;
	}, pt = Ee(f, "namespaceURI"), mt = function(e) {
		return pt ? pt(e) : e.namespaceURI;
	}, ht = function(e) {
		return k(e) === j.element ? C(e) : null;
	};
	if (typeof a == "function") {
		let e = n.createElement("template");
		e.content && e.content.ownerDocument && (n = e.content.ownerDocument);
	}
	let P, F = "", gt, _t = !1, vt = 0, yt = function() {
		if (vt > 0) throw E("A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the \"DOMPurify and Trusted Types\" section of the README.");
	}, bt = function(e) {
		yt(), vt++;
		try {
			return P.createHTML(e);
		} finally {
			vt--;
		}
	}, xt = function(e) {
		return P && Qt ? bt(e) : e;
	}, St = function(e) {
		yt(), vt++;
		try {
			return P.createScriptURL(e);
		} finally {
			vt--;
		}
	}, Ct = function() {
		return _t ||= (gt = lt(d, i), !0), gt;
	}, wt = n, Tt = wt.implementation, Et = wt.createNodeIterator, Dt = wt.createDocumentFragment, Ot = wt.getElementsByTagName, kt = r.importNode, I = ut();
	t.isSupported = typeof c == "function" && typeof x == "function" && Tt && Tt.createHTMLDocument !== void 0;
	let At = ze, jt = Be, Mt = Ve, Nt = Ge, Pt = Ke, Ft = Je, It = Ye, Lt = Ze, Rt = qe, L = null, zt = O({}, [
		...Oe,
		...ke,
		...Ae,
		...Me,
		...Pe
	]), R = null, Bt = O({}, [
		...Fe,
		...Ie,
		...Le,
		...Re
	]), z = null, Vt = null, Ht = null, B = Object.seal(g(null, {
		tagCheck: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: null
		},
		attributeCheck: {
			writable: !0,
			configurable: !1,
			enumerable: !0,
			value: null
		}
	})), Ut = !0, Wt = !0, Gt = !1, Kt = !0, V = !1, H = !0, U = !1, qt = !1, Jt = null, Yt = null, Xt = !1, W = !1, Zt = !1, Qt = !1, $t = !0, en = !1, tn = "user-content-", nn = !0, rn = !1, G = null, K = null, q = !1, J = null, an = O({}, /* @__PURE__ */ "annotation-xml.audio.colgroup.desc.foreignobject.head.iframe.math.mi.mn.mo.ms.mtext.noembed.noframes.noscript.plaintext.script.selectedcontent.style.svg.template.thead.title.video.xmp".split(".")), on = null, sn = O({}, [
		"audio",
		"video",
		"img",
		"source",
		"image",
		"track"
	]), cn = null, ln = O({}, [
		"alt",
		"class",
		"for",
		"id",
		"label",
		"name",
		"pattern",
		"placeholder",
		"role",
		"summary",
		"title",
		"value",
		"style",
		"xmlns"
	]), un = "http://www.w3.org/1998/Math/MathML", dn = "http://www.w3.org/2000/svg", Y = "http://www.w3.org/1999/xhtml", X = Y, fn = !1, pn = null, mn = O({}, [
		un,
		dn,
		Y
	], he), hn = m(O({}, [
		"mi",
		"mo",
		"mn",
		"ms",
		"mtext"
	])), gn = null, _n = m(O({}, ["annotation-xml"])), vn = null, yn = m(g(null)), bn = O({}, [
		"title",
		"style",
		"font",
		"a",
		"script"
	]), xn = null, Sn = ["application/xhtml+xml", "text/html"], Z = null, Cn = null, wn = null, Tn = n.createElement("form"), En = function(e) {
		return e instanceof RegExp || e instanceof Function;
	}, Dn = function() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		e && typeof e == "object" || (e = {}), e = Ce(e), xn = Sn.indexOf(e.PARSER_MEDIA_TYPE) === -1 ? "text/html" : e.PARSER_MEDIA_TYPE, Z = xn === "application/xhtml+xml" ? he : y, L = M(e, "ALLOWED_TAGS", zt, { transform: Z }), R = M(e, "ALLOWED_ATTR", Bt, { transform: Z }), pn = M(e, "ALLOWED_NAMESPACES", mn, { transform: he }), cn = M(e, "ADD_URI_SAFE_ATTR", ln, {
			transform: Z,
			base: ln
		}), on = M(e, "ADD_DATA_URI_TAGS", sn, {
			transform: Z,
			base: sn
		}), J = M(e, "FORBID_CONTENTS", an, { transform: Z }), Vt = M(e, "FORBID_TAGS", g(null), { transform: Z }), Ht = M(e, "FORBID_ATTR", g(null), { transform: Z }), q = S(e, "USE_PROFILES") ? e.USE_PROFILES && typeof e.USE_PROFILES == "object" ? Ce(e.USE_PROFILES) : e.USE_PROFILES : !1, Ut = e.ALLOW_ARIA_ATTR !== !1, Wt = e.ALLOW_DATA_ATTR !== !1, Gt = e.ALLOW_UNKNOWN_PROTOCOLS || !1, Kt = e.ALLOW_SELF_CLOSE_IN_ATTR !== !1, V = e.SAFE_FOR_TEMPLATES || !1, H = e.SAFE_FOR_XML !== !1, U = e.WHOLE_DOCUMENT || !1, W = e.RETURN_DOM || !1, Zt = e.RETURN_DOM_FRAGMENT || !1, Qt = e.RETURN_TRUSTED_TYPE || !1, Xt = e.FORCE_BODY || !1, $t = e.SANITIZE_DOM !== !1, en = e.SANITIZE_NAMED_PROPS || !1, nn = e.KEEP_CONTENT !== !1, rn = e.IN_PLACE || !1, Rt = De(e.ALLOWED_URI_REGEXP) ? e.ALLOWED_URI_REGEXP : qe, X = typeof e.NAMESPACE == "string" ? e.NAMESPACE : Y, gn = dt(e, "MATHML_TEXT_INTEGRATION_POINTS", hn), vn = dt(e, "HTML_INTEGRATION_POINTS", _n);
		let t = dt(e, "CUSTOM_ELEMENT_HANDLING", yn);
		if (z = g(null), S(t, "tagNameCheck") && En(t.tagNameCheck) && (z.tagNameCheck = t.tagNameCheck), S(t, "attributeNameCheck") && En(t.attributeNameCheck) && (z.attributeNameCheck = t.attributeNameCheck), S(t, "allowCustomizedBuiltInElements") && typeof t.allowCustomizedBuiltInElements == "boolean" && (z.allowCustomizedBuiltInElements = t.allowCustomizedBuiltInElements), h(z), V && (Wt = !1), Zt && (W = !0), q && ((S(e, "ALLOWED_TAGS") || S(e, "ALLOWED_ATTR")) && typeof console < "u" && typeof console.warn == "function" && console.warn("DOMPurify: USE_PROFILES overrides ALLOWED_TAGS and ALLOWED_ATTR. Do not use these options together."), L = O({}, Pe), R = g(null), q.html === !0 && (O(L, Oe), O(R, Fe)), q.svg === !0 && (O(L, ke), O(R, Ie), O(R, Re)), q.svgFilters === !0 && (O(L, Ae), O(R, Ie), O(R, Re)), q.mathMl === !0 && (O(L, Me), O(R, Le), O(R, Re))), B.tagCheck = null, B.attributeCheck = null, S(e, "ADD_TAGS") && (typeof e.ADD_TAGS == "function" ? B.tagCheck = e.ADD_TAGS : v(e.ADD_TAGS) && (L === zt && (L = we(L)), O(L, e.ADD_TAGS, Z))), S(e, "ADD_ATTR") && (typeof e.ADD_ATTR == "function" ? B.attributeCheck = e.ADD_ATTR : v(e.ADD_ATTR) && (R === Bt && (R = we(R)), O(R, e.ADD_ATTR, Z))), S(e, "ADD_FORBID_CONTENTS") && v(e.ADD_FORBID_CONTENTS) && (J === an && (J = we(J)), O(J, e.ADD_FORBID_CONTENTS, Z)), nn && (L["#text"] = !0), U && O(L, [
			"html",
			"head",
			"body"
		]), L.table && (L.tbody = !0, delete Vt.tbody), e.TRUSTED_TYPES_POLICY) {
			if (typeof e.TRUSTED_TYPES_POLICY.createHTML != "function") throw E("TRUSTED_TYPES_POLICY configuration option must provide a \"createHTML\" hook.");
			if (typeof e.TRUSTED_TYPES_POLICY.createScriptURL != "function") throw E("TRUSTED_TYPES_POLICY configuration option must provide a \"createScriptURL\" hook.");
			let t = P;
			P = e.TRUSTED_TYPES_POLICY;
			try {
				F = bt("");
			} catch (e) {
				throw P = t, e;
			}
		} else e.TRUSTED_TYPES_POLICY === null ? (P = void 0, F = "") : (P === void 0 && (P = Ct()), P && typeof F == "string" && (F = bt("")));
		Cn = m(e);
	}, On = O({}, [
		...ke,
		...Ae,
		...je
	]), kn = O({}, [...Me, ...Ne]), An = function(e, t, n) {
		return t === Y ? e === "svg" : t === un ? e === "svg" && (n === "annotation-xml" || gn[n]) : !!On[e];
	}, jn = function(e, t, n) {
		return t === Y ? e === "math" : t === dn ? e === "math" && vn[n] : !!kn[e];
	}, Mn = function(e, t, n) {
		return t === dn && !vn[n] || t === un && !gn[n] ? !1 : !kn[e] && (bn[e] || !On[e]);
	}, Nn = function(e) {
		let t = mt(e), n = y(N(e)), r = x(e), i = X, a = "template";
		return r && k(r) === j.element && (i = mt(r), a = y(N(r))), pn[t] ? t === dn ? An(n, i, a) : t === un ? jn(n, i, a) : t === Y ? Mn(n, i, a) : xn === "application/xhtml+xml" : !1;
	}, Q = function(e) {
		ae(t.removed, { element: e }), qn(e);
		try {
			x(e).removeChild(e);
		} catch {
			if (ee(e), !x(e)) throw E("a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place");
		}
	}, Pn = function(e, t, n) {
		try {
			ne(e, t);
		} catch {
			try {
				e.removeAttribute(n);
			} catch {}
		}
	}, Fn = function(e) {
		zn(e);
		let t = b(e);
		t && _(oe(t), (t) => {
			try {
				te(e, t);
			} catch {}
		}), k(e) === j.element && Ln(e, !1);
	}, In = function(e, n, r) {
		if (!r) try {
			r = n.getAttributeNode(e);
		} catch {
			r = null;
		}
		if (ae(t.removed, {
			attribute: r || null,
			from: n
		}), r) Pn(n, r, e);
		else try {
			n.removeAttribute(e);
		} catch {}
		if (e === "is") {
			if (W || Zt) try {
				Q(n);
			} catch {}
			else try {
				n.setAttribute(e, "");
			} catch {}
		}
	}, Ln = function(e, t) {
		let n = C(e);
		if (n) for (let r = n.length - 1; r >= 0; --r) {
			let i = n[r], a = i && i.name;
			typeof a == "string" && !(t && R[Z(a)]) && Pn(e, i, a);
		}
	}, Rn = function(e, t) {
		let n = arguments.length > 2 && arguments[2] !== void 0 && arguments[2], r = [e];
		for (; r.length > 0;) {
			let e = r.pop();
			if (t(e) === !1) continue;
			if (n && k(e) === j.element) {
				let t = xe(e);
				ar(t) && r.push(t);
			}
			let i = b(e);
			if (i) for (let e = i.length - 1; e >= 0; --e) r.push(i[e]);
		}
	}, zn = function(e) {
		Rn(e, (e) => {
			k(e) === j.element && Ln(e, !0);
		});
	}, Bn = function(e) {
		let t = [];
		return Rn(e, (e) => {
			t.push(e);
		}, !0), t;
	}, Vn = function(e, t) {
		let n = ce();
		_(Bn(e), (e) => {
			k(e) === j.element && le(n, e);
		}), _(t, (e) => {
			k(e) === j.element && !ue(n, e) && Ln(e, !0);
		});
	}, Hn = function(e, n) {
		let r = !1;
		return _(t.removed, (t) => {
			t.element && (r ||= t.element === e, zn(t.element));
		}), Vn(e, n), r;
	}, Un = function(e, t) {
		Fn(e), Hn(e, t);
	}, Wn = function(e, t) {
		let n = G, r = null, i = () => (r || (r = ce(), _(t, (e) => {
			le(r, e);
		})), r);
		for (let t = 0;; t++) {
			let r = Bn(e), a = [e], o = !1;
			if (_(r, (e) => {
				k(e) === j.documentFragment ? ae(a, e) : !o && !ue(n, e) && (o = ue(i(), e));
			}), !o) return;
			if (t >= 8) throw E("the tree kept changing during in-place sanitization; refusing to return it");
			_(a, (t, n) => {
				Gn(t, n > 0, e, i());
			});
		}
	}, Gn = function(e, t, n, r) {
		let i = Zn(e), a;
		for (; a = i.nextNode();) ue(r, a) && !ue(G, a) && (t && $(I.uponSanitizeShadowNode, a, null), xr(a, n));
	}, Kn = function(e) {
		if (!G) return;
		le(G, e);
		let t = pe(K, e);
		if (t !== void 0) {
			if (t >= 8) throw E("the tree kept changing during in-place sanitization; refusing to return it");
			me(K, e, t + 1);
		}
	}, qn = function(e) {
		G && (de(G, e), pe(K, e) === void 0 && me(K, e, 0));
	}, Jn = function(e, t) {
		return H ? e === "patchsrc" || e === "for" && t !== "label" && t !== "output" : !1;
	}, Yn = function(e) {
		H && Rn(e, (e) => {
			let t = k(e);
			if (t === j.processingInstruction || t === j.comment && T($e, e.data)) {
				try {
					ee(e);
				} catch {}
				return !1;
			}
			if (t === j.element) {
				let t = e, n = Z(N(e));
				try {
					t.hasAttribute && t.hasAttribute("patchsrc") && t.removeAttribute("patchsrc"), t.hasAttribute && t.hasAttribute("for") && Jn("for", n) && t.removeAttribute("for");
				} catch {}
			}
			return !0;
		});
	}, Xn = function(e) {
		let t = null, r = null;
		if (Xt) e = "<remove></remove>" + e;
		else {
			let t = ge(e, it);
			r = t && t[0];
		}
		xn === "application/xhtml+xml" && X === Y && (e = "<html xmlns=\"http://www.w3.org/1999/xhtml\"><head></head><body>" + e + "</body></html>");
		let i = P ? bt(e) : e;
		if (X === Y) try {
			t = new u().parseFromString(i, xn);
		} catch {}
		if (!t || !t.documentElement) {
			t = Tt.createDocument(X, "template", null);
			try {
				t.documentElement.innerHTML = fn ? F : i;
			} catch {}
		}
		let a = t.body || t.documentElement;
		return e && r && a.insertBefore(n.createTextNode(r), a.childNodes[0] || null), X === Y ? Ot.call(t, U ? "html" : "body")[0] : U ? t.documentElement : a;
	}, Zn = function(e) {
		let t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1], n = Se ? Se(e) : e.ownerDocument;
		return Et.call(n || e, e, (t ? 0 : l.SHOW_ELEMENT) | l.SHOW_COMMENT | l.SHOW_TEXT | l.SHOW_PROCESSING_INSTRUCTION | l.SHOW_CDATA_SECTION, null);
	}, Qn = function(e) {
		return e = _e(e, At, " "), e = _e(e, jt, " "), e = _e(e, Mt, " "), e;
	}, $n = function(e) {
		nr(e);
		let t = e.querySelectorAll?.call(e, "template");
		t && _(t, (e) => {
			ar(e.content) && $n(e.content);
		});
	}, er = O({}, [
		"caption",
		"colgroup",
		"col",
		"thead",
		"tbody",
		"tfoot",
		"tr",
		"td",
		"th",
		"style",
		"script",
		"template"
	]), tr = function(e) {
		if (xn === "application/xhtml+xml") return;
		let t = e.querySelectorAll?.call(e, "table,tbody,thead,tfoot,tr,colgroup");
		t && t.length !== 0 && _(t, (t) => {
			_(oe(b(t)), (n) => {
				let r = k(n);
				if (!(r === j.text ? T(Ue, n.data) : r === j.element && !er[y(N(n))])) return;
				let i = t;
				for (; i && y(N(i)) !== "table";) i = i === e ? null : x(i);
				let a = i && i !== e ? x(i) : null;
				if (a) try {
					a.insertBefore(n, i);
				} catch {}
			});
		});
	}, nr = function(e) {
		tr(e), e.normalize();
		let t = Zn(e, !0), n = null, r = t.nextNode();
		for (; r;) {
			let e = r.data;
			if (T(We, e) && (e = _e(e, We, ""), r.data = e), T(He, e) && (e = Qn(e), r.data = e), e && k(r) === j.text) {
				if (n) {
					let t = n.data;
					T(He, t[t.length - 1] + e[0]) && (n.data = Qn(t + e[0]));
				}
				n = r;
			}
			r = t.nextNode();
		}
	}, rr = function(e) {
		let t = D ? D(e) : null;
		return typeof t != "string" || Z(t) !== "form" ? !1 : typeof e.nodeName != "string" || typeof e.textContent != "string" || typeof e.removeChild != "function" || e.attributes !== C(e) || typeof e.removeAttribute != "function" || typeof e.removeAttributeNode != "function" || typeof e.getAttributeNode != "function" || typeof e.setAttribute != "function" || typeof e.namespaceURI != "string" || typeof e.insertBefore != "function" || typeof e.hasChildNodes != "function" || e.nodeType !== w(e) || e.childNodes !== b(e);
	}, ir = function(e) {
		if (!w || typeof e != "object" || !e) return null;
		try {
			let t = w(e);
			return typeof t == "number" ? t : null;
		} catch {
			return null;
		}
	}, ar = function(e) {
		return ir(e) === j.documentFragment;
	}, or = function(e) {
		return ir(e) !== null;
	};
	function $(e, n, r) {
		e.length !== 0 && _(e, (e) => {
			e.call(t, n, r, Cn);
		});
	}
	let sr = function(e, t) {
		let n = !!st[t], r = !!at[t];
		return !n && !r && !ot[t] || mt(e) !== Y ? !1 : n ? e.hasChildNodes() : or(e.firstElementChild) ? !0 : r && typeof e.textContent == "string" && T(Qe, e.textContent);
	}, cr = function(e, t, n) {
		return !!(H && n === j.element && e.hasChildNodes() && !or(e.firstElementChild) && T(Qe, e.textContent) && T(Qe, e.innerHTML) || H && n === j.element && sr(e, t) || n === j.processingInstruction || H && n === j.comment && T(et, e.data));
	}, lr = function(e, t) {
		return e instanceof RegExp ? T(e, t) : e instanceof Function && !!e(t, ...[...arguments].slice(2));
	}, ur = function(e, t, n) {
		if (!Vt[t] && gr(t) && lr(z.tagNameCheck, t)) return !1;
		if (nn && !J[t] && !J[y(t)]) {
			let t = x(e), r = b(e);
			if (r && t) {
				let i = r.length;
				for (let a = i - 1; a >= 0; --a) {
					let i = e === n ? p(r[a], !0) : r[a];
					t.insertBefore(i, be(e));
				}
			}
		}
		return Q(e), !0;
	}, dr = function(e, t, n, r) {
		return e.length === 0 ? t : t === n || t === r ? we(t) : t;
	}, fr = function(e, t) {
		return e === t || x(e) !== null ? !1 : (rn && zn(e), qn(e), !0);
	}, pr = function(e, n) {
		if (Kn(e), $(I.beforeSanitizeElements, e, null), fr(e, n)) return !0;
		if (rr(e)) return Q(e), !0;
		let r = Z(N(e)), i = k(e);
		if (L = dr(I.uponSanitizeElement, L, zt, Jt), $(I.uponSanitizeElement, e, {
			tagName: r,
			allowedTags: L
		}), fr(e, n)) return !0;
		if (cr(e, r, i)) return Q(e), !0;
		if ((Vt[r] || !(B.tagCheck instanceof Function && B.tagCheck(r)) && !L[r]) && ur(e, r, n)) return !0;
		if (i === j.element && !Nn(e) || (r === "noscript" || r === "noembed" || r === "noframes") && T(tt, e.innerHTML)) return Q(e), !0;
		if (V && i === j.text) {
			let n = e.textContent, r = Qn(n);
			n !== r && (ae(t.removed, { element: e.cloneNode() }), e.textContent = r);
		}
		return $(I.afterSanitizeElements, e, null), fr(e, n);
	}, mr = function(e, t, r) {
		if (Ht[t] || Jn(t, e) || $t && (t === "id" || t === "name") && (r in n || r in Tn)) return !1;
		let i = R[t] || B.attributeCheck instanceof Function && B.attributeCheck(t, e);
		if (Wt && T(Nt, t) || Ut && T(Pt, t)) return !0;
		if (!i) return gr(e) && lr(z.tagNameCheck, e) && lr(z.attributeNameCheck, t, e) || t === "is" && z.allowCustomizedBuiltInElements && lr(z.tagNameCheck, r);
		if (cn[t]) return !0;
		let a = _e(r, It, "");
		return T(Rt, a) || (t === "src" || t === "xlink:href" || t === "href") && e !== "script" && ve(r, "data:") === 0 && on[e] || Gt && !T(Ft, a) ? !0 : !r;
	}, hr = O({}, [
		"annotation-xml",
		"color-profile",
		"font-face",
		"font-face-format",
		"font-face-name",
		"font-face-src",
		"font-face-uri",
		"missing-glyph"
	]), gr = function(e) {
		return !hr[y(e)] && T(Lt, e);
	}, _r = function(e, t, n, r) {
		if (P && typeof d == "object" && typeof d.getAttributeType == "function" && !n) switch (d.getAttributeType(e, t)) {
			case "TrustedHTML": return bt(r);
			case "TrustedScriptURL": return St(r);
		}
		return r;
	}, vr = function(e, t, n, r) {
		try {
			return n ? e.setAttributeNS(n, t, r) : e.setAttribute(t, r), !rr(e) || (Q(e), !1);
		} catch {
			return In(t, e), !1;
		}
	}, yr = function(e, t) {
		return H && T(rt, t) ? !0 : y(e) === "attributename" && ve(t, "href") !== -1;
	}, br = function(e, n) {
		if ($(I.beforeSanitizeAttributes, e, null), fr(e, n)) return;
		let r = ht(e);
		if (!r || rr(e)) return;
		R = dr(I.uponSanitizeAttribute, R, Bt, Yt);
		let i = {
			attrName: "",
			attrValue: "",
			keepAttr: !0,
			allowedAttributes: R,
			forceKeepAttr: void 0
		}, a = r.length, o = Z(N(e));
		for (; a--;) {
			let n = r[a];
			if (!n) continue;
			let s = n.name, c = n.namespaceURI, l = n.value, u = Z(s), d = l, f = s === "value" ? d : ye(d), p = !1;
			i.attrName = u, i.attrValue = f, i.keepAttr = !0, i.forceKeepAttr = void 0, $(I.uponSanitizeAttribute, e, i), f = i.attrValue, en && (u === "id" || u === "name") && ve(f, tn) !== 0 && (In(s, e, n), f = tn + f, p = !0), yr(s, f) ? In(s, e, n) : i.forceKeepAttr || (i.keepAttr ? !Kt && T(nt, f) ? In(s, e, n) : (V && (f = Qn(f)), mr(o, u, f) ? (f = _r(o, u, c, f), f !== d && vr(e, s, c, f) && p && ie(t.removed)) : In(s, e, n)) : In(s, e, n));
		}
		$(I.afterSanitizeAttributes, e, null), fr(e, n);
	}, xr = function(e, t) {
		pr(e, t), br(e, t), ar(e.content) && Sr(e.content);
	}, Sr = function(e) {
		let t = null, n = Zn(e);
		for ($(I.beforeSanitizeShadowDOM, e, null); t = n.nextNode();) if ($(I.uponSanitizeShadowNode, t, null), xr(t, e), k(t) === j.element) {
			let e = xe(t);
			ar(e) && (Cr(e), Sr(e));
		}
		V && nr(e), $(I.afterSanitizeShadowDOM, e, null);
	}, Cr = function(e) {
		let t = [{
			node: e,
			shadow: null
		}];
		for (; t.length > 0;) {
			let e = t.pop();
			if (e.shadow) {
				Sr(e.shadow);
				continue;
			}
			let n = e.node, r = k(n) === j.element, i = b(n);
			if (i) for (let e = i.length - 1; e >= 0; --e) t.push({
				node: i[e],
				shadow: null
			});
			if (r) {
				let e = D ? D(n) : null;
				if (typeof e == "string" && Z(e) === "template") {
					let e = n.content;
					ar(e) && t.push({
						node: e,
						shadow: null
					});
				}
			}
			if (r) {
				let e = xe(n);
				ar(e) && t.push({
					node: null,
					shadow: e
				}, {
					node: e,
					shadow: null
				});
			}
		}
	}, wr = function(e) {
		let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, i = null, a = null, o = null, s = null;
		if (fn = !e, fn && (e = "<!-->"), typeof e != "string" && !or(e) && (e = Te(e), typeof e != "string")) throw E("dirty is not a string, aborting");
		if (!t.isSupported) return e;
		qt ? (L = Jt, R = Yt) : Dn(n), wn = Cn, t.removed = [];
		let c = rn && typeof e != "string" && or(e), l = [], u = G, d = K;
		if (c) {
			Yn(e), l = Bn(e);
			let t = N(e);
			if (typeof t == "string") {
				let n = Z(t);
				if (!L[n] || Vt[n]) throw Un(e, l), E("root node is forbidden and cannot be sanitized in-place");
			}
			if (rr(e)) throw Un(e, l), E("root node is clobbered and cannot be sanitized in-place");
			G = ce(), K = fe();
		} else if (or(e)) i = Xn("<!---->"), a = i.ownerDocument.importNode(e, !0), a.nodeType === j.element && a.nodeName === "BODY" || a.nodeName === "HTML" ? i = a : i.appendChild(a), Cr(i);
		else {
			if (!W && !V && !U && e.indexOf("<") === -1) return xt(e);
			if (i = Xn(e), !i) return W ? null : Qt ? F : "";
		}
		i && Xt && Q(i.firstChild);
		let f = c ? e : i;
		try {
			c && Cr(e);
			let t = Zn(f);
			for (; o = t.nextNode();) xr(o, f);
			c && Wn(e, l);
		} catch (t) {
			throw c && Un(e, l), t;
		} finally {
			G = u, K = d;
		}
		if (c) {
			if (Hn(e, l)) throw E("a node selected for removal could not be safely returned; refusing to sanitize in place");
			return V && $n(e), e;
		}
		if (W) {
			if (V && $n(i), Zt) for (s = Dt.call(i.ownerDocument); i.firstChild;) s.appendChild(i.firstChild);
			else s = i;
			return (R.shadowroot || R.shadowrootmode) && (s = kt.call(r, s, !0)), s;
		}
		V && nr(i);
		let p = U ? i.outerHTML : i.innerHTML;
		return U && L["!doctype"] && i.ownerDocument && i.ownerDocument.doctype && i.ownerDocument.doctype.name && T(Xe, i.ownerDocument.doctype.name) && (p = "<!DOCTYPE " + i.ownerDocument.doctype.name + ">\n" + p), xt(p);
	};
	return t.sanitize = function(e) {
		let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, r = wn, i = L, a = R, o = t.removed;
		wn = null;
		try {
			return wr(e, n);
		} finally {
			wn = r, r && (qt || Dn(r), L = i, R = a, t.removed = o);
		}
	}, t.setConfig = function() {
		let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		Dn(e), qt = !0, Jt = L, Yt = R;
	}, t.clearConfig = function() {
		Cn = null, qt = !1, Jt = null, Yt = null, P = gt, F = "";
	}, t.isValidAttribute = function(e, t, n) {
		Cn || Dn({});
		let r = Z(e), i = Z(t);
		return typeof n == "string" && (yr(t, n) || !Kt && T(nt, n)) ? !1 : mr(r, i, n);
	}, t.addHook = function(e, t) {
		typeof t == "function" && S(I, e) && ae(I[e], t);
	}, t.removeHook = function(e, t) {
		if (S(I, e)) {
			if (t !== void 0) {
				let n = re(I[e], t);
				return n === -1 ? void 0 : se(I[e], n, 1)[0];
			}
			return ie(I[e]);
		}
	}, t.removeHooks = function(e) {
		S(I, e) && (I[e] = []);
	}, t.removeAllHooks = function() {
		I = ut();
	}, t;
}
var N = ft();
export { N as default };
